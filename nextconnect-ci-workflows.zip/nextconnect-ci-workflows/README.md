# nextconnect-ci-workflows
The project repo to hold the generic CI workflows for nextconnect projects
