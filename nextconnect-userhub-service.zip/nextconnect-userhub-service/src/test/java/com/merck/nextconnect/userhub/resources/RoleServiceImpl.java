package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements UserDetailsService {

  private final UserRepository userRepository;

  static final String USER_IS_DISABLED = "User is disabled";

  @Autowired
  public RoleServiceImpl(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

    List<GrantedAuthority> list = new ArrayList<GrantedAuthority>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(2219);
    jwtUser.setRoleId(154);
    jwtUser.setRole("LW-Service Admin");
    jwtUser.setOrgId(5);
    jwtUser.setUsername("qa1.lbwter@yandex.com");
    jwtUser.setSystemDefinedRole(true);
    return new AuthenticatedUser(jwtUser, "Test@123", list);
  }
}
