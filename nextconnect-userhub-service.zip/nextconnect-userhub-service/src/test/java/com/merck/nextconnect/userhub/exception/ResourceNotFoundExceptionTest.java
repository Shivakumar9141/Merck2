package com.merck.nextconnect.userhub.exception;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ResourceNotFoundExceptionTest {

  @Test
  public void testConstructorWithMessage() {
    String errorMessage = "Resource not found";
    ResourceNotFoundException exception = new ResourceNotFoundException(errorMessage);

    assertNotNull(exception);
    assertEquals(errorMessage, exception.getMessage());
  }

  @Test
  public void testConstructorWithCustomErrorCode() {
    CustomErrorCodes errorCode = CustomErrorCodes.ORG_NOT_FOUND;
    ResourceNotFoundException exception = new ResourceNotFoundException(errorCode);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCodeAndParams() {
    CustomErrorCodes errorCode = CustomErrorCodes.ORG_NOT_FOUND;
    List<String> params = Arrays.asList("User", "123");
    ResourceNotFoundException exception = new ResourceNotFoundException(errorCode, params);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }
}
