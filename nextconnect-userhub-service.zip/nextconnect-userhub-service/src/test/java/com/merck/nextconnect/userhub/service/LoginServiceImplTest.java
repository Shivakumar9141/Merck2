package com.merck.nextconnect.userhub.service;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class LoginServiceImplTest {

  @InjectMocks private LoginServiceImpl loginServiceImpl;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetAuthNRedirectUrl() {
    String idpAppURL =
        "https://login.microsoftonline.com/db76fb59-a377-4120-bc54-59dead7d39c9/saml2?whr=merckgroup.com";
    String relayState = "http://dev-nextconnect.sial.com";
    String assertionConsumerServiceUrl =
        "https://dev-nextconnect.sial.com/nextconnect/saml/sso/reply.jsp";
    String issuerId = "https://dev-nextconnect.sial.com/nextconnect/saml/sp/metadata.jsp";
    assertNotEquals(
        null,
        loginServiceImpl.getAuthNRedirectUrl(
            idpAppURL, relayState, assertionConsumerServiceUrl, issuerId));
  }
}
