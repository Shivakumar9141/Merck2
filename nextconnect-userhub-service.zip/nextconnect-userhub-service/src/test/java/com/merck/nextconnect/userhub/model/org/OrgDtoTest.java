package com.merck.nextconnect.userhub.model.org;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class OrgDtoTest {

  @Test
  public void testNoArgsConstructor() {
    OrgDto orgDto = new OrgDto();
    assertNotNull(orgDto);
  }

  @Test
  public void testAllArgsConstructor() {
    int orgId = 1;
    String name = "Test Org";
    Boolean status = true;
    String description = "Test Description";
    String createdBy = "Test User";
    String createdOn = "2023-01-01T12:00:00+00:00";
    String type = "Test Type";
    Map<String, Object> customProperties = new HashMap<>();
    Long historicalDataSubscription = 123L;
    List<PartnerTypeEntity> partnerTypes = new ArrayList<>();
    boolean isAutoCreated = true;
    boolean deleted = false;
    boolean enableDeleteIcon = true;
    boolean enableToggle = true;

    OrgDto orgDto =
        new OrgDto(
            orgId,
            name,
            status,
            description,
            createdBy,
            createdOn,
            type,
            customProperties,
            historicalDataSubscription,
            partnerTypes,
            isAutoCreated,
            deleted,
            enableDeleteIcon,
            enableToggle);

    assertEquals(orgId, orgDto.getOrgId());
    assertEquals(name, orgDto.getName());
    assertEquals(status, orgDto.getStatus());
    assertEquals(description, orgDto.getDescription());
    assertEquals(createdBy, orgDto.getCreatedBy());
    assertEquals(createdOn, orgDto.getCreatedOn());
    assertEquals(type, orgDto.getType());
    assertEquals(customProperties, orgDto.getCustomProperties());
    assertEquals(historicalDataSubscription, orgDto.getHistoricalDataSubscription());
    assertEquals(partnerTypes, orgDto.getPartnerTypes());
    assertTrue(orgDto.isAutoCreated());
    assertFalse(orgDto.isDeleted());
    assertTrue(orgDto.isEnableDeleteIcon());
    assertTrue(orgDto.isEnableToggle());
  }

  @Test
  public void testConstructorWithBasicFields() {
    int orgId = 1;
    String name = "Test Org";
    String type = "Test Type";
    String description = "Test Description";
    Boolean status = true;

    OrgDto orgDto = new OrgDto(orgId, name, type, description, status);

    assertEquals(orgId, orgDto.getOrgId());
    assertEquals(name, orgDto.getName());
    assertEquals(type, orgDto.getType());
    assertEquals(description, orgDto.getDescription());
    assertEquals(status, orgDto.getStatus());
  }

  @Test
  public void testConstructorWithDeletedField() {
    int orgId = 1;
    String name = "Test Org";
    String type = "Test Type";
    String description = "Test Description";
    Boolean status = true;
    Boolean deleted = true;

    OrgDto orgDto = new OrgDto(orgId, name, type, description, status, deleted);

    assertEquals(orgId, orgDto.getOrgId());
    assertEquals(name, orgDto.getName());
    assertEquals(type, orgDto.getType());
    assertEquals(description, orgDto.getDescription());
    assertEquals(status, orgDto.getStatus());
    assertTrue(orgDto.isDeleted());
  }

  @Test
  public void testConstructorWithCreatedOnDate() {
    int orgId = 1;
    String name = "Test Org";
    String description = "Test Description";
    String createdBy = "Test User";
    Date createdOn = new Date();
    Boolean status = true;
    String type = "Test Type";

    OrgDto orgDto = new OrgDto(orgId, name, description, createdBy, createdOn, status, type);

    assertEquals(orgId, orgDto.getOrgId());
    assertEquals(name, orgDto.getName());
    assertEquals(description, orgDto.getDescription());
    assertEquals(createdBy, orgDto.getCreatedBy());
    assertNotNull(orgDto.getCreatedOn());
    assertEquals(status, orgDto.getStatus());
    assertEquals(type, orgDto.getType());
  }

  @Test
  public void testConstructorWithNullCreatedOnDate() {
    int orgId = 1;
    String name = "Test Org";
    String description = "Test Description";
    String createdBy = "Test User";
    Date createdOn = null;
    Boolean status = true;
    String type = "Test Type";

    OrgDto orgDto = new OrgDto(orgId, name, description, createdBy, createdOn, status, type);

    assertEquals(orgId, orgDto.getOrgId());
    assertEquals(name, orgDto.getName());
    assertEquals(description, orgDto.getDescription());
    assertEquals(createdBy, orgDto.getCreatedBy());
    assertNull(orgDto.getCreatedOn());
    assertEquals(status, orgDto.getStatus());
    assertEquals(type, orgDto.getType());
  }

  @Test
  public void testConstructorWithHistoricalData() {
    int orgId = 1;
    String name = "Test Org";
    String description = "Test Description";
    String createdBy = "Test User";
    Date createdOn = new Date();
    Boolean status = true;
    String type = "Test Type";
    Long historicalDataSubscription = 123L;
    boolean isAutoCreated = true;

    OrgDto orgDto =
        new OrgDto(
            orgId,
            name,
            description,
            createdBy,
            createdOn,
            status,
            type,
            historicalDataSubscription,
            isAutoCreated);

    assertEquals(orgId, orgDto.getOrgId());
    assertEquals(name, orgDto.getName());
    assertEquals(description, orgDto.getDescription());
    assertEquals(createdBy, orgDto.getCreatedBy());
    assertNotNull(orgDto.getCreatedOn());
    assertEquals(status, orgDto.getStatus());
    assertEquals(type, orgDto.getType());
    assertEquals(historicalDataSubscription, orgDto.getHistoricalDataSubscription());
    assertTrue(orgDto.isAutoCreated());
  }

  @Test
  public void testBuilderPattern() {
    OrgDto orgDto =
        OrgDto.builder()
            .orgId(1)
            .name("Test Org")
            .status(true)
            .description("Test Description")
            .createdBy("Test User")
            .createdOn("2023-01-01T12:00:00+00:00")
            .type("Test Type")
            .build();

    assertEquals(1, orgDto.getOrgId());
    assertEquals("Test Org", orgDto.getName());
    assertEquals(true, orgDto.getStatus());
    assertEquals("Test Description", orgDto.getDescription());
    assertEquals("Test User", orgDto.getCreatedBy());
    assertEquals("2023-01-01T12:00:00+00:00", orgDto.getCreatedOn());
    assertEquals("Test Type", orgDto.getType());
  }
}
