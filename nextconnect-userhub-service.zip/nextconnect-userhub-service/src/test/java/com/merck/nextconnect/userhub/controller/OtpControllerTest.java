package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.resources.IUserSubscription;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import com.merck.nextconnect.utils.otp.resource.IOtpService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class OtpControllerTest {

  @Mock private IOtpService iOtpService;

  @InjectMocks OtpController otpController;
  @Mock private IUserSubscription userSubscriptionService;

  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @Before
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties to prevent NumberFormatException and DataValidationException
    when(authUser.getId()).thenReturn("123");

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testSendOTP() throws Exception {

    String userId = "123";
    Pair<String, String> userContactDetails = Pair.of("phoneNumber", "email");
    when(userSubscriptionService.getUserPhoneAndEmail(Long.parseLong(userId)))
        .thenReturn(userContactDetails);
    ResponseEntity<?> response = otpController.sendOTP(true, true);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertTrue((Boolean) response.getBody());
  }

  @Test(expected = DataValidationException.class)
  public void testSendOTPWhenException() throws Exception {

    when(userSubscriptionService.getUserPhoneAndEmail(anyLong()))
        .thenThrow(
            new DataValidationException("Please configure mobile number with this user's profile"));
    otpController.sendOTP(true, true);
  }

  @Test(expected = DataValidationException.class)
  public void testSendOTPFailure() throws Exception {
    // Call sendOTP method with both options false
    otpController.sendOTP(false, false);
  }

  @Test
  public void testValidateOtp() throws Exception {
    String userId = "123";
    Pair<String, String> userContactDetails = Pair.of("1234567890", "testemail@gmail.com");
    when(userSubscriptionService.getUserPhoneAndEmail(Long.parseLong(authUser.getId())))
        .thenReturn(userContactDetails);
    when(iOtpService.validateOTP(
            "123456", userContactDetails.getFirst(), userContactDetails.getSecond(), userId))
        .thenReturn(true);

    ResponseEntity<?> response = otpController.validateOtp("123456");
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertTrue((Boolean) response.getBody());
  }

  @Test(expected = DataValidationException.class)
  public void testValidateOTPWhenException() throws Exception {

    when(userSubscriptionService.getUserPhoneAndEmail(anyLong()))
        .thenThrow(
            new DataValidationException("Please configure mobile number with this user's profile"));
    otpController.validateOtp("test");
  }

  @Test(expected = DataValidationException.class)
  public void testValidateOTPFailure() throws Exception {
    // Call sendOTP method with both options false
    otpController.validateOtp("");
  }
}
