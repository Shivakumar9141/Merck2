package com.merck.nextconnect.userhub.repository.hazelcast;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class SelfRegistrationStoreTest {

  @Mock private HazelcastInstance hazelcastInstance;
  @Mock private IMap<String, SelfRegistrationDTO> selfRegistrationMap;

  @InjectMocks private SelfRegistrationStore selfRegistrationStore;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    when(hazelcastInstance.<String, SelfRegistrationDTO>getMap(
            SelfRegistrationStore.SELF_REGISTRATION_MAP))
        .thenReturn(selfRegistrationMap);
  }

  @Test
  public void testAddSelfRegistrationMap() {
    // Arrange
    String sessionId = "test-session-id";
    SelfRegistrationDTO selfRegistrationDTO = new SelfRegistrationDTO();

    // Act
    selfRegistrationStore.addSelfRegistrationMap(sessionId, selfRegistrationDTO);

    // Assert
    verify(selfRegistrationMap).put(sessionId, selfRegistrationDTO);
  }

  @Test
  public void testGetSelfRegistrationMap() {
    // Arrange
    String sessionId = "test-session-id";
    SelfRegistrationDTO expectedDTO = new SelfRegistrationDTO();
    when(selfRegistrationMap.get(sessionId)).thenReturn(expectedDTO);

    // Act
    SelfRegistrationDTO result = selfRegistrationStore.getSelfRegistrationMap(sessionId);

    // Assert
    assertEquals(expectedDTO, result);
    verify(selfRegistrationMap).get(sessionId);
  }

  @Test
  public void testRemoveSelfRegistrationMap() {
    // Arrange
    String sessionId = "test-session-id";

    // Act
    selfRegistrationStore.removeSelfRegistrationMap(sessionId);

    // Assert
    verify(selfRegistrationMap).remove(sessionId);
  }
}
