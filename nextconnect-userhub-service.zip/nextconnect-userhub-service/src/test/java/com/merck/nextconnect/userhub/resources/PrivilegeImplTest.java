package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import com.merck.nextconnect.userhub.repository.jpa.EntityRepository;
import com.merck.nextconnect.userhub.repository.jpa.PrivilegeRepository;
import com.merck.nextconnect.userhub.resources.impl.PrivilegeImpl;
import com.merck.nextconnect.userhub.resources.impl.UserRolePrivileges;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class PrivilegeImplTest {

  @InjectMocks private PrivilegeImpl privilegeImpl;

  @Mock private PrivilegeRepository privilegeRepo;
  private Authentication authentication;
  private Privilege privilege1;
  @Mock private UserRolePrivileges userRolePrivileges;

  private Privilege privilege2;

  private List<Privilege> privileges = new ArrayList<>();

  @Mock private Privilege privilege;

  @Mock private List<Privilege> privilegeList;

  @Mock private EntityRepository entityRepo;

  @BeforeEach
  public void setup() {
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    //  mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();

    privilegeRepo = mock(PrivilegeRepository.class);
    ReflectionTestUtils.setField(privilegeImpl, "privilegeRepo", privilegeRepo);
    ReflectionTestUtils.setField(privilegeImpl, "userRolePrivileges", userRolePrivileges);

    privilege1 = new Privilege();
    privilege1.setprivilegeId(1);
    privilege1.setOperation("view_user");
    privilege1.setResourceType("entity");

    privilege2 = new Privilege();
    privilege2.setprivilegeId(2);
    privilege2.setOperation("delete_user");
    privilege2.setResourceType("entity");

    privileges.add(privilege1);
    privileges.add(privilege2);
  }

  @Test
  public void testAddPrivilegeSuccess() {

    PrivilegeInfo privilegeInfo = new PrivilegeInfo();
    when(privilegeRepo.save(any(Privilege.class))).thenReturn(privilege1);
    assertEquals(1, privilegeImpl.add(privilegeInfo));
  }

  @Test
  public void testAddPrivilegeFailure() {
    PrivilegeInfo privilegeInfo = new PrivilegeInfo();
    privilege = new Privilege();
    when(privilegeRepo.save(any(Privilege.class))).thenReturn(privilege);
    assertEquals(0, privilegeImpl.add(privilegeInfo));
  }

  @Test
  public void testGetPrivileges() {
    when(privilegeRepo.findAll()).thenReturn(privileges);
    assertEquals(2, privilegeImpl.getAll(null).size());
    assertEquals("view_user", privilegeImpl.getAll(null).get(0).getOperation());
  }

  @Test
  public void testGetPrivilegesFailure() {
    privilegeList = new ArrayList<>();
    when(privilegeRepo.findAll()).thenReturn(privilegeList);
    assertEquals(0, privilegeImpl.getAll(null).size());
  }

  @Test
  public void testGetPrivilegesIfFilterByIsNotNull() {
    when(privilegeRepo.getByFilter("test")).thenReturn(privileges);
    assertEquals(2, privilegeImpl.getAll("test").size());
  }

  @Test
  public void testDelete() {
    long privilegeId = 12345L;

    doNothing().when(userRolePrivileges).deletePrivilege(privilegeId);
    doNothing().when(privilegeRepo).deleteById(privilegeId);
    privilegeImpl.delete(privilegeId);
    verify(privilegeRepo).deleteById(privilegeId);
  }

  @Test
  public void testGetAllEntities() {
    List<Entities> entities = Arrays.asList(new Entities());

    when(entityRepo.findAll()).thenReturn(entities);
    List<Entities> result = privilegeImpl.getAllEntities();
    assertEquals(entities, result);
  }
}
