package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class BusinessDomainRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterjdbcTemplate;

  @InjectMocks private BusinessDomainRepositoryJdbc businessDomainRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testObtainAllBusinessDomain_Success() {
    // Arrange
    List<Map<String, Object>> mockResult = new ArrayList<>();
    Map<String, Object> domain1 = new HashMap<>();
    domain1.put("domainId", 1);
    domain1.put("domainName", "Test Domain 1");

    Map<String, Object> domain2 = new HashMap<>();
    domain2.put("domainId", 2);
    domain2.put("domainName", "Test Domain 2");

    mockResult.add(domain1);
    mockResult.add(domain2);

    when(namedParameterjdbcTemplate.queryForList(anyString(), any(Map.class)))
        .thenReturn(mockResult);

    // Act
    List<BusinessDomainDTO> result = businessDomainRepositoryJdbc.obtainAllBusinessDomain();

    // Assert
    assertEquals(2, result.size());
    assertEquals(1, result.get(0).getDomainId());
    assertEquals("Test Domain 1", result.get(0).getDomainName());
    assertEquals(2, result.get(1).getDomainId());
    assertEquals("Test Domain 2", result.get(1).getDomainName());
  }

  @Test
  public void testObtainAllBusinessDomain_Exception() {
    // Arrange
    when(namedParameterjdbcTemplate.queryForList(anyString(), any(Map.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    List<BusinessDomainDTO> result = businessDomainRepositoryJdbc.obtainAllBusinessDomain();

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testFetchDomainForUser_Success() {
    // Arrange
    Long userId = 123L;
    BusinessDomainDTO expectedDomain = new BusinessDomainDTO();
    expectedDomain.setDomainId(1);
    expectedDomain.setDomainName("Test Domain");

    when(namedParameterjdbcTemplate.queryForObject(
            anyString(), any(Map.class), any(BeanPropertyRowMapper.class)))
        .thenReturn(expectedDomain);

    // Act
    BusinessDomainDTO result = businessDomainRepositoryJdbc.fetchDomainForUser(userId);

    // Assert
    assertEquals(expectedDomain, result);
  }

  @Test
  public void testFetchDomainForUser_Exception() {
    // Arrange
    Long userId = 123L;
    when(namedParameterjdbcTemplate.queryForObject(
            anyString(), any(Map.class), any(BeanPropertyRowMapper.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    BusinessDomainDTO result = businessDomainRepositoryJdbc.fetchDomainForUser(userId);

    // Assert
    assertNull(result);
  }
}
