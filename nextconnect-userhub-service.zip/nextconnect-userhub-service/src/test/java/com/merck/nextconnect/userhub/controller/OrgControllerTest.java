package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.OrganizationType;
import com.merck.nextconnect.userhub.model.OrgFilter;
import com.merck.nextconnect.userhub.model.OrgPartnerBrandPartnerTypeDTO;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.resources.IOrganization;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class OrgControllerTest {

  @Mock private IOrganization organization;

  @InjectMocks OrgController orgController;

  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;
  @Mock private UserOrgPrivileges userOrgPrivileges;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetOrgsSuccess() throws Exception {

    List<OrgDto> expectedOrgs = new ArrayList<>();
    expectedOrgs.add(new OrgDto(1, "test", "test", "test", true));
    when(organization.getAll(anyString(), anyString(), anyString(), anyString()))
        .thenReturn(expectedOrgs);
    ResponseEntity<List<OrgDto>> response = orgController.getOrgs("test", "test", "test");
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(expectedOrgs, response.getBody());
  }

  @Test
  public void testUserDomain() throws Exception {

    List<UserDomain> expectedDomains = new ArrayList<>();
    UserDomain userDomain = new UserDomain();
    userDomain.setDomainId(1);
    userDomain.setDomainName("test");
    expectedDomains.add(userDomain);
    when(organization.getDomains(anyInt())).thenReturn(expectedDomains);
    ResponseEntity<List<UserDomain>> response = orgController.userDomain(1);
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(expectedDomains, response.getBody());
    // verify(AuditLogger.getInstance(), times(1)).auditLog(anyString());
  }

  @Test
  public void testCreateOrg() throws Exception {

    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setName("test");
    orgInfo.setType("test");
    orgInfo.setStatus(true);
    int orgId = 123;
    when(organization.create(orgInfo)).thenReturn(orgId);
    ResponseEntity<?> response = orgController.createOrg(orgInfo);
    assertNotNull(response);
    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    HttpHeaders headers = response.getHeaders();
    assertNotNull(headers);
    //    assertTrue(headers.containsKey("Location"));
    assertEquals("/orgs/" + orgId, headers.getLocation().toString());
    // verify(AuditLogger.getInstance(), times(1)).auditLog(anyString());
  }

  @Test
  public void testUpdateOrg() throws Exception {
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setName("test");
    orgInfo.setType("test");
    orgInfo.setStatus(true);
    int orgId = 123;
    doNothing().when(organization).update(orgInfo, orgId);
    ResponseEntity<?> response = orgController.updateOrg(orgId, orgInfo);
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(orgId));
    // verify(AuditLogger.getInstance(), times(1)).auditLog(AuditLoggerUtil.formatLog(Constants.ORG,
    // Constants.PUT, properties));
  }

  @Test
  public void testGetFacets() throws Exception {

    List<String> orgFacets = new ArrayList<>();
    orgFacets.add("Facet1");
    orgFacets.add("Facet2");
    orgFacets.add("Facet3");

    String operation = "exampleOperation";
    when(organization.getFacets(operation)).thenReturn(orgFacets);
    ResponseEntity<List<String>> response = orgController.getFacets(operation);
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(orgFacets, response.getBody());
  }

  @Test
  public void testDeleteOrg() throws Exception {

    int orgId = 123;
    ResponseEntity<?> response = orgController.deleteOrg(orgId);
    verify(organization, times(1)).delete(orgId);
    assertNotNull(response);
    assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void testGetOrganizationType() throws Exception {

    List<OrganizationType> orgTypes = new ArrayList<>();
    OrganizationType organizationType = new OrganizationType();
    organizationType.setId(1);
    organizationType.setOrgTypeName("test");
    orgTypes.add(organizationType);

    when(organization.getOrganizationType()).thenReturn(orgTypes);
    ResponseEntity<List<OrganizationType>> response = orgController.getOrganizationType();
    verify(organization, times(1)).getOrganizationType();
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(orgTypes.size(), response.getBody().size());
    assertEquals(orgTypes, response.getBody());
  }

  @Test
  public void testFilter() throws Exception {

    OrgFilter mockFilter = new OrgFilter();
    when(organization.getFilter()).thenReturn(mockFilter);

    ResponseEntity<OrgFilter> response = orgController.filter();
    verify(organization, times(1)).getFilter();
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
  }

  @Test
  public void testGetOrgsWithParams() throws Exception {

    String sortBy = "name";
    String orderBy = "asc";
    List<String> filterBy = new ArrayList<>();
    String searchBy = "example";
    Integer page = 1;
    Integer pageLimit = 10;

    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    Page<Organization> mockOrgList = mock(Page.class);
    when(organization.getAllOrgs(fetchCriteria)).thenReturn(mockOrgList);
    when(mockOrgList.getTotalPages()).thenReturn(1);
    when(mockOrgList.getTotalElements()).thenReturn(10L);
    List<OrgDto> orgs = new ArrayList<>();
    when(userOrgPrivileges.addCustomProperties(orgs)).thenReturn(orgs);
    ResponseEntity<List<OrgDto>> response =
        orgController.getOrgs(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    verify(organization, times(1)).getAllOrgs(fetchCriteria);
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    // assertEquals(1, response.getBody().size());
  }

  @Test
  public void testGetOrgBrandPartnerTypes() throws Exception {

    Integer orgId = 123;
    OrgPartnerBrandPartnerTypeDTO mockOrgBrandPartnerType = new OrgPartnerBrandPartnerTypeDTO();
    when(organization.getOrgBrandPartnerTypes(orgId)).thenReturn(mockOrgBrandPartnerType);
    ResponseEntity<OrgPartnerBrandPartnerTypeDTO> response =
        orgController.getOrgBrandPartnerTypes(orgId);
    verify(organization, times(1)).getOrgBrandPartnerTypes(orgId);
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
  }

  @Test
  public void testUpdateOrgStatus() throws Exception {

    int orgId = 123;
    OrgInfo orgInfo = new OrgInfo();
    ResponseEntity<?> response = orgController.updateOrgStatus(orgId, orgInfo);
    verify(organization, times(1)).updateOrgStatus(orgInfo, orgId);
    assertNotNull(response);
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }
}
