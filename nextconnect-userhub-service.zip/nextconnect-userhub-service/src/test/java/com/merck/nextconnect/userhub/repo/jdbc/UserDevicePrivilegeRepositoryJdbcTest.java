package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.exception.CustomException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class UserDevicePrivilegeRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private UserDevicePrivilegeRepositoryJdbc userDevicePrivilegeRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetAllUserIdForDeviceId_Success() throws CustomException {
    // Arrange
    Long deviceId = 123L;
    List<Long> expectedUserIds = Arrays.asList(101L, 102L, 103L);

    when(namedParameterJdbcTemplate.queryForList(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedUserIds);

    // Act
    List<Long> result = userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(deviceId);

    // Assert
    assertEquals(3, result.size());
    assertEquals(Long.valueOf(101L), result.get(0));
    assertEquals(Long.valueOf(102L), result.get(1));
    assertEquals(Long.valueOf(103L), result.get(2));
  }

  @Test
  public void testGetAllUserIdForDeviceId_NullDeviceId() throws CustomException {
    // Act
    List<Long> result = userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(null);

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testGetAllUserIdForDeviceId_EmptyResult() throws CustomException {
    // Arrange
    Long deviceId = 123L;

    when(namedParameterJdbcTemplate.queryForList(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(Collections.emptyList());

    // Act
    List<Long> result = userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(deviceId);

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  void testGetAllUserIdForDeviceId_ExceptionHandling() {
    // Arrange
    Long deviceId = 123L;

    when(namedParameterJdbcTemplate.queryForList(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act & Assert
    CustomException ex =
        assertThrows(
            CustomException.class,
            () -> userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(deviceId));

    // optional: assert on message if repository wraps/sets a message
    // assertTrue(ex.getMessage().contains("Database error"));
  }
}
