package com.merck.nextconnect.userhub.authentication.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserCredentials;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.user.AccountStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserCredentialsRepository;
import com.merck.nextconnect.userhub.resources.IAccountPolicy;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.email.entities.ApplicationConfig;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCrypt;

@ExtendWith(MockitoExtension.class)
class NextConnectAuthTest {

  @Mock private UserCredentialsRepository userCredentialsRepository;
  @Mock private IAccountPolicy accountPolicy;
  @Mock private ApplicationConfigRepository applicationConfigRepository;

  @InjectMocks private NextConnectAuth nextConnectAuth;

  private UserCredentials userCredentials;
  private UserProfile userProfile;
  private Role role;
  private Login login;
  private ApplicationConfig applicationConfig;

  @BeforeEach
  public void setUp() {
    // Setup test data
    login = new Login();
    login.setUsername("testuser");
    login.setPassword("password123");

    role = new Role();
    role.setServiceRole(false);

    userProfile = new UserProfile();
    userProfile.setUserId(1L);
    userProfile.setRole(role);

    userCredentials = new UserCredentials();
    userCredentials.setUserProfile(userProfile);
    userCredentials.setPasswordHash(BCrypt.hashpw("password123", BCrypt.gensalt()));
    userCredentials.setStatus(AccountStatus.ACTIVE.value());
    userCredentials.setCreatedTime(new Timestamp(System.currentTimeMillis()));

    applicationConfig = new ApplicationConfig();
    applicationConfig.setValue("90"); // 90 days validity
  }

  @Test
  void testAuthenticate_Success() throws Exception {
    when(userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH))
        .thenReturn(userCredentials);
    when(applicationConfigRepository.findByCategoryAndKey(
            Constants.PASSWORD_POLICY, Constants.VALIDITY_DAYS))
        .thenReturn(applicationConfig);

    boolean result = nextConnectAuth.authenticate(login);

    assertTrue(result);
    verify(accountPolicy).resetLockOut(userProfile.getUserId());
  }

  @Test
  void testAuthenticate_UserNotFound_throwsLoginAuthenticationException() {
    when(userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH))
        .thenReturn(null);

    LoginAuthenticationException ex =
        assertThrows(LoginAuthenticationException.class, () -> nextConnectAuth.authenticate(login));
    assertEquals("Username or password is incorrect", ex.getMessage());
  }

  @Test
  void testAuthenticate_IncorrectPassword() {
    login.setPassword("wrongpassword");
    when(userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH))
        .thenReturn(userCredentials);

    boolean result = nextConnectAuth.authenticate(login);

    assertFalse(result);
    verify(accountPolicy).failedLoginAttempt(userCredentials);
  }

  @Test
  void testAuthenticate_AccountLocked_throwsLoginAuthenticationException() {
    // Set account status to LOCKED
    userCredentials.setStatus(AccountStatus.LOCKED.value());

    when(userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH))
        .thenReturn(userCredentials);
    when(applicationConfigRepository.findByCategoryAndKey(
            Constants.PASSWORD_POLICY, Constants.VALIDITY_DAYS))
        .thenReturn(applicationConfig);

    LoginAuthenticationException ex =
        assertThrows(LoginAuthenticationException.class, () -> nextConnectAuth.authenticate(login));
    assertEquals("Your account is locked.please reset the password to login.", ex.getMessage());
  }

  @Test
  void testAuthenticate_PasswordExpired_throwsLoginAuthenticationException() {
    // Set creation time to 100 days ago (beyond the 90 day validity)
    long hundredDaysInMillis = 100L * 24 * 60 * 60 * 1000;
    Timestamp oldTimestamp = new Timestamp(System.currentTimeMillis() - hundredDaysInMillis);
    userCredentials.setCreatedTime(oldTimestamp);

    when(userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH))
        .thenReturn(userCredentials);
    when(applicationConfigRepository.findByCategoryAndKey(
            Constants.PASSWORD_POLICY, Constants.VALIDITY_DAYS))
        .thenReturn(applicationConfig);

    LoginAuthenticationException ex =
        assertThrows(LoginAuthenticationException.class, () -> nextConnectAuth.authenticate(login));
    assertEquals("User's account got expired.", ex.getMessage());
  }

  @Test
  void testAuthenticate_ServiceRoleBypassesExpiry() {
    // Set service role to true
    role.setServiceRole(true);

    // Set creation time to 100 days ago (beyond the 90 day validity)
    long hundredDaysInMillis = 100L * 24 * 60 * 60 * 1000;
    Timestamp oldTimestamp = new Timestamp(System.currentTimeMillis() - hundredDaysInMillis);
    userCredentials.setCreatedTime(oldTimestamp);

    when(userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH))
        .thenReturn(userCredentials);

    boolean result = nextConnectAuth.authenticate(login);

    assertTrue(result);
    // validateExpiry should be bypassed for service role -> no call to applicationConfigRepository
    verify(applicationConfigRepository, never()).findByCategoryAndKey(anyString(), anyString());
  }

  @Test
  void testValidateExpiry_privateMethod_behavior() throws Exception {
    when(applicationConfigRepository.findByCategoryAndKey(
            Constants.PASSWORD_POLICY, Constants.VALIDITY_DAYS))
        .thenReturn(applicationConfig);

    // Use reflection to test private method validateExpiry(Timestamp)
    Method validateExpiryMethod =
        NextConnectAuth.class.getDeclaredMethod("validateExpiry", Timestamp.class);
    validateExpiryMethod.setAccessible(true);

    // Test with recent timestamp (should not throw exception)
    Timestamp recentTimestamp = new Timestamp(System.currentTimeMillis());
    assertDoesNotThrow(() -> validateExpiryMethod.invoke(nextConnectAuth, recentTimestamp));

    // Test with old timestamp (should throw LoginAuthenticationException wrapped in
    // InvocationTargetException)
    long hundredDaysInMillis = 100L * 24 * 60 * 60 * 1000;
    Timestamp oldTimestamp = new Timestamp(System.currentTimeMillis() - hundredDaysInMillis);

    Exception ex =
        assertThrows(
            Exception.class, () -> validateExpiryMethod.invoke(nextConnectAuth, oldTimestamp));
    // unwrap cause to verify actual LoginAuthenticationException and message
    Throwable cause = ex.getCause();
    assertNotNull(cause);
    assertTrue(cause instanceof LoginAuthenticationException);
    assertEquals(
        "User's account got expired.", ((LoginAuthenticationException) cause).getMessage());
  }
}
