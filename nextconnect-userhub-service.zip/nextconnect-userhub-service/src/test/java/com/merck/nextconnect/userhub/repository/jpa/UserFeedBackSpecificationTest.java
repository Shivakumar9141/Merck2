package com.merck.nextconnect.userhub.repository.jpa;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.userhub.entities.UserFeedBackEntity;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.repo.jdbc.UserFeedBackRepositoryJdbc;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.jpa.domain.Specification;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class UserFeedBackSpecificationTest {

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @Mock private UserFeedBackRepository userFeedBackRepository;

  @Mock private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;

  @Mock private UserRepository userRepository;

  @InjectMocks private UserFeedBackSpecification userFeedBackSpecification;

  private UserProfile userProfile;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    // Setup user profile
    userProfile = new UserProfile();
    Country country = new Country();
    country.setCountryCode("US");
    userProfile.setCountry(country);
  }

  @Test
  public void testSpecification_WithSearchCriteria() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(10L);
      jwtUser.setOrgId(100);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(10L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setSearchBy("TestOrg");

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_WithFilterCriteria() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(10L);
      jwtUser.setOrgId(100);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(10L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      FetchCriteria fetchCriteria = new FetchCriteria();
      List<String> filterBy = new ArrayList<>();
      filterBy.add("rating.ONE");
      filterBy.add("rating.FIVE");
      filterBy.add("role.Admin");
      filterBy.add("orgName.TestOrg");
      filterBy.add("countryCode.US");
      filterBy.add("feedbackRange.LESS_THAN_SIX_MONTHS");
      fetchCriteria.setFilterBy(filterBy);

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_DistributorFSERole() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(10L);
      jwtUser.setOrgId(100);
      jwtUser.setRole(Constants.DISTRIBUTOR_FSE);
      jwtUser.setRoleId(10L);
      AuthenticatedUser distributorFseUser =
          new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(distributorFseUser);

      FetchCriteria fetchCriteria = new FetchCriteria();

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_DistributorAdminRole() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(10L);
      jwtUser.setOrgId(100);
      jwtUser.setRole(Constants.DISTRIBUTOR_ADMIN);
      jwtUser.setRoleId(10L);
      AuthenticatedUser distributorAdminUser =
          new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(distributorAdminUser);

      FetchCriteria fetchCriteria = new FetchCriteria();

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_FSEUserRole() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(10L);
      jwtUser.setOrgId(100);
      jwtUser.setRole(Constants.FSE_USER);
      jwtUser.setRoleId(10L);
      AuthenticatedUser fseUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(fseUser);

      FetchCriteria fetchCriteria = new FetchCriteria();

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_EmptyAccessibleOrgs() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(10L);
      jwtUser.setOrgId(100);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(10L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      FetchCriteria fetchCriteria = new FetchCriteria();

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_WithNullSearchAndNullFilter() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Given
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(20L);
      jwtUser.setOrgId(200);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(20L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Mock userOrgPrivileges to return empty list
      Mockito.when(userOrgPrivileges.getOrgs(Mockito.any(), Mockito.any(), Mockito.any()))
          .thenReturn(new ArrayList<>());

      // Mock userRepository to return a user profile with country
      UserProfile userProfile = new UserProfile();
      com.merck.nextconnect.utils.common.entities.Country country =
          new com.merck.nextconnect.utils.common.entities.Country();
      country.setCountryCode("US");
      userProfile.setCountry(country);
      Mockito.when(userRepository.getUserById(Mockito.anyLong())).thenReturn(userProfile);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setSearchBy(null);
      fetchCriteria.setFilterBy(null);

      // When
      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      // Then
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_WithEmptyFilterList() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(30L);
      jwtUser.setOrgId(300);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(30L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      Mockito.when(userOrgPrivileges.getOrgs(Mockito.any(), Mockito.any(), Mockito.any()))
          .thenReturn(new ArrayList<>());

      UserProfile userProfile = new UserProfile();
      com.merck.nextconnect.utils.common.entities.Country country =
          new com.merck.nextconnect.utils.common.entities.Country();
      country.setCountryCode("DE");
      userProfile.setCountry(country);
      Mockito.when(userRepository.getUserById(Mockito.anyLong())).thenReturn(userProfile);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setFilterBy(new ArrayList<>());

      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_WithRatingFilter() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(40L);
      jwtUser.setOrgId(400);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(40L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      Mockito.when(userOrgPrivileges.getOrgs(Mockito.any(), Mockito.any(), Mockito.any()))
          .thenReturn(new ArrayList<>());

      UserProfile userProfile = new UserProfile();
      com.merck.nextconnect.utils.common.entities.Country country =
          new com.merck.nextconnect.utils.common.entities.Country();
      country.setCountryCode("IN");
      userProfile.setCountry(country);
      Mockito.when(userRepository.getUserById(Mockito.anyLong())).thenReturn(userProfile);

      FetchCriteria fetchCriteria = new FetchCriteria();
      List<String> filterBy = new ArrayList<>();
      filterBy.add("rating.ONE");
      fetchCriteria.setFilterBy(filterBy);

      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_WithFeedbackRangeLessThanSixMonths() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(50L);
      jwtUser.setOrgId(500);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(50L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      Mockito.when(userOrgPrivileges.getOrgs(Mockito.any(), Mockito.any(), Mockito.any()))
          .thenReturn(new ArrayList<>());

      UserProfile userProfile = new UserProfile();
      com.merck.nextconnect.utils.common.entities.Country country =
          new com.merck.nextconnect.utils.common.entities.Country();
      country.setCountryCode("FR");
      userProfile.setCountry(country);
      Mockito.when(userRepository.getUserById(Mockito.anyLong())).thenReturn(userProfile);

      FetchCriteria fetchCriteria = new FetchCriteria();
      List<String> filterBy = new ArrayList<>();
      filterBy.add("feedbackRange.LESS_THAN_SIX_MONTHS");
      fetchCriteria.setFilterBy(filterBy);

      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      assertNotNull(result);
    }
  }

  @Test
  public void testSpecification_WithAccessibleOrgsNotEmpty() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      JwtUser jwtUser = new JwtUser();
      jwtUser.setId(60L);
      jwtUser.setOrgId(600);
      jwtUser.setRole(Constants.LW_FSE);
      jwtUser.setRoleId(60L);
      AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Simulate accessible orgs not empty
      List<OrgDto> orgs = new ArrayList<>();
      OrgDto org = new OrgDto();
      org.setOrgId(601);
      orgs.add(org);
      Mockito.when(userOrgPrivileges.getOrgs(Mockito.any(), Mockito.any(), Mockito.any()))
          .thenReturn(orgs);

      UserProfile userProfile = new UserProfile();
      com.merck.nextconnect.utils.common.entities.Country country =
          new com.merck.nextconnect.utils.common.entities.Country();
      country.setCountryCode("JP");
      userProfile.setCountry(country);
      Mockito.when(userRepository.getUserById(Mockito.anyLong())).thenReturn(userProfile);

      FetchCriteria fetchCriteria = new FetchCriteria();

      Specification<UserFeedBackEntity> result =
          userFeedBackSpecification.specification(fetchCriteria);

      assertNotNull(result);
    }
  }
}
