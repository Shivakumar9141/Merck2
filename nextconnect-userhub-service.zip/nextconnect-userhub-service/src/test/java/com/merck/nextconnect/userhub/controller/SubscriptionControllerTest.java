package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.UserhubBaseTest;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.EmailSubscriptionValidationDTO;
import com.merck.nextconnect.userhub.model.InvalidEmailsDTO;
import com.merck.nextconnect.userhub.model.PhoneNumberDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.ISubscriptionType;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.resources.IUserSubscription;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import com.merck.nextconnect.utils.exception.EmailException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class SubscriptionControllerTest extends UserhubBaseTest {

  @Mock private ISubscriptionType subscriptionTypeService;

  @InjectMocks private SubscriptionController subscriptionController;
  @Mock private IUserSubscription userSubscriptionService;
  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;
  @Mock UserRepository userRepository;
  @Mock IUser iuser;

  @Before
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties to prevent NumberFormatException
    when(authUser.getId()).thenReturn("123");
    when(authUser.getOrgId()).thenReturn(5);
    when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetAllUsers() {
    List<SubscriptionTypeDTO> mockSubscriptionTypes = new ArrayList<>();
    SubscriptionTypeDTO subscriptionType1 =
        new SubscriptionTypeDTO(/* add necessary parameters */ );
    mockSubscriptionTypes.add(subscriptionType1);
    when(subscriptionTypeService.getAllSubscription()).thenReturn(mockSubscriptionTypes);
    ResponseEntity<List<SubscriptionTypeDTO>> response = subscriptionController.getAllUsers();
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(mockSubscriptionTypes, response.getBody());
  }

  @Test
  public void testGetSubscription() throws CustomException {
    long userId = 1L;
    UserSubscriptionDTO mockUserSubscriptionDTO =
        new UserSubscriptionDTO(/* add necessary parameters */ );
    when(userSubscriptionService.fetchAllUserSubscriptionByUser(userId))
        .thenReturn(mockUserSubscriptionDTO);
    ResponseEntity<UserSubscriptionDTO> response = subscriptionController.getSubscription(userId);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(mockUserSubscriptionDTO, response.getBody());
  }

  @Test
  public void testSearchMailId() {
    String mailId = "example@mail.com";
    List<String> mockMailSearches = new ArrayList<>();
    mockMailSearches.add("example1@mail.com");
    when(userRepository.findEmailsByOrgIdAndStatusAndDeleted(
            mailId, authUser.getOrgId(), UserStatus.ACTIVE.value(), false))
        .thenReturn(mockMailSearches);
    ResponseEntity<?> response = subscriptionController.searchMailId(mailId);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(mockMailSearches, response.getBody());
  }

  @Test
  public void testValidateMailId() throws CustomException {
    EmailSubscriptionValidationDTO emailSubscriptionValidationDTO =
        new EmailSubscriptionValidationDTO();
    InvalidEmailsDTO mockInvalidEmails = new InvalidEmailsDTO();
    when(userSubscriptionService.validateEmails(emailSubscriptionValidationDTO))
        .thenReturn(mockInvalidEmails);
    ResponseEntity<InvalidEmailsDTO> response =
        subscriptionController.validateMailId(emailSubscriptionValidationDTO);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(mockInvalidEmails, response.getBody());
  }

  @Test
  public void testUnsubscribeUser()
      throws DataValidationException, EmailException, CustomException {

    ResponseEntity<?> responseEntity = subscriptionController.unsubscribeUser();
    verify(iuser)
        .unSubscribe(
            Long.parseLong(authUser.getId()), authUser.getOrgId(), authUser.getRoleId(), null);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
  }

  @Test
  public void testSendOTP()
      throws CustomException,
          DataValidationException,
          NumberFormatException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {

    PhoneNumberDTO phoneNumberDTO = new PhoneNumberDTO();
    phoneNumberDTO.setIsdCode("91");
    phoneNumberDTO.setPhoneNumber("1234567890");
    ResponseEntity<?> responseEntity = subscriptionController.sendOTP(phoneNumberDTO);
    verify(userSubscriptionService)
        .sendOTP(
            Long.parseLong(authUser.getId()),
            phoneNumberDTO.getIsdCode(),
            phoneNumberDTO.getPhoneNumber());
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  public void testValidateOTP()
      throws CustomException,
          DataValidationException,
          NumberFormatException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {

    String isdCode = "91";
    String phoneNumber = "1234567890";
    String otp = "1234";
    ResponseEntity<?> responseEntity =
        subscriptionController.validateOTP(isdCode, phoneNumber, otp);
    verify(userSubscriptionService)
        .validateOTP(Long.parseLong(authUser.getId()), isdCode, phoneNumber, otp);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }
}
