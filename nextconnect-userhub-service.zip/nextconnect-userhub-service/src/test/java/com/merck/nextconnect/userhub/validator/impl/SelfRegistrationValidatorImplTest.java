package com.merck.nextconnect.userhub.validator.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SelfRegistrationValidatorImplTest<NotNullString> {

  @Mock private NotNullString notNullString;

  @InjectMocks private SelfRegistrationValidatorImpl validator;

  private SelfRegistrationDTO validDto;
  private UserProfile userProfile;
  private Country country;
  private RoleOfInterest roleOfInterest;

  @org.junit.Before
  public void setUp() {
    validator = new SelfRegistrationValidatorImpl();

    validDto = new SelfRegistrationDTO();
    validDto.setFirstName("John");
    validDto.setLastName("Doe");
    validDto.setEmail("john.doe@example.com");
    validDto.setCountryCode("US");
    validDto.setRoleOfInterest("DOCTOR");
    validDto.setSerialNo("12345");
    validDto.setPhone("1234567890");
    validDto.setIsdCode("+1");

    country = new Country();
    country.setCountryCode("US");

    roleOfInterest = new RoleOfInterest();
    roleOfInterest.setRoleOfInterest("DOCTOR");

    userProfile = null; // For valid case, user shouldn't exist
  }

  @Test
  public void selfRegistrationValidator_WithExistingUser_ShouldThrowException() {
    // Arrange
    userProfile = new UserProfile();

    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () ->
                validator.selfRegistrationValidator(
                    userProfile, country, validDto, roleOfInterest));
    assertEquals("EMAIL_ALREADY_EXISTS", exception.getErrorCode());
  }

  @Test
  public void selfRegistrationValidator_WithInvalidCountry_ShouldThrowException() {
    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () -> validator.selfRegistrationValidator(null, null, validDto, roleOfInterest));
    assertEquals("INVALID_COUNTRY_CODE", exception.getErrorCode());
  }

  @Test
  public void selfRegistrationValidator_WithInvalidRoleOfInterest_ShouldThrowException() {
    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () -> validator.selfRegistrationValidator(null, country, validDto, null));
    assertEquals("ROLE_OF_INTERESET_NOT_FOUND", exception.getErrorCode());
  }

  @Test
  public void selfRegistrationUserValidationValidator_WithValidData_ShouldNotThrowException() {
    // Arrange
    UserProfile selfRegisteredUser = new UserProfile();
    selfRegisteredUser.setInvitedVia(UserInvitedVia.SELF_REGISTRATION.value());
    selfRegisteredUser.setValidated(false);
    Organization org = new Organization();
    org.setId((int) 1L);
    selfRegisteredUser.setOrg(org);

    UserProfile validatingUser = new UserProfile();
    validatingUser.setOrg(org);

    // Act & Assert
    try {
      validator.selfRegistrationUserValidationValidator(selfRegisteredUser, validatingUser);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test
  public void selfRegistrationDataValidation_WithMatchingData_ShouldNotThrowException() {
    // Arrange
    SelfRegistrationDTO cacheDto = new SelfRegistrationDTO();
    cacheDto.setFirstName("John");
    cacheDto.setLastName("Doe");
    cacheDto.setEmail("john.doe@example.com");
    cacheDto.setCountryCode("US");
    cacheDto.setRoleOfInterest("DOCTOR");
    cacheDto.setSerialNo("12345");
    cacheDto.setPhone("1234567890");
    cacheDto.setIsdCode("+1");

    // Act & Assert
    try {
      validator.selfRegistrationDataValidation(validDto, cacheDto);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test
  public void selfRegistrationDataValidation_WithMismatchedData_ShouldThrowException() {
    // Arrange
    SelfRegistrationDTO cacheDto = new SelfRegistrationDTO();
    cacheDto.setFirstName("Jane"); // Different first name
    cacheDto.setLastName("Doe");
    cacheDto.setEmail("john.doe@example.com");
    cacheDto.setCountryCode("US");
    cacheDto.setRoleOfInterest("DOCTOR");
    cacheDto.setSerialNo("12345");
    cacheDto.setPhone("1234567890");
    cacheDto.setIsdCode("+1");

    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () -> validator.selfRegistrationDataValidation(validDto, cacheDto));
    assertEquals("PROPERTY_MISMATCH", exception.getErrorCode());
  }
}
