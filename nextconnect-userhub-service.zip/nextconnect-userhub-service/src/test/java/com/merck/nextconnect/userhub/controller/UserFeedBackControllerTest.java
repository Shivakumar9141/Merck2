package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.FeedBackDTO;
import com.merck.nextconnect.userhub.model.FeedBackStatus;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.UserDefaulterFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackPageDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingDTO;
import com.merck.nextconnect.userhub.model.user.UserDataList;
import com.merck.nextconnect.userhub.resources.IUserFeedBackService;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/** JUnit 5 conversion of UserFeedBackControllerTest. */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserFeedBackControllerTest {

  @Mock private IUserFeedBackService userFeedBackService;

  @InjectMocks private UserFeedBackController controller;

  @Mock private Authentication authentication;
  @Mock private AuthenticatedUser authUser;

  @BeforeEach
  void setUp() {
    // Prepare SecurityContext with mocked Authentication
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Install principal
    when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  void testCreateFeedBack() throws CustomException {
    UserDataDTO userDataDTO = new UserDataDTO();
    UserFeedBackDTO userFeedBackDTO = new UserFeedBackDTO();

    // stub authUser.getId() since controller likely uses it
    when(authUser.getId()).thenReturn("123");

    when(userFeedBackService.createFeedBack(userFeedBackDTO, authUser.getId()))
        .thenReturn(userDataDTO);

    ResponseEntity<?> responseEntity = controller.createFeedBack(userFeedBackDTO);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  void testGetAllFeedBacks() {
    String sortBy = "userName";
    String orderBy = "asc";
    List<String> filterBy = new ArrayList<>();
    String searchBy = "";
    Integer page = 1;
    Integer pageLimit = 20;

    UserFeedBackPageDTO expectedUserFeedBackPageDTO = new UserFeedBackPageDTO();
    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);

    when(userFeedBackService.getAllFeedBacks(fetchCriteria))
        .thenReturn(expectedUserFeedBackPageDTO);

    ResponseEntity<?> responseEntity =
        controller.getAllFeedBacks(sortBy, orderBy, filterBy, searchBy, page, pageLimit);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedUserFeedBackPageDTO, responseEntity.getBody());
    HttpHeaders headers = responseEntity.getHeaders();
    assertEquals(
        String.valueOf(expectedUserFeedBackPageDTO.getTotalPages()),
        headers.getFirst("X-Pagination-Count"));
    assertEquals(
        String.valueOf(expectedUserFeedBackPageDTO.getRecordCount()),
        headers.getFirst("X-Record-Count"));
  }

  @Test
  void testGetDefaultersFacets() throws CustomException {
    UserDefaulterFacets expectedFacets = new UserDefaulterFacets();
    when(userFeedBackService.getFeedBackDefaultersFacets()).thenReturn(expectedFacets);
    ResponseEntity<?> responseEntity = controller.getDefaultersFacets();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedFacets, responseEntity.getBody());
  }

  @Test
  void testGetRatingDetails() throws CustomException {
    long userId = 123L;
    List<String> filterBy = new ArrayList<>();
    UserFeedBackRatingDTO userFeedBackRatingDTO = null;
    when(userFeedBackService.getRatingDetails(userId, authUser, filterBy))
        .thenReturn(userFeedBackRatingDTO);
    ResponseEntity<?> responseEntity = controller.getRatingDetails(userId, filterBy);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(userFeedBackRatingDTO, responseEntity.getBody());
  }

  @Test
  void testGetUsersFacets() throws CustomException {
    UserFeedBackFacets expectedFacets = new UserFeedBackFacets();
    when(userFeedBackService.getUserFeedBackFacets()).thenReturn(expectedFacets);
    ResponseEntity<?> responseEntity = controller.getUsersFacets();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedFacets, responseEntity.getBody());
  }

  @Test
  void testGetFeedbackDefaulters() throws CustomException {
    String sortBy = "userName";
    String orderBy = "asc";
    List<String> filterBy = new ArrayList<>();
    String searchBy = "";
    Integer page = 1;
    Integer pageLimit = 20;

    UserDataList expectedUserDataList = new UserDataList();
    when(userFeedBackService.getNoFeedBackSortByEntries(filterBy, sortBy)).thenReturn(sortBy);

    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    when(userFeedBackService.getFeedBackDefaulters(fetchCriteria)).thenReturn(expectedUserDataList);

    ResponseEntity<?> responseEntity =
        controller.getFeedbackDefaulters(sortBy, orderBy, filterBy, searchBy, page, pageLimit);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedUserDataList.getUsers(), responseEntity.getBody());
    HttpHeaders headers = responseEntity.getHeaders();
    assertEquals(
        String.valueOf(expectedUserDataList.getTotalPages()),
        headers.getFirst("x-pagination-count"));
    assertEquals(
        String.valueOf(expectedUserDataList.getRecordCount()), headers.getFirst("X-Record-Count"));
  }

  @Test
  void testGetTotalFeedback() throws CustomException {
    Long userId = 123L;
    FeedBackStatus expectedUserFeedBack = new FeedBackStatus();
    when(userFeedBackService.getFeedBack(userId)).thenReturn(expectedUserFeedBack);
    ResponseEntity<?> responseEntity = controller.getTotalFeedback(userId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedUserFeedBack, responseEntity.getBody());
  }

  @Test
  void testGetTotalFeedbacks() throws CustomException {
    FeedBackDTO expectedUserFeedbackData = new FeedBackDTO();
    when(userFeedBackService.getAllUsersFeedBack(authUser)).thenReturn(expectedUserFeedbackData);
    ResponseEntity<?> responseEntity = controller.getTotalFeedbacks();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedUserFeedbackData, responseEntity.getBody());
  }
}
