package com.merck.nextconnect.userhub.resources;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.repo.jdbc.BusinessDomainRepositoryJdbc;
import com.merck.nextconnect.userhub.resources.impl.BusinessDomainServiceImpl;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.util.ReflectionTestUtils;

public class BusinessDomainServiceImplTest {

  @InjectMocks private BusinessDomainServiceImpl businessDomainService;
  @Mock private BusinessDomainRepositoryJdbc businessDomainRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    businessDomainRepositoryJdbc = mock(BusinessDomainRepositoryJdbc.class);
    businessDomainService = new BusinessDomainServiceImpl();
    ReflectionTestUtils.setField(
        businessDomainService, "businessDomainRepositoryJdbc", businessDomainRepositoryJdbc);
  }

  @Test
  public void testGetAllBusinessDomain() throws DataValidationException {
    List<BusinessDomainDTO> mockBusinessDomainList = new ArrayList<>();
    BusinessDomainDTO domain1 = new BusinessDomainDTO(1, "Others");
    mockBusinessDomainList.add(domain1);
    when(businessDomainRepositoryJdbc.obtainAllBusinessDomain()).thenReturn(mockBusinessDomainList);
    List<BusinessDomainDTO> result = businessDomainService.getAllBusinessDomain(true);
    // assertEquals(1, result.size());
    verify(businessDomainRepositoryJdbc, times(1)).obtainAllBusinessDomain();
  }

  @Test
  public void testGetAllBusinessDomain_GenericFalse() throws DataValidationException {
    List<BusinessDomainDTO> mockBusinessDomainList = new ArrayList<>();
    BusinessDomainDTO domain1 = new BusinessDomainDTO(1, "Generic");
    mockBusinessDomainList.add(domain1);
    when(businessDomainRepositoryJdbc.obtainAllBusinessDomain()).thenReturn(mockBusinessDomainList);
    List<BusinessDomainDTO> result = businessDomainService.getAllBusinessDomain(false);
    // assertEquals(1, result.size());
    verify(businessDomainRepositoryJdbc, times(1)).obtainAllBusinessDomain();
  }
}
