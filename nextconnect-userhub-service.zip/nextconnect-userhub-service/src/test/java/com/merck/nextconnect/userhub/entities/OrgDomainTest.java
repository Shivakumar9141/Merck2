package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.utils.common.entities.UserDomain;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class OrgDomainTest {

  private OrgDomain orgDomain;
  private Organization org;
  private UserDomain domain;

  @BeforeEach
  public void setUp() {
    orgDomain = new OrgDomain();
    org = new Organization();
    domain = new UserDomain();
  }

  @Test
  public void testGetSetId() {
    Integer id = 123;
    orgDomain.setId(id);
    assertEquals(id, orgDomain.getId());
  }

  @Test
  public void testGetSetOrg() {
    orgDomain.setOrg(org);
    assertEquals(org, orgDomain.getOrg());
  }

  @Test
  public void testGetSetDomain() {
    orgDomain.setDomain(domain);
    assertEquals(domain, orgDomain.getDomain());
  }
}
