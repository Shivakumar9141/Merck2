package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthToken;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.DeviceTypeOperation;
import com.merck.nextconnect.authfilter.repository.hazelcast.TokenStore;
import com.merck.nextconnect.authfilter.resources.IprivilegeBuilder;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.UserInfo;
import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import com.merck.nextconnect.userhub.model.org.OrgSettingsDto;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.model.user.UserLoginInfo;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserProfileSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.impl.AuthenticationImpl;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.resources.impl.UserRolePrivileges;
import com.merck.nextconnect.userhub.response.SamlAuthResponse;
import com.merck.nextconnect.userhub.response.SamlValidationResponse;
import com.merck.nextconnect.userhub.util.LoginUtil;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpStatus;
import org.joda.time.DateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.Response;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthenticationImplTest {

  @InjectMocks private AuthenticationImpl authenticationimpl;

  @Mock private UserRepository userRepo;

  @Mock private JwtTokenGenerator jwtTokenGenerator;

  @Mock private Authentication authentication;

  @Mock private AuthenticatedUser authUser;

  @Mock private UserRolePrivileges userRolePrivileges;

  @Mock private IprivilegeBuilder privilegeBuilder;

  @Mock private TokenStore tokenStore;

  @Mock private Signature signature;

  @Mock private Response response;

  @Mock private SAMLSignatureProfileValidator profileValidator;

  @Mock private LoginUtil loginUtil;

  @Mock private UserProfileSettingsRepository userProfileSettingsRepository;

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @Mock private org.opensaml.xml.signature.Signature mockSignature; // if needed

  // fields that in original were constructed via mock() in setUp()
  private ICountry iCountry;
  private IRoles iroles;
  private MenuService menuManagementService;

  // sample values for injected @Value fields
  private final String encryptKeyForLoginToken = "testEncryptKey";
  private final String samlValidationIssuer =
      "https://sts.windows.net/db76fb59-a377-4120-bc54-59dead7d39c9/";

  @BeforeEach
  void setUp() {
    // create any additional mocks not annotated
    iCountry = mock(ICountry.class);
    iroles = mock(IRoles.class);
    userOrgPrivileges = mock(UserOrgPrivileges.class);
    menuManagementService = mock(MenuService.class);

    // instantiate and inject private fields (mirrors original setup)
    authenticationimpl = new AuthenticationImpl();
    ReflectionTestUtils.setField(authenticationimpl, "userRepo", userRepo);
    ReflectionTestUtils.setField(authenticationimpl, "iCountry", iCountry);
    ReflectionTestUtils.setField(authenticationimpl, "iroles", iroles);
    ReflectionTestUtils.setField(authenticationimpl, "userOrgPrivileges", userOrgPrivileges);
    ReflectionTestUtils.setField(
        authenticationimpl, "userProfileSettingsRepository", userProfileSettingsRepository);
    ReflectionTestUtils.setField(
        authenticationimpl, "menuManagementService", menuManagementService);
    ReflectionTestUtils.setField(authenticationimpl, "userRolePrivileges", userRolePrivileges);
    ReflectionTestUtils.setField(
        authenticationimpl, "encryptKeyForLoginToken", encryptKeyForLoginToken);
    ReflectionTestUtils.setField(authenticationimpl, "samlValidationIssuer", samlValidationIssuer);
    // Inject the missing mocked dependencies
    ReflectionTestUtils.setField(authenticationimpl, "privilegeBuilder", privilegeBuilder);
    ReflectionTestUtils.setField(authenticationimpl, "jwtTokenGenerator", jwtTokenGenerator);
    ReflectionTestUtils.setField(authenticationimpl, "loginUtil", loginUtil);
    ReflectionTestUtils.setField(authenticationimpl, "tokenStore", tokenStore);

    // Set up SecurityContext mock (so SecurityContextHolder.getContext() works)
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  void testLogin_Success_throwsLoginAuthenticationException() {
    Login login = new Login();
    login.setUsername("testUser");
    login.setUserdomain("DNAP");

    // Expect a LoginAuthenticationException based on original test annotation
    assertThrows(LoginAuthenticationException.class, () -> authenticationimpl.login(login));
  }

  @Test
  void testLogin_InvalidUsernamePassword_throwsLoginAuthenticationException() {
    Login login = new Login();
    login.setUsername("invalidUser");
    login.setUserdomain("DNAP");

    assertThrows(LoginAuthenticationException.class, () -> authenticationimpl.login(login));
  }

  @Test
  void testLogin_OrgDeactivated_throwsAccessDeniedException() {
    Login login = new Login();
    Organization org = new Organization();
    org.setId(1);
    login.setUsername("deactivatedUser");
    login.setUserdomain("DNAP");
    UserProfile userProfile = new UserProfile();
    userProfile.setStatus(UserStatus.ACTIVE.value());
    userProfile.setOrg(org);
    userProfile.getOrg().setStatus(false);

    when(userRepo.getUserWithOutOrg(login.getUsername(), "merck_auth")).thenReturn(userProfile);

    assertThrows(AccessDeniedException.class, () -> authenticationimpl.login(login));
  }

  @Test
  void testGenerateAuthToken_invokesPrivateMethod() throws Exception {
    UserProfile userProfile = new UserProfile();

    Method generateAuthTokenMethod =
        AuthenticationImpl.class.getDeclaredMethod("generateAuthToken", UserProfile.class);
    generateAuthTokenMethod.setAccessible(true);

    AuthToken authToken =
        (AuthToken) generateAuthTokenMethod.invoke(authenticationimpl, userProfile);
    assertNotNull(authToken);
  }

  @Test
  void testGetLoginTypes() {
    String loginText = "testUser";
    List<String> expectedLoginTypes = Arrays.asList("email", "username");
    when(userRepo.getLoginTypes(loginText)).thenReturn(expectedLoginTypes);

    UserLoginInfo result = authenticationimpl.getLoginTypes(loginText);

    assertEquals(loginText, result.getUserName());
    assertEquals(expectedLoginTypes, result.getAuthenticationTypes());
  }

  @Test
  void testGetUserInfo() throws ResourceNotFoundException {
    long userId = 1;
    String username = "testUser";

    UserDomain userDomain = new UserDomain();
    userDomain.setDomainName("test");
    Language lang = new Language();
    lang.setCode("code");
    Role role = new Role();
    role.setRoleId(1);
    role.setName("test");
    Organization org = new Organization();
    org.setId(1);
    org.setName("test");
    org.setParent(org);
    org.setType("type");

    com.merck.nextconnect.utils.common.entities.DateFormat dateFormat =
        new com.merck.nextconnect.utils.common.entities.DateFormat();
    dateFormat.setDateFormat("yyyy-MM-dd");

    UserProfile userProfile = new UserProfile();
    userProfile.setUserDomain(userDomain);
    userProfile.setLanguage(lang);
    userProfile.setRole(role);
    userProfile.setOrg(org);
    userProfile.setDateFormat(dateFormat);

    when(userRepo.getUserById(userId, authUser.getOrgId(), authUser.getRoleId()))
        .thenReturn(userProfile);
    when(iroles.getPrivileges(role.getRoleId(), "test")).thenReturn(new ArrayList<RolePrivilege>());
    when(userOrgPrivileges.getOrgPrivileges()).thenReturn(new ArrayList<>());
    when(userOrgPrivileges.getOrgSpecificSettings()).thenReturn(mock(OrgSettingsDto.class));
    UserProfileSettingsDTO mockUserProfileSettingsDTO = mock(UserProfileSettingsDTO.class);
    when(userProfileSettingsRepository.fetchUserProfileSettings(userId))
        .thenReturn(mockUserProfileSettingsDTO);
    when(menuManagementService.getMenuGroups(Mockito.any())).thenReturn(new ArrayList<>());

    UserInfo userInfo = authenticationimpl.getUserInfo(userId, username, authUser.getOrgId());

    assertNotNull(userInfo);
    assertEquals(userId, userInfo.getId());
    assertEquals(username, userInfo.getUsername());
  }

  @Test
  void testFillPrivileges_invokesPrivilegeBuilder() throws Exception {
    Role role = new Role();
    role.setRoleId(1L);

    List<String> entityPrivilegeList = new ArrayList<>();
    entityPrivilegeList.add("ENTITY_READ");
    when(userRolePrivileges.getEntityPrivilegeList(1L)).thenReturn(entityPrivilegeList);

    List<Long> deviceGroupLevelPrivileges = new ArrayList<>();
    deviceGroupLevelPrivileges.add(1L);
    when(userRolePrivileges.getDeviceGroupPrivilegeList(1L)).thenReturn(deviceGroupLevelPrivileges);

    Map<DeviceTypeOperation, List<String>> deviceTypePrivilegesMap = new HashMap<>();
    List<String> deviceTypePrivileges = new ArrayList<>();
    deviceTypePrivileges.add("DEVICE_TYPE_READ");
    deviceTypePrivilegesMap.put(DeviceTypeOperation.read, deviceTypePrivileges);
    Map<Long, Map<DeviceTypeOperation, List<String>>> deviceTypeLevelPrivileges = new HashMap<>();
    deviceTypeLevelPrivileges.put(1L, deviceTypePrivilegesMap);
    when(userRolePrivileges.getDeviceTypePrivilegeMap(1L)).thenReturn(deviceTypeLevelPrivileges);

    Method fillPrivilegesMethod =
        AuthenticationImpl.class.getDeclaredMethod("fillPrivileges", Role.class);
    fillPrivilegesMethod.setAccessible(true);
    fillPrivilegesMethod.invoke(authenticationimpl, role);

    verify(privilegeBuilder).addEntityPrivileges(1L, entityPrivilegeList);
    verify(privilegeBuilder).addDeviceGroupPrivileges(1L, deviceGroupLevelPrivileges);
    verify(privilegeBuilder).addDeviceTypePrivileges(1L, deviceTypeLevelPrivileges);
  }

  @Test
  void testGetTokenFromCacheByHash_throwsException() {
    String hash = "testHash";
    String encryptedToken = new String(Base64.encodeBase64("$aMl3nCK3y123222".getBytes()));
    when(tokenStore.retrieveAuthToken(hash)).thenReturn(encryptedToken);

    assertThrows(Exception.class, () -> authenticationimpl.getTokenFromCacheByHash(hash));
  }

  @Test
  void testValidateProfileSignature_ValidSignature() throws Exception {
    Method method =
        AuthenticationImpl.class.getDeclaredMethod("validateProfileSignature", Signature.class);
    method.setAccessible(true);

    boolean result = (boolean) method.invoke(authenticationimpl, signature);
    assertTrue(result);
  }

  @Test
  void testSamlAssertionValidation_NoEncryptedAssertionsAndSingleAssertion() throws Exception {
    when(response.getEncryptedAssertions()).thenReturn(Collections.emptyList());
    Assertion assertion = mock(Assertion.class);
    when(response.getAssertions()).thenReturn(Collections.singletonList(assertion));

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlAssertionValidation", Response.class);
    method.setAccessible(true);
    boolean result = (boolean) method.invoke(authenticationimpl, response);

    assertTrue(result);
  }

  @Test
  void testSamlAssertionValidation_EncryptedAssertionsNotPresent() throws Exception {
    when(response.getEncryptedAssertions()).thenReturn(Collections.emptyList());
    Assertion assertion = mock(Assertion.class);
    when(response.getAssertions()).thenReturn(Collections.singletonList(assertion));

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlAssertionValidation", Response.class);
    method.setAccessible(true);
    boolean result = (boolean) method.invoke(authenticationimpl, response);

    assertTrue(result);
  }

  @Test
  void testSamlAssertionValidation_EncryptedAssertionsPresent() throws Exception {
    Assertion assertion = mock(Assertion.class);
    when(response.getAssertions()).thenReturn(Collections.singletonList(assertion));

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlAssertionValidation", Response.class);
    method.setAccessible(true);
    boolean result = (boolean) method.invoke(authenticationimpl, response);

    assertTrue(result);
  }

  @Test
  void testDateTimeValidation_ValidDates() throws Exception {
    DateTime now = DateTime.now();
    DateTime pastTime = now.minusMinutes(1);
    DateTime futureTime = now.plusMinutes(1);
    Method method =
        AuthenticationImpl.class.getDeclaredMethod(
            "dateTimeValidation", DateTime.class, DateTime.class);
    method.setAccessible(true);
    boolean result = (boolean) method.invoke(authenticationimpl, pastTime, futureTime);
    assertTrue(result);
  }

  @Test
  void testValidateIssuer_ValidIssuer() throws Exception {
    String validIssuer = "https://sts.windows.net/db76fb59-a377-4120-bc54-59dead7d39c9/";
    Method method = AuthenticationImpl.class.getDeclaredMethod("validateIssuer", String.class);
    method.setAccessible(true);
    boolean result = (boolean) method.invoke(authenticationimpl, validIssuer);
    assertTrue(result);
  }

  @Test
  void testLoginBySaml_ValidResponseFailure() {
    String validSamlResponse = "valid_saml_response";
    when(loginUtil.validateAndParseSamlResponse(validSamlResponse)).thenReturn(null);

    SamlAuthResponse response = authenticationimpl.loginBySaml(validSamlResponse);
    assertEquals(HttpStatus.SC_BAD_REQUEST, response.getStatusCode());
  }

  @Test
  void testGetAuthTokenByUserName_UserProfileDoesNotExist() throws Exception {
    Method method =
        AuthenticationImpl.class.getDeclaredMethod("getAuthTokenByUserName", String.class);
    method.setAccessible(true);
    SamlAuthResponse samlAuthResponse =
        (SamlAuthResponse) method.invoke(authenticationimpl, "test@example.com");

    assertEquals(HttpStatus.SC_UNAUTHORIZED, samlAuthResponse.getStatusCode());
    assertEquals("Unauthorized", samlAuthResponse.getStatusMessage());
    assertNull(samlAuthResponse.getAuthToken());
  }

  @Test
  void testStoreTokenAndGetHash_returnsNonNull() throws Exception {
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();
    AuthToken auth = new AuthToken();
    auth.setToken("accessToken");
    samlAuthResponse.setAuthToken(auth);

    SamlValidationResponse samlValidationResponse = new SamlValidationResponse();
    samlValidationResponse.setEmailAdress("test@example.com");

    Method method =
        AuthenticationImpl.class.getDeclaredMethod(
            "storeTokenAndGetHash", SamlAuthResponse.class, SamlValidationResponse.class);
    method.setAccessible(true);
    String hashForThisUser =
        (String) method.invoke(authenticationimpl, samlAuthResponse, samlValidationResponse);

    assertNotNull(hashForThisUser);
  }

  @Test
  void testGetUserInfo_ReturnsUserInfoWithExpectedFields() throws ResourceNotFoundException {
    long userId = 123L;
    String username = "testuser";
    int orgId = 10;

    // Mock AuthenticatedUser in SecurityContext
    AuthenticatedUser mockAuthUser = mock(AuthenticatedUser.class);
    when(mockAuthUser.getRoleId()).thenReturn(2L);
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(mockAuthUser);
    SecurityContextHolder.setContext(securityContext);

    // Mock UserProfile and related entities
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(userId);
    userProfile.setEmail("testuser@example.com");
    userProfile.setStatus("ACTIVE");
    userProfile.setFirstName("Test");
    userProfile.setLastName("User");
    userProfile.setAutoCreated(true);
    userProfile.setInvitedVia("email");
    userProfile.setValidated(true);

    com.merck.nextconnect.utils.common.entities.UserDomain userDomain =
        new com.merck.nextconnect.utils.common.entities.UserDomain();
    userDomain.setDomainName("testdomain");
    userProfile.setUserDomain(userDomain);

    com.merck.nextconnect.utils.common.entities.DateFormat dateFormat =
        new com.merck.nextconnect.utils.common.entities.DateFormat();
    dateFormat.setDateFormat("yyyy-MM-dd");
    userProfile.setDateFormat(dateFormat);

    com.merck.nextconnect.utils.common.entities.Language language =
        new com.merck.nextconnect.utils.common.entities.Language();
    language.setCode("EN");
    userProfile.setLanguage(language);

    com.merck.nextconnect.userhub.entities.Role role =
        new com.merck.nextconnect.userhub.entities.Role();
    role.setRoleId(2L);
    role.setName("Admin");
    userProfile.setRole(role);

    com.merck.nextconnect.userhub.entities.Organization org =
        new com.merck.nextconnect.userhub.entities.Organization();
    org.setId(orgId);
    org.setName("TestOrg");
    org.setType("ORG_TYPE");
    com.merck.nextconnect.userhub.entities.Organization parentOrg =
        new com.merck.nextconnect.userhub.entities.Organization();
    parentOrg.setType("PARENT_TYPE");
    org.setParent(parentOrg);
    userProfile.setOrg(org);

    com.merck.nextconnect.utils.common.entities.Country country =
        new com.merck.nextconnect.utils.common.entities.Country();
    country.setCountryCode("DE");
    userProfile.setCountry(country);

    userProfile.setTimeZoneId(1);

    when(userRepo.getUserById(userId, orgId, 2L)).thenReturn(userProfile);
    when(userOrgPrivileges.getOrgPrivileges()).thenReturn(new ArrayList<>());
    when(userOrgPrivileges.getOrgSpecificSettings()).thenReturn(mock(OrgSettingsDto.class));
    UserProfileSettingsDTO mockUserProfileSettingsDTO = mock(UserProfileSettingsDTO.class);
    when(userProfileSettingsRepository.fetchUserProfileSettings(userId))
        .thenReturn(mockUserProfileSettingsDTO);
    when(menuManagementService.getMenuGroups(Mockito.any())).thenReturn(new ArrayList<>());

    UserInfo userInfo = authenticationimpl.getUserInfo(userId, username, orgId);

    assertNotNull(userInfo);
    assertEquals(userId, userInfo.getId());
    assertEquals(username, userInfo.getUsername());
    assertEquals("testuser@example.com", userInfo.getEmail());
    assertEquals("ACTIVE", userInfo.getStatus());
    assertEquals("testdomain", userInfo.getDomainName());
    assertEquals("yyyy-MM-dd", userInfo.getDateFormat());
    assertEquals("EN", userInfo.getLanguageCode());
    assertEquals("Admin", userInfo.getRole());
    assertEquals(2L, userInfo.getRoleId());
    assertEquals(orgId, userInfo.getOrgId());
    assertEquals("TestOrg", userInfo.getOrgName());
    assertEquals("Test", userInfo.getFirstName());
    assertEquals("User", userInfo.getLastName());
    assertTrue(userInfo.isDomainVisible());
    assertEquals("DE", userInfo.getCountryCode());
    assertTrue(userInfo.isAutoCreated());
    assertEquals("email", userInfo.getInvitedVia());
    assertTrue(userInfo.isValidated());
    assertEquals("ORG_TYPE", userInfo.getOrgType());
    assertEquals("PARENT_TYPE", userInfo.getParentType());
  }

  @Test
  void testSamlResponseValidation_InvalidIssuer() throws Exception {
    Response mockResponse = mock(Response.class);
    Assertion mockAssertion = mock(Assertion.class);
    org.opensaml.saml2.core.Issuer mockIssuer = mock(org.opensaml.saml2.core.Issuer.class);
    Signature mockSignature = mock(Signature.class);
    org.opensaml.saml2.core.Conditions mockConditions =
        mock(org.opensaml.saml2.core.Conditions.class);
    org.opensaml.saml2.core.AttributeStatement mockAttributeStatement =
        mock(org.opensaml.saml2.core.AttributeStatement.class);
    Attribute mockAttribute = mock(Attribute.class);
    org.opensaml.xml.XMLObject mockXmlObject = mock(org.opensaml.xml.XMLObject.class);

    when(mockResponse.getAssertions()).thenReturn(Collections.singletonList(mockAssertion));
    when(mockAssertion.getIssuer()).thenReturn(mockIssuer);
    when(mockIssuer.getValue()).thenReturn("invalid-issuer");
    when(mockAssertion.getSignature()).thenReturn(mockSignature);

    DateTime notBefore = DateTime.now().minusMinutes(5);
    DateTime notOnOrAfter = DateTime.now().plusMinutes(5);
    when(mockAssertion.getConditions()).thenReturn(mockConditions);
    when(mockConditions.getNotBefore()).thenReturn(notBefore);
    when(mockConditions.getNotOnOrAfter()).thenReturn(notOnOrAfter);

    when(mockAssertion.getAttributeStatements())
        .thenReturn(
            Collections.<org.opensaml.saml2.core.AttributeStatement>singletonList(
                mockAttributeStatement));
    when(mockAttributeStatement.getAttributes()).thenReturn(Collections.nCopies(8, mockAttribute));
    when(mockAttribute.getAttributeValues())
        .thenReturn(Collections.<org.opensaml.xml.XMLObject>singletonList(mockXmlObject));
    org.w3c.dom.Element mockDomElement = mock(org.w3c.dom.Element.class);
    when(((org.opensaml.xml.XMLObject) mockXmlObject).getDOM()).thenReturn(mockDomElement);
    when(mockDomElement.getTextContent()).thenReturn("user@example.com");

    BasicX509Credential mockCredential = mock(BasicX509Credential.class);
    when(loginUtil.getCredential()).thenReturn(mockCredential);

    AuthenticationImpl spyAuthImpl = Mockito.spy(authenticationimpl);

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlResponseValidation", Response.class);
    method.setAccessible(true);
    SamlValidationResponse result = null;
    try {
      result = (SamlValidationResponse) method.invoke(spyAuthImpl, mockResponse);
    } catch (InvocationTargetException e) {
      e.getCause().printStackTrace();
      throw e;
    }

    assertFalse(result.isValidationStatus());
  }

  @Test
  void testSamlResponseValidation_InvalidProfileSignature() throws Exception {
    Response mockResponse = mock(Response.class);
    Assertion mockAssertion = mock(Assertion.class);
    org.opensaml.saml2.core.Issuer mockIssuer = mock(org.opensaml.saml2.core.Issuer.class);
    Signature mockSignature = mock(Signature.class);
    org.opensaml.saml2.core.Conditions mockConditions =
        mock(org.opensaml.saml2.core.Conditions.class);
    Attribute mockAttribute = mock(Attribute.class);
    XMLObject mockXmlObject = mock(XMLObject.class);

    when(mockResponse.getAssertions()).thenReturn(Collections.singletonList(mockAssertion));
    when(mockAssertion.getIssuer()).thenReturn(mockIssuer);
    when(mockIssuer.getValue()).thenReturn(samlValidationIssuer);
    when(mockAssertion.getSignature()).thenReturn(mockSignature);

    DateTime notBefore = DateTime.now().minusMinutes(5);
    DateTime notOnOrAfter = DateTime.now().plusMinutes(5);
    when(mockAssertion.getConditions()).thenReturn(mockConditions);

    BasicX509Credential mockCredential = mock(BasicX509Credential.class);

    AuthenticationImpl spyAuthImpl = Mockito.spy(authenticationimpl);

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlResponseValidation", Response.class);
    method.setAccessible(true);
    try {
      SamlValidationResponse result =
          (SamlValidationResponse) method.invoke(spyAuthImpl, mockResponse);
      assertFalse(result.isValidationStatus());
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause();
      assertNotNull(cause);
    }
  }

  @Test
  void testSamlResponseValidation_InvalidDateTime() throws Exception {
    Response mockResponse = mock(Response.class);
    Assertion mockAssertion = mock(Assertion.class);
    org.opensaml.saml2.core.Issuer mockIssuer = mock(org.opensaml.saml2.core.Issuer.class);
    Signature mockSignature = mock(Signature.class);
    org.opensaml.saml2.core.Conditions mockConditions =
        mock(org.opensaml.saml2.core.Conditions.class);
    Attribute mockAttribute = mock(Attribute.class);
    XMLObject mockXmlObject = mock(XMLObject.class);

    when(mockResponse.getAssertions()).thenReturn(Collections.singletonList(mockAssertion));
    when(mockAssertion.getIssuer()).thenReturn(mockIssuer);
    when(mockIssuer.getValue()).thenReturn(samlValidationIssuer);
    when(mockAssertion.getSignature()).thenReturn(mockSignature);

    DateTime notBefore = DateTime.now().plusMinutes(5);
    DateTime notOnOrAfter = DateTime.now().minusMinutes(5);
    when(mockAssertion.getConditions()).thenReturn(mockConditions);
    when(mockConditions.getNotBefore()).thenReturn(notBefore);
    when(mockConditions.getNotOnOrAfter()).thenReturn(notOnOrAfter);

    BasicX509Credential mockCredential = mock(BasicX509Credential.class);

    AuthenticationImpl spyAuthImpl = Mockito.spy(authenticationimpl);

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlResponseValidation", Response.class);
    method.setAccessible(true);
    try {
      SamlValidationResponse result =
          (SamlValidationResponse) method.invoke(spyAuthImpl, mockResponse);
      assertFalse(result.isValidationStatus());
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause();
      assertNotNull(cause);
    }
  }

  @Test
  void testSamlResponseValidation_InvalidSamlAssertionValidation() throws Exception {
    Response mockResponse = mock(Response.class);
    Assertion mockAssertion = mock(Assertion.class);
    org.opensaml.saml2.core.Issuer mockIssuer = mock(org.opensaml.saml2.core.Issuer.class);
    Signature mockSignature = mock(Signature.class);
    org.opensaml.saml2.core.Conditions mockConditions =
        mock(org.opensaml.saml2.core.Conditions.class);
    Attribute mockAttribute = mock(Attribute.class);
    XMLObject mockXmlObject = mock(XMLObject.class);

    when(mockResponse.getAssertions()).thenReturn(Collections.singletonList(mockAssertion));
    when(mockAssertion.getIssuer()).thenReturn(mockIssuer);
    when(mockIssuer.getValue()).thenReturn(samlValidationIssuer);
    when(mockAssertion.getSignature()).thenReturn(mockSignature);

    DateTime notBefore = DateTime.now().minusMinutes(5);
    DateTime notOnOrAfter = DateTime.now().plusMinutes(5);
    when(mockAssertion.getConditions()).thenReturn(mockConditions);
    when(mockConditions.getNotBefore()).thenReturn(notBefore);
    when(mockConditions.getNotOnOrAfter()).thenReturn(notOnOrAfter);

    BasicX509Credential mockCredential = mock(BasicX509Credential.class);

    AuthenticationImpl spyAuthImpl = Mockito.spy(authenticationimpl);

    Method method =
        AuthenticationImpl.class.getDeclaredMethod("samlResponseValidation", Response.class);
    method.setAccessible(true);
    try {
      SamlValidationResponse result =
          (SamlValidationResponse) method.invoke(spyAuthImpl, mockResponse);
      assertFalse(result.isValidationStatus());
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause();
      assertNotNull(cause);
    }
  }
}
