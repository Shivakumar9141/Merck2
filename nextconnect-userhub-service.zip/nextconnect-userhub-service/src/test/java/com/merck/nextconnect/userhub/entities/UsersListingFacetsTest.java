package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UsersListingFacetsTest {

  private UsersListingFacets facets;

  @BeforeEach
  public void setUp() {
    facets = new UsersListingFacets();
  }

  @Test
  public void testRoleGetterAndSetter() {
    List<String> roles = Arrays.asList("ADMIN", "USER");
    facets.setRole(roles);
    assertEquals(roles, facets.getRole());
  }

  @Test
  public void testStatusGetterAndSetter() {
    List<String> statuses = Arrays.asList("ACTIVE", "INACTIVE");
    facets.setStatus(statuses);
    assertEquals(statuses, facets.getStatus());
  }

  @Test
  public void testOrgGetterAndSetter() {
    List<String> orgs = Arrays.asList("Org1", "Org2");
    facets.setOrg(orgs);
    assertEquals(orgs, facets.getOrg());
  }

  @Test
  public void testCountryCodeGetterAndSetter() {
    List<String> countryCodes = Arrays.asList("US", "DE", "IN");
    facets.setCountryCode(countryCodes);
    assertEquals(countryCodes, facets.getCountryCode());
  }

  @Test
  public void testDefaultValues() {
    assertNull(facets.getRole());
    assertNull(facets.getStatus());
    assertNull(facets.getOrg());
    assertNull(facets.getCountryCode());
  }
}
