package com.merck.nextconnect.userhub.config;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Base64;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;

/** JUnit 5 conversion of MailConfigTest. */
@ExtendWith(MockitoExtension.class)
class MailConfigTest {

  @Mock private JavaMailSender javaMailSender;

  @Mock private MimeMessage mimeMessage;

  @InjectMocks private MailConfig mailConfig;

  @BeforeEach
  public void setUp() throws MessagingException {
    ReflectionTestUtils.setField(mailConfig, "headerName", "X-Custom-Header");
    ReflectionTestUtils.setField(mailConfig, "headerValue", "TestValue");
    ReflectionTestUtils.setField(mailConfig, "email", "test@example.com");

    when(javaMailSender.createMimeMessage()).thenReturn(mimeMessage);
    doNothing().when(mimeMessage).setFrom(any(InternetAddress.class));
  }

  @Test
  void testSendEmailInNonProdEnvironment() throws MessagingException {
    // Arrange
    String to = "recipient@example.com";
    String subject = "Test Subject";
    String body = "<p>Test Body</p>";
    String environment = "DEV";

    // Act
    mailConfig.send(to, subject, body, environment);

    // Assert
    verify(javaMailSender, times(1)).createMimeMessage();
    verify(mimeMessage, times(1)).setFrom(any(InternetAddress.class));

    // Verify header is set with Base64 encoded value
    String encodedValue = Base64.getEncoder().encodeToString("TestValue".getBytes());
    verify(mimeMessage, times(1)).setHeader("X-Custom-Header", encodedValue);

    verify(javaMailSender, times(1)).send(mimeMessage);
  }

  @Test
  void testSendEmailInProdEnvironment() throws MessagingException {
    // Arrange
    String to = "recipient@example.com";
    String subject = "Test Subject";
    String body = "<p>Test Body</p>";
    String environment = "PROD";

    // Act
    mailConfig.send(to, subject, body, environment);

    // Assert
    verify(javaMailSender, times(1)).createMimeMessage();
    verify(mimeMessage, times(1)).setFrom(any(InternetAddress.class));
    verify(javaMailSender, times(1)).send(mimeMessage);
  }
}
