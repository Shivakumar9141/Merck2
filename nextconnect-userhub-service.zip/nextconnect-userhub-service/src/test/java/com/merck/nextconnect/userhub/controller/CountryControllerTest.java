package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.CountryDTO;
import com.merck.nextconnect.userhub.model.CountryTimezoneDTO;
import com.merck.nextconnect.userhub.resources.ICountry;
import com.merck.nextconnect.userhub.resources.IRegion;
import com.merck.nextconnect.utils.common.entities.Country;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class CountryControllerTest {

  @Mock private ICountry iCountry;

  @Mock private IRegion iRegion;

  @InjectMocks private CountryController countryController;

  @Mock private Authentication authentication;

  @Mock private AuthenticatedUser authUser;
  @Mock AuditLoggerUtil auditLoggerUtil;
  @Mock AuditLogger auditLogger;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getId()).thenReturn("1");
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    Mockito.mock(AuditLoggerUtil.class);
  }

  @Test
  public void testGetCountries() {

    List<Country> countries = new ArrayList<>();
    Country country = new Country();
    country.setId(1);
    country.setCountryName("Test");
    countries.add(country);
    when(iCountry.getCountries("Test")).thenReturn(countries);
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    // when(AuditLoggerUtil.formatLog("resource", "action", null)).thenReturn("test string");
    ResponseEntity<List<Country>> responseEntity = countryController.getCountries("Test");

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(countries, responseEntity.getBody());
  }

  @Test
  public void testGetCountryByRegionId() {
    List<CountryDTO> countryDTOs = new ArrayList<>();
    CountryDTO countryDTO = new CountryDTO();
    countryDTO.setCountryId(1);
    countryDTO.setCountryName("Test");
    countryDTOs.add(countryDTO);
    List<Integer> list = new ArrayList<>();
    list.add(1);
    when(iRegion.getCountryByRegionId(list)).thenReturn(countryDTOs);
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    // when(AuditLoggerUtil.formatLog("resource", "action", null)).thenReturn("test string");

    // Removed unnecessary stub: Mockito.doNothing().when(auditLogger).auditLog("test");
    ResponseEntity<List<CountryDTO>> responseEntity = countryController.getCountryByRegionId(list);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(countryDTOs, responseEntity.getBody());
  }

  @Test
  public void testGetCountriesTimezone() {
    List<CountryTimezoneDTO> countryTimezoneDTOs = new ArrayList<>();
    CountryTimezoneDTO countryTimezoneDTO = new CountryTimezoneDTO();
    countryTimezoneDTO.setCountry(1);
    countryTimezoneDTOs.add(countryTimezoneDTO);
    when(iCountry.getCountriesTimezone(1)).thenReturn(countryTimezoneDTOs);

    ResponseEntity<List<CountryTimezoneDTO>> responseEntity =
        countryController.getCountriesTimezone(1);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(countryTimezoneDTOs, responseEntity.getBody());
  }
}
