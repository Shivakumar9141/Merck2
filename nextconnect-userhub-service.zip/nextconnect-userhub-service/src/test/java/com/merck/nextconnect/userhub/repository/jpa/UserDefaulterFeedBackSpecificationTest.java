package com.merck.nextconnect.userhub.repository.jpa;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.jpa.domain.Specification;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class UserDefaulterFeedBackSpecificationTest {

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @Mock private UserFeedBackRepository userFeedBackRepository;

  @InjectMocks private UserDefaulterFeedBackSpecification specification;

  private AuthenticatedUser authUser;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    // Setup authenticated user
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123L);
    jwtUser.setOrgId(1);
    jwtUser.setRole("ADMIN");
    jwtUser.setRoleId(1L);
  }

  @Test
  public void testSpecificationWithSearchCriteria() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Mock static method
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Setup fetch criteria with search
      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setSearchBy("Test Org");

      // Execute
      Specification<UserProfile> result = specification.specification(fetchCriteria);

      // Verify
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithFilters() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Mock static method
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Setup fetch criteria with filters
      FetchCriteria fetchCriteria = new FetchCriteria();
      List<String> filters =
          Arrays.asList("role.CUSTOMER_ADMIN", "orgName.TestOrg", "countryCode.US");
      fetchCriteria.setFilterBy(filters);

      // Execute
      Specification<UserProfile> result = specification.specification(fetchCriteria);

      // Verify
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationForDistributorFSE() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Setup distributor FSE user
      JwtUser jwtUser = new JwtUser();
      jwtUser.setRole(Constants.DISTRIBUTOR_FSE);
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Setup fetch criteria
      FetchCriteria fetchCriteria = new FetchCriteria();

      // Execute
      Specification<UserProfile> result = specification.specification(fetchCriteria);

      // Verify
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithNoFeedbackFilter() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      // Mock static method
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Setup fetch criteria with NOFEEDBACK filter
      FetchCriteria fetchCriteria = new FetchCriteria();
      List<String> filters = Arrays.asList(Constants.NOFEEDBACK);
      fetchCriteria.setFilterBy(filters);

      // Execute
      Specification<UserProfile> result = specification.specification(fetchCriteria);

      // Verify
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithSearchBy() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      AuthenticatedUser mockUser = Mockito.mock(AuthenticatedUser.class);
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(mockUser);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setSearchBy("TestOrg");

      Specification<UserProfile> spec = specification.specification(fetchCriteria);
      assertNotNull(spec);
    }
  }

  @Test
  public void testSpecificationWithRoleAndCountryCodeFilters() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      AuthenticatedUser mockUser = Mockito.mock(AuthenticatedUser.class);
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(mockUser);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setFilterBy(Arrays.asList("role.CUSTOMER_ADMIN", "countryCode.US"));

      Specification<UserProfile> spec = specification.specification(fetchCriteria);
      assertNotNull(spec);
    }
  }

  @Test
  public void testSpecificationWithAccessibleOrgs() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      AuthenticatedUser mockUser = Mockito.mock(AuthenticatedUser.class);
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(mockUser);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setFilterBy(Arrays.asList("role.CUSTOMER_ADMIN"));

      Specification<UserProfile> spec = specification.specification(fetchCriteria);
      assertNotNull(spec);
    }
  }

  @Test
  public void testSpecificationForDistributorFSEWithOrgs() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      AuthenticatedUser mockUser = Mockito.mock(AuthenticatedUser.class);
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(mockUser);

      FetchCriteria fetchCriteria = new FetchCriteria();

      Specification<UserProfile> spec = specification.specification(fetchCriteria);
      assertNotNull(spec);
    }
  }

  @Test
  public void testSpecificationWithNoFeedbackFilterAddsRoles() {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      AuthenticatedUser mockUser = Mockito.mock(AuthenticatedUser.class);
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(mockUser);

      FetchCriteria fetchCriteria = new FetchCriteria();
      fetchCriteria.setFilterBy(Arrays.asList(Constants.NOFEEDBACK));

      Specification<UserProfile> spec = specification.specification(fetchCriteria);
      assertNotNull(spec);
    }
  }
}
