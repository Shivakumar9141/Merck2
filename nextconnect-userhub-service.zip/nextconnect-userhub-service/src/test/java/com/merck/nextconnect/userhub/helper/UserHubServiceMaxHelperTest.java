package com.merck.nextconnect.userhub.helper;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.repo.jdbc.CoveredProductRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.DeviceRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserDevicePrivilegeRepository;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpClientErrorException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpServerErrorException;
import com.merck.nextconnect.utils.hazelcast.service.ServiceMaxTokenService;
import com.merck.nextconnect.utils.servicemax.model.ServiceMaxAuthInfo;
import com.merck.nextconnect.utils.servicemax.resources.ServiceMaxService;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class UserHubServiceMaxHelperTest {

  @Mock private ServiceMaxService serviceMaxService;
  @Mock private ServiceMaxTokenService serviceMaxTokenService;
  @Mock private CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;
  @Mock private DeviceRepositoryJdbc deviceRepositoryJdbc;
  @Mock private UserDevicePrivilegeRepository userDevicePrivilegeRepo;

  @InjectMocks private UserHubServiceMaxHelper userHubServiceMaxHelper;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smTockenURL", "http://token-url");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "tokenValidity", 3600L);
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smClientId", "client-id");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smClientSecret", "client-secret");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smUserName", "username");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smPassword", "password");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "maxRetry", 3);
    ReflectionTestUtils.setField(
        userHubServiceMaxHelper, "smInstalledProductURL", "http://ip-url/");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smCoveredProductURL", "http://cp-url/");
    ReflectionTestUtils.setField(userHubServiceMaxHelper, "smServiceURL", "http://service-url?");
  }

  @Test
  public void testGetSMToken()
      throws CustomHttpClientErrorException, CustomHttpServerErrorException {
    // Arrange
    String expectedToken = "test-token";
    when(serviceMaxService.getAuthToken(anyString(), any(ServiceMaxAuthInfo.class), anyLong()))
        .thenReturn(expectedToken);

    // Act
    String actualToken = userHubServiceMaxHelper.getSMToken();

    // Assert
    assertEquals(expectedToken, actualToken);
    verify(serviceMaxService)
        .getAuthToken(eq("http://token-url"), any(ServiceMaxAuthInfo.class), eq(3600L));
  }

  @Test
  public void testGetServiceMaxAuthInfo() {
    // Act
    ServiceMaxAuthInfo authInfo = userHubServiceMaxHelper.getServiceMaxAuthInfo();

    // Assert
    assertEquals("client-id", authInfo.getSmClientId());
    assertEquals("client-secret", authInfo.getSmClientSecret());
    assertEquals("username", authInfo.getSmUserName());
    assertEquals("password", authInfo.getSmPassword());
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_WhenActivatedAndCheckboxAlreadyTicked()
      throws Exception {
    // Arrange
    String smDeviceId = "device123";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, true);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, true);

    // Assert - should not update as checkbox is already ticked
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_WhenActivatedAndCheckboxNotTicked()
      throws Exception {
    // Arrange
    String smDeviceId = "device123";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, false);
    doNothing()
        .when(serviceMaxService)
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, true);

    // Assert - should update as checkbox is not ticked
    ArgumentCaptor<Map<String, Object>> paramsCaptor = ArgumentCaptor.forClass(Map.class);
    verify(serviceMaxService, times(1))
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            eq("http://ip-url/device123"),
            paramsCaptor.capture());

    Map<String, Object> params = paramsCaptor.getValue();
    assertEquals(true, params.get("Network__c"));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_WhenDeactivatedAndCheckboxNotTicked()
      throws Exception {
    // Arrange
    String smDeviceId = "device123";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, false);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, false);

    // Assert - should not update as checkbox is already unticked
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxCP_WhenActivatedAndCheckboxAlreadyTicked()
      throws Exception {
    // Arrange
    String smCoveredProductId = "cp123";
    mockIsMyMilliqActivatedCheckboxTicked("CP", smCoveredProductId, true);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxCP(smCoveredProductId, true);

    // Assert - should not update as checkbox is already ticked
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxCP_WhenActivatedAndCheckboxNotTicked()
      throws Exception {
    // Arrange
    String smCoveredProductId = "cp123";
    mockIsMyMilliqActivatedCheckboxTicked("CP", smCoveredProductId, false);
    doNothing()
        .when(serviceMaxService)
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxCP(smCoveredProductId, true);

    // Assert - should update as checkbox is not ticked
    ArgumentCaptor<Map<String, Object>> paramsCaptor = ArgumentCaptor.forClass(Map.class);
    verify(serviceMaxService, times(1))
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            eq("http://cp-url/cp123"),
            paramsCaptor.capture());

    Map<String, Object> params = paramsCaptor.getValue();
    assertEquals(true, params.get("Network__c"));
  }

  @Test
  public void testInvokeUpdateServiceMaxObjectAPI() {
    // Arrange
    String serviceUrl = "http://test-url";
    Map<String, Object> params = Map.of("key", "value");
    doNothing()
        .when(serviceMaxService)
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));

    // Act
    userHubServiceMaxHelper.invokeUpdateServiceMaxObjectAPI(serviceUrl, params);

    // Assert
    verify(serviceMaxService, times(1))
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            eq("http://token-url"),
            eq(3600L),
            eq(3),
            eq(serviceUrl),
            eq(params));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_Activated_CheckboxAlreadyTicked()
      throws Exception {
    // Arrange
    String smDeviceId = "device123";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, true);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, true);

    // Assert: Should not call update API since checkbox is already ticked
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_Activated_CheckboxNotTicked() throws Exception {
    // Arrange
    String smDeviceId = "device456";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, false);
    doNothing()
        .when(serviceMaxService)
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, true);

    // Assert: Should call update API since checkbox is not ticked
    ArgumentCaptor<Map<String, Object>> paramsCaptor = ArgumentCaptor.forClass(Map.class);
    verify(serviceMaxService, times(1))
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            eq("http://ip-url/" + smDeviceId),
            paramsCaptor.capture());
    Map<String, Object> params = paramsCaptor.getValue();
    assertEquals(true, params.get("Network__c"));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_Deactivated_CheckboxNotTicked()
      throws Exception {
    // Arrange
    String smDeviceId = "device789";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, false);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, false);

    // Assert: Should not call update API since checkbox is already unticked
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_Deactivated_CheckboxTicked() throws Exception {
    // Arrange
    String smDeviceId = "device999";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, true);
    doNothing()
        .when(serviceMaxService)
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, false);

    // Assert: Should call update API since checkbox is ticked and needs to be unticked
    ArgumentCaptor<Map<String, Object>> paramsCaptor = ArgumentCaptor.forClass(Map.class);
    verify(serviceMaxService, times(1))
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            eq("http://ip-url/" + smDeviceId),
            paramsCaptor.capture());
    Map<String, Object> params = paramsCaptor.getValue();
    assertEquals(false, params.get("Network__c"));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_Activated_CheckboxNull() throws Exception {
    // Arrange
    String smDeviceId = "deviceNull";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, null);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, true);

    // Assert: Should not call update API since checkbox is null (treated as already ticked)
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  @Test
  public void testUpdateMymilliqActivatedCheckBoxIP_Deactivated_CheckboxNull() throws Exception {
    // Arrange
    String smDeviceId = "deviceNull2";
    mockIsMyMilliqActivatedCheckboxTicked("IP", smDeviceId, null);

    // Act
    userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(smDeviceId, false);

    // Assert: Should not call update API since checkbox is null (treated as already unticked)
    verify(serviceMaxService, never())
        .invokeUpdateServiceMaxObjectAPI(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            anyString(),
            any(Map.class));
  }

  // Helper method to mock the isMyMilliqActivatedCheckboxTicked private method behavior
  private void mockIsMyMilliqActivatedCheckboxTicked(String flag, String id, Boolean returnValue)
      throws Exception {
    String query = "";
    if ("IP".equals(flag)) {
      query = "q=SELECT+Network__c+FROM+SVMXC__Installed_Product__c+WHERE+Id='" + id + "'";
    } else if ("CP".equals(flag)) {
      query = "q=SELECT+Network__c+FROM+SVMXC__Service_Contract_Products__c+WHERE+Id='" + id + "'";
    }

    String serviceUrl = "http://service-url?" + query;

    // Create JSON response
    JSONObject record = new JSONObject();
    record.put("Network__c", returnValue);

    JSONArray records = new JSONArray();
    records.put(record);

    JSONObject jsonResponse = new JSONObject();
    jsonResponse.put("records", records);

    ResponseEntity<String> response = new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);

    when(serviceMaxService.getServiceMaxData(
            any(ServiceMaxAuthInfo.class),
            anyString(),
            anyLong(),
            any(Integer.class),
            eq(serviceUrl)))
        .thenReturn(response);
  }
}
