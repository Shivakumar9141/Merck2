package com.merck.nextconnect.userhub.repository.ldap;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ldap.core.LdapTemplate;

public class AuthenticationRepositoryImplTest {

  @Mock private LdapTemplate sialLdap;

  @InjectMocks private AuthenticationRepositoryImpl authenticationRepository;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testAuthenticateByEmail_Success() {
    // Arrange
    String email = "test@sial.com";
    String password = "password";
    when(sialLdap.authenticate(anyString(), anyString(), anyString())).thenReturn(true);

    // Act
    boolean result = authenticationRepository.authenticateByEmail(email, password);

    // Assert
    assertTrue(result);
  }

  @Test
  public void testAuthenticateByEmail_Failure() {
    // Arrange
    String email = "test@sial.com";
    String password = "wrongpassword";
    when(sialLdap.authenticate(anyString(), anyString(), anyString())).thenReturn(false);

    // Act
    boolean result = authenticationRepository.authenticateByEmail(email, password);

    // Assert
    assertFalse(result);
  }

  @Test
  public void testAuthenticateByUsername_Success() {
    // Arrange
    String username = "testuser";
    String password = "password";
    when(sialLdap.authenticate(anyString(), anyString(), anyString())).thenReturn(true);

    // Act
    boolean result = authenticationRepository.authenticateByUsername(username, password);

    // Assert
    assertTrue(result);
  }

  @Test
  public void testAuthenticateByUsername_Failure() {
    // Arrange
    String username = "testuser";
    String password = "wrongpassword";
    when(sialLdap.authenticate(anyString(), anyString(), anyString())).thenReturn(false);

    // Act
    boolean result = authenticationRepository.authenticateByUsername(username, password);

    // Assert
    assertFalse(result);
  }
}
