package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RoleCardPrivilegeTest {

  private RoleCardPrivilege roleCardPrivilege;
  private Role role;
  private Privilege privilege;
  private Card card;

  @BeforeEach
  public void setUp() {
    roleCardPrivilege = new RoleCardPrivilege();
    role = new Role();
    privilege = new Privilege();
    card = new Card();

    // Set up test data
    Organization organization = new Organization();
    organization.setId(1);
    role.setOrg(organization);
    privilege.setprivilegeId(2);
    card.setId(3);
  }

  @Test
  public void testGetSetId() {
    long id = 123L;
    roleCardPrivilege.setId(id);
    assertEquals(id, roleCardPrivilege.getId());
  }

  @Test
  public void testGetSetRole() {
    roleCardPrivilege.setRole(role);
    assertEquals(role, roleCardPrivilege.getRole());
  }

  @Test
  public void testGetSetPrivilege() {
    roleCardPrivilege.setPrivilege(privilege);
    assertEquals(privilege, roleCardPrivilege.getPrivilege());
  }

  @Test
  public void testGetSetCard() {
    roleCardPrivilege.setCard(card);
    assertEquals(card, roleCardPrivilege.getCard());
  }
}
