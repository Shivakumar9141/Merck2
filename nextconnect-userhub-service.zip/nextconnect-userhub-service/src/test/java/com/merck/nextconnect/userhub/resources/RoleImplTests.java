package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupAccess;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleInfo;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.impl.RoleImpl;
import com.merck.nextconnect.userhub.resources.impl.UserRolePrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("RoleImpl Service Tests")
public class RoleImplTests {

  @InjectMocks private RoleImpl roleImpl;

  @Mock private RoleRepository roleRepo;

  @Mock private OrganizationRepository orgRepo;

  @Mock private IOrgPermissions orgPermissions;

  @Mock private UserRepository userRepo;

  @Mock private AuthenticatedUser authUser;

  @Mock private UserRolePrivileges userRolePrivileges;

  @Mock
  private com.merck.nextconnect.userhub.repository.jpa.RoleEntityPrivilegesRepository
      roleEntityPrivilegesRepo;

  @Mock
  private com.merck.nextconnect.userhub.repository.jpa.RoleDeviceTypePrivilegesRepository
      roleDeviceTypePrivilegesRepo;

  @Mock
  private com.merck.nextconnect.userhub.repository.jpa.RoleDeviceGroupPrivilegesRepository
      roleDeviceGroupPrivilegesRepo;

  @Mock
  private com.merck.nextconnect.userhub.repository.jpa.RoleCardPrivilegesRepository
      roleCardPrivilegesRepo;

  private MockedStatic<UserhubUtils> mockedUtils;

  private Role role1;
  private Role role2;
  private Role role3;
  private Organization organization;
  private List<Role> roles;

  @BeforeEach
  public void setup() {
    // Mock UserhubUtils static method
    mockedUtils = Mockito.mockStatic(UserhubUtils.class);
    mockedUtils.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
    mockedUtils.when(() -> UserhubUtils.validatePattern(anyString(), anyString())).thenReturn(true);

    // Mock authUser properties
    when(authUser.getOrgId()).thenReturn(5);
    when(authUser.getId()).thenReturn("1");
    when(authUser.getRoleId()).thenReturn(1L);
    when(authUser.getRole()).thenReturn("Admin");
    when(authUser.isSystemDefinedRole()).thenReturn(false);

    // Inject mocked repositories into UserRolePrivileges using reflection
    ReflectionTestUtils.setField(
        userRolePrivileges, "roleEntityPrivilegesRepo", roleEntityPrivilegesRepo);
    ReflectionTestUtils.setField(
        userRolePrivileges, "roleDeviceTypePrivilegesRepo", roleDeviceTypePrivilegesRepo);
    ReflectionTestUtils.setField(
        userRolePrivileges, "roleDeviceGroupPrivilegesRepo", roleDeviceGroupPrivilegesRepo);

    // Initialize test data
    // Initialize test data
    role1 = new Role();
    role1.setRoleId(1L);
    role1.setName("role1");
    role1.setSystemDefined(false);

    role2 = new Role();
    role2.setRoleId(2);
    role2.setName("role2");
    role2.setSystemDefined(false);

    role3 = new Role();
    role3.setRoleId(3);
    role3.setName("Customer Admin");
    role3.setSystemDefined(true);

    roles = new ArrayList<>();
    roles.add(role1);
    roles.add(role2);
    roles.add(role3);

    organization = new Organization(5);
    organization.setName("Test Org");
    organization.setType(Constants.CUSTOMER);
  }

  @AfterEach
  public void tearDown() {
    if (mockedUtils != null) {
      mockedUtils.close();
    }
  }

  @Test
  @DisplayName("Test add role successfully")
  public void testAddRole_Success() throws DuplicateResourceException, DataValidationException {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("TestRole");

    when(roleRepo.getRoleByName("TestRole", 5)).thenReturn(null);
    when(orgRepo.findById(5)).thenReturn(Optional.of(organization));
    when(roleRepo.save(any(Role.class))).thenReturn(role1);

    // Act
    long roleId = roleImpl.add(roleInfo);

    // Assert
    assertEquals(1L, roleId);
    verify(roleRepo, times(1)).getRoleByName("TestRole", 5);
    verify(roleRepo, times(1)).save(any(Role.class));
  }

  @Test
  @DisplayName("Test add role with invalid name throws DataValidationException")
  public void testAddRole_InvalidName() {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("Invalid@Role#Name");

    mockedUtils
        .when(() -> UserhubUtils.validatePattern(anyString(), eq("Invalid@Role#Name")))
        .thenReturn(false);

    // Act & Assert
    assertThrows(DataValidationException.class, () -> roleImpl.add(roleInfo));
  }

  @Test
  @DisplayName("Test add role with duplicate name throws DuplicateResourceException")
  public void testAddRole_DuplicateName() {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("DuplicateRole");

    when(roleRepo.getRoleByName("DuplicateRole", 5)).thenReturn(role1);

    // Act & Assert
    assertThrows(DuplicateResourceException.class, () -> roleImpl.add(roleInfo));
  }

  @Test
  @DisplayName("Test delete non-system defined role with no users")
  public void testDelete_Success() throws DataValidationException {
    // Arrange
    // Inject mocked repositories into UserRolePrivileges for this specific test
    ReflectionTestUtils.setField(
        userRolePrivileges, "roleEntityPrivilegesRepo", roleEntityPrivilegesRepo);
    ReflectionTestUtils.setField(
        userRolePrivileges, "roleDeviceTypePrivilegesRepo", roleDeviceTypePrivilegesRepo);
    ReflectionTestUtils.setField(
        userRolePrivileges, "roleDeviceGroupPrivilegesRepo", roleDeviceGroupPrivilegesRepo);

    when(roleRepo.getRoleByOrg(1L, 5)).thenReturn(role1);
    when(userRepo.getUsersByRole(1L, 5)).thenReturn(new ArrayList<>());
    when(userRepo.removeDeletedUsersRole(1L, 5)).thenReturn(1);
    when(roleEntityPrivilegesRepo.deleteByRoleId(1L)).thenReturn(1);
    when(roleDeviceTypePrivilegesRepo.deleteByRoleId(1L)).thenReturn(1);
    when(roleDeviceGroupPrivilegesRepo.deleteByRoleId(1L)).thenReturn(1);
    doNothing().when(userRolePrivileges).deleteMeasureEventGroupsByRoleId(1L);
    doNothing().when(userRolePrivileges).deleteOrgPrivilegesByRoleId(1L);
    when(roleCardPrivilegesRepo.deleteByRoleId(1L)).thenReturn(1);
    when(roleRepo.deleteByOrgId(1L, 5)).thenReturn(1);

    // Act
    roleImpl.delete(1L);

    // Assert
    verify(roleRepo, times(1)).deleteByOrgId(1L, 5);
    verify(userRepo, times(1)).removeDeletedUsersRole(1L, 5);
  }

  @Test
  @DisplayName("Test delete system defined role throws DataValidationException")
  public void testDelete_SystemDefinedRole() {
    // Arrange
    when(roleRepo.getRoleByOrg(3L, 5)).thenReturn(role3);

    // Act & Assert
    assertThrows(DataValidationException.class, () -> roleImpl.delete(3L));
  }

  @Test
  @DisplayName("Test delete role with assigned users throws DataValidationException")
  public void testDelete_RoleWithUsers() {
    // Arrange
    List<UserProfile> users = new ArrayList<>();
    users.add(new UserProfile());

    when(roleRepo.getRoleByOrg(1L, 5)).thenReturn(role1);
    when(userRepo.getUsersByRole(1L, 5)).thenReturn(users);

    // Act & Assert
    assertThrows(DataValidationException.class, () -> roleImpl.delete(1L));
  }

  @Test
  @DisplayName("Test getAll roles for current org")
  public void testGetAll_CurrentOrg() throws ResourceNotFoundException {
    // Arrange
    when(roleRepo.getUserDefinedRoles(5)).thenReturn(roles);
    when(userRepo.findById(1L)).thenReturn(Optional.of(new UserProfile()));

    // Act
    List<Role> result = roleImpl.getAll(null);

    // Assert
    assertNotNull(result);
    verify(roleRepo, times(1)).getUserDefinedRoles(5);
  }

  @Test
  @DisplayName("Test getAll roles for different org with access")
  public void testGetAll_DifferentOrgWithAccess() throws ResourceNotFoundException {
    // Arrange
    int orgId = 10;
    when(orgPermissions.hasRoleAccess(orgId, OrgPrivileges.manage_accounts)).thenReturn(true);
    when(roleRepo.getRoles(orgId)).thenReturn(roles);
    when(orgRepo.findOrgById(orgId)).thenReturn(Optional.of(organization));
    when(userRepo.findById(1L)).thenReturn(Optional.of(new UserProfile()));

    // Act
    List<Role> result = roleImpl.getAll(orgId);

    // Assert
    assertNotNull(result);
    verify(roleRepo, times(1)).getRoles(orgId);
  }

  @Test
  @DisplayName("Test getAll roles for different org without access throws AccessDeniedException")
  public void testGetAll_DifferentOrgNoAccess() {
    // Arrange
    int orgId = 10;
    when(orgPermissions.hasRoleAccess(orgId, OrgPrivileges.manage_accounts)).thenReturn(false);

    // Act & Assert
    assertThrows(AccessDeniedException.class, () -> roleImpl.getAll(orgId));
  }

  @Test
  @DisplayName("Test update role successfully")
  public void testUpdate_Success()
      throws DataValidationException, DuplicateResourceException, ResourceNotFoundException {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("UpdatedRole");

    when(roleRepo.getRoleByOrg(1L, 5)).thenReturn(role1);
    when(roleRepo.getRoleByName("UpdatedRole", 5)).thenReturn(null);
    when(roleRepo.update("UpdatedRole", 1L, 5)).thenReturn(1);

    // Act
    roleImpl.update(roleInfo, 1L);

    // Assert
    verify(roleRepo, times(1)).update("UpdatedRole", 1L, 5);
  }

  @Test
  @DisplayName("Test update system defined role throws DataValidationException")
  public void testUpdate_SystemDefinedRole() {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("UpdatedRole");

    when(roleRepo.getRoleByOrg(3L, 5)).thenReturn(role3);

    // Act & Assert
    assertThrows(DataValidationException.class, () -> roleImpl.update(roleInfo, 3L));
  }

  @Test
  @DisplayName("Test update role with invalid name throws DataValidationException")
  public void testUpdate_InvalidName() {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("Invalid@Name");

    when(roleRepo.getRoleByOrg(1L, 5)).thenReturn(role1);
    mockedUtils
        .when(() -> UserhubUtils.validatePattern(anyString(), eq("Invalid@Name")))
        .thenReturn(false);

    // Act & Assert
    assertThrows(DataValidationException.class, () -> roleImpl.update(roleInfo, 1L));
  }

  @Test
  @DisplayName("Test update role with duplicate name throws DuplicateResourceException")
  public void testUpdate_DuplicateName() {
    // Arrange
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("DuplicateRole");

    when(roleRepo.getRoleByOrg(1L, 5)).thenReturn(role1);
    when(roleRepo.getRoleByName("DuplicateRole", 5)).thenReturn(role2);

    // Act & Assert
    assertThrows(DuplicateResourceException.class, () -> roleImpl.update(roleInfo, 1L));
  }

  @Test
  @DisplayName("Test fetchOne returns role")
  public void testFetchOne_Success() {
    // Arrange
    when(roleRepo.getRoleByOrg(1L, 5)).thenReturn(role1);

    // Act
    Role result = roleImpl.fetchOne(1L);

    // Assert
    assertNotNull(result);
    assertEquals("role1", result.getName());
    verify(roleRepo, times(1)).getRoleByOrg(1L, 5);
  }

  @Test
  @DisplayName("Test getPrivileges with filterBy DEVICETYPE")
  public void testGetPrivileges_WithDeviceTypeFilter() throws ResourceNotFoundException {
    // Arrange
    long roleId = 1L;
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();
    RolePrivilege privilege = new RolePrivilege();
    privilege.setPrivilegeId(1);
    expectedPrivileges.add(privilege);

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    when(userRolePrivileges.getDeviceTypePrivileges(roleId, Constants.ROLE))
        .thenReturn(expectedPrivileges);

    // Act
    List<RolePrivilege> result = roleImpl.getPrivileges(roleId, Constants.DEVICETYPE);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    verify(userRolePrivileges, times(1)).getDeviceTypePrivileges(roleId, Constants.ROLE);
  }

  @Test
  @DisplayName("Test getPrivileges with filterBy ENTITY")
  public void testGetPrivileges_WithEntityFilter() throws ResourceNotFoundException {
    // Arrange
    long roleId = 1L;
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    when(userRolePrivileges.getEntityPrivileges(roleId, Constants.ROLE))
        .thenReturn(expectedPrivileges);

    // Act
    List<RolePrivilege> result = roleImpl.getPrivileges(roleId, Constants.ENTITY);

    // Assert
    assertNotNull(result);
    verify(userRolePrivileges, times(1)).getEntityPrivileges(roleId, Constants.ROLE);
  }

  @Test
  @DisplayName("Test getPrivileges with filterBy CARD")
  public void testGetPrivileges_WithCardFilter() throws ResourceNotFoundException {
    // Arrange
    long roleId = 1L;
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    when(userRolePrivileges.getCardPrivileges(roleId)).thenReturn(expectedPrivileges);

    // Act
    List<RolePrivilege> result = roleImpl.getPrivileges(roleId, Constants.CARD);

    // Assert
    assertNotNull(result);
    verify(userRolePrivileges, times(1)).getCardPrivileges(roleId);
  }

  @Test
  @DisplayName("Test getPrivileges without filter returns all privileges")
  public void testGetPrivileges_NoFilter() throws ResourceNotFoundException {
    // Arrange
    long roleId = 1L;
    List<RolePrivilege> deviceTypePrivileges = new ArrayList<>();
    List<RolePrivilege> entityPrivileges = new ArrayList<>();
    List<RolePrivilege> cardPrivileges = new ArrayList<>();

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    when(userRolePrivileges.getDeviceTypePrivileges(roleId, Constants.ROLE))
        .thenReturn(deviceTypePrivileges);
    when(userRolePrivileges.getEntityPrivileges(roleId, Constants.ROLE))
        .thenReturn(entityPrivileges);
    when(userRolePrivileges.getCardPrivileges(roleId)).thenReturn(cardPrivileges);

    // Act
    List<RolePrivilege> result = roleImpl.getPrivileges(roleId, null);

    // Assert
    assertNotNull(result);
    verify(userRolePrivileges, times(1)).getDeviceTypePrivileges(roleId, Constants.ROLE);
    verify(userRolePrivileges, times(1)).getEntityPrivileges(roleId, Constants.ROLE);
    verify(userRolePrivileges, times(1)).getCardPrivileges(roleId);
  }

  @Test
  @DisplayName("Test getPrivileges throws exception when role not found")
  public void testGetPrivileges_RoleNotFound() {
    // Arrange
    long roleId = 999L;
    when(roleRepo.findById(roleId)).thenReturn(Optional.empty());

    // Act & Assert
    assertThrows(
        java.util.NoSuchElementException.class, () -> roleImpl.getPrivileges(roleId, null));
  }

  @Test
  @DisplayName("Test addPrivileges successfully")
  public void testAddPrivileges_Success() {
    // Arrange
    long roleId = 1L;
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
    ResourcePrivilege privilege = new ResourcePrivilege();
    resourcePrivileges.add(privilege);

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    doNothing().when(userRolePrivileges).addPrivilegeToRole(resourcePrivileges, role1);

    // Act
    roleImpl.addPrivileges(roleId, resourcePrivileges);

    // Assert
    verify(roleRepo, times(1)).findById(roleId);
    verify(userRolePrivileges, times(1)).addPrivilegeToRole(resourcePrivileges, role1);
  }

  @Test
  @DisplayName("Test deletePrivileges successfully")
  public void testDeletePrivileges_Success() {
    // Arrange
    long roleId = 1L;
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    doNothing().when(userRolePrivileges).deletePrivilegeToRole(resourcePrivileges, role1);

    // Act
    roleImpl.deletePrivileges(roleId, resourcePrivileges);

    // Assert
    verify(roleRepo, times(1)).findById(roleId);
    verify(userRolePrivileges, times(1)).deletePrivilegeToRole(resourcePrivileges, role1);
  }

  @Test
  @DisplayName("Test getDeviceGroupPrivileges successfully")
  public void testGetDeviceGroupPrivileges_Success() throws ResourceNotFoundException {
    // Arrange
    long roleId = 1L;
    long deviceTypeId = 10L;
    DeviceGroupPrivilege privilege = new DeviceGroupPrivilege();

    when(roleRepo.getRoleByOrg(roleId, 5)).thenReturn(role1);
    when(userRolePrivileges.getDeviceGroupPrivileges(roleId, deviceTypeId, Constants.ROLE))
        .thenReturn(privilege);

    // Act
    DeviceGroupPrivilege result = roleImpl.getDeviceGroupPrivileges(roleId, deviceTypeId);

    // Assert
    assertNotNull(result);
    verify(roleRepo, times(1)).getRoleByOrg(roleId, 5);
    verify(userRolePrivileges, times(1))
        .getDeviceGroupPrivileges(roleId, deviceTypeId, Constants.ROLE);
  }

  @Test
  @DisplayName("Test getDeviceGroupPrivileges throws ResourceNotFoundException when role not found")
  public void testGetDeviceGroupPrivileges_RoleNotFound() {
    // Arrange
    long roleId = 999L;
    long deviceTypeId = 10L;

    when(roleRepo.getRoleByOrg(roleId, 5)).thenReturn(null);

    // Act & Assert
    assertThrows(
        ResourceNotFoundException.class,
        () -> roleImpl.getDeviceGroupPrivileges(roleId, deviceTypeId));
  }

  @Test
  @DisplayName("Test addDeviceGroupPrivileges successfully")
  public void testAddDeviceGroupPrivileges_Success() {
    // Arrange
    long roleId = 1L;
    List<DeviceGroupAccess> deviceGroupAccessList = new ArrayList<>();
    DeviceGroupAccess access = new DeviceGroupAccess();
    deviceGroupAccessList.add(access);

    when(roleRepo.getRoleByOrg(roleId, 5)).thenReturn(role1);
    doNothing()
        .when(userRolePrivileges)
        .addDeviceGroupPrivilegeToRole(deviceGroupAccessList, role1);

    // Act
    roleImpl.addDeviceGroupPrivileges(roleId, deviceGroupAccessList);

    // Assert
    verify(roleRepo, times(1)).getRoleByOrg(roleId, 5);
    verify(userRolePrivileges, times(1))
        .addDeviceGroupPrivilegeToRole(deviceGroupAccessList, role1);
  }

  @Test
  @DisplayName("Test deleteDeviceGroupPrivileges successfully")
  public void testDeleteDeviceGroupPrivileges_Success() {
    // Arrange
    long roleId = 1L;
    List<DeviceGroupAccess> deviceGroupAccessList = new ArrayList<>();

    when(roleRepo.getRoleByOrg(roleId, 5)).thenReturn(role1);
    doNothing()
        .when(userRolePrivileges)
        .deleteDeviceGroupPrivilegeToRole(deviceGroupAccessList, role1);

    // Act
    roleImpl.deleteDeviceGroupPrivileges(roleId, deviceGroupAccessList);

    // Assert
    verify(roleRepo, times(1)).getRoleByOrg(roleId, 5);
    verify(userRolePrivileges, times(1))
        .deleteDeviceGroupPrivilegeToRole(deviceGroupAccessList, role1);
  }

  @Test
  @DisplayName("Test getPrivileges with roleId only")
  public void testGetPrivileges_RoleIdOnly() throws ResourceNotFoundException {
    // Arrange
    long roleId = 1L;
    List<RolePrivilege> deviceTypePrivileges = new ArrayList<>();
    List<RolePrivilege> entityPrivileges = new ArrayList<>();
    List<RolePrivilege> cardPrivileges = new ArrayList<>();

    when(roleRepo.findById(roleId)).thenReturn(Optional.of(role1));
    when(userRolePrivileges.getDeviceTypePrivileges(roleId, Constants.ROLE))
        .thenReturn(deviceTypePrivileges);
    when(userRolePrivileges.getEntityPrivileges(roleId, Constants.ROLE))
        .thenReturn(entityPrivileges);
    when(userRolePrivileges.getCardPrivileges(roleId)).thenReturn(cardPrivileges);

    // Act
    List<RolePrivilege> result = roleImpl.getPrivileges(roleId);

    // Assert
    assertNotNull(result);
    verify(roleRepo, times(1)).findById(roleId);
  }
}
