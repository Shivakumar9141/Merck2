package com.merck.nextconnect.userhub.model;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.entities.Menu;
import com.merck.nextconnect.userhub.entities.UserMenu;
import org.junit.jupiter.api.Test;

public class MenuDTOTest {

  @Test
  public void testConverter() {
    // Arrange
    Menu menu = new Menu();
    menu.setMenu_id(1);
    menu.setDefaultSequence(2);
    menu.setIconRelativeUriImage("icon/path.png");
    menu.setActive(true);
    menu.setToolTip("Sample tooltip");
    menu.setMandatory(false);
    menu.setMenu_key("menu_key_1");

    // Act
    MenuDTO result = MenuDTO.converter(menu);

    // Assert
    assertEquals(1, result.getMenuId());
    assertEquals(2, result.getMenuSequence());
    assertEquals("icon/path.png", result.getIconUriImage());
    assertTrue(result.isVisible());
    assertEquals("Sample tooltip", result.getToolTip());
    assertFalse(result.isMandatory());
    assertEquals("menu_key_1", result.getMenuKey());
  }

  @Test
  public void testExistingUserMenu() {
    // Arrange
    Menu menu = new Menu();
    menu.setMenu_id(3);
    menu.setIconRelativeUriImage("user/icon.png");
    menu.setToolTip("User menu tooltip");
    menu.setMandatory(true);
    menu.setMenu_key("user_menu_key");

    UserMenu userMenu = new UserMenu();
    userMenu.setMenu(menu);
    userMenu.setSequence(5);
    userMenu.setVisible(false);

    // Act
    MenuDTO result = MenuDTO.existingUserMenu(userMenu);

    // Assert
    assertEquals(3, result.getMenuId());
    assertEquals(5, result.getMenuSequence());
    assertEquals("user/icon.png", result.getIconUriImage());
    assertFalse(result.isVisible());
    assertEquals("User menu tooltip", result.getToolTip());
    assertTrue(result.isMandatory());
    assertEquals("user_menu_key", result.getMenuKey());
  }
}
