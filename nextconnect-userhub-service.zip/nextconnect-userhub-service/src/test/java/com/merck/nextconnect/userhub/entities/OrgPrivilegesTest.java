package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class OrgPrivilegesTest {

  private OrgPrivileges orgPrivileges;
  private Privilege privilege;
  private Organization org;

  @BeforeEach
  public void setUp() {
    orgPrivileges = new OrgPrivileges();
    privilege = new Privilege();
    org = new Organization();
  }

  @Test
  public void testGetSetId() {
    int id = 123;
    orgPrivileges.setId(id);
    assertEquals(id, orgPrivileges.getId());
  }

  @Test
  public void testGetSetPrivilege() {
    privilege.setprivilegeId(1);
    privilege.setOperation("TestPrivilege");
    orgPrivileges.setPrivilege(privilege);
    assertEquals(privilege, orgPrivileges.getPrivilege());
    assertEquals("TestPrivilege", orgPrivileges.getPrivilege().getOperation());
  }

  @Test
  public void testGetSetOrg() {
    org.setId(1);
    org.setName("TestOrg");
    orgPrivileges.setOrg(org);
    assertEquals(org, orgPrivileges.getOrg());
    assertEquals("TestOrg", orgPrivileges.getOrg().getName());
  }

  @Test
  public void testGetSetType() {
    String type = "READ";
    orgPrivileges.setType(type);
    assertEquals(type, orgPrivileges.getType());
  }

  @Test
  public void testDefaultConstructor() {
    OrgPrivileges newOrgPrivileges = new OrgPrivileges();
    assertNotNull(newOrgPrivileges);
  }
}
