package com.merck.nextconnect.userhub.mail.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.config.MailConfig;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

public class MailServiceTest {

  @InjectMocks private MailService mailService;

  @Mock private MailConfig mailConfig;

  @Mock private EmailTemplateService emailTemplateService;

  @Mock private EmailService emailService;

  @Mock private SecurityContext securityContext;

  @Mock private Authentication authentication;

  private AuthenticatedUser authUser;
  private UserProfile userProfile;
  private EmailTemplate emailTemplate;

  @BeforeEach
  public void setUp() {
    // Initialize mocks with lenient settings
    MockitoAnnotations.openMocks(this);

    // Set up properties via reflection
    ReflectionTestUtils.setField(mailService, "fromEmail", "test@example.com");
    ReflectionTestUtils.setField(mailService, "loginUrl", "http://example.com/login");
    ReflectionTestUtils.setField(mailService, "resetPasswordUrl", "http://example.com/reset");
    ReflectionTestUtils.setField(mailService, "registrationUrl", "http://example.com/register");
    ReflectionTestUtils.setField(mailService, "nextconnectEnvironment", "test");

    // Set up user profile
    userProfile = new UserProfile();
    userProfile.setEmail("user@example.com");
    userProfile.setLoginName("testuser");
    userProfile.setFirstName("Test");
    userProfile.setLastName("User");

    // Set up organization
    Organization org = new Organization();
    org.setName("TestOrg");
    userProfile.setOrg(org);

    // Set up language
    Language language = new Language();
    language.setId(1);
    userProfile.setLanguage(language);

    // Set up user domain
    UserDomain userDomain = new UserDomain();
    userDomain.setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.setUserDomain(userDomain);

    // Set up authenticated user
    com.merck.nextconnect.authfilter.model.JwtUser jwtUser =
        new com.merck.nextconnect.authfilter.model.JwtUser();
    jwtUser.setId(123L);
    authUser = new AuthenticatedUser(jwtUser, "password", new java.util.ArrayList<>());

    // Set up email template
    emailTemplate = new EmailTemplate();
    emailTemplate.setOrgId("1");
  }

  @Test
  public void testSendMailMethod() throws AddressException, MessagingException {
    // Arrange
    String to = "test@example.com";
    String subject = "Test Subject";
    String body = "Test Body";
    String environment = "test";

    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.sendMail(to, subject, body, environment);

    // Assert
    verify(mailConfig, times(1)).send(to, subject, body, environment);
  }

  @Test
  public void testIsLabwaterOrgWithDirectLabwaterOrg() {
    // Arrange
    Organization org = new Organization();
    org.setName(Constants.LABWATER);
    userProfile.setOrg(org);

    // Act
    boolean result = invokeIsLabwaterOrg(userProfile);

    // Assert
    assertTrue(result);
  }

  @Test
  public void testIsLabwaterOrgWithParentLabwaterOrg() {
    // Arrange
    Organization parentOrg = new Organization();
    parentOrg.setName(Constants.LABWATER);

    Organization org = new Organization();
    org.setName("ChildOrg");
    org.setParent(parentOrg);

    userProfile.setOrg(org);

    // Act
    boolean result = invokeIsLabwaterOrg(userProfile);

    // Assert
    assertTrue(result);
  }

  @Test
  public void testIsLabwaterOrgWithNonLabwaterOrg() {
    // Arrange
    Organization org = new Organization();
    org.setName("NonLabwater");
    userProfile.setOrg(org);

    // Act
    boolean result = invokeIsLabwaterOrg(userProfile);

    // Assert
    assertFalse(result);
  }

  @Test
  public void testSendInviteEmailForNextconnectAuth() throws Exception {
    // Arrange
    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Mock mailConfig.send to avoid actual email sending
      doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jti123", "test");

      // Assert
      verify(mailConfig, times(1))
          .send(eq(userProfile.getEmail()), anyString(), anyString(), eq("test"));
    }
  }

  @Test
  public void testSendPasswordResetEmailForNextconnectAuth() throws Exception {
    // Arrange
    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Mock mailConfig.send to avoid actual email sending
      doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

      // Act
      mailService.send(userProfile, Constants.RESET_PASSWORD, "jti123", "test");

      // Assert
      verify(mailConfig, times(1))
          .send(eq(userProfile.getEmail()), anyString(), anyString(), eq("test"));
    }
  }

  @Test
  public void testSendInviteEmailForSelfRegistration() throws Exception {
    // Arrange
    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      userProfile.setInvitedVia(UserInvitedVia.SELF_REGISTRATION.value());
      userProfile.setAutoCreated(true);

      Organization org = new Organization();
      org.setName(Constants.LABWATER);
      userProfile.setOrg(org);

      // For Labwater org with self-registration, the implementation uses emailService
      when(emailTemplateService.findByCategoryAndLanguageId(
              eq(Constants.INVITE_USER_AUTO_ORG_SELF_REG), eq(1)))
          .thenReturn(emailTemplate);
      when(emailService.sendMail(any(), anyString())).thenReturn(true);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jti123", "test");

      // Assert - for Labwater org with self-registration, emailService is used
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSendAccountActivationEmail() throws Exception {
    // Arrange
    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Mock mailConfig.send to avoid actual email sending
      doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

      // Act
      mailService.send(userProfile, "ACCOUNT_ACTIVATION", "jti123", "test");

      // Assert
      verify(mailConfig, times(1))
          .send(eq(userProfile.getEmail()), anyString(), anyString(), eq("test"));
    }
  }

  @Test
  public void testSendAccountLockedEmail() throws Exception {
    // Arrange
    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Mock mailConfig.send to avoid actual email sending
      doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

      // Act
      mailService.send(userProfile, "ACCOUNT_LOCKED", "jti123", "test");

      // Assert
      verify(mailConfig, times(1))
          .send(eq(userProfile.getEmail()), anyString(), anyString(), eq("test"));
    }
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_InviteUser_SelfRegistration() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    userProfile.setInvitedVia(UserInvitedVia.SELF_REGISTRATION.value());
    userProfile.setAutoCreated(true);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_AUTO_ORG_SELF_REG), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(emailService, times(1)).sendMail(any(), eq("test"));
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_InviteUser_Manual() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    userProfile.setInvitedVia("MANUAL");
    userProfile.setAutoCreated(false);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_SelfRegistration() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    userProfile.setInvitedVia(UserInvitedVia.SELF_REGISTRATION.value());
    userProfile.setAutoCreated(true);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_AUTO_ORG_SELF_REG), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(emailService, times(1)).sendMail(any(), eq("test"));
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_ManualInvite() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    userProfile.setInvitedVia("MANUAL");
    userProfile.setAutoCreated(false);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSend_NextconnectAuth_NonLabwaterOrg_InviteUser() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_INVITATION),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_NextconnectAuth_NonLabwaterOrg_ResetPassword() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.RESET_PASSWORD, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_PASSWORD_UPDATE),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_ResetPassword() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    EmailTemplate resetTemplate = new EmailTemplate();
    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            eq(Constants.PASSWORD_FORGOT), eq(1), eq(Constants.ACTIVE)))
        .thenReturn(resetTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    // Act
    mailService.send(userProfile, Constants.RESET_PASSWORD, "jtiToken", "test");

    // Assert
    verify(emailService, times(1)).sendMail(any(), eq("test"));
  }

  @Test
  public void testSend_MerckAuth_NonLabwaterOrg() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.MERCK_AUTH);
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_INVITATION),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_MerckAuth_LabwaterOrg() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.MERCK_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSend_SialAuth_NonLabwaterOrg() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider("SIAL_AUTH");
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_INVITATION),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_SialAuth_LabwaterOrg() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider("SIAL_AUTH");
    userProfile.getOrg().setName(Constants.LABWATER);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  private boolean invokeIsLabwaterOrg(UserProfile userProfile) {
    try {
      java.lang.reflect.Method method =
          MailService.class.getDeclaredMethod("isLabwaterOrg", UserProfile.class);
      method.setAccessible(true);
      return (boolean) method.invoke(mailService, userProfile);
    } catch (Exception e) {
      throw new RuntimeException("Failed to invoke isLabwaterOrg method", e);
    }
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_Manual_EmailServiceCalled() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    userProfile.setInvitedVia("MANUAL");
    userProfile.setAutoCreated(false);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSend_NextconnectAuth_NonLabwaterOrg_InviteUser_MailConfigCalled()
      throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_INVITATION),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_NextconnectAuth_NonLabwaterOrg_ResetPassword_MailConfigCalled()
      throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.RESET_PASSWORD, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_PASSWORD_UPDATE),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_NextconnectAuth_LabwaterOrg_ResetPassword_EmailServiceCalled()
      throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    EmailTemplate resetTemplate = new EmailTemplate();
    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            eq(Constants.PASSWORD_FORGOT), eq(1), eq(Constants.ACTIVE)))
        .thenReturn(resetTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    // Act
    mailService.send(userProfile, Constants.RESET_PASSWORD, "jtiToken", "test");

    // Assert
    verify(emailService, times(1)).sendMail(any(), eq("test"));
  }

  @Test
  public void testSend_MerckAuth_LabwaterOrg_EmailServiceCalled() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.MERCK_AUTH);
    userProfile.getOrg().setName(Constants.LABWATER);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSend_MerckAuth_NonLabwaterOrg_MailConfigCalled() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider(Constants.MERCK_AUTH);
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_INVITATION),
            anyString(),
            eq("test"));
  }

  @Test
  public void testSend_SialAuth_LabwaterOrg_EmailServiceCalled() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider("SIAL_AUTH");
    userProfile.getOrg().setName(Constants.LABWATER);
    when(emailTemplateService.findByCategoryAndLanguageId(
            eq(Constants.INVITE_USER_LABWATER_ROLE_MANUAL), eq(1)))
        .thenReturn(emailTemplate);
    when(emailService.sendMail(any(), anyString())).thenReturn(true);

    try (MockedStatic<SecurityContextHolder> securityContextHolderMock =
        Mockito.mockStatic(SecurityContextHolder.class)) {
      securityContextHolderMock.when(SecurityContextHolder::getContext).thenReturn(securityContext);
      when(securityContext.getAuthentication()).thenReturn(authentication);
      when(authentication.getPrincipal()).thenReturn(authUser);

      // Act
      mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

      // Assert
      verify(emailService, times(1)).sendMail(any(), eq("test"));
    }
  }

  @Test
  public void testSend_SialAuth_NonLabwaterOrg_MailConfigCalled() throws Exception {
    // Arrange
    userProfile.getUserDomain().setAuthenticationProvider("SIAL_AUTH");
    userProfile.getOrg().setName("NonLabwater");
    doNothing().when(mailConfig).send(anyString(), anyString(), anyString(), anyString());

    // Act
    mailService.send(userProfile, Constants.INVITE_USER, "jtiToken", "test");

    // Assert
    verify(mailConfig, times(1))
        .send(
            eq(userProfile.getEmail()),
            eq(Constants.NEXTCONNECT_INVITATION),
            anyString(),
            eq("test"));
  }
}
