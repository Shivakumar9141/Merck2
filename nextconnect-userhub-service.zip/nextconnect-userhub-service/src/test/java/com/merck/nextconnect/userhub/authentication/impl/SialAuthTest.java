package com.merck.nextconnect.userhub.authentication.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;

public class SialAuthTest {

  @Mock private LdapTemplate sialLdap;

  @InjectMocks private SialAuth sialAuth;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testAuthenticate_Success() {
    // Arrange
    Login login = new Login();
    login.setUsername("testUser");
    login.setPassword("testPassword");

    EqualsFilter filter = new EqualsFilter("sAMAccountName", login.getUsername());
    when(sialLdap.authenticate(
            eq(Constants.EMPTY_STRING), eq(filter.encode()), eq(login.getPassword())))
        .thenReturn(true);

    // Act
    boolean result = sialAuth.authenticate(login);

    // Assert
    assertTrue(result);
  }

  @Test
  public void testAuthenticate_Failure() {
    // Arrange
    Login login = new Login();
    login.setUsername("testUser");
    login.setPassword("wrongPassword");

    EqualsFilter filter = new EqualsFilter("sAMAccountName", login.getUsername());
    when(sialLdap.authenticate(
            eq(Constants.EMPTY_STRING), eq(filter.encode()), eq(login.getPassword())))
        .thenReturn(false);

    // Act
    boolean result = sialAuth.authenticate(login);

    // Assert
    assertFalse(result);
  }
}
