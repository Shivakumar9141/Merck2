package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.DeviceDTO;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class DeviceRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private DeviceRepositoryJdbc deviceRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testFindSmDeviceIdByDeviceId_Success() {
    // Arrange
    Long deviceId = 123L;
    List<DeviceDTO> expectedDevices = new ArrayList<>();
    expectedDevices.add(DeviceDTO.builder().smDeviceId("SM001").build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedDevices);

    // Act
    List<DeviceDTO> result = deviceRepositoryJdbc.findSmDeviceIdByDeviceId(deviceId);

    // Assert
    assertEquals(1, result.size());
    assertEquals("SM001", result.get(0).getSmDeviceId());
  }

  @Test
  public void testFindSmDeviceIdByDeviceId_NullDeviceId() {
    // Act
    List<DeviceDTO> result = deviceRepositoryJdbc.findSmDeviceIdByDeviceId(null);

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testFindSmDeviceIdByDeviceId_ExceptionHandling() {
    // Arrange
    Long deviceId = 123L;
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    List<DeviceDTO> result = deviceRepositoryJdbc.findSmDeviceIdByDeviceId(deviceId);

    // Assert
    assertEquals(0, result.size());
  }
}
