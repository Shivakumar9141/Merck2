package com.merck.nextconnect.userhub.model.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class UserTypesTest {

  @Test
  public void testEnumValues() {
    assertEquals("internal_auth", UserTypes.INTERNAL_AUTH.value());
    assertEquals("sial_auth", UserTypes.SIAL_AUTH.value());
  }

  @Test
  public void testEnumCount() {
    assertEquals(2, UserTypes.values().length);
  }
}
