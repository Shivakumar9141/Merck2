package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserAccountPolicy;
import com.merck.nextconnect.userhub.entities.UserCredentials;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserAccountPolicyRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserCredentialsRepository;
import com.merck.nextconnect.userhub.resources.impl.AccountPolicyImpl;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class AccountPolicyImplTest {

  @InjectMocks private AccountPolicyImpl accountPolicy;

  @Mock private UserAccountPolicyRepository userAccountPolicyRepo;

  @Mock private UserCredentialsRepository userCredentialsRepository;

  @Mock private JwtTokenGenerator jwtTokenGenerator;

  private UserProfile userProfile;
  private UserCredentials userCredentials;

  @BeforeEach
  void setUp() {
    // instantiate service and inject mocks (InjectMocks + MockitoExtension would normally handle
    // this,
    // but keep parity with original approach using ReflectionTestUtils)
    accountPolicy = new AccountPolicyImpl();
    ReflectionTestUtils.setField(accountPolicy, "userAccountPolicyRepo", userAccountPolicyRepo);
    ReflectionTestUtils.setField(
        accountPolicy, "userCredentialsRepository", userCredentialsRepository);
    ReflectionTestUtils.setField(accountPolicy, "jwtTokenGenerator", jwtTokenGenerator);

    userProfile = new UserProfile();
    userProfile.setUserId(1L);
    userProfile.setRole(new Role());
    userProfile.setStatus(UserStatus.ACTIVE.value());

    userCredentials = new UserCredentials();
    userCredentials.setUserProfile(userProfile);
    userCredentials.setCredentialId(1L);
  }

  @Test
  void testResetLockOut() {
    accountPolicy.resetLockOut(userProfile.getUserId());
    verify(userAccountPolicyRepo).deleteByUserId(userProfile.getUserId());
  }

  @Test
  void testLockUserAccount_throwsLoginAuthenticationException_andInvokesDeps() {
    long userId = 1L;
    long activeCredentialId = 1L;

    when(userCredentialsRepository.lockUserAccount(activeCredentialId)).thenReturn(1);
    doNothing().when(jwtTokenGenerator).removeTokenRecords(userId);

    assertThrows(
        LoginAuthenticationException.class,
        () -> accountPolicy.lockUserAccount(userId, activeCredentialId));

    verify(userCredentialsRepository, times(1)).lockUserAccount(activeCredentialId);
    verify(jwtTokenGenerator, times(1)).removeTokenRecords(userId);
  }

  @Test
  void testFailedLoginAttempt_throwsLoginAuthenticationException_andUpdatesAttempts() {
    UserAccountPolicy userAccountPolicy = new UserAccountPolicy();
    userAccountPolicy.setFailedAttempts(5);
    userAccountPolicy.setLastFailed(new Date(System.currentTimeMillis() - 10000));
    userAccountPolicy.setUserProfile(userProfile);

    when(userAccountPolicyRepo.getByUserId(userProfile.getUserId())).thenReturn(userAccountPolicy);

    // Set threshold and timeThreshold to trigger lockout
    ReflectionTestUtils.setField(accountPolicy, "threshold", 3);
    ReflectionTestUtils.setField(accountPolicy, "timeThreshold", 300000L);

    when(userCredentialsRepository.lockUserAccount(userCredentials.getCredentialId()))
        .thenReturn(1);
    doNothing().when(jwtTokenGenerator).removeTokenRecords(userProfile.getUserId());

    assertThrows(
        LoginAuthenticationException.class,
        () -> accountPolicy.failedLoginAttempt(userCredentials));

    // Verify updateUserLoginAttempt was called to increment failed attempts to 6
    verify(userAccountPolicyRepo, times(1))
        .updateUserLoginAttempt(eq(userProfile.getUserId()), eq(6), any(Date.class));
  }
}
