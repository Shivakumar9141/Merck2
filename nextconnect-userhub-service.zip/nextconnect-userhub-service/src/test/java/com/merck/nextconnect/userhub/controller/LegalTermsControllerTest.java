package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import com.merck.nextconnect.userhub.entities.PolicyTypeEntity;
import com.merck.nextconnect.userhub.resources.ILegalTermsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class LegalTermsControllerTest {

  @Mock private ILegalTermsService legalTermsServiceMock;

  @InjectMocks private LegalTermsController legalTermsController;

  @BeforeEach
  public void setUp() {
    openMocks(this);
  }

  @Test
  public void testGetLegalTerms_Success() throws Exception {
    PolicyTypeEntity policyTypeEntity = new PolicyTypeEntity();

    when(legalTermsServiceMock.getPolicyOrTerms(null, null, null, 0)).thenReturn(policyTypeEntity);

    ResponseEntity<PolicyTypeEntity> responseEntity =
        legalTermsController.legalTerms(null, null, null, 0);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(policyTypeEntity, responseEntity.getBody());
  }
}
