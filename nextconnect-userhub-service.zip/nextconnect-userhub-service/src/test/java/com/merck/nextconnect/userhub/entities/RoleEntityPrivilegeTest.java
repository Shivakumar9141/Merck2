package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RoleEntityPrivilegeTest {

  private RoleEntityPrivilege roleEntityPrivilege;
  private Role role;
  private Privilege privilege;
  private Entities entities;

  @BeforeEach
  public void setUp() {
    roleEntityPrivilege = new RoleEntityPrivilege();
    role = new Role();
    privilege = new Privilege();
    entities = new Entities();
  }

  @Test
  public void testGetSetRoleEntityId() {
    long id = 123L;
    roleEntityPrivilege.setRoleEntityId(id);
    assertEquals(id, roleEntityPrivilege.getRoleEntityId());
  }

  @Test
  public void testGetSetRole() {
    roleEntityPrivilege.setRole(role);
    assertEquals(role, roleEntityPrivilege.getRole());
  }

  @Test
  public void testGetSetPrivilege() {
    roleEntityPrivilege.setPrivilege(privilege);
    assertEquals(privilege, roleEntityPrivilege.getPrivilege());
  }

  @Test
  public void testGetSetEntities() {
    roleEntityPrivilege.setEntities(entities);
    assertEquals(entities, roleEntityPrivilege.getEntities());
  }
}
