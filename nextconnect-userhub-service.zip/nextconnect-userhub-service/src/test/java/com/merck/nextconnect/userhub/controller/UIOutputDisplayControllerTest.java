package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.entities.UIOutputDisplay;
import com.merck.nextconnect.userhub.resources.IUIOutputDisplay;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class UIOutputDisplayControllerTest {

  @Mock private IUIOutputDisplay uiOutputDisplay;

  @InjectMocks private UIOutputDisplayController controller;

  @Test
  void testGetDates() {
    List<UIOutputDisplay> outputDisplays = new ArrayList<>();
    when(uiOutputDisplay.getAll()).thenReturn(outputDisplays);

    ResponseEntity<List<UIOutputDisplay>> responseEntity = controller.getDates();

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(outputDisplays, responseEntity.getBody());
  }
}
