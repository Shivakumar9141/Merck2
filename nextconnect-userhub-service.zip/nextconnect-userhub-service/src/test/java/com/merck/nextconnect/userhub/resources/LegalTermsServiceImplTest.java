package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.entities.LegalTermsMapping;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.PolicyTypeEntity;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.LegalTermsReference;
import com.merck.nextconnect.userhub.repository.jpa.LegalTermsRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.resources.impl.LegalTermsServiceImpl;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.validator.LegalTermsValidator;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class LegalTermsServiceImplTest {

  @Mock private LegalTermsRepository legalTermsRepository;

  @Mock private LegalTermsValidator legalTermsValidator;

  @Mock private CountryRepository countryRepository;

  @Mock private OrganizationRepository organizationRepository;

  @InjectMocks private LegalTermsServiceImpl legalTermsService;

  private Organization labwaterOrg;

  @BeforeEach
  void setUp() {
    labwaterOrg = new Organization();
    labwaterOrg.setId(1);
    labwaterOrg.setName(Constants.LABWATER);
    labwaterOrg.setType("Distributors");

    // ensure the service has the mocked dependencies (InjectMocks usually handles this,
    // but keep parity with original approach)
    ReflectionTestUtils.setField(legalTermsService, "legalTermsRepository", legalTermsRepository);
    ReflectionTestUtils.setField(
        legalTermsService, "organizationRepository", organizationRepository);
  }

  @Test
  void testGetPolicyOrTerms() throws Exception {
    String languageCode = "en";
    String type = "privacy_policy";
    String countryCode = "US";
    int orgId = 1;
    Country country = new Country();
    country.setId(1);

    Organization parentorg = new Organization();
    parentorg.setId(1);
    labwaterOrg.setParent(parentorg);

    when(organizationRepository.findOrgById(anyInt())).thenReturn(Optional.of(labwaterOrg));
    when(organizationRepository.findIdByName(Constants.LABWATER)).thenReturn(1);
    when(countryRepository.findByCountryCode(countryCode)).thenReturn(country);

    when(legalTermsRepository
            .findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
                anyString(), anyString(), anyInt(), anyString(), anyString(), anyString()))
        .thenReturn(Optional.of(new LegalTermsMapping()));

    PolicyTypeEntity result =
        legalTermsService.getPolicyOrTerms(languageCode, type, countryCode, orgId);

    // verify repository was called with expected args (the service likely inverts some params;
    // use the expected order from production code)
    verify(legalTermsRepository)
        .findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
            countryCode,
            languageCode,
            labwaterOrg.getId(),
            type,
            LegalTermsReference.ORGTYPE.value(),
            Constants.ORG_TYPE_DISTRIBUTOR);
  }

  @Test
  void testGetPolicyOrTermsOrgTypeOthers() throws Exception {
    String languageCode = "en";
    String type = "privacy_policy";
    String countryCode = "US";
    int orgId = 1;
    Country country = new Country();
    country.setId(1);

    Organization parentorg = new Organization();
    parentorg.setId(1);
    labwaterOrg.setParent(parentorg);
    labwaterOrg.setType("test");

    when(organizationRepository.findOrgById(anyInt())).thenReturn(Optional.of(labwaterOrg));
    when(organizationRepository.findIdByName(Constants.LABWATER)).thenReturn(1);
    when(countryRepository.findByCountryCode(countryCode)).thenReturn(country);

    when(legalTermsRepository
            .findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
                countryCode,
                languageCode,
                1,
                type,
                LegalTermsReference.NOFILTER.value(),
                Constants.NO_FILTER))
        .thenReturn(Optional.of(new LegalTermsMapping()));

    PolicyTypeEntity result =
        legalTermsService.getPolicyOrTerms(languageCode, type, countryCode, orgId);

    verify(legalTermsRepository)
        .findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
            eq(countryCode),
            eq(languageCode),
            eq(labwaterOrg.getId()),
            eq(type),
            eq(LegalTermsReference.NOFILTER.value()),
            anyString());
  }

  @Test
  void testGetPolicyOrTermsOrgIdNotEqualWithParentId_throwsResourceNotFound() throws Exception {
    String languageCode = "en";
    String type = "privacy_policy";
    String countryCode = "US";
    int orgId = 4;

    Organization parentorg = new Organization();
    parentorg.setId(2);
    parentorg.setType("test");
    labwaterOrg.setParent(parentorg);
    labwaterOrg.setType("test");

    when(organizationRepository.findOrgById(anyInt())).thenReturn(Optional.of(labwaterOrg));
    when(organizationRepository.findIdByName(Constants.LABWATER)).thenReturn(3);

    // Act & Assert
    assertThrows(
        ResourceNotFoundException.class,
        () -> legalTermsService.getPolicyOrTerms(languageCode, type, countryCode, orgId));
  }

  @Test
  void testGetPolicyOrTermsOrgIdIs0_throwsDataValidationException() throws Exception {
    String languageCode = "en";
    String type = "privacy_policy";
    String countryCode = "US";
    int orgId = 0;

    assertThrows(
        DataValidationException.class,
        () -> legalTermsService.getPolicyOrTerms(languageCode, type, countryCode, orgId));
  }

  @Test
  void testGetPolicyOrTermsParentIdIsNull_throwsResourceNotFound() throws Exception {
    String languageCode = "en";
    String type = "privacy_policy";
    String countryCode = "US";
    int orgId = 4;

    labwaterOrg.setType("test");
    when(organizationRepository.findOrgById(anyInt())).thenReturn(Optional.of(labwaterOrg));
    when(organizationRepository.findIdByName(Constants.LABWATER)).thenReturn(3);

    assertThrows(
        ResourceNotFoundException.class,
        () -> legalTermsService.getPolicyOrTerms(languageCode, type, countryCode, orgId));
  }
}
