package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.entities.AuthOrg;
import com.merck.nextconnect.authfilter.entities.AuthOrgBrandPartnerType;
import com.merck.nextconnect.authfilter.entities.AuthOrgPartnerPeripheralSupplier;
import com.merck.nextconnect.authfilter.entities.AuthPartnerPeripheralSupplier;
import com.merck.nextconnect.authfilter.entities.PartnerBrandPartnerType;
import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.AuthOrgBrandPartnerTypeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.AuthOrgPartnerPeripheralSupplierRepository;
import com.merck.nextconnect.authfilter.repository.jpa.OrgRepository;
import com.merck.nextconnect.authfilter.repository.jpa.PartnerBrandPartnerTypeRepository;
import com.merck.nextconnect.authfilter.resources.impl.OrgPermissions;
import com.merck.nextconnect.userhub.constants.UserhubConstants;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.OrganizationType;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.OrgFilter;
import com.merck.nextconnect.userhub.model.OrgPartnerBrandPartnerTypeDTO;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.repository.jpa.OrgDomainRepositiory;
import com.merck.nextconnect.userhub.repository.jpa.OrgSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationTypeRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.impl.OrganizationImpl;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.userhub.validator.UserhubValidator;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class OrganizationImplTest {

  @InjectMocks private OrganizationImpl organizationImpl;

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @Mock private OrganizationRepository orgRepo;

  @Mock private Authentication authentication;

  @Mock private ServiceImpl serviceImpl;

  @Mock private AuthenticatedUser authUser;

  @Mock private OrgPermissions orgPermissions;

  @Mock private OrgDomainRepositiory orgDomainRepo;

  @Mock private ApplicationConfigRepository applicationConfigRepository;

  @Mock private UserhubValidator userhubValidator;

  @Mock private OrgRepository orgRepository;

  @Mock private UserRepository userRepo;

  @Mock private EmailService emailService;

  @Mock private AuthOrgBrandPartnerTypeRepository orgBrandPartnerTypeRepository;

  @Mock private OrganizationTypeRepository orgTypeRepository;

  @Mock private AuthOrgPartnerPeripheralSupplierRepository orgBrandRepo;

  @Mock private UserDevicePrivilegeRepository userDevicePrivilegeRepository;

  @Mock private IUser iUser;

  @Mock private OrgSettingsRepository orgSettingsRepository;

  @Mock private PartnerBrandPartnerTypeRepository partnerBrandPartnerTypeRepository;

  @BeforeEach
  public void setUp() {
    // With MockitoExtension, @Mock and @InjectMocks are initialized automatically.
    // Set a SecurityContext with a mocked Authentication so tests can stub principal as needed.
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
  }

  @Test
  public void testGetAll() {
    String operation = "manage_accounts";
    String searchBy = "SOME_SEARCH_CRITERIA";
    String type = "SOME_TYPE";
    String reference = Constants.ORG_LIST_IN_ADD_USER;

    List<OrgDto> orgs = new ArrayList<>(); // Provide sample data here
    List<OrgDto> filteredOrgs =
        orgs.stream().filter(o -> o.getStatus() && !o.isDeleted()).collect(Collectors.toList());
    when(userOrgPrivileges.getOrgs(any(), any(), any())).thenReturn(orgs);

    List<OrgDto> result = organizationImpl.getAll(operation, searchBy, type, reference);

    verify(userOrgPrivileges).getOrgs(any(), any(), any());
    assertEquals(filteredOrgs, result);
  }

  @Test
  public void testGetOrgs()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    List<OrgDto> orgs = new ArrayList<>();
    assertEquals(orgs, new ArrayList<>());
  }

  @Test
  public void testGetOrgByName() {
    Organization org = new Organization();
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(authUser.getOrgId()).thenReturn(1);
    when(orgRepo.getOrgByName("orgName", authUser.getOrgId())).thenReturn(org);

    Organization result = organizationImpl.getOrgByName("orgName");

    assertEquals(org, result);
  }

  @Test
  public void testGetDomains() {
    Integer orgId = 1;
    List<UserDomain> userDomains = new ArrayList<>();
    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);
    when(orgPermissions.hasRoleAccess(eq(orgId), eq(OrgPrivileges.manage_accounts)))
        .thenReturn(true);
    when(applicationConfigRepository.findValueByCategoryAndKey(
            eq(UserhubConstants.USER_DOMAIN), eq(UserhubConstants.DOMAIN_VISIBILITY)))
        .thenReturn(Constants.YES);
    when(orgRepo.getOrgTypeById(eq(orgId))).thenReturn("test");
    when(orgDomainRepo.getDomains(eq(orgId))).thenReturn(userDomains);

    List<UserDomain> result = organizationImpl.getDomains(orgId);

    assertEquals(userDomains, result);
  }

  @Test
  public void testGetDomains_IfBusinessUnit() {
    Integer orgId = 1;
    UserDomain userdomain = new UserDomain();
    userdomain.setDomainName("nextconnect");
    List<UserDomain> userDomains = new ArrayList<>();
    userDomains.add(userdomain);

    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);
    when(orgPermissions.hasRoleAccess(eq(orgId), eq(OrgPrivileges.manage_accounts)))
        .thenReturn(true);
    when(applicationConfigRepository.findValueByCategoryAndKey(
            eq(UserhubConstants.USER_DOMAIN), eq(UserhubConstants.DOMAIN_VISIBILITY)))
        .thenReturn("NO");
    when(orgRepo.getOrgTypeById(eq(orgId))).thenReturn(Constants.BUSINESS_UNIT);
    when(orgDomainRepo.getDomains(eq(orgId))).thenReturn(userDomains);

    List<UserDomain> result = organizationImpl.getDomains(orgId);
    assertNotNull(result);
  }

  //    @Test
  //    public void testGetDomains_IfNotBusinessUnit() {
  //        Integer orgId = 1;
  //        List<UserDomain> userDomains = new ArrayList<>();
  //
  //        when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);
  //        when(orgPermissions.hasRoleAccess(eq(orgId),
  // eq(OrgPrivileges.manage_accounts))).thenReturn(true);
  //        when(applicationConfigRepository.findByCategoryAndKey(eq(UserhubConstants.USER_DOMAIN),
  // eq(UserhubConstants.DOMAIN_VISIBILITY)))
  //                .thenReturn("NO");
  //        when(orgRepo.getOrgTypeById(eq(orgId))).thenReturn("test");
  //        when(orgDomainRepo.getDomains(eq(orgId))).thenReturn(userDomains);
  //
  //        List<UserDomain> result = organizationImpl.getDomains(orgId);
  //        assertEquals(userDomains, result);
  //    }

  @Test
  public void testCreateOrg()
      throws DataValidationException,
          DuplicateResourceException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setStatus(true);
    orgInfo.setName("test");
    orgInfo.setDesc("desc");
    orgInfo.setHistoricalDataSubscription(1L);

    int expectedOrgId = 123;
    doNothing().when(userhubValidator).validateOrgStatus(orgInfo.getStatus());
    when(userOrgPrivileges.createOrg(orgInfo)).thenReturn(expectedOrgId);

    int actualOrgId = organizationImpl.create(orgInfo);

    assertEquals(expectedOrgId, actualOrgId);
  }

  @Test
  public void testGetFacets_LW_MCS() {
    List<OrgDto> orgDtoList = new ArrayList<>();
    orgDtoList.add(new OrgDto(1, "test", "test", "description", true));
    String operation = "manage_accounts";
    String searchBy = "SOME_SEARCH_CRITERIA";
    String type = "SOME_TYPE";
    String reference = Constants.ORG_LIST_IN_ADD_USER;
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(authUser.getRole()).thenReturn("USER");
    when(organizationImpl.getAll(operation, searchBy, type, reference)).thenReturn(orgDtoList);

    List<String> facets = organizationImpl.getFacets(operation);
    assertEquals(Arrays.asList("test"), facets);
  }

  @Test
  public void testUpdateOrgStatus_Success()
      throws EmailException,
          CustomException,
          com.merck.nextconnect.userhub.exception.CustomException {
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setStatus(false);
    AuthOrg authOrg = new AuthOrg();
    authOrg.setStatus(true);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(authUser.getUsername()).thenReturn("testuser");
    when(orgRepository.getOrg(anyInt())).thenReturn(authOrg);

    List<UserProfile> userProfiles = new ArrayList<>();
    UserProfile userprofile = new UserProfile();
    userprofile.setUserId(1L);
    userprofile.setFirstName("name");
    userprofile.setLastName("name");
    userprofile.setLanguage(new Language(1));
    userProfiles.add(userprofile);
    when(userRepo.findByOrgIdAndStatus(123)).thenReturn(userProfiles);

    organizationImpl.updateOrgStatus(orgInfo, 123);

    verify(orgRepository, times(1)).saveAndFlush(authOrg);
  }

  @Test
  public void testGetOrgBrandPartnerTypes_UserHasAccessAndOrgHasBrandTypes() {
    int orgId = 123;
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    AuthPartnerPeripheralSupplier authPartnerPeripheralSupplier =
        new AuthPartnerPeripheralSupplier();
    authPartnerPeripheralSupplier.setId(1);

    AuthOrgPartnerPeripheralSupplier authOrgPartnerPeripheralSupplier =
        new AuthOrgPartnerPeripheralSupplier();
    authOrgPartnerPeripheralSupplier.setPartnerPeripheralSupplier(authPartnerPeripheralSupplier);

    AuthOrgBrandPartnerType authOrgBrandPartnerType = new AuthOrgBrandPartnerType();
    authOrgBrandPartnerType.setOrgBrand(authOrgPartnerPeripheralSupplier);

    PartnerBrandPartnerType partnerBrandPartnerType = new PartnerBrandPartnerType();
    PartnerTypeEntity partnerTypeEntity = new PartnerTypeEntity();
    partnerTypeEntity.setPartnerTypeId(1);
    partnerBrandPartnerType.setPartnerTypeEntity(partnerTypeEntity);
    authOrgBrandPartnerType.setPartnerBrandPartnerType(partnerBrandPartnerType);

    List<AuthOrgBrandPartnerType> orgBrandPartnerTypes = new ArrayList<>();
    orgBrandPartnerTypes.add(authOrgBrandPartnerType);

    when(orgPermissions.hasRoleAccess(orgId, OrgPrivileges.manage_accounts)).thenReturn(true);
    when(orgBrandPartnerTypeRepository.findByOrgBrandOrgId(orgId)).thenReturn(orgBrandPartnerTypes);

    OrgPartnerBrandPartnerTypeDTO result = organizationImpl.getOrgBrandPartnerTypes(orgId);
    assertNotNull(result);
  }

  @Test
  public void testGetOrganizationType_UserCanCreateCustomerAndPartnerOrgTypes() {
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    Collection<? extends GrantedAuthority> authorities = new ArrayList<>();
    ((List<GrantedAuthority>) authorities)
        .add((GrantedAuthority) () -> Constants.CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE);
    ((List<GrantedAuthority>) authorities)
        .add((GrantedAuthority) () -> Constants.CREATE_PARTNER_ORG_TYPE_PRIVILEGE);

    when(authUser.getAuthorities()).thenReturn((Collection) authorities);

    OrganizationType customerOrgType = new OrganizationType();
    customerOrgType.setOrgTypeName(Constants.ORG_TYPE_CUSTOMER);
    OrganizationType partnerOrgType = new OrganizationType();
    partnerOrgType.setOrgTypeName(Constants.ORG_TYPE_PARTNER);

    List<OrganizationType> result = organizationImpl.getOrganizationType();
    assertNotNull(result);
  }

  @Test
  public void testDelete_SuperAdminOrBusinessManager_Role()
      throws CustomException,
          EmailException,
          com.merck.nextconnect.userhub.exception.CustomException {
    List<GrantedAuthority> list = new ArrayList<>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(2219);
    jwtUser.setRole("LW-super admin");
    authUser = new AuthenticatedUser(jwtUser, "Test@123", list);
    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);

    Organization org = new Organization();
    org.setId(1);
    org.setType("Partners");
    when(orgRepo.getOrg(1)).thenReturn(org);

    organizationImpl.delete(1);

    assertTrue(org.isDeleted());
    verify(orgRepo).save(org);
  }

  @Test
  public void testDelete_ManuallyCreated_Role()
      throws CustomException,
          EmailException,
          com.merck.nextconnect.userhub.exception.CustomException {
    List<GrantedAuthority> list = new ArrayList<>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(2219);
    jwtUser.setRole("LW-Service Admin");
    authUser = new AuthenticatedUser(jwtUser, "Test@123", list);
    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);

    Organization org = new Organization();
    org.setId(1);
    org.setType("Partners");
    org.setAutoCreated(false);

    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(1L);
    userProfile.setStatus("Active");
    userProfile.setFirstName("name");
    userProfile.setLastName("name");
    userProfile.setLanguage(new Language(1));
    userProfile.setEmail("test");

    List<UserProfile> userProfiles = new ArrayList<>();
    userProfiles.add(userProfile);

    when(orgRepo.getOrg(1)).thenReturn(org);
    when(userRepo.findByOrgIdAndDeleted(1, false)).thenReturn(userProfiles);

    List<Long> liln = new ArrayList<>();
    liln.add(1L);
    liln.add(2L);
    when(userDevicePrivilegeRepository.getDeviceIdsFromUserId(userProfile.getUserId()))
        .thenReturn(liln);

    organizationImpl.delete(1);

    assertTrue(org.isDeleted());
    verify(orgRepo).save(org);
  }

  @Test
  void testDelete_ManuallyCreated_Role_AutoCreated_True() {
    List<GrantedAuthority> list = new ArrayList<>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(2219);
    jwtUser.setRole("LW-Service Admin");
    authUser = new AuthenticatedUser(jwtUser, "Test@123", list);
    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);

    Organization org = new Organization();
    org.setId(1);
    org.setType("Partners");
    org.setAutoCreated(true);

    when(orgRepo.getOrg(1)).thenReturn(org);

    assertThrows(DataValidationException.class, () -> organizationImpl.delete(1));
  }

  @Test
  void testDelete_NoRole() {
    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);
    Organization org = new Organization();
    org.setId(1);
    org.setType("Partners");
    org.setAutoCreated(true);
    when(orgRepo.getOrg(1)).thenReturn(org);

    assertThrows(DataValidationException.class, () -> organizationImpl.delete(1));
  }

  @Test
  void testDelete_NoOrg() {
    when(UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);
    when(orgRepo.getOrg(1)).thenReturn(null);

    assertThrows(ResourceNotFoundException.class, () -> organizationImpl.delete(1));
  }

  @Test
  public void testGetFilter_AllOrgTypePrivilege() {
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    Collection<? extends GrantedAuthority> authorities = new ArrayList<>();
    when(authUser.getAuthorities()).thenReturn((Collection) authorities);

    Organization org = new Organization();
    org.setType("test");
    org.setStatus(true);
    List<Organization> orgs = new ArrayList<>();
    orgs.add(org);

    OrgFilter orgFilter = organizationImpl.getFilter();
    assertNotNull(orgFilter);
  }

  @Test
  public void testGetAllOrgsByOrderAsc()
      throws CustomException, com.merck.nextconnect.userhub.exception.CustomException {
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setSearchBy("test");
    fetchCriteria.setSortBy("createdOn");
    fetchCriteria.setOrderBy("asc");
    fetchCriteria.setPageNo(2);
    fetchCriteria.setPageLimit(1);

    Page<Organization> result = organizationImpl.getAllOrgs(fetchCriteria);
    assertNull(result);
  }

  @Test
  public void testGetAllOrgsByOrderDesc()
      throws CustomException, com.merck.nextconnect.userhub.exception.CustomException {
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setSearchBy("test");
    fetchCriteria.setSortBy("createdOn");
    fetchCriteria.setPageNo(2);
    fetchCriteria.setPageLimit(1);

    Page<Organization> result = organizationImpl.getAllOrgs(fetchCriteria);
    assertNull(result);
  }

  @Test
  public void testGetAllOrgsSortByNull()
      throws CustomException, com.merck.nextconnect.userhub.exception.CustomException {
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setSearchBy("test");
    fetchCriteria.setPageNo(2);
    fetchCriteria.setPageLimit(1);

    Page<Organization> result = organizationImpl.getAllOrgs(fetchCriteria);
    assertNull(result);
  }

  @Test
  public void testGetFilterValues()
      throws NoSuchMethodException,
          SecurityException,
          IllegalAccessException,
          IllegalArgumentException,
          InvocationTargetException {
    List<String> filterBy = Arrays.asList("status.Active", "type.Admin", "status.Inactive");
    Method method = OrganizationImpl.class.getDeclaredMethod("getFilterValues", List.class);
    method.setAccessible(true);
    @SuppressWarnings("unchecked")
    Map<String, List<String>> result =
        (Map<String, List<String>>) method.invoke(organizationImpl, filterBy);

    assertNotNull(result);
  }

  @Test
  public void testOrgListConvertor() {
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(authUser.getRole()).thenReturn("USER");

    Organization parent = new Organization();
    parent.setName("test");
    Organization org = new Organization();
    org.setId(1);
    org.setParent(parent);
    List<Organization> orgs = new ArrayList<>();
    orgs.add(org);

    when(orgSettingsRepository.findHistoricalDataSubscriptionByOrgId(org.getId())).thenReturn(1L);
    List<OrgDto> result = organizationImpl.orgListConvertor(orgs);
    assertEquals(1, result.size());
  }

  @Test
  public void testUpdate()
      throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    Map<String, Object> map = new HashMap<>();
    map.put("partner_peripheral_supplier", 2);

    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setStatus(true);
    orgInfo.setName("OrgName");
    orgInfo.setDesc("OrgDescription");
    orgInfo.setType(Constants.PARTNER);
    orgInfo.setHistoricalDataSubscription(2L);
    orgInfo.setPartnerTypeIds(Arrays.asList(1, 2));
    orgInfo.setCustomProperties(map);

    AuthOrg org1 = new AuthOrg();
    org1.setId(5);
    AuthOrg org = new AuthOrg();
    org.setId(456);
    org.setParent(org1);
    org.setName("OrgName");
    org.setDescription("OrgDescription");
    org.setStatus(true);

    // Mock authUser properly for UserhubUtils.getAuthenticatedUser()
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(authUser.getOrgId()).thenReturn(5);
    when(authUser.getUsername()).thenReturn("testuser");

    doNothing().when(userhubValidator).validateOrgStatus(orgInfo.getStatus());

    AuthPartnerPeripheralSupplier authPartnerPeripheralSupplier =
        new AuthPartnerPeripheralSupplier();
    authPartnerPeripheralSupplier.setId(2);

    AuthOrgPartnerPeripheralSupplier orgPartnerPeripheralSupplier =
        new AuthOrgPartnerPeripheralSupplier();
    orgPartnerPeripheralSupplier.setId(1);
    orgPartnerPeripheralSupplier.setPartnerPeripheralSupplier(authPartnerPeripheralSupplier);

    List<PartnerBrandPartnerType> partnerBrandPartnerTypes = new ArrayList<>();
    PartnerBrandPartnerType par = new PartnerBrandPartnerType();
    par.setId(1);
    partnerBrandPartnerTypes.add(par);

    when(orgRepository.getOrg(anyInt())).thenReturn(org);
    when(orgBrandRepo.getOrgBrandByOrgId(456)).thenReturn(orgPartnerPeripheralSupplier);
    when(orgBrandPartnerTypeRepository.deleteById(anyInt())).thenReturn(1);
    when(orgBrandRepo.updateOrgBrand(anyInt(), anyInt())).thenReturn(1);
    when(orgBrandRepo.getOrgBrandByOrgIdAndBrandId(anyInt(), anyInt()))
        .thenReturn(orgPartnerPeripheralSupplier);
    when(partnerBrandPartnerTypeRepository.getBrandPartnerType(anyInt(), anyList()))
        .thenReturn(partnerBrandPartnerTypes);

    try {
      organizationImpl.update(orgInfo, 456);
      verify(orgBrandPartnerTypeRepository).saveAll(anyList());
    } catch (Exception e) {
      fail("Exception thrown: " + e.getMessage());
    }
  }

  @Test
  public void testUpdateException()
      throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          com.merck.nextconnect.userhub.exception.CustomException {
    Map<String, Object> map = new HashMap<>();
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setStatus(true);
    orgInfo.setName("OrgName");
    orgInfo.setDesc("OrgDescription");
    orgInfo.setType(Constants.PARTNER);

    doNothing().when(userhubValidator).validateOrgStatus(orgInfo.getStatus());

    assertThrows(DataValidationException.class, () -> organizationImpl.update(orgInfo, 456));
  }
}
