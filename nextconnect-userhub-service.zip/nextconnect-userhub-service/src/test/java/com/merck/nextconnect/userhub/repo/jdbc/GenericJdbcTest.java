package com.merck.nextconnect.userhub.repo.jdbc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class GenericJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private GenericJdbc genericJdbc;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testUpdateDeviceAccessRequestStatusApproved() {
    // Arrange
    Long deviceId = 123L;
    Long userId = 456L;

    // Act
    genericJdbc.updateDeviceAccessRequestStatusApproved(deviceId, userId);

    // Assert
    verify(namedParameterJdbcTemplate, times(1))
        .update(anyString(), any(MapSqlParameterSource.class));
  }

  @Test
  public void testDeleteRequestDeviceForDeviceFromUser() {
    // Arrange
    Long deviceId = 123L;
    Long userId = 456L;

    // Act
    genericJdbc.deleteRequestDeviceForDeviceFromUser(deviceId, userId);

    // Assert
    verify(namedParameterJdbcTemplate, times(1))
        .update(anyString(), any(MapSqlParameterSource.class));
  }
}
