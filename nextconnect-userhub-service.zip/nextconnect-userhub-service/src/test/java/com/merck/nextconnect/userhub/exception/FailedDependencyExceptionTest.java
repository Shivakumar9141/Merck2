package com.merck.nextconnect.userhub.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

public class FailedDependencyExceptionTest {

  @Test
  public void testConstructorWithMessage() {
    String errorMessage = "Failed dependency error occurred";
    FailedDependencyException exception = new FailedDependencyException(errorMessage);

    assertNotNull(exception);
    assertEquals(errorMessage, exception.getMessage());
  }

  @Test
  public void testConstructorWithCustomErrorCode() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    FailedDependencyException exception = new FailedDependencyException(errorCode);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCodeAndParams() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    List<String> params = Arrays.asList("param1", "param2");
    FailedDependencyException exception = new FailedDependencyException(errorCode, params);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }
}
