package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.resources.IDateFormat;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class DateFormatControllerTest {

  private DateFormatController dateFormatController;
  private IDateFormat mockDateFormat;
  @Mock private AuthenticatedUser authUser;
  @Mock private Authentication authentication;

  @BeforeEach
  public void setUp() {
    mockDateFormat = mock(IDateFormat.class);
    dateFormatController = new DateFormatController();
    dateFormatController.dateFormat = mockDateFormat;
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetDates() {
    List<DateFormat> mockDateFormats = new ArrayList<>();
    DateFormat dateFormat1 = new DateFormat();
    dateFormat1.setId(1);
    dateFormat1.setDateFormat("dd/MM/yyyy");
    DateFormat dateFormat2 = new DateFormat();
    dateFormat2.setId(2);
    dateFormat2.setDateFormat("MM/dd/yyyy");
    mockDateFormats.add(dateFormat1);
    mockDateFormats.add(dateFormat2);

    when(mockDateFormat.getDateFormats()).thenReturn(mockDateFormats);
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    ResponseEntity<List<DateFormat>> responseEntity = dateFormatController.getDates();

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(mockDateFormats, responseEntity.getBody());
  }
}
