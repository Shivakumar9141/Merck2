package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.resources.impl.OrgCardEntity;
import com.merck.nextconnect.userhub.model.FeedBackTrendDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackDateDTO;
import com.merck.nextconnect.userhub.model.UserFeedbackTrend;
import com.merck.nextconnect.userhub.model.UserRatingTrend;
import com.merck.nextconnect.userhub.model.UserRatingsDTO;
import com.merck.nextconnect.userhub.repo.jdbc.UserFeedBackRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserFeedBackRepository;
import com.merck.nextconnect.userhub.resources.impl.UserFeedBackChartServiceImpl;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

public class UserFeedBackChartServiceImplTest {

  @Mock private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;

  @Mock private UserFeedBackRepository userFeedBackRepository;

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @InjectMocks private UserFeedBackChartServiceImpl userFeedBackChartService;

  @Mock private AuthenticatedUser authUser;

  @Mock OrgCardEntity orgCardEntity;

  private Authentication authentication;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
    when(authUser.getRole()).thenReturn("USER");
    //  mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void getUserFeedBackTrend_WhenDurationIsThreeMonths_ExpectTrendData() {

    when(userOrgPrivileges.getOrgs(any(), any(), any())).thenReturn(Collections.emptyList());
    UserFeedbackTrend trend =
        userFeedBackChartService.getUserFeedBackTrend(Constants.FEEDBACK_DURATION_THREE_MONTHS);
    assertNotNull(trend);
  }

  @Test
  public void getUserFeedBackTrend_WhenUserDataMapIsEmpty() {

    when(userOrgPrivileges.getOrgs(any(), any(), any())).thenReturn(Collections.emptyList());
    UserFeedbackTrend trend = userFeedBackChartService.getUserFeedBackTrend(6L);
    assertNotNull(trend);
  }

  @Test
  public void getUserRatingTrend_WhenDurationIsThreeMonths_ExpectRatingTrend() {
    when(userOrgPrivileges.getOrgs(any(), any(), any())).thenReturn(Collections.emptyList());
    UserRatingTrend trend =
        userFeedBackChartService.getUserRatingTrend(Constants.FEEDBACK_DURATION_THREE_MONTHS);
    assertNotNull(trend);
  }

  @Test
  public void getUserRatingTrend_WhenDurationIsNotThreeMonths_ExpectRatingTrend() {
    when(userOrgPrivileges.getOrgs(any(), any(), any())).thenReturn(Collections.emptyList());
    UserRatingTrend trend = userFeedBackChartService.getUserRatingTrend(6L);
    assertNotNull(trend);
  }

  @Test
  public void testGetFormattedOutPut()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    double input = 123.456;
    Method method =
        UserFeedBackChartServiceImpl.class.getDeclaredMethod("getFormattedOutPut", double.class);
    method.setAccessible(true);

    double result = (double) method.invoke(userFeedBackChartService, input);
    assertEquals(
        123.4,
        result,
        0.001,
        "Formatted output should match"); // Considering rounding to one decimal
    // place
  }

  @Test
  public void testProcessDefaultUserRating()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    List<UserFeedBackDateDTO> infoList = new ArrayList<>();
    UserFeedBackDateDTO info1 = new UserFeedBackDateDTO("2024-04-01", null, 5L);
    infoList.add(info1);

    Map<String, Long> userCountMap = new HashMap<>();
    userCountMap.put("2024-04-01", 5L);
    userCountMap.put("2024-04-02", 10L);

    List<UserRatingsDTO> userRatings = new ArrayList<>();
    Method method =
        UserFeedBackChartServiceImpl.class.getDeclaredMethod(
            "processDefaultUserRating", List.class, List.class, Map.class);
    method.setAccessible(true);
    method.invoke(userFeedBackChartService, userRatings, infoList, userCountMap);

    assertEquals(infoList.size(), userRatings.size(), "Size of userRatings should match infoList");
    for (int i = 0; i < infoList.size(); i++) {
      UserFeedBackDateDTO info = infoList.get(i);
      UserRatingsDTO rating = userRatings.get(i);
      assertEquals(info.getChartDate(), rating.getCreatedDate(), "Created date should match");
      assertEquals(info.getCount(), rating.getTotalUsers(), "Total users should match");
    }
  }

  @Test
  public void testProcessDefaultFeedBackTrend()
      throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
    List<FeedBackTrendDTO> feedTrendList = new ArrayList<>();
    List<UserFeedBackDateDTO> infoList = new ArrayList<>();
    Map<String, Long> userCountMap = new HashMap<>();
    infoList.add(new UserFeedBackDateDTO("2024-04-19", null, 10L));
    userCountMap.put("2024-04-19", 10L);

    UserFeedBackChartServiceImpl userFeedBackChartService = new UserFeedBackChartServiceImpl();
    Method method =
        UserFeedBackChartServiceImpl.class.getDeclaredMethod(
            "processDefaultFeedBackTrend", List.class, List.class, Map.class);
    method.setAccessible(true);
    method.invoke(userFeedBackChartService, feedTrendList, infoList, userCountMap);
    assertEquals(
        infoList.size(), feedTrendList.size(), "Feed trend list size should match info list size");
  }
}
