package com.merck.nextconnect.userhub.validator.impl;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserhubValidatorImplTest {

  private UserhubValidatorImpl validator;
  private OrgAndUserDetail orgAndUserDetail;

  @BeforeEach
  void setUp() {
    validator = new UserhubValidatorImpl();
    orgAndUserDetail = new OrgAndUserDetail();

    // Set up valid data
    orgAndUserDetail.setInvitedVia(UserInvitedVia.INSTALLED_PRODUCT.value());
    orgAndUserDetail.setFirstName("John");
    orgAndUserDetail.setLastName("Doe");
    orgAndUserDetail.setEmail("john.doe@example.com");
    orgAndUserDetail.setBillTo("BillTo123");
    orgAndUserDetail.setShipTo("ShipTo123");
    orgAndUserDetail.setSoldTo("SoldTo123");
    orgAndUserDetail.setSmAdminCountryCode("US");
  }

  @Test
  void testValidateOrgStatus_ValidStatus() throws DataValidationException {
    // should not throw
    validator.validateOrgStatus(true);
  }

  @Test
  void testValidateOrgStatus_NullStatus() {
    assertThrows(DataValidationException.class, () -> validator.validateOrgStatus(null));
  }

  @Test
  void testValidateForNull_ValidData() throws DataValidationException {
    // should not throw
    validator.validateForNull(orgAndUserDetail);
  }

  @Test
  void testValidateForNull_NullInvitedVia() {
    orgAndUserDetail.setInvitedVia(null);
    assertThrows(DataValidationException.class, () -> validator.validateForNull(orgAndUserDetail));
  }

  @Test
  void testValidateForNull_NullFirstName() {
    orgAndUserDetail.setFirstName(null);
    assertThrows(DataValidationException.class, () -> validator.validateForNull(orgAndUserDetail));
  }

  @Test
  void testValidateForNull_NullLastName() {
    orgAndUserDetail.setLastName(null);
    assertThrows(DataValidationException.class, () -> validator.validateForNull(orgAndUserDetail));
  }

  @Test
  void testValidateForNull_NullEmail() {
    orgAndUserDetail.setEmail(null);
    assertThrows(DataValidationException.class, () -> validator.validateForNull(orgAndUserDetail));
  }

  @Test
  void testIsValidOrgDetailsPresent_ValidData() {
    assertTrue(validator.isValidOrgDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidOrgDetailsPresent_MissingSoldTo() {
    orgAndUserDetail.setSoldTo(null);
    assertFalse(validator.isValidOrgDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidOrgDetailsPresent_MissingBillTo() {
    orgAndUserDetail.setBillTo(null);
    assertFalse(validator.isValidOrgDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidOrgDetailsPresent_InvalidInvitedVia() {
    orgAndUserDetail.setInvitedVia("INVALID_VALUE");
    assertFalse(validator.isValidOrgDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidUserInviteDetailsPresent_ValidData() {
    assertTrue(validator.isValidUserInviteDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidUserInviteDetailsPresent_MissingFirstName() {
    orgAndUserDetail.setFirstName(null);
    assertFalse(validator.isValidUserInviteDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidUserInviteDetailsPresent_MissingLastName() {
    orgAndUserDetail.setLastName(null);
    assertFalse(validator.isValidUserInviteDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidUserInviteDetailsPresent_MissingEmail() {
    orgAndUserDetail.setEmail(null);
    assertFalse(validator.isValidUserInviteDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidUserInviteDetailsPresent_MissingCountryCode() {
    orgAndUserDetail.setSmAdminCountryCode(null);
    assertFalse(validator.isValidUserInviteDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testIsValidUserInviteDetailsPresent_InvalidInvitedVia() {
    orgAndUserDetail.setInvitedVia("INVALID_VALUE");
    assertFalse(validator.isValidUserInviteDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testValidInvitedVia_InstalledProduct() {
    orgAndUserDetail.setInvitedVia(UserInvitedVia.INSTALLED_PRODUCT.value());
    assertTrue(validator.isValidOrgDetailsPresent(orgAndUserDetail));
  }

  @Test
  void testValidInvitedVia_ServiceContract() {
    orgAndUserDetail.setInvitedVia(UserInvitedVia.SERVIE_CONTRACT.value());
    assertTrue(validator.isValidOrgDetailsPresent(orgAndUserDetail));
  }
}
