package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DeviceLocationTest {

  private DeviceLocation deviceLocation;
  private Long testLocationId;
  private String testLocationName;

  @BeforeEach
  public void setUp() {
    deviceLocation = new DeviceLocation();
    testLocationId = 123L;
    testLocationName = "Test Location";
  }

  @Test
  public void testGetSetLocationId() {
    deviceLocation.setLocationId(testLocationId);
    assertEquals(testLocationId, deviceLocation.getLocationId());
  }

  @Test
  public void testGetSetLocationName() {
    deviceLocation.setLocationName(testLocationName);
    assertEquals(testLocationName, deviceLocation.getLocationName());
  }
}
