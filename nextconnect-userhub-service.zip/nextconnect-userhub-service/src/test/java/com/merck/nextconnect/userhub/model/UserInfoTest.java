package com.merck.nextconnect.userhub.model;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.model.org.OrgSettingsDto;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class UserInfoTest {

  @Test
  public void testUserInfoGettersAndSetters() {
    // Create test data
    UserInfo userInfo = new UserInfo();
    userInfo.setId(123L);
    userInfo.setUsername("testuser");
    userInfo.setEmail("test@example.com");
    userInfo.setStatus("ACTIVE");
    userInfo.setRole("ADMIN");
    userInfo.setDateFormat("MM/dd/yyyy");
    userInfo.setCountryCode("US");
    userInfo.setDomainVisible(true);
    userInfo.setLanguageCode("en");
    userInfo.setRoleId(456L);
    userInfo.setOrgId(789);
    userInfo.setTimeZone(1);
    userInfo.setDomainName("example.com");
    userInfo.setOrgName("Test Org");
    userInfo.setAutoCreated(true);
    userInfo.setFirstName("John");
    userInfo.setLastName("Doe");
    userInfo.setInvitedVia("EMAIL");
    userInfo.setValidated(true);
    userInfo.setOrgType("CUSTOMER");
    userInfo.setParentType("PARENT");
    userInfo.setEmailInviteCount(2);

    // Set complex objects
    List<Privileges> privileges = new ArrayList<>();
    userInfo.setPrivileges(privileges);

    OrgSettingsDto orgSettings = new OrgSettingsDto();
    userInfo.setOrgSettings(orgSettings);

    UserProfileSettingsDTO userProfileSettings = new UserProfileSettingsDTO();
    userInfo.setUserProfileSettings(userProfileSettings);

    List<MenuGroupResponse> menuGroups = new ArrayList<>();
    userInfo.setMenuGroups(menuGroups);

    CountryTimezoneDTO countryTimezoneDTO = new CountryTimezoneDTO();
    userInfo.setCountryTimezoneDTO(countryTimezoneDTO);

    // Verify all getters return expected values
    assertEquals(123L, userInfo.getId());
    assertEquals("testuser", userInfo.getUsername());
    assertEquals("test@example.com", userInfo.getEmail());
    assertEquals("ACTIVE", userInfo.getStatus());
    assertEquals("ADMIN", userInfo.getRole());
    assertEquals("MM/dd/yyyy", userInfo.getDateFormat());
    assertEquals("US", userInfo.getCountryCode());
    assertTrue(userInfo.isDomainVisible());
    assertEquals("en", userInfo.getLanguageCode());
    assertEquals(456L, userInfo.getRoleId());
    assertEquals(789, userInfo.getOrgId());
    assertEquals(Integer.valueOf(1), userInfo.getTimeZone());
    assertEquals("example.com", userInfo.getDomainName());
    assertEquals("Test Org", userInfo.getOrgName());
    assertTrue(userInfo.isAutoCreated());
    assertEquals("John", userInfo.getFirstName());
    assertEquals("Doe", userInfo.getLastName());
    assertEquals("EMAIL", userInfo.getInvitedVia());
    assertTrue(userInfo.isValidated());
    assertEquals("CUSTOMER", userInfo.getOrgType());
    assertEquals("PARENT", userInfo.getParentType());
    assertEquals(2, userInfo.getEmailInviteCount());

    // Verify complex objects
    assertEquals(privileges, userInfo.getPrivileges());
    assertEquals(orgSettings, userInfo.getOrgSettings());
    assertEquals(userProfileSettings, userInfo.getUserProfileSettings());
    assertEquals(menuGroups, userInfo.getMenuGroups());
    assertEquals(countryTimezoneDTO, userInfo.getCountryTimezoneDTO());

    // Test boolean toggle
    userInfo.setDomainVisible(false);
    assertFalse(userInfo.isDomainVisible());

    userInfo.setAutoCreated(false);
    assertFalse(userInfo.isAutoCreated());

    userInfo.setValidated(false);
    assertFalse(userInfo.isValidated());
  }
}
