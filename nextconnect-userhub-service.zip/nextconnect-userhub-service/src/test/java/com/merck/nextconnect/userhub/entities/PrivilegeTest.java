package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PrivilegeTest {

  private Privilege privilege;
  private PrivilegeInfo privilegeInfo;

  @BeforeEach
  public void setUp() {
    privilege = new Privilege();
    privilegeInfo = new PrivilegeInfo();
    privilegeInfo.setResourceType("testResource");
    privilegeInfo.setOperation("testOperation");
  }

  @Test
  public void testDefaultConstructor() {
    Privilege privilege = new Privilege();
    assertEquals(0, privilege.getprivilegeId());
    assertEquals(null, privilege.getResourceType());
    assertEquals(null, privilege.getOperation());
  }

  @Test
  public void testPrivilegeInfoConstructor() {
    Privilege privilege = new Privilege(privilegeInfo);
    assertEquals("testResource", privilege.getResourceType());
    assertEquals("testOperation", privilege.getOperation());
  }

  @Test
  public void testParameterizedConstructor() {
    Privilege privilege = new Privilege(123L, "testResource", "testOperation");
    assertEquals(123L, privilege.getprivilegeId());
    assertEquals("testResource", privilege.getResourceType());
    assertEquals("testOperation", privilege.getOperation());
  }

  @Test
  public void testGetAndSetPrivilegeId() {
    long id = 123L;
    privilege.setprivilegeId(id);
    assertEquals(id, privilege.getprivilegeId());
  }

  @Test
  public void testGetAndSetResourceType() {
    String resourceType = "testResource";
    privilege.setResourceType(resourceType);
    assertEquals(resourceType, privilege.getResourceType());
  }

  @Test
  public void testGetAndSetOperation() {
    String operation = "testOperation";
    privilege.setOperation(operation);
    assertEquals(operation, privilege.getOperation());
  }
}
