package com.merck.nextconnect.userhub.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

public class SubscriptionCategoryDTOTest {

  @Test
  public void testConstructorAndGetters() {
    // Arrange
    Long id = 1L;
    String name = "Test Category";
    boolean status = true;
    List<String> emails = Arrays.asList("test@example.com", "test2@example.com");
    int days = 5;

    // Act
    SubscriptionCategoryDTO dto = new SubscriptionCategoryDTO(id, name, status, emails, days);

    // Assert
    assertEquals(id, dto.getSubscriptionCategoryId());
    assertEquals(name, dto.getCategoryName());
    assertEquals(status, dto.isStatus());
    assertEquals(emails, dto.getEmails());
    assertEquals(days, dto.getNumberOfDaysAdvance());
  }

  @Test
  public void testBuilder() {
    // Arrange
    Long id = 2L;
    String name = "Builder Category";
    boolean status = false;
    List<String> emails = Arrays.asList("builder@example.com");
    int days = 10;

    // Act
    SubscriptionCategoryDTO dto =
        SubscriptionCategoryDTO.builder()
            .subscriptionCategoryId(id)
            .categoryName(name)
            .status(status)
            .emails(emails)
            .numberOfDaysAdvance(days)
            .build();

    // Assert
    assertEquals(id, dto.getSubscriptionCategoryId());
    assertEquals(name, dto.getCategoryName());
    assertEquals(status, dto.isStatus());
    assertEquals(emails, dto.getEmails());
    assertEquals(days, dto.getNumberOfDaysAdvance());
  }

  @Test
  public void testNoArgsConstructor() {
    // Act
    SubscriptionCategoryDTO dto = new SubscriptionCategoryDTO();

    // Assert
    assertNotNull(dto);
  }

  @Test
  public void testCompareTo() {
    // Arrange
    SubscriptionCategoryDTO dto1 = new SubscriptionCategoryDTO(1L, "Category1", true, null, 0);
    SubscriptionCategoryDTO dto2 = new SubscriptionCategoryDTO(2L, "Category2", true, null, 0);
    SubscriptionCategoryDTO dto3 = new SubscriptionCategoryDTO(1L, "Different", false, null, 0);

    // Assert
    assertEquals(-1, dto1.compareTo(dto2)); // 1 < 2
    assertEquals(1, dto2.compareTo(dto1)); // 2 > 1
    assertEquals(0, dto1.compareTo(dto3)); // Same ID
  }

  @Test
  public void testToString() {
    // Arrange
    Long id = 3L;
    String name = "ToString Category";
    boolean status = true;
    List<String> emails = Arrays.asList("string@example.com");
    int days = 7;

    SubscriptionCategoryDTO dto = new SubscriptionCategoryDTO(id, name, status, emails, days);

    // Act
    String result = dto.toString();

    // Assert
    assertTrue(result.contains(id.toString()));
    assertTrue(result.contains(name));
    assertTrue(result.contains(String.valueOf(status)));
    assertTrue(result.contains(emails.toString()));
    assertTrue(result.contains(String.valueOf(days)));
  }
}
