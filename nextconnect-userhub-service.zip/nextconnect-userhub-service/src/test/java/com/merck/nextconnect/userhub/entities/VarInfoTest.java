package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class VarInfoTest {

  private VarInfo varInfo;

  @BeforeEach
  public void setUp() {
    varInfo = new VarInfo();
  }

  @Test
  public void testGetSetId() {
    Integer id = 123;
    varInfo.setId(id);
    assertEquals(id, varInfo.getId());
  }

  @Test
  public void testGetSetVarShortName() {
    String shortName = "testShortName";
    varInfo.setVarShortName(shortName);
    assertEquals(shortName, varInfo.getVarShortName());
  }

  @Test
  public void testGetSetVarDispName() {
    String dispName = "Test Display Name";
    varInfo.setVarDispName(dispName);
    assertEquals(dispName, varInfo.getVarDispName());
  }

  @Test
  public void testGetSetVarType() {
    String varType = "STRING";
    varInfo.setVarType(varType);
    assertEquals(varType, varInfo.getVarType());
  }
}
