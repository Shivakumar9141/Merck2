package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.entities.UIOutputDisplay;
import com.merck.nextconnect.userhub.repository.jpa.UIOutputDisplayRepository;
import com.merck.nextconnect.userhub.resources.impl.UIOutputDisplayServiceImpl;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class UIOutputDisplayServiceImplTest {

  @Test
  public void testGetAll() {
    UIOutputDisplayRepository outputDisplayRepository = mock(UIOutputDisplayRepository.class);
    UIOutputDisplayServiceImpl outputDisplayService = new UIOutputDisplayServiceImpl();
    ReflectionTestUtils.setField(
        outputDisplayService, "outputDisplayRepository", outputDisplayRepository);
    List<UIOutputDisplay> expectedOutputDisplays = new ArrayList<>();
    UIOutputDisplay outputDisplay1 = new UIOutputDisplay();
    outputDisplay1.setId(1);
    expectedOutputDisplays.add(outputDisplay1);
    when(outputDisplayRepository.findAll()).thenReturn(expectedOutputDisplays);
    List<UIOutputDisplay> actualOutputDisplays = outputDisplayService.getAll();
    verify(outputDisplayRepository).findAll();

    assertEquals(expectedOutputDisplays.size(), actualOutputDisplays.size());
  }
}
