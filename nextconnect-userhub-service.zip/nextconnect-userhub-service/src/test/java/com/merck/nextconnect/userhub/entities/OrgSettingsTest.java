package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class OrgSettingsTest {

  private OrgSettings orgSettings;
  private Organization organization;

  @BeforeEach
  public void setUp() {
    orgSettings = new OrgSettings();
    organization = new Organization();
    organization.setId(1);
  }

  @Test
  public void testGetSetId() {
    orgSettings.setId(123);
    assertEquals(123, orgSettings.getId());
  }

  @Test
  public void testGetSetOrg() {
    orgSettings.setOrg(organization);
    assertEquals(organization, orgSettings.getOrg());
  }

  @Test
  public void testGetSetLogo() {
    String logo = "company_logo.png";
    orgSettings.setLogo(logo);
    assertEquals(logo, orgSettings.getLogo());
  }

  @Test
  public void testGetSetTheme() {
    String theme = "dark";
    orgSettings.setTheme(theme);
    assertEquals(theme, orgSettings.getTheme());
  }

  @Test
  public void testGetSetAppName() {
    String appName = "NextConnect";
    orgSettings.setAppName(appName);
    assertEquals(appName, orgSettings.getAppName());
  }

  @Test
  public void testGetSetHistoricalDataSubscription() {
    Long subscription = 365L;
    orgSettings.setHistoricalDataSubscription(subscription);
    assertEquals(subscription, orgSettings.getHistoricalDataSubscription());
  }

  @Test
  public void testDefaultValues() {
    OrgSettings newOrgSettings = new OrgSettings();
    assertEquals(0, newOrgSettings.getId());
    assertNull(newOrgSettings.getOrg());
    assertNull(newOrgSettings.getLogo());
    assertNull(newOrgSettings.getTheme());
    assertNull(newOrgSettings.getAppName());
    assertNull(newOrgSettings.getHistoricalDataSubscription());
  }
}
