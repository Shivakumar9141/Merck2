package com.merck.nextconnect.userhub.validator.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;

import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LegalTermsValidatorImplTest {

  private LegalTermsValidatorImpl legalTermsValidator;

  @BeforeEach
  public void setUp() {
    legalTermsValidator = new LegalTermsValidatorImpl();
  }

  @Test
  public void testValidateForNull_ValidInputs() throws DataValidationException {
    // Should not throw exception with valid inputs
    legalTermsValidator.validateForNull("en", "US", "privacy policy");
    legalTermsValidator.validateForNull("fr", "FR", "terms and condition");
  }

  @Test
  public void testValidateForNull_NullLanguageCode() {
    assertThrows(
        DataValidationException.class,
        () -> legalTermsValidator.validateForNull(null, "US", "privacy policy"));
  }

  @Test
  public void testValidateForNull_NullCountryCode() {
    assertThrows(
        DataValidationException.class,
        () -> legalTermsValidator.validateForNull("en", null, "privacy policy"));
  }

  @Test
  public void testValidateForNull_NullType() {
    assertThrows(
        DataValidationException.class, () -> legalTermsValidator.validateForNull("en", "US", null));
  }

  @Test
  public void testValidateForNull_InvalidType() {
    assertThrows(
        DataValidationException.class,
        () -> legalTermsValidator.validateForNull("en", "US", "invalid type"));
  }
}
