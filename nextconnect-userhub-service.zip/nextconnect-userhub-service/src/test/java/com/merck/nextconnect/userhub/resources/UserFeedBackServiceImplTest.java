package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserFeedBackEntity;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.FeedBackDTO;
import com.merck.nextconnect.userhub.model.FeedBackStatus;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackPageDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingsDTO;
import com.merck.nextconnect.userhub.model.user.UserDataList;
import com.merck.nextconnect.userhub.repo.jdbc.UserFeedBackRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserDefaulterFeedBackSpecification;
import com.merck.nextconnect.userhub.repository.jpa.UserFeedBackRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserFeedBackSpecification;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.impl.UserFeedBackServiceImpl;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UserFeedBackServiceImplTest {

  @InjectMocks private UserFeedBackServiceImpl userFeedBackService;
  @Mock private UserFeedBackRepository userFeedBackRepository;
  @Mock private UserRepository userRepository;
  @Mock private AuthenticatedUser authUser;

  private Authentication authentication;

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @Mock private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;

  @Mock private UserFeedBackSpecification userFeedBackSpecification;

  @Mock private UserDefaulterFeedBackSpecification userDefaulterFeedBackSpecification;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
    when(authUser.getOrgId()).thenReturn(5);
    // Removed unnecessary stub: when(authUser.getId()).thenReturn("1");
    // Removed unnecessary stub: when(authUser.getRoleId()).thenReturn(1L);
    // Removed unnecessary stub: when(authUser.getRole()).thenReturn("USER");
    //  mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testCreateFeedBack() throws CustomException {
    // Prepare test data
    UserFeedBackDTO feedBackDTO = new UserFeedBackDTO();
    feedBackDTO.setFeedback("Test feedback");
    feedBackDTO.setRating(4);

    UserProfile userProfile = new UserProfile();
    userProfile.setCountry(new Country(12, "123", "india"));
    userProfile.setStatus("Active");
    userProfile.setDeleted(false);

    UserFeedBackEntity userEntity =
        new UserFeedBackEntity(1, userProfile, 12, "feedBack", new Timestamp(12L));
    when(userRepository.findByUserIdAndStatusAndDeleted(anyLong(), anyString(), anyBoolean()))
        .thenReturn(userProfile);
    when(userFeedBackRepository.save(any(UserFeedBackEntity.class))).thenReturn(userEntity);
    UserDataDTO result = userFeedBackService.createFeedBack(feedBackDTO, "1");
    assertNotNull(result);
    assertNotNull(result.getCountryName());
    assertNotNull(result.getCreatedDate());
  }

  @Test
  public void testGetAllFeedBack() throws CustomException {
    authUser = (AuthenticatedUser) loadUserByRole("LW-FSE");
    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));

    when(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null))
        .thenReturn(new ArrayList<>());
    when(userFeedBackRepositoryJdbc.getAllFeedBacks("1")).thenReturn(entities);

    FeedBackDTO result = userFeedBackService.getAllUsersFeedBack(authUser);
    assertNotNull(result);
  }

  @Test
  public void testGetAllUsersFeedBack_DistributorFseRole() throws CustomException {
    authUser = (AuthenticatedUser) loadUserByRole("Distributor FSE");

    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));

    List<Integer> orgs = Arrays.asList(1, 2);
    when(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null))
        .thenReturn(new ArrayList<>());
    when(userFeedBackRepository.getDistributorFSEOrgs(anyLong(), anyList(), anyInt()))
        .thenReturn(orgs);
    when(userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSE(
            "1", Arrays.asList("Technical User", "Quality Manager", "Customer Admin"), orgs))
        .thenReturn(entities);
    FeedBackDTO result = userFeedBackService.getAllUsersFeedBack(authUser);
    assertNotNull(result);
  }

  @Test
  public void testGetAllUsersFeedBack_DistributorAdminRole() throws CustomException {
    authUser = (AuthenticatedUser) loadUserByRole("Distributor Admin");

    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));

    List<Integer> orgs = Arrays.asList(1, 2);
    when(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null))
        .thenReturn(new ArrayList<>());
    when(userFeedBackRepository.getDistributorAdminOrgs(anyList(), anyInt())).thenReturn(orgs);
    when(userFeedBackRepositoryJdbc.getAllUsersFeedBacksForDistributorAdmin(
            Arrays.asList("Technical User", "Quality Manager", "Customer Admin"), orgs))
        .thenReturn(entities);
    FeedBackDTO result = userFeedBackService.getAllUsersFeedBack(authUser);
    assertNotNull(result);
  }

  @Test
  public void testGetAllUsersFeedBack() throws CustomException {

    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));

    when(authUser.getRole()).thenReturn("ADMIN"); // Mock to go to the else branch
    when(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null))
        .thenReturn(new ArrayList<>());
    when(userFeedBackRepositoryJdbc.getAllUsersFeedBacks()).thenReturn(entities);
    FeedBackDTO result = userFeedBackService.getAllUsersFeedBack(authUser);
    assertNotNull(result);
  }

  @Test
  public void testGetFeedBack_NoFeedbackFound() {
    Long userId = 1L;
    UserProfile userProfile = new UserProfile();
    userProfile.setCountry(new Country());
    when(userRepository.findById(userId)).thenReturn(java.util.Optional.of(userProfile));
    when(userFeedBackRepository.getAllFeedbackByCountry(any())).thenReturn(new ArrayList<>());

    assertThrows(CustomException.class, () -> userFeedBackService.getFeedBack(userId));
  }

  @Test
  public void testGetFeedBack_WithFeedback() throws CustomException {
    Long userId = 1L;
    UserProfile userProfile = new UserProfile();
    userProfile.setCountry(new Country());
    userProfile.setValidated(true);
    userProfile.setInvitedOrActivatedTs(Timestamp.from(Instant.now()));
    List<UserFeedBackEntity> entities = new ArrayList<>();
    entities.add(
        new UserFeedBackEntity(1L, userProfile, 1, "feedBack", Timestamp.from(Instant.now())));
    when(userRepository.findById(userId)).thenReturn(java.util.Optional.of(userProfile));
    when(userFeedBackRepository.getAllFeedbackByCountry(any())).thenReturn(entities);
    when(userFeedBackRepository.getLatestFeedBack(userId))
        .thenReturn(
            new UserFeedBackEntity(1L, userProfile, 1, "feedBack", Timestamp.from(Instant.now())));
    FeedBackStatus result = userFeedBackService.getFeedBack(userId);
    assertNotNull(result);
    assertTrue(result.isStatus());
  }

  @Test
  public void testGetAllFeedBack_EmptyList() {
    Long userId = 1L;
    when(userFeedBackRepositoryJdbc.getAllUsersFeedBacks()).thenReturn(new ArrayList<>());

    assertThrows(CustomException.class, () -> userFeedBackService.getAllFeedBack(userId));
  }

  @Test
  public void testGetAllFeedBack_NonEmptyList() throws CustomException {
    Long userId = 1L;
    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));
    when(userFeedBackRepositoryJdbc.getAllUsersFeedBacks()).thenReturn(entities);

    FeedBackDTO result = userFeedBackService.getAllFeedBack(userId);

    assertNotNull(result);
  }

  @Test
  public void testGetAllFeedBacks_NonEmptyList() {
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setSortBy("rating");
    fetchCriteria.setPageNo(1);
    fetchCriteria.setPageLimit(10);
    fetchCriteria.setOrderBy("DESC");
    List<UserFeedBackEntity> users = new ArrayList<>();
    Language lang = new Language(1);
    lang.setValue("Eng");
    Organization org = new Organization(1);
    org.setName("org");
    Role role = new Role(1L);
    role.setName("role");
    UserProfile user = new UserProfile();
    user.setUserId(1L);
    user.setLanguage(lang);
    user.setFirstName("test");
    user.setLastName("test");
    user.setOrg(org);
    user.setRole(role);
    user.setEmail("email");
    user.setCountry(new Country(1, "countryCode", "countryName"));
    users.add(new UserFeedBackEntity(1L, user, 1, "feedBack", Timestamp.from(Instant.now())));

    PageRequest pageRequest = PageRequest.of(0, 10);
    Page<UserFeedBackEntity> pagedUsers = new PageImpl<>(users, pageRequest, users.size());

    when(userFeedBackSpecification.specification(any(FetchCriteria.class))).thenReturn(null);
    when(userFeedBackRepository.findAll(
            (Specification<UserFeedBackEntity>) isNull(), any(Pageable.class)))
        .thenReturn(pagedUsers);

    UserFeedBackPageDTO result = userFeedBackService.getAllFeedBacks(fetchCriteria);

    // Verify the result
    assertNotNull(result);
    assertFalse(result.getUsers().isEmpty());
    assertEquals(1, result.getTotalPages());
    assertEquals(1, result.getRecordCount());
  }

  @Test
  public void testGetUserFeedBackFacets_NonEmptyList() throws CustomException {
    Role role = new Role();
    role.setName("role");
    Organization org = new Organization();
    org.setName("org");
    UserProfile user = new UserProfile();
    user.setRole(role);
    user.setCountry(new Country(1, "123", "countryName"));
    user.setOrg(org);
    List<UserFeedBackEntity> userProfiles = new ArrayList<UserFeedBackEntity>();
    userProfiles.add(
        new UserFeedBackEntity(1L, user, 1, "feedBack", Timestamp.from(Instant.now())));
    FetchCriteria fetchCriteria = new FetchCriteria();

    // when(userFeedBackSpecification.specification(any())).thenReturn(any());
    when(userFeedBackRepository.findAll(userFeedBackSpecification.specification(any())))
        .thenReturn(userProfiles);

    UserFeedBackFacets result = userFeedBackService.getUserFeedBackFacets();

    // Verify the result
    assertNotNull(result);
  }

  @Test
  public void testGetUserFeedBackFacets_EmptyList() throws CustomException {
    List<UserFeedBackEntity> userProfiles = new ArrayList<>();
    FetchCriteria fetchCriteria = new FetchCriteria();

    // when(userFeedBackSpecification.specification(new
    // FetchCriteria())).thenReturn(any());
    when(userFeedBackRepository.findAll(userFeedBackSpecification.specification(any())))
        .thenReturn(userProfiles);

    UserFeedBackFacets result = userFeedBackService.getUserFeedBackFacets();
  }

  @Test
  public void testGetRatingDetailsForFseUser() throws CustomException {
    authUser = (AuthenticatedUser) loadUserByRole("LW-FSE");
    List<UserDataDTO> entities = new ArrayList<>();

    // Add multiple users with different IDs to make getUniqueUsersCounts work properly
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));
    entities.add(
        new UserDataDTO(
            2L,
            "firstName2",
            "lastName2",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback2",
            "countryCode",
            "role",
            "email2",
            1L,
            "userOrgCreatedVia"));

    List<UserFeedBackRatingsDTO> val = new ArrayList<>();
    val.add(new UserFeedBackRatingsDTO(1, 1, 2));
    when(userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSEWithFilters(
            anyString(), anyList(), anyList(), anyString()))
        .thenReturn(entities);
    when(userFeedBackRepositoryJdbc.getAllRatings(eq(123L), anyString())).thenReturn(val);
    when(userFeedBackRepositoryJdbc.getAllFeedBacksWithFilters(eq("123"), anyString()))
        .thenReturn(entities);
    // Mock getTotalFSEUsers - use lenient() to ensure it matches regardless of parameter specifics
    when(userFeedBackRepositoryJdbc.getTotalFSEUsers(any(), any(), any()))
        .thenReturn(20L); // Total users should be larger than unique feedback users (2)
    UserFeedBackRatingDTO ratingDetails =
        userFeedBackService.getRatingDetails(
            123L,
            authUser,
            Arrays.asList(
                "rating.rating", "roles.roles", "cusorg.cusorg", "countryCode.countryCode"));
    assertNotNull(ratingDetails);
    assertEquals(10.0, ratingDetails.getFeedBackPercentage(), 0.1); // 2/20 * 100 = 10%
  }

  @Test
  public void testGetRatingDetailsForDistributorFse() throws CustomException {
    authUser = (AuthenticatedUser) loadUserByRole(Constants.DISTRIBUTOR_FSE);
    List<UserFeedBackRatingsDTO> val = new ArrayList<>();
    val.add(new UserFeedBackRatingsDTO(1, 1, 2));
    when(userFeedBackRepositoryJdbc.getAllRatingsForDistributorFSE(
            anyLong(), anyList(), anyList(), anyString()))
        .thenReturn(val);

    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));
    when(userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSEWithFilters(
            anyString(), anyList(), anyList(), anyString()))
        .thenReturn(entities);
    when(userFeedBackRepository.getDistributorFSEOrgs(
            Long.valueOf(authUser.getId()),
            Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
            authUser.getOrgId()))
        .thenReturn(Arrays.asList(1, 2));
    when(userFeedBackRepositoryJdbc.getTotalDistributorFSEUsers(
            anyLong(), anyList(), anyList(), anyString()))
        .thenReturn(2L);

    UserFeedBackRatingDTO ratingDetails =
        userFeedBackService.getRatingDetails(123L, authUser, Arrays.asList("filter1", "filter2"));
    assertNotNull(ratingDetails);
  }

  @Test
  public void testGetRatingDetailsForDistributorAdmin() throws CustomException {
    authUser = (AuthenticatedUser) loadUserByRole(Constants.DISTRIBUTOR_ADMIN);

    List<UserFeedBackRatingsDTO> val = new ArrayList<>();
    val.add(new UserFeedBackRatingsDTO(1, 1, 2));
    when(userFeedBackRepositoryJdbc.getAllUsersRatingsForDistributorAdmin(
            anyLong(), anyList(), anyList(), anyString()))
        .thenReturn(val);

    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));
    when(userFeedBackRepositoryJdbc.getAllUsersFeedBacksForDistributorAdminWithFilters(
            anyList(), anyList(), anyString()))
        .thenReturn(entities);
    when(userFeedBackRepositoryJdbc.getTotalUsersDistributorAdmin(
            anyList(), anyList(), anyString()))
        .thenReturn(2L);
    when(userFeedBackRepository.getDistributorAdminOrgs(
            Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")), authUser.getOrgId()))
        .thenReturn(Arrays.asList(1, 2));

    UserFeedBackRatingDTO ratingDetails =
        userFeedBackService.getRatingDetails(123L, authUser, Arrays.asList("filter1", "filter2"));
    assertNotNull(ratingDetails);
  }

  @Test
  public void testGetRatingDetailsForOtherRole() throws CustomException {
    when(authUser.getRole()).thenReturn("ADMIN"); // Mock the role to avoid NPE
    when(authUser.getOrgId()).thenReturn(1);
    when(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null))
        .thenReturn(new ArrayList<>());

    List<UserFeedBackRatingsDTO> val = new ArrayList<>();
    val.add(new UserFeedBackRatingsDTO(1, 1, 2));
    when(userFeedBackRepositoryJdbc.getAllUsersRatings(eq(123L), anyString())).thenReturn(val);

    List<UserDataDTO> entities = new ArrayList<>();
    entities.add(
        new UserDataDTO(
            1L,
            "firstName",
            "lastName",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback",
            "countryCode",
            "role",
            "email",
            1L,
            "userOrgCreatedVia"));
    entities.add(
        new UserDataDTO(
            2L,
            "firstName2",
            "lastName2",
            "customerOrgName",
            "language",
            "countryName",
            null,
            1,
            "feedback2",
            "countryCode",
            "role",
            "email2",
            1L,
            "userOrgCreatedVia"));
    when(userFeedBackRepositoryJdbc.getAllUsersFeedBacksWithFilters(anyString()))
        .thenReturn(entities);
    // Use any() for all parameters to ensure matching
    when(userFeedBackRepositoryJdbc.getTotalUsers(any(), any()))
        .thenReturn(20L); // Larger than unique users (2)

    UserFeedBackRatingDTO ratingDetails =
        userFeedBackService.getRatingDetails(123L, authUser, Arrays.asList("filter1", "filter2"));
    assertNotNull(ratingDetails);
    assertEquals(10.0, ratingDetails.getFeedBackPercentage(), 0.1); // 2/20 * 100 = 10%
  }

  @Test
  public void testGetRatingDetailsWithEmptyRepositories() {
    // Mock authUser to be DISTRIBUTOR_FSE role to trigger the else branch with empty entities
    when(authUser.getRole()).thenReturn(Constants.DISTRIBUTOR_FSE);
    when(authUser.getId()).thenReturn("123");

    // Mock userOrgPrivileges to return empty list so accessibleOrgs remains empty
    when(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null))
        .thenReturn(new ArrayList<>());

    // Mock getDistributorFSEOrgs to return empty list
    when(userFeedBackRepository.getDistributorFSEOrgs(anyLong(), anyList(), anyInt()))
        .thenReturn(new ArrayList<>());

    assertThrows(
        CustomException.class,
        () -> userFeedBackService.getRatingDetails(123L, authUser, Arrays.asList()));
  }

  @Test
  public void testGetFeedBackDefaultersWithNoFeedbackFilter() throws CustomException {
    com.merck.nextconnect.utils.model.FetchCriteria fetchCriteria =
        new com.merck.nextconnect.utils.model.FetchCriteria();
    List<String> filterBy = new ArrayList<>();
    filterBy.add(Constants.NOFEEDBACK);
    fetchCriteria.setFilterBy(filterBy);
    fetchCriteria.setSortBy("org.name");
    fetchCriteria.setOrderBy("desc");
    fetchCriteria.setPageNo(1);
    fetchCriteria.setPageLimit(10);
    Language lang = new Language(1);
    lang.setValue("Eng");
    Organization org = new Organization(1);
    org.setName("org");
    Role role = new Role(1L);
    role.setName("role");
    UserProfile user = new UserProfile();
    user.setUserId(1L);
    user.setLanguage(lang);
    user.setFirstName("test");
    user.setLastName("test");
    user.setOrg(org);
    user.setRole(role);
    user.setEmail("email");
    user.setCountry(new Country(1, "countryCode", "countryName"));
    List<UserProfile> users = new ArrayList<>();
    users.add(user);

    PageRequest page = PageRequest.of(0, 10);
    Page<UserProfile> pagedUsers = new PageImpl<>(users, page, users.size());

    when(userDefaulterFeedBackSpecification.specification(
            any(com.merck.nextconnect.userhub.model.FetchCriteria.class)))
        .thenReturn(null);
    when(userRepository.findAll((Specification<UserProfile>) isNull(), any(Pageable.class)))
        .thenReturn(pagedUsers);
    UserDataList result = userFeedBackService.getFeedBackDefaulters(fetchCriteria);

    assertNotNull(result);
  }

  @Test
  public void testGetFeedBackDefaultersWithoutNoFeedbackFilter() throws CustomException {
    com.merck.nextconnect.utils.model.FetchCriteria fetchCriteria =
        new com.merck.nextconnect.utils.model.FetchCriteria();
    fetchCriteria.setSortBy("org.name");
    fetchCriteria.setOrderBy("desc");
    fetchCriteria.setPageNo(1);
    fetchCriteria.setPageLimit(10);
    Language lang = new Language(1);
    lang.setValue("Eng");
    Organization org = new Organization(1);
    org.setName("org");
    Role role = new Role(1L);
    role.setName("role");
    UserProfile user = new UserProfile();
    user.setUserId(1L);
    user.setLanguage(lang);
    user.setFirstName("test");
    user.setLastName("test");
    user.setOrg(org);
    user.setRole(role);
    user.setEmail("email");
    user.setCountry(new Country(1, "countryCode", "countryName"));

    List<UserFeedBackEntity> users = new ArrayList<>();
    users.add(new UserFeedBackEntity(1L, user, 1, "feedBack", Timestamp.from(Instant.now())));

    PageRequest page = PageRequest.of(0, 10);
    Page<UserFeedBackEntity> pagedUsers = new PageImpl<>(users, page, users.size());

    when(userFeedBackSpecification.specification(any(FetchCriteria.class))).thenReturn(null);
    when(userFeedBackRepository.findAll(
            (Specification<UserFeedBackEntity>) isNull(), any(Pageable.class)))
        .thenReturn(pagedUsers);
    UserDataList result = userFeedBackService.getFeedBackDefaulters(fetchCriteria);

    assertNotNull(result);
  }

  public UserDetails loadUserByRole(String role) throws UsernameNotFoundException {

    List<GrantedAuthority> list = new ArrayList<GrantedAuthority>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(1);
    jwtUser.setRoleId(154);
    jwtUser.setRole(role);
    jwtUser.setOrgId(5);
    jwtUser.setUsername("qa1.lbwter@yandex.com");
    jwtUser.setSystemDefinedRole(true);
    return new AuthenticatedUser(jwtUser, "Test@123", list);
  }
}
