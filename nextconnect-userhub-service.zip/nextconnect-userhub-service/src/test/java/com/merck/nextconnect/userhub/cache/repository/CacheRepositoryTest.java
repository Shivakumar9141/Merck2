package com.merck.nextconnect.userhub.cache.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

import com.hazelcast.cluster.Cluster;
import com.hazelcast.core.DistributedObject;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.merck.nextconnect.userhub.cache.util.CacheUtil;
import java.lang.reflect.Field;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

/** JUnit 5 conversion of CacheRepositoryTest. */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CacheRepositoryTest {

  @Mock private HazelcastInstance hazelcastInstance;

  @Mock private IMap<Object, Object> mockMap;

  @Mock private Cluster cluster;

  @InjectMocks private CacheRepository cacheRepository;

  @BeforeEach
  public void setUp() {
    // With MockitoExtension, mocks are initialized automatically

    // Basic stubbing used across tests
    // Casts are used to satisfy generic type bounds when necessary
    when(hazelcastInstance.getMap(anyString())).thenReturn(mockMap);
    when(hazelcastInstance.getCluster()).thenReturn(cluster);

    // Setup CacheUtil.HazelcastMapInfo for clearAllMaps test
    try {
      Field field = CacheUtil.class.getDeclaredField("HazelcastMapInfo");
      field.setAccessible(true);
      Map<String, String> newMap = new HashMap<>();
      newMap.put("testMap", "Test Map");
      field.set(null, newMap);
    } catch (Exception e) {
      // Log and continue; tests should still run with the default behaviour
      System.err.println("Failed to set CacheUtil.HazelcastMapInfo: " + e.getMessage());
    }
  }

  @Test
  public void testGetMapValues_WithLongResourceId() {
    // Setup
    @SuppressWarnings("unchecked")
    Map.Entry<Object, Object> entry = mock(Map.Entry.class);
    when(entry.getKey()).thenReturn(1L);

    Iterator<Map.Entry<Object, Object>> mockIterator = mock(Iterator.class);
    when(mockIterator.hasNext()).thenReturn(true, false);
    when(mockIterator.next()).thenReturn(entry);

    @SuppressWarnings("unchecked")
    Set<Map.Entry<Object, Object>> mockEntrySet = mock(Set.class);
    when(mockEntrySet.iterator()).thenReturn(mockIterator);

    when(mockMap.isEmpty()).thenReturn(false);
    when(mockMap.entrySet()).thenReturn(mockEntrySet);
    when(mockMap.get(1L)).thenReturn("testValue");

    // Execute
    String result = cacheRepository.getMapValues("testMap", "1");

    // Verify
    assertEquals("testValue", result);
  }

  @Test
  public void testGetMapValues_WithStringResourceId() {
    // Setup
    @SuppressWarnings("unchecked")
    Map.Entry<Object, Object> entry = mock(Map.Entry.class);
    when(entry.getKey()).thenReturn("testKey");

    Iterator<Map.Entry<Object, Object>> mockIterator = mock(Iterator.class);
    when(mockIterator.hasNext()).thenReturn(true, false);
    when(mockIterator.next()).thenReturn(entry);

    @SuppressWarnings("unchecked")
    Set<Map.Entry<Object, Object>> mockEntrySet = mock(Set.class);
    when(mockEntrySet.iterator()).thenReturn(mockIterator);

    when(mockMap.isEmpty()).thenReturn(false);
    when(mockMap.entrySet()).thenReturn(mockEntrySet);
    when(mockMap.get("testId")).thenReturn("testValue");

    // Execute
    String result = cacheRepository.getMapValues("testMap", "testId");

    // Verify
    assertEquals("testValue", result);
  }

  @Test
  public void testGetMapValues_WithNullValue() {
    // Setup
    @SuppressWarnings("unchecked")
    Map.Entry<Object, Object> entry = mock(Map.Entry.class);
    when(entry.getKey()).thenReturn("testKey");

    Iterator<Map.Entry<Object, Object>> mockIterator = mock(Iterator.class);
    when(mockIterator.hasNext()).thenReturn(true, false);
    when(mockIterator.next()).thenReturn(entry);

    @SuppressWarnings("unchecked")
    Set<Map.Entry<Object, Object>> mockEntrySet = mock(Set.class);
    when(mockEntrySet.iterator()).thenReturn(mockIterator);

    when(mockMap.isEmpty()).thenReturn(false);
    when(mockMap.entrySet()).thenReturn(mockEntrySet);
    when(mockMap.get("testId")).thenReturn(null);

    // Execute
    String result = cacheRepository.getMapValues("testMap", "testId");

    // Verify
    assertEquals("No Entry is present for this resourceId ", result);
  }

  @Test
  public void testGetMapValues_WithoutResourceId() {
    // Setup
    Map<Object, Object> resultMap = new HashMap<>();
    resultMap.put("key1", "value1");

    when(mockMap.isEmpty()).thenReturn(false);
    when(mockMap.entrySet()).thenReturn(resultMap.entrySet());

    // Execute
    String result = cacheRepository.getMapValues("testMap", null);

    // Verify
    assertNotNull(result);
  }

  @Test
  public void testGetMapValues_EmptyMap() {
    // Setup
    when(mockMap.isEmpty()).thenReturn(true);

    // Execute
    String result = cacheRepository.getMapValues("testMap", null);

    // Verify
    assertEquals("Map is Empty", result);
  }

  @Test
  public void testClearCacheValues_WithMapNameAndResourceId() {
    // Setup
    @SuppressWarnings("unchecked")
    Map.Entry<Object, Object> entry = mock(Map.Entry.class);
    when(entry.getKey()).thenReturn(1L);

    Iterator<Map.Entry<Object, Object>> mockIterator = mock(Iterator.class);
    when(mockIterator.hasNext()).thenReturn(true, false);
    when(mockIterator.next()).thenReturn(entry);

    @SuppressWarnings("unchecked")
    Set<Map.Entry<Object, Object>> mockEntrySet = mock(Set.class);
    when(mockEntrySet.iterator()).thenReturn(mockIterator);

    when(mockMap.isEmpty()).thenReturn(false);
    when(mockMap.entrySet()).thenReturn(mockEntrySet);
    when(mockMap.containsKey(1L)).thenReturn(true);

    // Execute
    String result = cacheRepository.clearCacheValues("testMap", "1");

    // Verify
    assertEquals("Entry will be cleared for this resourceId", result);
    verify(mockMap).remove(1L);
  }

  @Test
  public void testClearCacheValues_WithMapNameOnly() {
    // Setup
    when(mockMap.isEmpty()).thenReturn(false);

    // Execute
    String result = cacheRepository.clearCacheValues("testMap", null);

    // Verify
    assertEquals("Entire map is cleared", result);
    verify(mockMap).clear();
  }

  @Test
  public void testClearCacheValues_AllMaps() {
    // Execute
    String result = cacheRepository.clearCacheValues(null, null);

    // Verify
    assertEquals("All maps are cleared", result);
    // Verify that getMap is called for at least one of the maps
    verify(hazelcastInstance, atLeastOnce()).getMap(anyString());
    // Note: original test expected mockMap.clear() to be called 15 times; keep the same
    // verification
    verify(mockMap, times(15)).clear();
  }

  @Test
  public void testGetMembers() {
    // Setup
    when(cluster.getMembers()).thenReturn(Collections.emptySet());

    // Execute
    String result = cacheRepository.getMembers();

    // Verify
    assertNotNull(result);
    verify(hazelcastInstance).getCluster();
    verify(cluster).getMembers();
  }

  @Test
  public void testGetAllDistributedCacheValues() {
    // Setup
    DistributedObject distributedObject =
        mock(DistributedObject.class, withSettings().extraInterfaces(Map.class));
    when(distributedObject.getName()).thenReturn("testMap");

    Collection<DistributedObject> objects = Collections.singletonList(distributedObject);
    when(hazelcastInstance.getDistributedObjects()).thenReturn(objects);

    Map<Object, Object> resultMap = new HashMap<>();
    resultMap.put("key1", "value1");
    when(mockMap.entrySet()).thenReturn(resultMap.entrySet());

    // Execute
    Map<String, String> result = cacheRepository.getAllDistributedCacheValues();

    // Verify
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @SuppressWarnings("rawtypes")
  @Test
  public void testGetApplicationConfigMap() {
    // Setup
    IMap<String, Object> configMap = mock(IMap.class);
    when(hazelcastInstance.getMap("applicationConfig")).thenReturn((IMap) configMap);

    // Execute
    IMap<String, Object> result = cacheRepository.getApplicationConfigMap();

    // Verify
    assertNotNull(result);
    verify(hazelcastInstance).getMap("applicationConfig");
  }
}
