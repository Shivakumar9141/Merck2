package com.merck.nextconnect.userhub.model.privilege;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class OrgPrivilegeTest {

  @Test
  public void testParameterizedConstructor() {
    // Setup test data
    long privilegeId = 123L;
    String operation = "READ";
    int resourceId = 456;
    String resourceType = "ORGANIZATION";

    // Create instance using parameterized constructor
    OrgPrivilege privilege = new OrgPrivilege(privilegeId, operation, resourceId, resourceType);

    // Verify all fields were set correctly
    assertEquals(privilegeId, privilege.getPrivilegeId());
    assertEquals(operation, privilege.getOperation());
    assertEquals(resourceId, privilege.getResourceId());
    assertEquals(resourceType, privilege.getResourceType());
  }
}
