package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.mail.IMailService;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.repository.jpa.DateFormatRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDomainRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.CountryLanguage;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.common.repository.jpa.CountryLanguageRepository;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.LanguageRepository;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserSupportImplTest {

  private MockedStatic<UserhubUtils> mockedUserhubUtils;

  @InjectMocks private UserSupportImpl userSupportImpl;

  @Mock private UserRepository userRepo;

  @Mock private RoleRepository roleRepo;

  @Mock private UserDomainRepository userDomainRepo;

  @Mock private JwtTokenGenerator jwtTokenGenerator;

  @Mock private IMailService mailService;

  @Mock private DateFormatRepository dateFormatRepo;

  @Mock private LanguageRepository languageRepo;

  @Mock private OrganizationRepository orgRepo;

  @Mock private PhoneNumberValidator phoneNumberValidator;

  @Mock private CountryRepository countryRepository;

  @Mock private CountryLanguageRepository countryLanguageRepository;

  @Mock
  private com.merck.nextconnect.authfilter.repository.jpa.UserAccessTokenRepository
      userAccessTokenRepo;

  @Mock private com.merck.nextconnect.authfilter.resources.IOrgPermissions orgPermissions;

  @BeforeEach
  void setUp() {
    // Initialize static mocking for UserhubUtils
    mockedUserhubUtils = mockStatic(UserhubUtils.class);
  }

  @AfterEach
  void tearDown() {
    if (mockedUserhubUtils != null) {
      mockedUserhubUtils.close();
    }
  }

  @Test
  void testGenerateToken() {
    // Arrange
    long userId = 123L;
    when(jwtTokenGenerator.generateAndPersistTokenForPassword(anyString(), anyString(), anyLong()))
        .thenReturn(null);

    // Act
    String token = userSupportImpl.generateToken(userId);

    // Assert
    assertNotNull(token);
    verify(jwtTokenGenerator, times(1))
        .generateAndPersistTokenForPassword(anyString(), anyString(), anyLong());
  }

  @Test
  void testAdd_SelfRegistration() throws Exception {
    // Arrange
    UserDetails userDetails = new UserDetails();
    userDetails.setEmail("test@example.com");
    userDetails.setLoginText("testuser");
    userDetails.setFirstName("Test");
    userDetails.setLastName("User");
    userDetails.setIsdCode("1");
    userDetails.setPhone("1234567890");
    userDetails.setDomainId(1L);
    userDetails.setRoleId(1L);
    userDetails.setOrgId(1);
    userDetails.setInvitedVia("SELF_REGISTRATION");
    userDetails.setCountryId(1);
    userDetails.setCountryCode("US");
    userDetails.setLanguageId(1);
    userDetails.setDateFormatId(1);

    // Mock authenticated user returned by UserhubUtils
    AuthenticatedUser mockAuthUser = mock(AuthenticatedUser.class);
    when(mockAuthUser.getOrgId()).thenReturn(1);
    when(mockAuthUser.getId()).thenReturn("0");
    mockedUserhubUtils.when(UserhubUtils::getAuthenticatedUser).thenReturn(mockAuthUser);

    // orgPermissions: allow access
    when(orgPermissions.hasRoleAccess(anyInt(), any())).thenReturn(true);

    UserDomain userDomain = new UserDomain();
    userDomain.setDomainId(1L);
    userDomain.setAuthenticationProvider("local");

    Role role = new Role();
    role.setRoleId(1L);
    role.setSystemDefined(false);
    role.setName("TestRole");

    Organization org = new Organization();
    org.setId(1);
    org.setStatus(true);
    org.setName("TestOrg");

    Country country = new Country();
    country.setId(1);
    country.setCountryCode("US");
    country.setCountryName("United States");

    DateFormat dateFormat = new DateFormat();
    dateFormat.setId(1);
    dateFormat.setDateFormat("MM/dd/yyyy");

    Language language = new Language();
    language.setId(1);
    language.setValue("English");
    language.setCode("en");

    CountryLanguage countryLanguage = new CountryLanguage();
    countryLanguage.setLanguage(language);

    UserProfile savedUser = new UserProfile();
    savedUser.setUserId(1L);
    savedUser.setEmail("test@example.com");
    savedUser.setFirstName("Test");
    savedUser.setLastName("User");
    savedUser.setPhone("1234567890");
    savedUser.setIsdCode("1");

    // repository stubbing
    when(userRepo.getUserByEmail(anyString())).thenReturn(null);
    when(userDomainRepo.findById(anyLong())).thenReturn(Optional.of(userDomain));
    when(orgRepo.findById(anyInt())).thenReturn(Optional.of(org));
    when(roleRepo.getRoleByOrg(anyLong(), anyInt())).thenReturn(role);
    when(roleRepo.getRoleByName(anyString(), anyInt())).thenReturn(role);
    when(dateFormatRepo.findById(anyInt())).thenReturn(Optional.of(dateFormat));
    when(countryRepository.findById(anyInt())).thenReturn(country);
    when(languageRepo.findById(anyInt())).thenReturn(language);
    when(countryLanguageRepository.findByCountryCountryCode(anyString()))
        .thenReturn(countryLanguage);
    when(userRepo.save(any(UserProfile.class))).thenReturn(savedUser);

    // Authenticated user profile retrieval (avoid NPE)
    UserProfile authUserProfile = new UserProfile();
    Organization authOrg = new Organization();
    authOrg.setId(1);
    authUserProfile.setOrg(authOrg);
    when(userRepo.getUserById(anyLong())).thenReturn(authUserProfile);

    // validators / side-effects
    doNothing().when(phoneNumberValidator).validatePhoneNumberFormat(anyString(), anyString());
    doNothing().when(mailService).send(any(UserProfile.class), anyString(), anyString(), any());

    // Act
    UserProfile result = userSupportImpl.add(userDetails);

    // Assert
    assertNotNull(result);
    assertEquals(savedUser.getUserId(), result.getUserId());
    assertEquals(savedUser.getEmail(), result.getEmail());
    verify(userRepo, times(1)).save(any(UserProfile.class));
    verify(mailService, times(1)).send(any(UserProfile.class), anyString(), anyString(), any());
  }

  @Test
  void testAdd_DuplicateEmail() throws Exception {
    // Arrange
    UserDetails userDetails = new UserDetails();
    userDetails.setEmail("existing@example.com");
    userDetails.setInvitedVia("SELF_REGISTRATION");
    userDetails.setIsdCode("1");
    userDetails.setPhone("1234567890");
    userDetails.setDomainId(1L);

    UserDomain userDomain = new UserDomain();
    userDomain.setDomainId(1L);
    userDomain.setAuthenticationProvider("local");

    when(userRepo.getUserByEmail("existing@example.com")).thenReturn(new UserProfile());
    when(userDomainRepo.findById(1L)).thenReturn(Optional.of(userDomain));

    doNothing().when(phoneNumberValidator).validatePhoneNumberFormat(anyString(), anyString());

    // Act & Assert
    assertThrows(DuplicateResourceException.class, () -> userSupportImpl.add(userDetails));
  }

  @Test
  void testSetLanguage() throws Exception {
    // Setup
    AuthenticatedUser authUser = mock(AuthenticatedUser.class);
    when(authUser.getId()).thenReturn("123");

    UserProfile authUserProfile = new UserProfile();
    Organization org = new Organization();
    authUserProfile.setOrg(org);
    Country country = new Country();
    country.setCountryCode("US");
    authUserProfile.setCountry(country);

    UserDetails userDetails = new UserDetails();
    userDetails.setInvitedVia(UserInvitedVia.INSTALLED_PRODUCT.value());
    userDetails.setCountryCode("DE");

    UserProfile user = new UserProfile();

    when(userRepo.getUserById(123L)).thenReturn(authUserProfile);

    Language language = new Language();
    language.setId(1);
    language.setValue("German");

    CountryLanguage countryLanguage = new CountryLanguage();
    countryLanguage.setLanguage(language);
    when(countryLanguageRepository.findByCountryCountryCode("DE")).thenReturn(countryLanguage);

    // Invoke private method via reflection
    java.lang.reflect.Method setLanguageMethod =
        UserSupportImpl.class.getDeclaredMethod(
            "setLanguage", AuthenticatedUser.class, UserDetails.class, UserProfile.class);
    setLanguageMethod.setAccessible(true);
    setLanguageMethod.invoke(userSupportImpl, authUser, userDetails, user);

    // Verify
    assertEquals(language, user.getLanguage());
  }
}
