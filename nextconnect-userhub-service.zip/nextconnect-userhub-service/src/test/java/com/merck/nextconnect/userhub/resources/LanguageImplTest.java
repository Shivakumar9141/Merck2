package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.resources.impl.LanguageImpl;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.repository.jpa.LanguageRepository;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.util.ReflectionTestUtils;

public class LanguageImplTest {

  @Mock private LanguageRepository languageRepo;
  @InjectMocks private LanguageImpl languageImpl;

  @BeforeEach
  public void setUp() {
    languageRepo = mock(LanguageRepository.class);
    languageImpl = new LanguageImpl();
    ReflectionTestUtils.setField(languageImpl, "languageRepo", languageRepo);
  }

  @Test
  public void testGetAllLanguages() {
    List<Language> mockLanguageList = new ArrayList<>();
    Language mockLanguage1 = new Language();
    mockLanguage1.setId(1);
    mockLanguage1.setValue("English");
    mockLanguageList.add(mockLanguage1);
    when(languageRepo.findAll()).thenReturn(mockLanguageList);
    List<Language> result = languageImpl.getAll();
    assertEquals(mockLanguageList.size(), result.size());
    assertEquals(mockLanguageList.get(0).getId(), result.get(0).getId());
    assertEquals(mockLanguageList.get(0).getValue(), result.get(0).getValue());
  }
}
