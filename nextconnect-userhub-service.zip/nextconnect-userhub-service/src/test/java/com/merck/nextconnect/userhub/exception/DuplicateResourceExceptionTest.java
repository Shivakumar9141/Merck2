package com.merck.nextconnect.userhub.exception;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

public class DuplicateResourceExceptionTest {

  @Test
  public void testConstructorWithMessage() {
    String errorMessage = "Resource already exists";
    DuplicateResourceException exception = new DuplicateResourceException(errorMessage);

    assertNotNull(exception);
    assertEquals(errorMessage, exception.getMessage());
  }

  @Test
  public void testConstructorWithCustomErrorCode() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    DuplicateResourceException exception = new DuplicateResourceException(errorCode);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCodeAndParams() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    List<String> params = Arrays.asList("param1", "param2");
    DuplicateResourceException exception = new DuplicateResourceException(errorCode, params);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }
}
