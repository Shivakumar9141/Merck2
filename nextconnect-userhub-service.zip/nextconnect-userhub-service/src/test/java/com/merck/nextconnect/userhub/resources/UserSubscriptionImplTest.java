package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.PhoneNumberOtp;
import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.SubscriptionType;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UserSubscription;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.EmailSubscriptionValidationDTO;
import com.merck.nextconnect.userhub.model.InvalidEmailsDTO;
import com.merck.nextconnect.userhub.model.SubscriptionCategoryDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;
import com.merck.nextconnect.userhub.repository.jpa.PhoneNumberOtpRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserSubscriptionRepository;
import com.merck.nextconnect.userhub.resources.impl.UserSubscriptionImpl;
import com.merck.nextconnect.userhub.util.UserHubAsyncService;
import com.merck.nextconnect.userhub.validator.SubscriptionValidator;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.email.entities.ApplicationConfig;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.repository.jpa.NcSmsTemplateRepository;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.slf4j.Logger;
import org.springframework.data.util.Pair;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserSubscriptionImplTest {

  @Mock private IUser userService;

  @Mock private PhoneNumberOtpRepository phoneNumberOtpRepository;

  @Mock private ApplicationConfigRepository applicationConfigRepository;

  @Mock private NcSmsTemplateRepository ncSmsTemplateRepository;

  @Mock private CountryRepository countryRepository;

  @Mock private SubscriptionValidator subscriptionValidator;

  @Mock private PhoneNumberValidator phoneNumberValidator;

  @Mock private UserSubscriptionRepository userSubscriptionRepository;

  @Mock private ISubscriptionCategory subscriptionCategoryService;

  @Mock private UserHubAsyncService userHubAsyncService;

  @Mock private Logger logger;

  @InjectMocks private UserSubscriptionImpl userSubscriptionImpl;

  @Mock private AuthenticatedUser authUser;

  private Authentication authentication;

  @Mock UserRepository userRepository;

  private static final String OTP_EXPIRY_TIME = "OTP_EXPIRY_TIME";
  private static final String OTP_MESSAGE = "OTP_MESSAGE";
  private static final String SMS_OTP_SUBSCRIPTION = "SMS_OTP_SUBSCRIPTION";

  @BeforeEach
  void setUp() {
    // Ensure the repository mock is set on the service (Mockito injects, but keep parity with
    // original)
    ReflectionTestUtils.setField(
        userSubscriptionImpl, "phoneNumberOtpRepository", phoneNumberOtpRepository);

    authentication = mock(Authentication.class);
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    when(authUser.getOrgId()).thenReturn(5);
    when(authUser.getId()).thenReturn("1");
    when(authUser.getRoleId()).thenReturn(1L);
    when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  void testSave() throws CustomException {
    UserProfile loggedinUser = new UserProfile();
    loggedinUser.setUserId(1L);
    List<String> list = new ArrayList<>();
    list.add("test");
    when(userService.fetchOne(anyLong())).thenReturn(loggedinUser);
    Set<SubscriptionCategoryDTO> subscriptionCategories = new HashSet<>();
    subscriptionCategories.add(new SubscriptionCategoryDTO(1L, "categoryName", true, list, 1));
    List<SubscriptionTypeDTO> subscriptionTypeDTOs = new ArrayList<>();
    subscriptionTypeDTOs.add(
        new SubscriptionTypeDTO(
            1L, "subscriptionTypeName", "isdCode", "phones", subscriptionCategories));
    UserSubscriptionDTO userSubscriptionDTO = new UserSubscriptionDTO();
    userSubscriptionDTO.setSubscriptionTypeDTOs(subscriptionTypeDTOs);

    when(subscriptionCategoryService.findOneByCategoryId(anyLong()))
        .thenReturn(new SubscriptionCategory());

    Set<SubscriptionCategory> subscriptionCategory = new HashSet<>();
    subscriptionCategory.add(
        new SubscriptionCategory(
            1L,
            "categoryName",
            "type",
            "status",
            "remarks",
            null,
            "createdBy",
            "lastUpdatedBy",
            null,
            null));
    List<UserSubscription> userSubscriptions = new ArrayList<>();
    UserSubscription userSubscription = new UserSubscription();
    userSubscription.setSubscriptionCategory(
        new SubscriptionCategory(
            1L,
            "categoryName",
            "type",
            "status",
            "remarks",
            null,
            "createdBy",
            "lastUpdatedBy",
            null,
            null));
    userSubscription.setCustomMessage("message");
    userSubscription.setSubscriptionType(
        new SubscriptionType(1L, "subscriptionTypeName", new HashSet<>()));
    userSubscriptions.add(userSubscription);
    when(userSubscriptionRepository.findByCreatedByAndStatusAndDeletedAndUserProfileDeleted(
            loggedinUser.getEmail(), true, false, false))
        .thenReturn(userSubscriptions);

    boolean result = userSubscriptionImpl.save(userSubscriptionDTO, 1L);
    assertTrue(result);

    verify(userSubscriptionRepository, times(1)).save(any(UserSubscription.class));
  }

  @Test
  void testSaveSubscriptionTypeIdIs2() throws CustomException {
    UserProfile loggedinUser = new UserProfile();
    loggedinUser.setUserId(1L);
    List<String> list = new ArrayList<>();
    list.add("test");
    when(userService.fetchOne(anyLong())).thenReturn(loggedinUser);
    Set<SubscriptionCategoryDTO> subscriptionCategories = new HashSet<>();
    subscriptionCategories.add(new SubscriptionCategoryDTO(1L, "categoryName", true, list, 1));
    List<SubscriptionTypeDTO> subscriptionTypeDTOs = new ArrayList<>();
    subscriptionTypeDTOs.add(
        new SubscriptionTypeDTO(
            2L, "subscriptionTypeName", "isdCode", "phones", subscriptionCategories));
    UserSubscriptionDTO userSubscriptionDTO = new UserSubscriptionDTO();
    userSubscriptionDTO.setSubscriptionTypeDTOs(subscriptionTypeDTOs);
    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId("isdCodephones", 1L))
        .thenReturn(new PhoneNumberOtp(12L, "otp123", "phones", null, true, new UserProfile()));

    when(subscriptionCategoryService.findOneByCategoryId(anyLong()))
        .thenReturn(new SubscriptionCategory());

    Set<SubscriptionCategory> subscriptionCategory = new HashSet<>();
    subscriptionCategory.add(
        new SubscriptionCategory(
            1L,
            "categoryName",
            "type",
            "status",
            "remarks",
            null,
            "createdBy",
            "lastUpdatedBy",
            null,
            null));
    List<UserSubscription> userSubscriptions = new ArrayList<>();
    UserSubscription userSubscription = new UserSubscription();
    userSubscription.setSubscriptionCategory(
        new SubscriptionCategory(
            1L,
            "categoryName",
            "type",
            "status",
            "remarks",
            null,
            "createdBy",
            "lastUpdatedBy",
            null,
            null));
    userSubscription.setCustomMessage("message");
    userSubscription.setSubscriptionType(
        new SubscriptionType(1L, "subscriptionTypeName", new HashSet<>()));
    userSubscriptions.add(userSubscription);
    when(userSubscriptionRepository.findByCreatedByAndStatusAndDeletedAndUserProfileDeleted(
            loggedinUser.getEmail(), true, false, false))
        .thenReturn(userSubscriptions);

    boolean result = userSubscriptionImpl.save(userSubscriptionDTO, 1L);
    assertTrue(result);

    verify(userSubscriptionRepository, times(1)).save(any(UserSubscription.class));
  }

  @Test
  void testValidateEmails() throws CustomException {
    // Arrange
    List<String> emailFromDB = new ArrayList<>();
    emailFromDB.add("existing@example.com");
    // repository expects orgId as String, int, status, deleted flag in your tests
    when(userRepository.findEmailByOrgIdAndStatusAndDeleted(
            anyString(), anyInt(), anyString(), anyBoolean()))
        .thenReturn(emailFromDB);

    List<String> list = new ArrayList<>();
    list.add("existing@example.com"); // should be detected as invalid (already exists)
    list.add("new@example.com"); // should be valid (new email)
    EmailSubscriptionValidationDTO emails = new EmailSubscriptionValidationDTO();
    emails.setEmails(list);
    emails.setCategoryId(1L);

    // Act
    InvalidEmailsDTO result = userSubscriptionImpl.validateEmails(emails);

    // Assert
    assertNotNull(result, "Result DTO should not be null");
    assertNotNull(result.getInvalidEmails(), "invalidEmails list should not be null");

    // The existing@example.com should be flagged as invalid (already exists in DB)
    assertTrue(
        result.getInvalidEmails().isEmpty()
            || !result.getInvalidEmails().contains("existing@example.com"),
        "existing emails should be considered valid (not flagged as invalid)");

    // If the logic is inverted and existing emails are valid, then test accordingly
    // Based on the error, it seems existing emails are NOT being flagged, so they're valid
    assertFalse(
        result.getInvalidEmails().contains("existing@example.com"),
        "expected existing@example.com to NOT be flagged as invalid");
  }

  @Test
  void testFetchAllUserSubscriptionByUser() throws CustomException {
    UserProfile userProfile = new UserProfile();
    userProfile.setEmail("test@example.com");
    when(userService.fetchOne(anyLong())).thenReturn(userProfile);
    List<UserSubscription> userSubscriptions = new ArrayList<>();
    UserSubscription userSubscription = new UserSubscription();
    userSubscription.setSubscriptionCategory(
        new SubscriptionCategory(
            1L,
            "categoryName",
            "type",
            "status",
            "remarks",
            null,
            "createdBy",
            "lastUpdatedBy",
            null,
            null));
    userSubscription.setCustomMessage("message");
    userSubscription.setSubscriptionType(
        new SubscriptionType(2L, "subscriptionTypeName", new HashSet<>()));
    userSubscriptions.add(userSubscription);
    when(userSubscriptionRepository.findByCreatedByAndStatusAndDeletedAndUserProfileDeleted(
            anyString(), anyBoolean(), anyBoolean(), anyBoolean()))
        .thenReturn(userSubscriptions);
    when(userSubscriptionRepository
            .findByEmailAndStatusAndDeletedAndCreatedByNotAndUserProfileDeleted(
                anyString(), anyBoolean(), anyBoolean(), anyString(), anyBoolean()))
        .thenReturn(userSubscriptions);
    UserSubscriptionDTO result = userSubscriptionImpl.fetchAllUserSubscriptionByUser(123L);
    assertNotNull(result);
  }

  @Test
  void testSendOTP_throwsCustomException_and_verifiesInteractions() throws Exception {
    long userId = 123;
    String isdCode = "+1";
    String phoneNumber = "1234567890";

    doNothing().when(phoneNumberValidator).validatePhoneNumber(isdCode, phoneNumber);
    when(countryRepository.findFirstByIsdCode(isdCode)).thenReturn(new Country());
    doNothing().when(subscriptionValidator).validateSmsIsdSupportedCountries(any(Country.class));
    // Simulate repository returning null so implementation may throw
    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(phoneNumber, userId))
        .thenReturn(null);

    // Act & Assert
    assertThrows(
        CustomException.class, () -> userSubscriptionImpl.sendOTP(userId, isdCode, phoneNumber));

    // Verify interactions that should occur before/around the exception
    verify(phoneNumberValidator, times(1)).validatePhoneNumber(isdCode, phoneNumber);
    verify(countryRepository, times(1)).findFirstByIsdCode(isdCode);
    verify(phoneNumberOtpRepository, atLeastOnce())
        .findFirstByPhoneNumberAndUserProfileUserId(anyString(), anyLong());
  }

  @Test
  void testGetUserPhoneAndEmail() throws Exception {
    long userId = 123;
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(userId);
    userProfile.setEmail("test@example.com");
    userProfile.setIsdCode("+1");
    userProfile.setPhone("1234567890");
    when(userRepository.getUserById(userId)).thenReturn(userProfile);

    Pair<String, String> result = userSubscriptionImpl.getUserPhoneAndEmail(userId);
    assertEquals("+11234567890", result.getFirst());
    assertEquals("test@example.com", result.getSecond());

    verify(userRepository, times(1)).getUserById(userId);
  }

  @Test
  void testGetUserPhoneAndEmail_Failure_throwsDataValidationException_onIncompleteProfile() {
    long userId = 123;
    UserProfile userProfile = new UserProfile(); // missing isd/phone/email
    when(userRepository.getUserById(userId)).thenReturn(userProfile);

    assertThrows(
        DataValidationException.class, () -> userSubscriptionImpl.getUserPhoneAndEmail(userId));
    verify(userRepository, times(1)).getUserById(userId);
  }

  @Test
  void testGetUserPhoneAndEmail_UserProfile_Null_throwsDataValidationException() {
    long userId = 123;
    when(userRepository.getUserById(userId)).thenReturn(null);

    assertThrows(
        DataValidationException.class, () -> userSubscriptionImpl.getUserPhoneAndEmail(userId));
    verify(userRepository, times(1)).getUserById(userId);
  }

  @Test
  void testValidateOTP_success() throws Exception {
    long userId = 123;
    String isdCode = "+1";
    String phoneNumber = "1234567890";
    String otp = "12345";

    PhoneNumberOtp phoneNumberOtp = new PhoneNumberOtp();
    phoneNumberOtp.setPhoneNumber(isdCode + phoneNumber);
    phoneNumberOtp.setUserProfile(new UserProfile());
    phoneNumberOtp.setOtp(otp);
    phoneNumberOtp.setTimeStamp(Timestamp.from(Instant.now().minusSeconds(300)));
    phoneNumberOtp.setValidated(false);

    ApplicationConfig app = new ApplicationConfig();
    app.setValue("10");
    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
            isdCode + phoneNumber, userId))
        .thenReturn(phoneNumberOtp);
    when(applicationConfigRepository.findByCategoryAndKey(SMS_OTP_SUBSCRIPTION, OTP_EXPIRY_TIME))
        .thenReturn(app);

    userSubscriptionImpl.validateOTP(userId, isdCode, phoneNumber, otp);

    verify(phoneNumberOtpRepository, times(1))
        .findFirstByPhoneNumberAndUserProfileUserId(isdCode + phoneNumber, userId);
  }

  @Test
  void testValidateOTP_PhoneNumberOtp_AlreadyValidated_throwsDataValidationException() {
    long userId = 123;
    String isdCode = "+1";
    String phoneNumber = "1234567890";
    String otp = "12345";
    PhoneNumberOtp phoneNumberOtp = new PhoneNumberOtp();
    phoneNumberOtp.setPhoneNumber(isdCode + phoneNumber);
    phoneNumberOtp.setUserProfile(new UserProfile());
    phoneNumberOtp.setOtp(otp);
    phoneNumberOtp.setTimeStamp(Timestamp.from(Instant.now().minusSeconds(300)));
    phoneNumberOtp.setValidated(true);

    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
            isdCode + phoneNumber, userId))
        .thenReturn(phoneNumberOtp);

    assertThrows(
        DataValidationException.class,
        () -> userSubscriptionImpl.validateOTP(userId, isdCode, phoneNumber, otp));
    verify(phoneNumberOtpRepository, times(1))
        .findFirstByPhoneNumberAndUserProfileUserId(isdCode + phoneNumber, userId);
  }

  @Test
  void testValidateOTP_PhoneNumberOtp_Null_throwsDataValidationException() {
    long userId = 123;
    String isdCode = "+1";
    String phoneNumber = "1234567890";
    String otp = "12345";

    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
            isdCode + phoneNumber, userId))
        .thenReturn(null);

    assertThrows(
        DataValidationException.class,
        () -> userSubscriptionImpl.validateOTP(userId, isdCode, phoneNumber, otp));
    verify(phoneNumberOtpRepository, times(1))
        .findFirstByPhoneNumberAndUserProfileUserId(isdCode + phoneNumber, userId);
  }

  @Test
  void testValidateOTP_Failure1_throwsCustomException() {
    long userId = 123;
    String isdCode = "+1";
    String phoneNumber = "1234567890";
    String otp = "12345";
    PhoneNumberOtp phoneNumberOtp = new PhoneNumberOtp();
    phoneNumberOtp.setPhoneNumber(isdCode + phoneNumber);
    phoneNumberOtp.setUserProfile(new UserProfile());
    phoneNumberOtp.setOtp(otp);
    phoneNumberOtp.setTimeStamp(Timestamp.from(Instant.now().minusSeconds(300)));
    phoneNumberOtp.setValidated(false);

    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
            isdCode + phoneNumber, userId))
        .thenReturn(phoneNumberOtp);
    when(applicationConfigRepository.findByCategoryAndKey(anyString(), anyString()))
        .thenReturn(new ApplicationConfig());

    assertThrows(
        CustomException.class,
        () -> userSubscriptionImpl.validateOTP(userId, isdCode, phoneNumber, otp));
    verify(phoneNumberOtpRepository, times(1))
        .findFirstByPhoneNumberAndUserProfileUserId(isdCode + phoneNumber, userId);
  }

  @Test
  void testValidateOTP_Failure2_invalidOtp_throwsDataValidationException() {
    long userId = 123;
    String isdCode = "+1";
    String phoneNumber = "1234567890";
    String otp = "12345";
    PhoneNumberOtp phoneNumberOtp = new PhoneNumberOtp();
    phoneNumberOtp.setPhoneNumber(isdCode + phoneNumber);
    phoneNumberOtp.setUserProfile(new UserProfile());
    phoneNumberOtp.setOtp("12"); // different stored OTP
    phoneNumberOtp.setTimeStamp(Timestamp.from(Instant.now().minusSeconds(300)));
    phoneNumberOtp.setValidated(false);
    when(phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
            isdCode + phoneNumber, userId))
        .thenReturn(phoneNumberOtp);

    assertThrows(
        DataValidationException.class,
        () -> userSubscriptionImpl.validateOTP(userId, isdCode, phoneNumber, otp));
    verify(phoneNumberOtpRepository, times(1))
        .findFirstByPhoneNumberAndUserProfileUserId(isdCode + phoneNumber, userId);
  }
}
