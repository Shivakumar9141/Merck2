package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PlatformSettingsTest {

  private PlatformSettings platformSettings;

  @BeforeEach
  public void setUp() {
    platformSettings = new PlatformSettings();
  }

  @Test
  public void testGetAndSetId() {
    long id = 123L;
    platformSettings.setId(id);
    assertEquals(id, platformSettings.getId());
  }

  @Test
  public void testGetAndSetAuthenticationType() {
    String authenticationType = "OAuth";
    platformSettings.setAuthenticationType(authenticationType);
    assertEquals(authenticationType, platformSettings.getAuthenticationType());
  }

  @Test
  public void testGetAndSetName() {
    String name = "Test Platform";
    platformSettings.setName(name);
    assertEquals(name, platformSettings.getName());
  }
}
