package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.CountryTimezoneDTO;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.file.entities.CountryTimezone;
import com.merck.nextconnect.utils.repository.jpa.CountryTimezoneRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CountryImplTest {

  @Mock private CountryRepository countryRepository;
  @Mock private CountryTimezoneRepository countryTimezoneRepository;

  @InjectMocks private CountryImpl countryImpl;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetCountries() {
    // Arrange
    String searchBy = "Test";
    List<Country> mockCountries = new ArrayList<>();
    Country country = new Country();
    country.setId(1);
    country.setCountryName("Test Country");
    mockCountries.add(country);

    when(countryRepository.findByCountryNameContainingIgnoreCaseOrderByCountryNameAsc(searchBy))
        .thenReturn(mockCountries);

    // Act
    List<Country> result = countryImpl.getCountries(searchBy);

    // Assert
    assertEquals(1, result.size());
    assertEquals(1, result.get(0).getId());
    // assertEquals("Test Country", result.get(0).getCountryName());
  }

  @Test
  public void testGetCountriesTimezoneWithCountryId() {
    // Arrange
    int countryId = 1;
    List<CountryTimezone> mockTimezones = new ArrayList<>();

    Country country = new Country();
    country.setId(countryId);

    CountryTimezone timezone = new CountryTimezone();
    timezone.setId(1);
    timezone.setTimezoneName("GMT+1");
    timezone.setTimezoneDesc("Central European Time");
    timezone.setTimezoneOffset("CET");
    timezone.setCountry(country);
    mockTimezones.add(timezone);

    when(countryTimezoneRepository.findByCountryId(countryId)).thenReturn(mockTimezones);

    // Act
    List<CountryTimezoneDTO> result = countryImpl.getCountriesTimezone(countryId);

    // Assert
    assertEquals(1, result.size());
    assertEquals(1L, result.get(0).getId());
    assertEquals("GMT+1", result.get(0).getTimezoneName());
    assertEquals("Central European Time", result.get(0).getTimezoneDesc());
    assertEquals("CET", result.get(0).getTimezoneAbbr());
    assertEquals(1, result.get(0).getCountry());
  }

  @Test
  public void testGetCountriesTimezoneWithNullCountryId() {
    // Arrange
    List<CountryTimezone> mockTimezones = new ArrayList<>();

    Country country = new Country();
    country.setId(1);

    CountryTimezone timezone = new CountryTimezone();
    timezone.setId(1);
    timezone.setTimezoneName("GMT+1");
    timezone.setTimezoneDesc("Central European Time");
    timezone.setTimezoneOffset("CET");
    timezone.setCountry(country);
    mockTimezones.add(timezone);

    when(countryTimezoneRepository.findAll()).thenReturn(mockTimezones);

    // Act
    List<CountryTimezoneDTO> result = countryImpl.getCountriesTimezone(null);

    // Assert
    assertEquals(1, result.size());
    assertEquals(1L, result.get(0).getId());
    assertEquals("GMT+1", result.get(0).getTimezoneName());
    assertEquals("Central European Time", result.get(0).getTimezoneDesc());
    assertEquals("CET", result.get(0).getTimezoneAbbr());
    assertEquals(1, result.get(0).getCountry());
  }

  @Test
  public void testGetCountryTimezone() {
    // Arrange
    Integer timezoneId = 1;

    Country country = new Country();
    country.setId(2);

    CountryTimezone timezone = new CountryTimezone();
    timezone.setId(timezoneId);
    timezone.setTimezoneName("GMT+1");
    timezone.setTimezoneDesc("Central European Time");
    timezone.setTimezoneOffset("CET");
    timezone.setCountry(country);

    when(countryTimezoneRepository.findById(timezoneId)).thenReturn(Optional.of(timezone));

    // Act
    CountryTimezoneDTO result = countryImpl.getCountryTimezone(timezoneId);

    // Assert
    assertEquals(1L, result.getId());
    assertEquals("GMT+1", result.getTimezoneName());
    assertEquals("Central European Time", result.getTimezoneDesc());
    assertEquals("CET", result.getTimezoneAbbr());
    assertEquals(2, result.getCountry());
  }
}
