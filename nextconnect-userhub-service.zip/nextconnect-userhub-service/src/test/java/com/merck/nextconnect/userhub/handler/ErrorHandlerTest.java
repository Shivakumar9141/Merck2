package com.merck.nextconnect.userhub.handler;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.authfilter.exception.CustomAuthenticationException;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.FailedDependencyException;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.MethodNotAllowedException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.ErrorResponse;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ErrorHandlerTest {

  private ErrorHandler errorHandler;

  @BeforeEach
  public void setUp() {
    errorHandler = new ErrorHandler();
  }

  @Test
  public void testExceptionHandler() {
    Exception ex = new Exception("Test exception");
    ResponseEntity<ErrorResponse> response = errorHandler.exceptionHandler(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    assertEquals(
        CustomErrorCodes.INTERNAL_SERVER_ERROR.getErrorCode(), response.getBody().getErrorCode());
    assertEquals(
        CustomErrorCodes.INTERNAL_SERVER_ERROR.getDescription(),
        response.getBody().getErrorMessage());
  }

  @Test
  public void testCustomExceptionHandler() {
    // Using ROLE_VALIDATION_ERROR which is explicitly mapped to UNPROCESSABLE_ENTITY in
    // errorStatusMapping
    CustomException ex = new CustomException(CustomErrorCodes.ROLE_VALIDATION_ERROR);
    ResponseEntity<ErrorResponse> response = errorHandler.exceptionHandler(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
    assertEquals(
        CustomErrorCodes.ROLE_VALIDATION_ERROR.getErrorCode(), response.getBody().getErrorCode());
    assertEquals(
        CustomErrorCodes.ROLE_VALIDATION_ERROR.getDescription(),
        response.getBody().getErrorMessage());
  }

  @Test
  public void testLoginAuthenticationExceptionHandler() {
    LoginAuthenticationException ex =
        new LoginAuthenticationException("Test login authentication exception");
    ResponseEntity<ErrorResponse> response = errorHandler.loginexceptionHandler(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testAccessDeniedException() {
    org.springframework.security.access.AccessDeniedException ex =
        new org.springframework.security.access.AccessDeniedException("Access denied");
    ResponseEntity<ErrorResponse> response = errorHandler.accessDeniedException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testCustomAccessDeniedException() {
    AccessDeniedException ex = new AccessDeniedException(CustomErrorCodes.UNAUTHORIZED_ACCESS);
    ResponseEntity<ErrorResponse> response = errorHandler.accessDeniedException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
    assertEquals(
        CustomErrorCodes.UNAUTHORIZED_ACCESS.getErrorCode(), response.getBody().getErrorCode());
    assertEquals(
        CustomErrorCodes.UNAUTHORIZED_ACCESS.getDescription(),
        response.getBody().getErrorMessage());
  }

  @Test
  public void testDuplicateResourceException() {
    DuplicateResourceException ex = new DuplicateResourceException(CustomErrorCodes.DUPLICATE_ORG);
    ResponseEntity<ErrorResponse> response = errorHandler.duplicateResourceException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testFailedDependencyException() {
    FailedDependencyException ex =
        new FailedDependencyException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    ResponseEntity<ErrorResponse> response = errorHandler.failedDependencyException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.FAILED_DEPENDENCY, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testMethodNotAllowedException() {
    MethodNotAllowedException ex =
        new MethodNotAllowedException("Test method not allowed exception");
    ResponseEntity<ErrorResponse> response = errorHandler.methodNotAllowedException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.METHOD_NOT_ALLOWED, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testDataValidationException() {
    DataValidationException ex = new DataValidationException("Test data validation error");
    ResponseEntity<ErrorResponse> response = errorHandler.dataValidationException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testFileValidationException() {
    com.merck.nextconnect.utils.file.handler.exception.DataValidationException ex =
        new com.merck.nextconnect.utils.file.handler.exception.DataValidationException(
            "Test file validation error");
    ResponseEntity<ErrorResponse> response = errorHandler.FileValidationExceptionHandler(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testResourceNotFoundException() {
    ResourceNotFoundException ex = new ResourceNotFoundException(CustomErrorCodes.DEVICE_NOT_FOUND);
    ResponseEntity<ErrorResponse> response = errorHandler.resourceNotFoundException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }

  @Test
  public void testCustomAuthenticationException() {
    CustomAuthenticationException ex =
        new CustomAuthenticationException("Test authentication exception");
    ResponseEntity<ErrorResponse> response = errorHandler.customAuthenticationException(ex);

    assertNotNull(response);
    assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    // Don't check the error code, just verify the status code is correct
  }
}
