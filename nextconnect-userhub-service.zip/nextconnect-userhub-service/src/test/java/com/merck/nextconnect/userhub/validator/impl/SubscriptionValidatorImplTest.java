package com.merck.nextconnect.userhub.validator.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class SubscriptionValidatorImplTest {

  @Mock private PhoneNumberValidator phoneNumberValidator;

  @InjectMocks private SubscriptionValidatorImpl subscriptionValidator;

  @Before
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testValidateSmsIsdSupportedCountries_ValidCountry() throws DataValidationException {
    // Arrange
    Country country = new Country();
    country.setSupportEnabled(true);

    // Act
    subscriptionValidator.validateSmsIsdSupportedCountries(country);

    // Assert - no exception thrown means test passed
  }

  @Test
  public void testValidateSmsIsdSupportedCountries_InvalidCountry() {
    // Arrange
    Country country = new Country();
    country.setSupportEnabled(false);

    // Act & Assert
    assertThrows(
        DataValidationException.class,
        () -> subscriptionValidator.validateSmsIsdSupportedCountries(country));
  }

  @Test
  public void testValidateOtp_ValidInput() throws DataValidationException {
    // Arrange
    String isdCode = "91";
    String phoneNumber = "1234567890";
    String otp = "123456";

    // Act
    subscriptionValidator.validateOtp(isdCode, phoneNumber, otp);

    // Assert
    verify(phoneNumberValidator).validatePhoneNumber(isdCode, phoneNumber);
  }

  @Test
  public void testValidateOtp_NullOtp() {
    // Arrange
    String isdCode = "91";
    String phoneNumber = "1234567890";
    String otp = null;

    // Act & Assert
    assertThrows(
        DataValidationException.class,
        () -> subscriptionValidator.validateOtp(isdCode, phoneNumber, otp));
  }

  @Test
  public void testValidateOtp_EmptyOtp() {
    // Arrange
    String isdCode = "91";
    String phoneNumber = "1234567890";
    String otp = "";

    // Act & Assert
    assertThrows(
        DataValidationException.class,
        () -> subscriptionValidator.validateOtp(isdCode, phoneNumber, otp));
  }

  @Test
  public void testValidateOtp_InvalidPhoneNumber() throws DataValidationException {
    // Arrange
    String isdCode = "91";
    String phoneNumber = "invalid";
    String otp = "123456";

    doThrow(new DataValidationException("Invalid phone number"))
        .when(phoneNumberValidator)
        .validatePhoneNumber(isdCode, phoneNumber);

    // Act & Assert
    assertThrows(
        DataValidationException.class,
        () -> subscriptionValidator.validateOtp(isdCode, phoneNumber, otp));
  }
}
