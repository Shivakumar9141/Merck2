package com.merck.nextconnect.userhub;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import io.swagger.v3.oas.models.OpenAPI;
import org.apache.hc.client5.http.ConnectionKeepAliveStrategy;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.util.TimeValue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class UserHubApplicationTest {

  private UserHubApplication userHubApplication;

  @BeforeEach
  public void setUp() {
    userHubApplication = new UserHubApplication();
  }

  @Test
  public void testGetPubPostbackRestTemplate() {
    CloseableHttpClient mockHttpClient = mock(CloseableHttpClient.class);
    // Inject mock using reflection
    try {
      java.lang.reflect.Field field =
          UserHubApplication.class.getDeclaredField("closeableHttpClient");
      field.setAccessible(true);
      field.set(userHubApplication, mockHttpClient);
    } catch (Exception e) {
      fail("Failed to set closeableHttpClient via reflection: " + e.getMessage());
    }
    RestTemplate restTemplate = userHubApplication.getPubPostbackRestTemplate();
    assertNotNull(restTemplate);
    assertTrue(restTemplate.getRequestFactory() instanceof HttpComponentsClientHttpRequestFactory);
  }

  @Test
  public void testHttpClientBean() {
    PoolingHttpClientConnectionManager pcm = userHubApplication.poolingConnectionManager();
    ConnectionKeepAliveStrategy kas = userHubApplication.connectionKeepAliveStrategy();
    CloseableHttpClient httpClient = userHubApplication.httpClient();
    assertNotNull(httpClient);
    assertNotNull(pcm);
    assertNotNull(kas);
  }

  @Test
  public void testPoolingConnectionManager() {
    PoolingHttpClientConnectionManager pcm = userHubApplication.poolingConnectionManager();
    assertNotNull(pcm);
    assertTrue(pcm.getMaxTotal() > 0);
  }

  @Test
  public void testConnectionKeepAliveStrategy() {
    ConnectionKeepAliveStrategy kas = userHubApplication.connectionKeepAliveStrategy();
    assertNotNull(kas);
  }

  @Test
  public void testIdleConnectionMonitor() {
    PoolingHttpClientConnectionManager pcm = mock(PoolingHttpClientConnectionManager.class);
    Runnable monitor = userHubApplication.idleConnectionMonitor(pcm);
    assertNotNull(monitor);
    // Should not throw
    monitor.run();
    verify(pcm, atLeastOnce()).closeExpired();
    verify(pcm, atLeastOnce()).closeIdle(any());
  }

  @Test
  public void testOpenApiBean() {
    OpenAPI openAPI = userHubApplication.openApi();
    assertNotNull(openAPI);
    assertNotNull(openAPI.getComponents());
    assertNotNull(openAPI.getInfo());
    assertEquals("NextConnect Platform API", openAPI.getInfo().getTitle());
  }

  @Test
  public void testConnectionKeepAliveStrategy_DefaultKeepAlive() {
    ConnectionKeepAliveStrategy kas = userHubApplication.connectionKeepAliveStrategy();
    org.apache.hc.core5.http.ClassicHttpResponse response =
        mock(org.apache.hc.core5.http.ClassicHttpResponse.class);
    org.apache.hc.core5.http.protocol.HttpContext context =
        mock(org.apache.hc.core5.http.protocol.HttpContext.class);

    when(response.getFirstHeader("Connection")).thenReturn(null);
    TimeValue result = kas.getKeepAliveDuration(response, context);
    assertEquals(TimeValue.ofMilliseconds(20000), result);
  }

  @Test
  public void testConnectionKeepAliveStrategy_KeepAliveHeaderWithTimeout() {
    ConnectionKeepAliveStrategy kas = userHubApplication.connectionKeepAliveStrategy();
    org.apache.hc.core5.http.ClassicHttpResponse response =
        mock(org.apache.hc.core5.http.ClassicHttpResponse.class);
    org.apache.hc.core5.http.protocol.HttpContext context =
        mock(org.apache.hc.core5.http.protocol.HttpContext.class);

    org.apache.hc.core5.http.Header connectionHeader = mock(org.apache.hc.core5.http.Header.class);
    when(response.getFirstHeader("Connection")).thenReturn(connectionHeader);

    org.apache.hc.core5.http.Header keepAliveHeader = mock(org.apache.hc.core5.http.Header.class);
    when(response.getFirstHeader("Keep-Alive")).thenReturn(keepAliveHeader);

    TimeValue result = kas.getKeepAliveDuration(response, context);
    assertEquals(TimeValue.ofMilliseconds(20000), result);
  }

  @Test
  public void testConnectionKeepAliveStrategy_KeepAliveHeaderWithMultipleParams() {
    ConnectionKeepAliveStrategy kas = userHubApplication.connectionKeepAliveStrategy();
    org.apache.hc.core5.http.ClassicHttpResponse response =
        mock(org.apache.hc.core5.http.ClassicHttpResponse.class);
    org.apache.hc.core5.http.protocol.HttpContext context =
        mock(org.apache.hc.core5.http.protocol.HttpContext.class);

    org.apache.hc.core5.http.Header connectionHeader = mock(org.apache.hc.core5.http.Header.class);
    when(connectionHeader.getValue()).thenReturn("keep-alive");
    when(response.getFirstHeader("Connection")).thenReturn(connectionHeader);

    org.apache.hc.core5.http.Header keepAliveHeader = mock(org.apache.hc.core5.http.Header.class);
    when(keepAliveHeader.getValue()).thenReturn("timeout=10, max=1000");
    when(response.getFirstHeader("Keep-Alive")).thenReturn(keepAliveHeader);

    TimeValue result = kas.getKeepAliveDuration(response, context);
    assertEquals(TimeValue.ofSeconds(10), result);
  }

  @Test
  public void testConnectionKeepAliveStrategy_KeepAliveHeaderWithoutTimeout() {
    ConnectionKeepAliveStrategy kas = userHubApplication.connectionKeepAliveStrategy();
    org.apache.hc.core5.http.ClassicHttpResponse response =
        mock(org.apache.hc.core5.http.ClassicHttpResponse.class);
    org.apache.hc.core5.http.protocol.HttpContext context =
        mock(org.apache.hc.core5.http.protocol.HttpContext.class);

    org.apache.hc.core5.http.Header connectionHeader = mock(org.apache.hc.core5.http.Header.class);
    when(connectionHeader.getValue()).thenReturn("keep-alive");
    when(response.getFirstHeader("Connection")).thenReturn(connectionHeader);

    org.apache.hc.core5.http.Header keepAliveHeader = mock(org.apache.hc.core5.http.Header.class);
    when(keepAliveHeader.getValue()).thenReturn("max=1000");
    when(response.getFirstHeader("Keep-Alive")).thenReturn(keepAliveHeader);

    TimeValue result = kas.getKeepAliveDuration(response, context);
    assertEquals(TimeValue.ofMilliseconds(20000), result);
  }
}
