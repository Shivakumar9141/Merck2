package com.merck.nextconnect.userhub.mail.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

public class MailTemplateImplTest {

  @Mock private EmailService emailService;
  @Mock private EmailTemplateService emailTemplateService;
  @Mock private SecurityContext securityContext;
  @Mock private Authentication authentication;
  @Mock private AuthenticatedUser authUser;

  @InjectMocks private MailTemplateImpl mailTemplate;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    ReflectionTestUtils.setField(mailTemplate, "fromEmail", "test@example.com");
    ReflectionTestUtils.setField(mailTemplate, "environment", "test");

    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(authUser);
    when(authUser.getUsername()).thenReturn("testuser");
    SecurityContextHolder.setContext(securityContext);
  }

  @Test
  public void testSendCountryUpdateAlertMail() throws Exception {
    // Arrange
    String toEmail = "user@example.com";
    int languageId = 1;
    EmailTemplate mockTemplate = new EmailTemplate();

    when(emailTemplateService.findLanguageIdByEmail(toEmail)).thenReturn(languageId);
    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            eq(Constants.COUNTRY_CHANGE), eq(languageId), eq(Constants.ACTIVE)))
        .thenReturn(mockTemplate);

    // Act
    mailTemplate.sendCountryUpdateAlertMail(toEmail);

    // Assert
    verify(emailService).sendMail(any(EmailMessage.class), eq("test"));
  }

  @Test
  public void testSendDeviceAssignmentChangeMail() throws Exception {
    // Arrange
    UserProfile userProfile = new UserProfile();
    userProfile.setEmail("user@example.com");
    userProfile.setFirstName("John");
    userProfile.setLastName("Doe");

    Language language = new Language();
    language.setId(1);
    userProfile.setLanguage(language);

    Device device = new Device();
    device.setDevicename("TestDevice");
    device.setProductCatalogNo("CAT123");
    device.setSerialno("SN456");

    String templateName = "DEVICE_ASSIGNMENT";
    String categoryName = "CATEGORY";
    String status = Constants.ACTIVE;

    EmailTemplate mockTemplate = new EmailTemplate();

    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            eq(templateName), eq(language.getId()), eq(status)))
        .thenReturn(mockTemplate);

    // Act
    mailTemplate.sendDeviceAssignmentChangeMail(
        userProfile, device, templateName, categoryName, status);

    // Assert
    verify(emailService).sendMail(any(EmailMessage.class), eq("test"));
  }
}
