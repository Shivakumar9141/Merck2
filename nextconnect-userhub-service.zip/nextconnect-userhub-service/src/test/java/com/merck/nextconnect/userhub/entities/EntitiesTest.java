package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class EntitiesTest {

  private Entities entity;

  @BeforeEach
  public void setUp() {
    entity = new Entities();
  }

  @Test
  public void testGetSetEntityId() {
    long id = 123L;
    entity.setEntityId(id);
    assertEquals(id, entity.getEntityId());
  }

  @Test
  public void testGetSetEntityName() {
    String name = "Test Entity";
    entity.setEntityName(name);
    assertEquals(name, entity.getEntityName());
  }
}
