package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.model.role.RoleInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RoleTest {

  private Role role;
  private Organization org;

  @BeforeEach
  public void setUp() {
    role = new Role();
    org = new Organization();
    org.setId(123);
  }

  @Test
  public void testDefaultConstructor() {
    assertFalse(role.isSystemDefined());
    assertFalse(role.isServiceRole());
  }

  @Test
  public void testConstructorWithId() {
    long roleId = 456;
    Role roleWithId = new Role(roleId);
    assertEquals(roleId, roleWithId.getRoleId());
  }

  @Test
  public void testConstructorWithRoleInfo() {
    String roleName = "Admin";
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName(roleName);

    Role roleFromInfo = new Role(roleInfo);
    assertEquals(roleName, roleFromInfo.getName());
  }

  @Test
  public void testGettersAndSetters() {
    // RoleId
    long roleId = 789;
    role.setRoleId(roleId);
    assertEquals(roleId, role.getRoleId());

    // Name
    String name = "Manager";
    role.setName(name);
    assertEquals(name, role.getName());

    // SystemDefined
    role.setSystemDefined(true);
    assertTrue(role.isSystemDefined());

    // Organization
    role.setOrg(org);
    assertEquals(org, role.getOrg());

    // ServiceRole
    role.setServiceRole(true);
    assertTrue(role.isServiceRole());
  }
}
