package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CardTest {

  private Card card;
  private DeviceType deviceType;

  @BeforeEach
  public void setUp() {
    card = new Card();
    deviceType = new DeviceType();
    deviceType.setDeviceTypeId(1);
  }

  @Test
  public void testGetSetId() {
    long id = 123L;
    card.setId(id);
    assertEquals(id, card.getId());
  }

  @Test
  public void testGetSetDataType() {
    String dataType = "testDataType";
    card.setDataType(dataType);
    assertEquals(dataType, card.getDataType());
  }

  @Test
  public void testGetSetDeviceType() {
    card.setDeviceType(deviceType);
    assertEquals(deviceType, card.getDeviceType());
  }
}
