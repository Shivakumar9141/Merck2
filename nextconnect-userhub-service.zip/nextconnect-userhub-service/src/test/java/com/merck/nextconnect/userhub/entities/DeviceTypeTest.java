package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DeviceTypeTest {

  private DeviceType deviceType;

  @BeforeEach
  public void setUp() {
    deviceType = new DeviceType();
  }

  @Test
  public void testGetAndSetDeviceTypeId() {
    long id = 123L;
    deviceType.setDeviceTypeId(id);
    assertEquals(id, deviceType.getDeviceTypeId());
  }

  @Test
  public void testGetAndSetDeviceType() {
    String type = "Smartphone";
    deviceType.setDeviceType(type);
    assertEquals(type, deviceType.getDeviceType());
  }

  @Test
  public void testDefaultConstructor() {
    DeviceType newDeviceType = new DeviceType();
    assertEquals(0L, newDeviceType.getDeviceTypeId());
    assertEquals(null, newDeviceType.getDeviceType());
  }
}
