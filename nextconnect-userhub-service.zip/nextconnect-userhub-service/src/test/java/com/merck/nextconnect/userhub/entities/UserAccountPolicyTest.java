package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserAccountPolicyTest {

  private UserAccountPolicy userAccountPolicy;
  private UserProfile userProfile;
  private Date lastFailed;
  private int failedAttempts;
  private long id;

  @BeforeEach
  public void setUp() {
    id = 123L;
    failedAttempts = 3;
    lastFailed = new Date();
    userProfile = new UserProfile();
    userProfile.setUserId(456L);

    userAccountPolicy = new UserAccountPolicy(userProfile, failedAttempts, lastFailed);
    userAccountPolicy.setId(id);
  }

  @Test
  public void testDefaultConstructor() {
    UserAccountPolicy policy = new UserAccountPolicy();
    assertNotNull(policy);
  }

  @Test
  public void testParameterizedConstructor() {
    assertEquals(userProfile, userAccountPolicy.getUserProfile());
    assertEquals(failedAttempts, userAccountPolicy.getFailedAttempts());
    assertEquals(lastFailed, userAccountPolicy.getLastFailed());
  }

  @Test
  public void testGetSetId() {
    assertEquals(id, userAccountPolicy.getId());

    long newId = 789L;
    userAccountPolicy.setId(newId);
    assertEquals(newId, userAccountPolicy.getId());
  }

  @Test
  public void testGetSetFailedAttempts() {
    assertEquals(failedAttempts, userAccountPolicy.getFailedAttempts());

    int newFailedAttempts = 5;
    userAccountPolicy.setFailedAttempts(newFailedAttempts);
    assertEquals(newFailedAttempts, userAccountPolicy.getFailedAttempts());
  }

  @Test
  public void testGetSetLastFailed() {
    assertEquals(lastFailed, userAccountPolicy.getLastFailed());

    Date newLastFailed = new Date();
    userAccountPolicy.setLastFailed(newLastFailed);
    assertEquals(newLastFailed, userAccountPolicy.getLastFailed());
  }

  @Test
  public void testGetSetUserProfile() {
    assertEquals(userProfile, userAccountPolicy.getUserProfile());

    UserProfile newUserProfile = new UserProfile();
    newUserProfile.setUserId(999L);
    userAccountPolicy.setUserProfile(newUserProfile);
    assertEquals(newUserProfile, userAccountPolicy.getUserProfile());
  }
}
