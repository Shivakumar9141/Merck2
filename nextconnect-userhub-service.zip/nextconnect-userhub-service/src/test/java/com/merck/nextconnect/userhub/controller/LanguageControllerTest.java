package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.UserhubBaseTest;
import com.merck.nextconnect.userhub.resources.ILanguage;
import com.merck.nextconnect.utils.common.entities.Language;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class LanguageControllerTest extends UserhubBaseTest {

  @Mock private ILanguage languageMock;

  @InjectMocks private LanguageController languageController;

  @Mock private AuthenticatedUser authUser;
  @Mock private Authentication authentication;

  @Before
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetLanguages_Success() {
    List<Language> languages = new ArrayList<>();
    Language language = new Language();
    language.setId(1);
    language.setValue("test");
    language.setCode("test");
    languages.add(language);

    when(languageMock.getAll()).thenReturn(languages);
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    ResponseEntity<List<Language>> responseEntity = languageController.getDates();

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(languages, responseEntity.getBody());
  }

  @Test
  public void testGetLanguages_EmptyList() {
    List<Language> emptyList = new ArrayList<>();

    when(languageMock.getAll()).thenReturn(emptyList);
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    ResponseEntity<List<Language>> responseEntity = languageController.getDates();

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(emptyList, responseEntity.getBody());
  }
}
