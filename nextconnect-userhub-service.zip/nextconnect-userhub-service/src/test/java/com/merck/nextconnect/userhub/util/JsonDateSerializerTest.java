package com.merck.nextconnect.userhub.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.sql.Timestamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

public class JsonDateSerializerTest {

  private JsonDateSerializer serializer;
  private JsonGenerator jsonGenerator;
  private SerializerProvider serializerProvider;

  @BeforeEach
  public void setUp() {
    serializer = new JsonDateSerializer();
    jsonGenerator = mock(JsonGenerator.class);
    serializerProvider = mock(SerializerProvider.class);
  }

  @Test
  public void serialize_shouldWriteFormattedDate() throws IOException {
    Timestamp timestamp = Timestamp.valueOf("2024-06-01 15:30:45.123");
    serializer.serialize(timestamp, jsonGenerator, serializerProvider);

    ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
    verify(jsonGenerator, times(1)).writeString(captor.capture());
    // The output should be in ISO 8601 format with timezone, but since SimpleDateFormat uses system
    // timezone,
    // we only check the prefix
    String value = captor.getValue();
    assertEquals(true, value.startsWith("2024-06-01T15:30:45"));
  }

  @Test
  public void serialize_shouldLogErrorOnIOException() throws IOException {
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    doThrow(new IOException("test")).when(jsonGenerator).writeString(anyString());

    serializer.serialize(timestamp, jsonGenerator, serializerProvider);
  }
}
