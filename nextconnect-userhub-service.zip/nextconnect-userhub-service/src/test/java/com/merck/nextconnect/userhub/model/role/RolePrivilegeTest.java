package com.merck.nextconnect.userhub.model.role;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class RolePrivilegeTest {

  @Test
  public void testDefaultConstructor() {
    RolePrivilege rolePrivilege = new RolePrivilege();
    assertNotNull(rolePrivilege);
  }

  @Test
  public void testParameterizedConstructor() {
    long privilegeId = 1L;
    String operation = "READ";
    long resourceId = 100L;
    String resourceType = "USER";

    RolePrivilege rolePrivilege =
        new RolePrivilege(privilegeId, operation, resourceId, resourceType);

    assertEquals(privilegeId, rolePrivilege.getPrivilegeId());
    assertEquals(operation, rolePrivilege.getOperation());
    assertEquals(resourceId, rolePrivilege.getResourceId());
    assertEquals(resourceType, rolePrivilege.getResourceType());
  }

  @Test
  public void testSettersAndGetters() {
    RolePrivilege rolePrivilege = new RolePrivilege();

    rolePrivilege.setPrivilegeId(2L);
    rolePrivilege.setOperation("WRITE");
    rolePrivilege.setResourceId(200L);
    rolePrivilege.setResourceType("ROLE");

    assertEquals(2L, rolePrivilege.getPrivilegeId());
    assertEquals("WRITE", rolePrivilege.getOperation());
    assertEquals(200L, rolePrivilege.getResourceId());
    assertEquals("ROLE", rolePrivilege.getResourceType());
  }
}
