package com.merck.nextconnect.userhub.authentication;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.authfilter.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.authentication.impl.MerckAuth;
import com.merck.nextconnect.userhub.authentication.impl.NextConnectAuth;
import com.merck.nextconnect.userhub.authentication.impl.SialAuth;
import com.merck.nextconnect.userhub.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

@MockitoSettings(strictness = Strictness.LENIENT)
public class AuthenticationFactoryTest {

  @Mock private MerckAuth merckAuth;
  @Mock private SialAuth sialAuth;
  @Mock private NextConnectAuth nextConnectAuth;

  @InjectMocks private AuthenticationFactory authenticationFactory;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetAuthProvider_NextConnect() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.NEXTCONNECT);
    assertNotNull(result);
    assertEquals(nextConnectAuth, result);
  }

  @Test
  public void testGetAuthProvider_Sial() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.SIAL);
    assertNotNull(result);
    assertEquals(sialAuth, result);
  }

  @Test
  public void testGetAuthProvider_MerckGlobal() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.MERCK_GLOBAL);
    assertNotNull(result);
    assertEquals(merckAuth, result);
  }

  @Test
  public void testGetAuthProvider_MerckDnap() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.MERCK_DNAP);
    assertNotNull(result);
    assertEquals(merckAuth, result);
  }

  @Test
  public void testGetAuthProvider_MerckDneu() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.MERCK_DNEU);
    assertNotNull(result);
    assertEquals(merckAuth, result);
  }

  @Test
  public void testGetAuthProvider_MerckDnla() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.MERCK_DNLA);
    assertNotNull(result);
    assertEquals(merckAuth, result);
  }

  @Test
  public void testGetAuthProvider_MerckDnna() {
    IAuthRepository result = authenticationFactory.getAuthProvider(Constants.MERCK_DNNA);
    assertNotNull(result);
    assertEquals(merckAuth, result);
  }

  @Test
  void testGetAuthProvider_InvalidDomain() {
    assertThrows(
        LoginAuthenticationException.class,
        () -> authenticationFactory.getAuthProvider("INVALID_DOMAIN"));
  }
}
