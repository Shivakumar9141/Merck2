package com.merck.nextconnect.userhub.constants;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class UserhubConstantsTest {

  @Test
  public void testConstantValues() {
    assertEquals("SINGLE_SIGN_ON", UserhubConstants.SINGLE_SIGN_ON);
    assertEquals("PUBLIC_KEY", UserhubConstants.PUBLIC_KEY);
    assertEquals("ACTIVE", UserhubConstants.ACTIVE);
    assertEquals("USER_PROFILE", UserhubConstants.USER_PROFILE);
    assertEquals("THUMBNAIL_IMAGE_SCALE_HEIGHT", UserhubConstants.THUMBNAIL_IMAGE_SCALE_HEIGHT);
    assertEquals("THUMBNAIL_IMAGE_SCALE_WIDTH", UserhubConstants.THUMBNAIL_IMAGE_SCALE_WIDTH);
    assertEquals("BLOB_IMAGE_SCALE_HEIGHT", UserhubConstants.BLOB_IMAGE_SCALE_HEIGHT);
    assertEquals("BLOB_IMAGE_SCALE_WIDTH", UserhubConstants.BLOB_IMAGE_SCALE_WIDTH);
    assertEquals("userId", UserhubConstants.USER_ID);
    assertEquals("userImage", UserhubConstants.USER_IMAGE);
    assertEquals("thumbnailUserImage", UserhubConstants.THUMBNAIL_USER_IMAGE);
    assertEquals("createdDate", UserhubConstants.CREATED_DATE);
    assertEquals("modifiedDate", UserhubConstants.MODIFIED_DATE);
    assertEquals("USER_DOMAIN", UserhubConstants.USER_DOMAIN);
    assertEquals("DOMAIN_VISIBILITY", UserhubConstants.DOMAIN_VISIBILITY);
  }

  @Test
  public void testConstantsAreNotNull() {
    assertEquals(false, UserhubConstants.SINGLE_SIGN_ON == null);
    assertEquals(false, UserhubConstants.PUBLIC_KEY == null);
    assertEquals(false, UserhubConstants.ACTIVE == null);
    assertEquals(false, UserhubConstants.USER_PROFILE == null);
    assertEquals(false, UserhubConstants.THUMBNAIL_IMAGE_SCALE_HEIGHT == null);
    assertEquals(false, UserhubConstants.THUMBNAIL_IMAGE_SCALE_WIDTH == null);
    assertEquals(false, UserhubConstants.BLOB_IMAGE_SCALE_HEIGHT == null);
    assertEquals(false, UserhubConstants.BLOB_IMAGE_SCALE_WIDTH == null);
    assertEquals(false, UserhubConstants.USER_ID == null);
    assertEquals(false, UserhubConstants.USER_IMAGE == null);
    assertEquals(false, UserhubConstants.THUMBNAIL_USER_IMAGE == null);
    assertEquals(false, UserhubConstants.CREATED_DATE == null);
    assertEquals(false, UserhubConstants.MODIFIED_DATE == null);
    assertEquals(false, UserhubConstants.USER_DOMAIN == null);
    assertEquals(false, UserhubConstants.DOMAIN_VISIBILITY == null);
  }

  @Test
  public void testConstantsAreFinal() throws Exception {
    // All fields should be final, so attempting to reflectively set should throw
    // exception
    java.lang.reflect.Field[] fields = UserhubConstants.class.getDeclaredFields();
    for (java.lang.reflect.Field field : fields) {
      int modifiers = field.getModifiers();
      assertEquals(true, java.lang.reflect.Modifier.isFinal(modifiers));
    }
  }

  @Test
  public void testClassIsUtilityClass() {
    // The class should not be instantiable
    try {
      UserhubConstants.class.getDeclaredConstructor().newInstance();
    } catch (Exception e) {
      assertEquals(java.lang.reflect.InvocationTargetException.class, e.getClass());
    }
  }
}
