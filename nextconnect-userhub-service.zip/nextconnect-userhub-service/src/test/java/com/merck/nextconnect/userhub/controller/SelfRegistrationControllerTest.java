package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.UserhubBaseTest;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.resources.ICountry;
import com.merck.nextconnect.userhub.resources.ISelfRegistrationService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.common.repository.jpa.RoleOfInterestRepository;
import com.merck.nextconnect.utils.exception.EmailException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

public class SelfRegistrationControllerTest extends UserhubBaseTest {

  @Mock private ISelfRegistrationService selfRegistrationService;

  @InjectMocks private SelfRegistrationController controller;

  @Mock private ICountry iCountry;
  @Mock private RoleOfInterestRepository roleOfInterestRepository;
  @Mock private OrganizationRepository organizationRepository;

  private MockHttpServletRequest request = new MockHttpServletRequest();

  @Before
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testSelfRegistration_Success() throws Exception {
    SelfRegistrationDTO dto = new SelfRegistrationDTO();
    when(selfRegistrationService.selfRegistration(dto, request.getSession().getId()))
        .thenReturn(true);

    ResponseEntity<Boolean> response = controller.selfRegistration(dto, request);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertTrue(response.getBody());
  }

  @Test
  public void testGetCountries_Success() {
    List<Country> countryList = new ArrayList<>();
    Country country = new Country();
    country.setId(1);
    country.setCountryName("test");
    countryList.add(country);
    when(iCountry.getCountries(Constants.EMPTY_STRING)).thenReturn(countryList);
    ResponseEntity<List<Country>> response = controller.getCountries();
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(countryList, response.getBody());
  }

  @Test
  public void testGetRoleOfInterest_Success() {
    int businessUnitId = 123;
    List<RoleOfInterest> roleOfInterestList = new ArrayList<>();
    roleOfInterestList.add(new RoleOfInterest(businessUnitId, "Role1", null, businessUnitId));
    when(roleOfInterestRepository.findByBusinessUnit(businessUnitId))
        .thenReturn(roleOfInterestList);
    ResponseEntity<List<RoleOfInterest>> response = controller.getRoleOfInterest(businessUnitId);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(roleOfInterestList, response.getBody());
  }

  @Test
  public void testGetRoleOfInterestForLabwater_Success() {
    int labwaterId = 123;
    List<RoleOfInterest> roleOfInterestList = new ArrayList<>();
    roleOfInterestList.add(new RoleOfInterest(labwaterId, "Role1", null, labwaterId));
    when(organizationRepository.findIdByName(Constants.LABWATER)).thenReturn(labwaterId);
    when(roleOfInterestRepository.findByBusinessUnit(labwaterId)).thenReturn(roleOfInterestList);
    ResponseEntity<List<RoleOfInterest>> response = controller.getRoleOfInterestForLabwater();
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(roleOfInterestList, response.getBody());
  }

  @Test
  public void testValidateSelfRegisteredUser_ValidUser()
      throws DataValidationException,
          ResourceNotFoundException,
          EmailException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    long userId = 123;
    boolean isValid = true;
    doNothing().when(selfRegistrationService).validateSelfRegisteredUser(userId, isValid);
    ResponseEntity<?> response = controller.validateSelfRegisteredUser(userId, isValid);
    assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    assertNull(response.getBody());
  }

  //  @Test(expected = DataValidationException.class)
  public void testValidateSelfRegisteredUser_InvalidUser()
      throws DataValidationException,
          ResourceNotFoundException,
          EmailException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    long userId = 123;
    boolean isValid = false;
    doThrow(DataValidationException.class)
        .when(selfRegistrationService)
        .validateSelfRegisteredUser(userId, isValid);

    controller.validateSelfRegisteredUser(userId, isValid);
  }

  @Test
  public void testSelfRegistrationValidation_ValidInput() throws Exception {
    SelfRegistrationDTO selfRegistrationDTO = new SelfRegistrationDTO();
    List<RoleOfInterest> roleOfInterestList = new ArrayList<>();
    roleOfInterestList.add(new RoleOfInterest(123, "Role1", null, 123));
    when(selfRegistrationService.selfRegistrationValidation(
            selfRegistrationDTO, request.getSession().getId()))
        .thenReturn(roleOfInterestList);

    ResponseEntity<List<RoleOfInterest>> response =
        controller.selfRegistrationValidation(selfRegistrationDTO, request);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
  }
}
