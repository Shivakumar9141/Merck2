package com.merck.nextconnect.userhub.validations.helper;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.validations.ValidationResult;
import org.junit.jupiter.api.Test;

public class SubscriptionHelperTest {

  @Test
  public void testValidateCountry_WhenSupportEnabled_ShouldReturnValid() {
    // Arrange
    Country country = new Country();
    country.setSupportEnabled(true);

    // Act
    ValidationResult result = SubscriptionHelper.validateCountry.test(country);

    // Assert
    assertTrue(result.isvalid());
  }

  @Test
  public void testValidateCountry_WhenSupportDisabled_ShouldReturnInvalid() {
    // Arrange
    Country country = new Country();
    country.setSupportEnabled(false);

    // Act
    ValidationResult result = SubscriptionHelper.validateCountry.test(country);

    // Assert
    assertFalse(result.isvalid());
  }

  @Test
  public void testValidateCountry_WhenCountryIsNull_ShouldReturnInvalid() {
    // Act
    ValidationResult result = SubscriptionHelper.validateCountry.test(null);

    // Assert
    assertFalse(result.isvalid());
  }

  @Test
  public void testValidateCountry_ShouldReturnInvalid_WhenCountryIsNull() {
    ValidationResult result = SubscriptionHelper.validateCountry.test(null);
    assertFalse(result.isvalid());
  }

  @Test
  public void testValidateCountry_ShouldReturnInvalid_WhenSupportEnabledIsFalse() {
    Country country = new Country();
    country.setSupportEnabled(false);
    ValidationResult result = SubscriptionHelper.validateCountry.test(country);
    assertFalse(result.isvalid());
  }

  @Test
  public void testValidateCountry_ShouldReturnValid_WhenSupportEnabledIsTrue() {
    Country country = new Country();
    country.setSupportEnabled(true);
    ValidationResult result = SubscriptionHelper.validateCountry.test(country);
    assertTrue(result.isvalid());
  }
}
