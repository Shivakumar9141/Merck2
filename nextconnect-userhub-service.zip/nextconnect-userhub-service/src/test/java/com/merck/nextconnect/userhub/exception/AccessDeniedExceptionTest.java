package com.merck.nextconnect.userhub.exception;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

public class AccessDeniedExceptionTest {

  @Test
  public void testConstructorWithMessage() {
    String errorMessage = "Access denied for this resource";
    AccessDeniedException exception = new AccessDeniedException(errorMessage);

    assertNotNull(exception);
    assertEquals(errorMessage, exception.getMessage());
  }

  @Test
  public void testConstructorWithCustomErrorCode() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    AccessDeniedException exception = new AccessDeniedException(errorCode);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCodeAndParams() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    List<String> params = Arrays.asList("user123", "resource456");
    AccessDeniedException exception = new AccessDeniedException(errorCode, params);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }
}
