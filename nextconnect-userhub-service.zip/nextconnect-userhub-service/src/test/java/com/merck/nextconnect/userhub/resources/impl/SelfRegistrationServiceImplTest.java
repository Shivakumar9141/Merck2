package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.DeviceType;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.SelfRegisteredUserDeviceMapping;
import com.merck.nextconnect.userhub.entities.ServiceContract;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.repository.hazelcast.SelfRegistrationStore;
import com.merck.nextconnect.userhub.repository.jpa.CoveredProductRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.SelfRegisteredUserDeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.ServiceContractRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDomainRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IUserSupport;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.validator.SelfRegistrationValidator;
import com.merck.nextconnect.utils.captcha.service.ValidateCaptchaService;
import com.merck.nextconnect.utils.common.DeviceWarrantyStatus;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.RoleOfInterestRepository;
import com.merck.nextconnect.utils.email.entities.ApplicationConfig;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.servicemax.helper.ServiceMaxServiceRequestHelper;
import com.merck.nextconnect.utils.servicemax.resources.ServiceMaxService;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import com.merck.nextconnect.utils.validator.SerialNumberValidator;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class SelfRegistrationServiceImplTest {

  @InjectMocks private SelfRegistrationServiceImpl selfRegistrationService;

  @Mock private DeviceRepository deviceRepository;
  @Mock private UserRepository userRepository;
  @Mock private SelfRegistrationValidator selfRegistrationValidator;
  @Mock private PhoneNumberValidator phoneNumberValidator;
  @Mock private CountryRepository countryRepository;
  @Mock private ServiceContractRepository serviceContractRepository;
  @Mock private IUserSupport iUserSupport;
  @Mock private RoleRepository roleRepo;
  @Mock private EmailTemplateService emailTemplateService;
  @Mock private EmailService emailService;
  @Mock private ServiceMaxService serviceMaxService;
  @Mock private RoleOfInterestRepository roleOfInterestRepository;
  @Mock private UserDomainRepository userDomainRepository;
  @Mock private SelfRegisteredUserDeviceRepository selfRegisteredUserDeviceRepository;
  @Mock private ApplicationConfigRepository applicationConfigRepository;
  @Mock private CoveredProductRepository coveredProductRepository;
  @Mock private OrganizationRepository organizationRepository;
  @Mock private SerialNumberValidator serialNumberValidator;
  @Mock private RoleRepository roleRepository;
  @Mock private UserRolePrivileges userRolePrivileges;
  @Mock private ValidateCaptchaService validateCaptchaService;
  @Mock private SelfRegistrationStore selfRegistrationStore;
  @Mock private SecurityContext securityContext;
  @Mock private Authentication authentication;
  @Mock private ServiceMaxServiceRequestHelper serviceMaxServiceRequestHelper;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(selfRegistrationService, "fromEmail", "test@example.com");
    ReflectionTestUtils.setField(selfRegistrationService, "environment", "test");
    ReflectionTestUtils.setField(
        selfRegistrationService, "recaptchaEndpoint", "https://recaptcha.example.com");
    ReflectionTestUtils.setField(selfRegistrationService, "recaptchaSecret", "recaptchaSecret");
    ReflectionTestUtils.setField(
        selfRegistrationService, "smaxSerialNoCheckUrl", "https://smax.example.com/check");

    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
  }

  @Test
  void testSelfRegistration_Success() throws Exception {
    String sessionId = "test-session-id";
    SelfRegistrationDTO selfRegistrationDTO = createSelfRegistrationDTO();
    SelfRegistrationDTO cachedDTO = createSelfRegistrationDTO();
    cachedDTO.setOrgId(1);

    Country country = new Country();
    country.setId(1);
    country.setCountryCode("US");

    Device device = createDevice();

    RoleOfInterest roleOfInterest = new RoleOfInterest();
    roleOfInterest.setMymilliqRoleName("USER_ROLE");

    Role role = new Role();
    role.setRoleId(1L);

    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(1L);

    when(selfRegistrationStore.getSelfRegistrationMap(sessionId)).thenReturn(cachedDTO);
    doNothing().when(selfRegistrationValidator).selfRegistrationDataValidation(any(), any());
    when(countryRepository.findByCountryCode(anyString())).thenReturn(country);
    when(roleOfInterestRepository.findByRoleOfInterest(anyString())).thenReturn(roleOfInterest);
    when(deviceRepository.findBySerialnoAndStatusAndDeleted(
            anyString(), anyBoolean(), anyBoolean()))
        .thenReturn(device);
    when(roleRepo.getRoleByName(anyString(), anyInt())).thenReturn(role);
    when(userDomainRepository.findDomainIdByDomainName(anyString())).thenReturn(1L);
    when(iUserSupport.add(any(UserDetails.class))).thenReturn(userProfile);

    boolean result = selfRegistrationService.selfRegistration(selfRegistrationDTO, sessionId);

    assertTrue(result);
    verify(selfRegistrationStore).removeSelfRegistrationMap(sessionId);
    verify(selfRegisteredUserDeviceRepository).save(any(SelfRegisteredUserDeviceMapping.class));
  }

  @Test
  void testSelfRegistration_SessionTimeout() {
    String sessionId = "test-session-id";
    SelfRegistrationDTO selfRegistrationDTO = createSelfRegistrationDTO();

    when(selfRegistrationStore.getSelfRegistrationMap(sessionId)).thenReturn(null);

    assertThrows(
        DataValidationException.class,
        () -> selfRegistrationService.selfRegistration(selfRegistrationDTO, sessionId));
  }

  @Test
  void testValidateSelfRegisteredUser_ValidUser() throws Exception {
    long userId = 1L;
    boolean isValid = true;

    JwtUser jwtUser = mock(JwtUser.class);
    when(jwtUser.getId()).thenReturn(2L);
    AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, null, null);

    UserProfile selfRegisteredUser = new UserProfile();
    selfRegisteredUser.setUserId(userId);
    selfRegisteredUser.setEmail("user@example.com");
    selfRegisteredUser.setFirstName("John");
    selfRegisteredUser.setLastName("Doe");

    UserProfile validatingUser = new UserProfile();
    validatingUser.setUserId(2L);

    SelfRegisteredUserDeviceMapping mapping = new SelfRegisteredUserDeviceMapping();
    Device device = createDevice();
    mapping.setDevice(device);

    when(authentication.getPrincipal()).thenReturn(authUser);
    when(userRepository.findByUserIdAndDeletedAndStatus(userId, false, "Active"))
        .thenReturn(selfRegisteredUser);
    when(userRepository.findByUserIdAndDeletedAndStatus(2L, false, "Active"))
        .thenReturn(validatingUser);
    when(selfRegisteredUserDeviceRepository.findByUserProfileUserId(userId)).thenReturn(mapping);
    when(deviceRepository.findByDeviceIdAndStatusAndDeleted(anyLong(), anyBoolean(), anyBoolean()))
        .thenReturn(device);
    doNothing().when(userRolePrivileges).autoAddUserDevicePrivileges(any(), any());
    doNothing()
        .when(emailService)
        .sendEmailForProfileStatusChange(
            anyString(), anyString(), anyString(), anyString(), anyString(), anyString());

    selfRegistrationService.validateSelfRegisteredUser(userId, isValid);

    verify(userRepository).updateUserValidatedByUserId(userId, true);
    verify(selfRegisteredUserDeviceRepository).delete(mapping);
  }

  @Test
  void testValidateSelfRegisteredUser_InvalidUser() throws Exception {
    long userId = 1L;
    boolean isValid = false;

    JwtUser jwtUser = mock(JwtUser.class);
    when(jwtUser.getId()).thenReturn(2L);
    AuthenticatedUser authUser = new AuthenticatedUser(jwtUser, null, null);

    UserProfile selfRegisteredUser = new UserProfile();
    selfRegisteredUser.setUserId(userId);
    selfRegisteredUser.setEmail("user@example.com");
    selfRegisteredUser.setFirstName("John");
    selfRegisteredUser.setLastName("Doe");

    UserProfile validatingUser = new UserProfile();
    validatingUser.setUserId(2L);
    validatingUser.setFirstName("Admin");
    validatingUser.setLastName("User");

    Organization org = new Organization();
    org.setName("Test Org");
    validatingUser.setOrg(org);

    SelfRegisteredUserDeviceMapping mapping = new SelfRegisteredUserDeviceMapping();
    Device device = createDevice();
    mapping.setDevice(device);

    when(authentication.getPrincipal()).thenReturn(authUser);
    when(userRepository.findByUserIdAndDeletedAndStatus(userId, false, "Active"))
        .thenReturn(selfRegisteredUser);
    when(userRepository.findByUserIdAndDeletedAndStatus(2L, false, "Active"))
        .thenReturn(validatingUser);
    when(selfRegisteredUserDeviceRepository.findByUserProfileUserId(userId)).thenReturn(mapping);
    when(deviceRepository.findByDeviceIdAndStatusAndDeleted(anyLong(), anyBoolean(), anyBoolean()))
        .thenReturn(device);
    doNothing()
        .when(emailService)
        .sendEmailForSelfRegistrationRequestRejected(
            any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any());

    selfRegistrationService.validateSelfRegisteredUser(userId, isValid);

    verify(userRepository).deleteUserByUserId(userId, true);
    verify(selfRegisteredUserDeviceRepository).delete(mapping);
  }

  @Test
  void testGetDeviceWarrantyStatus_InWarranty() {
    Device device = createDevice();
    device.setInstalledDate(Timestamp.from(Instant.now().minusSeconds(86400)));

    ApplicationConfig warrantyPeriod = new ApplicationConfig();
    warrantyPeriod.setValue("365");

    when(applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.WARRANTY_PERIOD, Constants.WARRANTY_PERIOD_VALUE, Constants.ACTIVE))
        .thenReturn(warrantyPeriod);

    DeviceWarrantyStatus status = selfRegistrationService.getDeviceWarrantyStatus(device);

    assertEquals(DeviceWarrantyStatus.IN_WARRANTY, status);
  }

  @Test
  void testGetDeviceWarrantyStatus_UnderServiceContract() {
    Device device = createDevice();
    device.setInstalledDate(Timestamp.from(Instant.now().minusSeconds(31536000)));

    ApplicationConfig warrantyPeriod = new ApplicationConfig();
    warrantyPeriod.setValue("30");

    Set<Long> serviceContractIds = new HashSet<>();
    serviceContractIds.add(1L);

    ServiceContract serviceContract = new ServiceContract();
    serviceContract.setEndDate(Timestamp.from(Instant.now().plusSeconds(86400)));

    when(applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.WARRANTY_PERIOD, Constants.WARRANTY_PERIOD_VALUE, Constants.ACTIVE))
        .thenReturn(warrantyPeriod);
    when(coveredProductRepository.findServiceContractIdByDeviceIdAndServiceLevel(
            device.getDeviceId(), Constants.CP_SERVICE_LEVEL))
        .thenReturn(serviceContractIds);
    when(serviceContractRepository.getByServiceContractStatusInAndServiceContractIdIn(
            anyList(), anySet()))
        .thenReturn(serviceContract);

    DeviceWarrantyStatus status = selfRegistrationService.getDeviceWarrantyStatus(device);

    assertEquals(DeviceWarrantyStatus.UNDER_SERVICE_CONTRACT, status);
  }

  @Test
  void testSelfRegistrationValidation_Success() throws Exception {
    String sessionId = "test-session-id";
    SelfRegistrationDTO selfRegistrationDTO = createSelfRegistrationDTO();

    Country country = new Country();
    country.setId(1);
    country.setCountryCode("US");
    country.setSupportEnabled(true);

    Device device = createDevice();
    device.setSoldTo("SOLD_TO");
    device.setBillTo("BILL_TO");

    Organization org = new Organization();
    org.setId(1);
    org.setStatus(true);

    List<RoleOfInterest> roles = new ArrayList<>();
    RoleOfInterest role = new RoleOfInterest();
    role.setId(1);
    role.setRoleOfInterest("USER");
    roles.add(role);

    ApplicationConfig warrantyPeriod = new ApplicationConfig();
    warrantyPeriod.setValue("365");

    when(validateCaptchaService.validateCaptcha(anyString(), anyString(), anyString()))
        .thenReturn(true);
    when(userRepository.getUserByEmail(anyString())).thenReturn(null);
    when(countryRepository.findByCountryCode(anyString())).thenReturn(country);
    doNothing().when(selfRegistrationValidator).selfRegistrationValidator(any(), any(), any());
    doNothing().when(phoneNumberValidator).validatePhoneNumberFormat(anyString(), anyString());
    doNothing().when(serialNumberValidator).validateSerialNumberPattern(anyString());
    when(deviceRepository.findBySerialnoAndStatusAndDeleted(
            anyString(), anyBoolean(), anyBoolean()))
        .thenReturn(device);
    when(applicationConfigRepository.findByCategoryAndKeyAndStatus(
            anyString(), anyString(), anyString()))
        .thenReturn(warrantyPeriod);

    String orgName =
        Constants.ORG_CAPITAL
            .concat("_")
            .concat(device.getSoldTo())
            .concat("_")
            .concat(device.getBillTo());
    when(organizationRepository.findByNameAndTypeAndParentIdAndDeleted(
            eq(orgName), eq(Constants.CUSTOMER), eq(0), eq(false)))
        .thenReturn(org);

    UserProfile selfRegisteredUser = new UserProfile();
    Organization userOrg = new Organization();
    userOrg.setId(1);
    userOrg.setStatus(true);
    selfRegisteredUser.setOrg(userOrg);

    when(roleOfInterestRepository.findRoleOfInterestByOrgType(anyString())).thenReturn(roles);

    List<RoleOfInterest> result =
        selfRegistrationService.selfRegistrationValidation(selfRegistrationDTO, sessionId);

    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(role.getRoleOfInterest(), result.get(0).getRoleOfInterest());
    verify(selfRegistrationStore).addSelfRegistrationMap(sessionId, selfRegistrationDTO);
  }

  // Note: testSelfRegistrationValidation_InvalidCaptcha left commented in original; convert when
  // required.

  @Test
  void testGetCAForDevice_InWarranty() throws Exception {
    Device device = createDevice();
    device.setEmailId("ca@example.com");
    device.setInstalledDate(Timestamp.from(Instant.now().minusSeconds(86400)));

    ApplicationConfig warrantyPeriod = new ApplicationConfig();
    warrantyPeriod.setValue("365");

    Role role = new Role();
    role.setRoleId(1L);

    UserProfile caProfile = new UserProfile();
    caProfile.setUserId(1L);
    caProfile.setEmail("ca@example.com");

    List<UserProfile> profiles = new ArrayList<>();
    profiles.add(caProfile);

    when(applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.WARRANTY_PERIOD, Constants.WARRANTY_PERIOD_VALUE, Constants.ACTIVE))
        .thenReturn(warrantyPeriod);
    when(roleRepository.getRoleByName(Constants.CUSTOMER_ADMIN, 1)).thenReturn(role);
    when(userRepository.findAllByEmailAndRole_RoleIdAndStatusAndDeleted(
            "ca@example.com", 1L, Constants.ACTIVE, false))
        .thenReturn(profiles);

    UserProfile result = selfRegistrationService.getCAForDevice(device, 1);

    assertNotNull(result);
    assertEquals(caProfile.getUserId(), result.getUserId());
  }

  @Test
  void testSendEmail() throws Exception {
    SelfRegistrationDTO selfRegistrationDTO = new SelfRegistrationDTO();
    selfRegistrationDTO.setEmail("test@example.com");

    EmailTemplate mockEmailTemplate = new EmailTemplate();
    when(emailTemplateService.findByTemplateName(Constants.SELF_REGISTRATION_FAILURE))
        .thenReturn(mockEmailTemplate);

    java.lang.reflect.Method sendEmailMethod =
        SelfRegistrationServiceImpl.class.getDeclaredMethod("sendEmail", SelfRegistrationDTO.class);
    sendEmailMethod.setAccessible(true);

    try {
      sendEmailMethod.invoke(selfRegistrationService, selfRegistrationDTO);
    } catch (java.lang.reflect.InvocationTargetException e) {
      if (e.getCause() instanceof Exception) {
        throw (Exception) e.getCause();
      }
      throw e;
    }

    verify(emailTemplateService).findByTemplateName(Constants.SELF_REGISTRATION_FAILURE);

    ArgumentCaptor<EmailMessage> emailMessageCaptor = ArgumentCaptor.forClass(EmailMessage.class);
    ArgumentCaptor<String> environmentCaptor = ArgumentCaptor.forClass(String.class);
    verify(emailService).sendMail(emailMessageCaptor.capture(), environmentCaptor.capture());

    EmailMessage capturedEmail = emailMessageCaptor.getValue();
    assertEquals(mockEmailTemplate, capturedEmail.getEmailTemplate());
    assertEquals("test@example.com", capturedEmail.getEmailFrom());
    assertEquals(selfRegistrationDTO.getEmail(), capturedEmail.getEmailTo());
    assertEquals(Constants.SELF_REGISTRATION_FAILURE_SUBJECT, capturedEmail.getSubject());
    assertEquals(
        com.merck.nextconnect.utils.common.Constants.EMAIL_SUCCESS_STATUS,
        capturedEmail.getStatus());
    assertEquals(
        com.merck.nextconnect.utils.common.Constants.EMAIL_CHAR_SET, capturedEmail.getCharset());
    assertEquals(
        com.merck.nextconnect.utils.common.Constants.EMAIL_CONTENT_TYPE,
        capturedEmail.getContentType());
    assertNotNull(capturedEmail.getEmailAttributes());
  }

  private SelfRegistrationDTO createSelfRegistrationDTO() {
    SelfRegistrationDTO dto = new SelfRegistrationDTO();
    dto.setEmail("test@example.com");
    dto.setFirstName("John");
    dto.setLastName("Doe");
    dto.setSerialNo("SN12345");
    dto.setCountryCode("US");
    dto.setIsdCode("1");
    dto.setPhone("5551234567");
    dto.setRoleOfInterest("USER");
    dto.setCaptchaResponse("captchaToken");
    return dto;
  }

  private Device createDevice() {
    Device device = new Device();
    device.setDeviceId(1L);
    device.setSerialno("SN12345");
    device.setDevicename("Test Device");
    device.setProductCatalogNo("CAT123");
    device.setStatus(true);
    device.setDeleted(false);
    device.setInstalledDate(Timestamp.from(Instant.now()));

    DeviceType deviceType = new DeviceType();
    deviceType.setDeviceType("Water Purifier");
    device.setDeviceType(deviceType);

    return device;
  }
}
