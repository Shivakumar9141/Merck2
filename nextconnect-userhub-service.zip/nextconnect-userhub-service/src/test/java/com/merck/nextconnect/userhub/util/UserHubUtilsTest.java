package com.merck.nextconnect.userhub.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class UserHubUtilsTest {

  @Test
  public void testValidatePattern() {
    String pattern = "^[a-zA-Z][a-zA-Z0-9 .-]{1,15}$";
    assertTrue(UserhubUtils.validatePattern(pattern, "admin"));
    assertTrue(UserhubUtils.validatePattern(pattern, "super admin"));
    assertTrue(UserhubUtils.validatePattern(pattern, "super-admin"));
    assertFalse(UserhubUtils.validatePattern(pattern, "1admin"));
    assertFalse(UserhubUtils.validatePattern(pattern, "super*admin"));
  }

  @Test
  public void testIsValidEmailAddress() {
    assertTrue(UserhubUtils.isValidEmailAddress("admin@sial.com"));
    assertFalse(UserhubUtils.isValidEmailAddress("admin"));
  }

  @Test
  public void testGetAuthProvider() {
    assertEquals(Constants.MERCK_AUTH, UserhubUtils.getAuthProvider(Constants.MERCK_DNAP));
    assertEquals(Constants.MERCK_AUTH, UserhubUtils.getAuthProvider(Constants.MERCK_DNNA));
    assertEquals(Constants.MERCK_AUTH, UserhubUtils.getAuthProvider(Constants.MERCK_GLOBAL));
    assertEquals(Constants.SIAL_AUTH, UserhubUtils.getAuthProvider(Constants.SIAL));
    assertEquals(Constants.NEXTCONNECT_AUTH, UserhubUtils.getAuthProvider(Constants.NEXTCONNECT));
  }
}
