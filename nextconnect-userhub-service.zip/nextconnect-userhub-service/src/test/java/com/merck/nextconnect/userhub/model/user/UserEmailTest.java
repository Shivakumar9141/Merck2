package com.merck.nextconnect.userhub.model.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserEmailTest {

  private UserEmail userEmail;

  @BeforeEach
  public void setUp() {
    userEmail = new UserEmail();
  }

  @Test
  public void testGetEmail_WhenNotSet_ShouldReturnNull() {
    assertNull(userEmail.getEmail());
  }

  @Test
  public void testSetAndGetEmail() {
    // Arrange
    String testEmail = "test@example.com";

    // Act
    userEmail.setEmail(testEmail);

    // Assert
    assertEquals(testEmail, userEmail.getEmail());
  }
}
