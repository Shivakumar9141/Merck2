package com.merck.nextconnect.userhub.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ErrorResponseTest {

  private ErrorResponse errorResponse;

  @BeforeEach
  public void setUp() {
    errorResponse = new ErrorResponse();
  }

  @Test
  public void testGetSetErrorMessage() {
    String errorMessage = "Test error message";
    errorResponse.setErrorMessage(errorMessage);
    assertEquals(errorMessage, errorResponse.getErrorMessage());
  }

  @Test
  public void testGetSetErrorCode() {
    String errorCode = "E123";
    errorResponse.setErrorCode(errorCode);
    assertEquals(errorCode, errorResponse.getErrorCode());
  }
}
