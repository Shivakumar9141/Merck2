package com.merck.nextconnect.userhub.repository.jpa;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.jpa.domain.Specification;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class UserSpecificationTest {

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @InjectMocks private UserSpecification userSpecification;

  private AuthenticatedUser authUser;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123L);
    jwtUser.setOrgId(1);
    jwtUser.setRole(Constants.SUPER_ADMIN);
    jwtUser.setRoleId(1L);
    this.authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
    }
  }

  @Test
  public void testSpecificationWithSearchCriteria() {
    // Arrange
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setSearchBy("test@example.com");

    List<OrgDto> orgInfoList = new ArrayList<>();

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      // Act
      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);

      // Assert
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithFilterCriteria() {
    // Arrange
    FetchCriteria fetchCriteria = new FetchCriteria();
    List<String> filterBy = new ArrayList<>();
    filterBy.add("status.ACTIVE");
    filterBy.add("role.ADMIN");
    filterBy.add("orgName.TestOrg");
    filterBy.add("orgId.2");
    filterBy.add("countryCode.US");
    fetchCriteria.setFilterBy(filterBy);

    List<OrgDto> orgInfoList = new ArrayList<>();

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      // Act
      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);

      // Assert
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithDistributorAdminRole() {
    // Arrange
    FetchCriteria fetchCriteria = new FetchCriteria();

    List<OrgDto> orgInfoList = new ArrayList<>();

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      // Act
      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);

      // Assert
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithFSSRole() {
    // Arrange
    FetchCriteria fetchCriteria = new FetchCriteria();

    List<OrgDto> orgInfoList = new ArrayList<>();

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      // Act
      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);

      // Assert
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithNullCriteria() {
    FetchCriteria fetchCriteria = new FetchCriteria();
    List<OrgDto> orgInfoList = new ArrayList<>();

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithEmptyFilterBy() {
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setFilterBy(new ArrayList<>());
    List<OrgDto> orgInfoList = new ArrayList<>();

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithICSSCoordinatorRole() {
    FetchCriteria fetchCriteria = new FetchCriteria();
    List<OrgDto> orgInfoList = new ArrayList<>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123L);
    jwtUser.setOrgId(1);
    jwtUser.setRole(Constants.SUPER_ADMIN);
    jwtUser.setRoleId(1L);
    List<String> authorities = new ArrayList<>();
    authorities.add(Constants.USER_MANAGEMENT_FOR_ICS_SERVICE_CORDINATOR_ROLE);
    AuthenticatedUser icsAuthUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(icsAuthUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithLWServiceAdminRole() {
    FetchCriteria fetchCriteria = new FetchCriteria();
    List<OrgDto> orgInfoList = new ArrayList<>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123L);
    jwtUser.setOrgId(1);
    jwtUser.setRole(Constants.LW_SERVICE_ADMIN);
    jwtUser.setRoleId(1L);
    AuthenticatedUser lwServiceAdminUser =
        new AuthenticatedUser(jwtUser, "password", new ArrayList<>());

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(lwServiceAdminUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);
      assertNotNull(result);
    }
  }

  @Test
  public void testSpecificationWithLWBusinessManagerRole() {
    FetchCriteria fetchCriteria = new FetchCriteria();
    List<OrgDto> orgInfoList = new ArrayList<>();
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123L);
    jwtUser.setOrgId(1);
    jwtUser.setRole(Constants.LW_BUSINESS_MANAGER);
    jwtUser.setRoleId(1L);
    AuthenticatedUser lwBusinessManagerUser =
        new AuthenticatedUser(jwtUser, "password", new ArrayList<>());

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(lwBusinessManagerUser);
      when(userOrgPrivileges.getOrgs(
              Mockito.eq(OrgPrivileges.manage_accounts), Mockito.isNull(), Mockito.isNull()))
          .thenReturn(orgInfoList);

      Specification<UserProfile> result = userSpecification.specification(fetchCriteria);
      assertNotNull(result);
    }
  }
}
