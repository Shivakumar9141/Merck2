package com.merck.nextconnect.userhub.validator.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

public class UserProfileValidatorImplTest {

  private UserProfileValidatorImpl validator;

  @BeforeEach
  public void setUp() {
    validator = new UserProfileValidatorImpl();
  }

  @Test
  public void validateUserProfile_shouldThrowException_whenStatusNotExpired() {
    // Arrange
    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("active");
    userProfile.setEmail("test@example.com");

    // Act & Assert
    CustomException exception =
        assertThrows(CustomException.class, () -> validator.validateUserProfile(userProfile));
    assertEquals(CustomErrorCodes.USER_STATUS_NOT_EXPIRED.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void validateUserProfile_shouldThrowException_whenNotAutoCreated() {
    // Arrange
    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("expired");
    userProfile.setAutoCreated(false);
    userProfile.setEmail("test@example.com");

    // Act & Assert
    CustomException exception =
        assertThrows(CustomException.class, () -> validator.validateUserProfile(userProfile));
    assertEquals(CustomErrorCodes.USER_NOT_AUTO_CREATED.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void validateUserProfile_shouldNotThrowException_whenValid() {
    // Arrange
    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("expired");
    userProfile.setAutoCreated(true);
    userProfile.setEmail("test@example.com");

    // Act & Assert
    try {
      validator.validateUserProfile(userProfile);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test
  public void userProfileImageValidator_shouldNotThrowException_whenImageIsNull() {
    // Act & Assert
    try {
      validator.UserProfileImageValidator(null);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test
  public void userProfileImageValidator_shouldThrowException_whenInvalidExtension() {
    // Arrange
    MultipartFile invalidImage =
        new MockMultipartFile("image.gif", "image.gif", "image/gif", "test".getBytes());

    // Act & Assert
    DataValidationException exception = null;
    try {
      validator.UserProfileImageValidator(invalidImage);
      fail("Expected DataValidationException was not thrown");
    } catch (DataValidationException e) {
      exception = e;
    }

    assertNotNull(exception, "Exception should not be null");
    // Check for the actual validation message format
    assertTrue(
        exception.getMessage().contains("[jpeg, jpg, png]"),
        "Exception message should contain validation details");
  }

  @Test
  public void userProfileImageValidator_shouldThrowException_whenFileTooLarge() {
    // Arrange
    byte[] largeContent = new byte[5 * 1024 * 1024]; // 5MB
    MultipartFile largeImage =
        new MockMultipartFile("image.jpg", "image.jpg", "image/jpeg", largeContent);

    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class, () -> validator.UserProfileImageValidator(largeImage));
    assertTrue(exception.getMessage().contains("4MB"));
  }

  @Test
  public void userProfileImageValidator_shouldNotThrowException_whenValidImage() {
    // Arrange
    byte[] validContent = new byte[1 * 1024 * 1024]; // 1MB
    MultipartFile validImage =
        new MockMultipartFile("image.jpg", "image.jpg", "image/jpeg", validContent);

    // Act & Assert
    try {
      validator.UserProfileImageValidator(validImage);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }
}
