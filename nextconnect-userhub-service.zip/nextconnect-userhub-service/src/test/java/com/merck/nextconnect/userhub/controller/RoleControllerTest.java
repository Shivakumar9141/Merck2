package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupAccess;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleInfo;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.resources.IRoles;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class RoleControllerTest {

  @InjectMocks RoleController roleController;

  @Mock IRoles iroles;

  @Mock RoleRepository roleRepo;

  Role role1;

  Role role2;

  Role role3;

  List<Role> roles = new ArrayList<>();

  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);

    roleRepo = mock(RoleRepository.class);
    // ReflectionTestUtils.setField(iroles,"roleRepo",roleRepo);
    role1 = new Role();
    role1.setRoleId(1L);
    role1.setName("role1");

    role2 = new Role();
    role1.setRoleId(2);
    role2.setName("role2");

    role3 = new Role();
    role1.setRoleId(3);
    role3.setName("role3");

    roles.add(role1);
    roles.add(role2);
    roles.add(role3);

    // Removed unnecessary stub: when(roleRepo.save(any(Role.class))).thenReturn(role1);
    // Removed unnecessary stub: when(roleRepo.findAll()).thenReturn(roles);
    //    when(roleRepo.findById(1L).get()).thenReturn(role1);
  }

  @Test
  public void testAddRole() throws DuplicateResourceException, DataValidationException {
    RoleInfo roleInfo = new RoleInfo();
    roleInfo.setName("role");
    long roleId = 123;
    when(iroles.add(roleInfo)).thenReturn(roleId);
    ResponseEntity<?> responseEntity = roleController.addRole(roleInfo);
    HttpHeaders headers = responseEntity.getHeaders();
    assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    assertEquals("/roles/" + roleId, headers.getLocation().toString());
  }

  @Test
  public void testGetRoles() throws ResourceNotFoundException {
    int orgId = 123;
    when(iroles.getAll(orgId)).thenReturn(roles);
    ResponseEntity<List<Role>> responseEntity = roleController.getRoles(orgId);
    List<Role> returnedRoles = responseEntity.getBody();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(roles.size(), returnedRoles.size());
  }

  @Test
  public void testDeleteRole() throws DataValidationException {
    long roleId = 123;
    ResponseEntity<String> responseEntity = roleController.deleteRole(roleId);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
    verify(iroles).delete(roleId);
  }

  @Test
  public void testGetRole() {
    long roleId = 123;
    when(iroles.fetchOne(roleId)).thenReturn(role1);
    ResponseEntity<Role> responseEntity = roleController.getRole(roleId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(role1, responseEntity.getBody());
    verify(iroles).fetchOne(roleId);
  }

  @Test
  public void testGetRoleNotFound() {
    long roleId = 123;
    when(iroles.fetchOne(roleId)).thenReturn(null);
    ResponseEntity<Role> responseEntity = roleController.getRole(roleId);
    assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    verify(iroles).fetchOne(roleId);
  }

  @Test
  public void testGetPrivileges()
      throws InterruptedException,
          ExecutionException,
          ResourceNotFoundException,
          java.util.concurrent.ExecutionException {
    long roleId = 123;
    String filterBy = "filter";
    List<RolePrivilege> privileges = new ArrayList<>();
    when(iroles.getPrivileges(roleId, filterBy)).thenReturn(privileges);
    ResponseEntity<List<RolePrivilege>> responseEntity =
        roleController.getPrivileges(roleId, filterBy);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(privileges, responseEntity.getBody());
    verify(iroles).getPrivileges(roleId, filterBy);
  }

  @Test
  public void testAddPrivileges() {
    long roleId = 123;
    List<ResourcePrivilege> resourcePrivilege = new ArrayList<>();
    ResponseEntity<?> responseEntity = roleController.addPrivileges(roleId, resourcePrivilege);
    assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    verify(iroles).addPrivileges(roleId, resourcePrivilege);
  }

  @Test
  public void testDeletePrivileges() {
    long roleId = 123; // Role ID
    List<ResourcePrivilege> resourcePrivilege = new ArrayList<>(); // List of privileges to delete
    ResponseEntity<?> responseEntity = roleController.deletePrivileges(roleId, resourcePrivilege);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
    verify(iroles).deletePrivileges(roleId, resourcePrivilege);
  }

  @Test
  public void testGetDeviceGroupPrivileges() throws ResourceNotFoundException {
    long roleId = 123;
    long deviceType = 456;
    DeviceGroupPrivilege deviceGroupPrivilege = new DeviceGroupPrivilege();
    when(iroles.getDeviceGroupPrivileges(roleId, deviceType)).thenReturn(deviceGroupPrivilege);
    ResponseEntity<DeviceGroupPrivilege> responseEntity =
        roleController.getDeviceGroupPrivileges(roleId, deviceType);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(deviceGroupPrivilege, responseEntity.getBody());
    verify(iroles).getDeviceGroupPrivileges(roleId, deviceType);
  }

  @Test
  public void testAddDeviceGroupPrivileges() {
    long roleId = 123;
    List<DeviceGroupAccess> deviceGroupAccessList = new ArrayList<>();
    DeviceGroupAccess deviceGroupAccess1 = new DeviceGroupAccess();
    deviceGroupAccess1.setDeviceGroupId(1);
    deviceGroupAccessList.add(deviceGroupAccess1);
    ResponseEntity<?> responseEntity =
        roleController.addDeviceGroupPrivileges(roleId, deviceGroupAccessList);
    assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    verify(iroles).addDeviceGroupPrivileges(roleId, deviceGroupAccessList);
  }

  @Test
  public void testDeleteDeviceGroupPrivileges() {
    long roleId = 123;
    List<DeviceGroupAccess> deviceGroupAccessList = new ArrayList<>();
    DeviceGroupAccess deviceGroupAccess1 = new DeviceGroupAccess();
    deviceGroupAccessList.add(deviceGroupAccess1);
    ResponseEntity<?> responseEntity =
        roleController.deleteDeviceGroupPrivileges(roleId, deviceGroupAccessList);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
    verify(iroles).deleteDeviceGroupPrivileges(roleId, deviceGroupAccessList);
  }

  @Test
  public void testUpdateRole()
      throws DataValidationException, DuplicateResourceException, ResourceNotFoundException {
    long roleId = 123;
    RoleInfo roleInfo = new RoleInfo();
    ResponseEntity<?> responseEntity = roleController.updateRole(roleId, roleInfo);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iroles).update(roleInfo, roleId);
  }

  @Test
  public void testGetPrivilegesOnlyRoleId()
      throws ResourceNotFoundException,
          InterruptedException,
          java.util.concurrent.ExecutionException {
    long roleId = 123; // Role ID
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();
    when(iroles.getPrivileges(roleId)).thenReturn(expectedPrivileges);
    ResponseEntity<List<RolePrivilege>> responseEntity = roleController.getPrivileges(roleId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedPrivileges, responseEntity.getBody());
    verify(iroles).getPrivileges(roleId);
  }
}
