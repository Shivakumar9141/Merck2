package com.merck.nextconnect.userhub.model.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ResetCredentialTest {

  private ResetCredential resetCredential;

  @BeforeEach
  public void setUp() {
    resetCredential = new ResetCredential();
  }

  @Test
  public void testCurrentPassword() {
    String password = "currentPass123";
    resetCredential.setCurrentPassword(password);
    assertEquals(password, resetCredential.getCurrentPassword());
  }

  @Test
  public void testNewPassword() {
    String password = "newPass456";
    resetCredential.setNewPassword(password);
    assertEquals(password, resetCredential.getNewPassword());
  }

  @Test
  public void testConfirmPassword() {
    String password = "confirmPass789";
    resetCredential.setConfirmPassword(password);
    assertEquals(password, resetCredential.getConfirmPassword());
  }
}
