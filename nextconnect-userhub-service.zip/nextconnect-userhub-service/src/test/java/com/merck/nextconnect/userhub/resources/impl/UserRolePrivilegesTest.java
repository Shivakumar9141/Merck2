package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.entities.AuthUser;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.DeviceTypeOperation;
import com.merck.nextconnect.authfilter.repository.jpa.MeasureEventGroupsPrivilegeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.RolesOrgPrivilegeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.UserTerritoryRepository;
import com.merck.nextconnect.authfilter.resources.IprivilegeBuilder;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.DeviceType;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.RoleDeviceTypePrivilege;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.mail.MailTemplate;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleDeviceGroup;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.repository.jpa.CardRepository;
import com.merck.nextconnect.userhub.repository.jpa.CustomerRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceLocationRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceTypeRepository;
import com.merck.nextconnect.userhub.repository.jpa.EntityRepository;
import com.merck.nextconnect.userhub.repository.jpa.PrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleCardPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleDeviceGroupPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleDeviceTypePrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleEntityPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDeviceAssignmentTrackRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.resources.RoleServiceImpl;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.SmsServiceValidation;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserRolePrivilegesTest {

  @Mock private RoleEntityPrivilegesRepository roleEntityPrivilegesRepo;

  @Mock private PrivilegeRepository privilegeRepo;

  @InjectMocks private UserRolePrivileges userRolePrivileges;

  @Mock DeviceTypeRepository deviceTypeRepo;

  @Mock RoleDeviceTypePrivilegesRepository roleDeviceTypePrivilegesRepo;

  @Mock IprivilegeBuilder privilegeBuilder;

  @Mock RoleDeviceGroupPrivilegesRepository roleDeviceGroupPrivilegesRepo;

  @Mock private AuthenticatedUser authUser;

  private Authentication authentication;

  @Autowired private RoleServiceImpl roleServiceImpl;

  @Mock IprivilegeProvider privilegeProvider;

  @Mock EntityRepository entityRepo;

  @Mock CardRepository cardRepo;

  @Mock UserOrgPrivileges userOrgPrivileges;

  @Mock RoleRepository roleRepo;

  @Mock RoleCardPrivilegesRepository roleCardPrivilegesRepo;

  @Mock CustomerRepository customerRepo;

  @Mock DeviceLocationRepository deviceLocationRepo;

  @Mock UserDevicePrivilegeRepository userDevicePrivilegeRepo;

  @Mock DeviceRepository deviceRepo;

  @Mock MeasureEventGroupsPrivilegeRepository measureEventGroupPrivilegeRepo;

  @Mock RolesOrgPrivilegeRepository rolesOrgPrivilegeRepository;

  @Mock private CountryRepository countryRepo;

  @Mock UserTerritoryRepository userTerritoryRepo;

  @Mock private RoleDeviceTypePrivilegesRepository roleDeviceTypePrivilegesRepository;

  @Mock private UserDeviceAssignmentTrackRepository userDeviceAssignmentTrackRepository;

  @Mock private MailTemplate mailTemplate;

  @Mock private SmsServiceValidation smsService;

  @BeforeEach
  void setUp() {
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
  }

  @Test
  void testGetDeviceGroupPrivileges_RoleResource() {
    long roleId = 1L;
    long deviceTypeId = 1L;
    String resource = Constants.ROLE;

    RoleDeviceGroup roleDeviceGroup1 = new RoleDeviceGroup();
    roleDeviceGroup1.setLocationId(1L);
    roleDeviceGroup1.setLocationName("Location 1");
    roleDeviceGroup1.setDeviceGruopId(1L);
    roleDeviceGroup1.setDeviceGroupName("Group 1");
    RoleDeviceGroup roleDeviceGroup2 = new RoleDeviceGroup();
    roleDeviceGroup2.setLocationId(1L);
    roleDeviceGroup2.setLocationName("Location 1");
    roleDeviceGroup2.setDeviceGruopId(2L);
    roleDeviceGroup2.setDeviceGroupName("Group 2");
    List<RoleDeviceGroup> roleDeviceGroupList = Arrays.asList(roleDeviceGroup1, roleDeviceGroup2);
    when(roleDeviceGroupPrivilegesRepo.getPrivileges(roleId, deviceTypeId))
        .thenReturn(roleDeviceGroupList);

    Privilege privilege = new Privilege();
    privilege.setResourceType(Constants.DEVICEGROUP);
    privilege.setprivilegeId(1L);
    when(privilegeRepo.getByFilter(Constants.DEVICEGROUP)).thenReturn(Arrays.asList(privilege));

    DeviceGroupPrivilege result =
        userRolePrivileges.getDeviceGroupPrivileges(roleId, deviceTypeId, resource);

    assertNotNull(result);
    assertEquals(1L, result.getPrivilegeId());
    assertNotNull(result.getLocations());
    assertEquals(1, result.getLocations().size());
    assertEquals(1L, result.getLocations().get(0).getId());
    assertEquals("Location 1", result.getLocations().get(0).getName());
    assertNotNull(result.getLocations().get(0).getDeviceGroups());
    assertEquals(2, result.getLocations().get(0).getDeviceGroups().size());
    assertEquals(1L, result.getLocations().get(0).getDeviceGroups().get(0).getId());
    assertEquals("Group 1", result.getLocations().get(0).getDeviceGroups().get(0).getName());
    assertEquals(2L, result.getLocations().get(0).getDeviceGroups().get(1).getId());
    assertEquals("Group 2", result.getLocations().get(0).getDeviceGroups().get(1).getName());
  }

  @Test
  void testGetDeviceTypePrivilegesWithValidInput() {
    long id = 1L;
    String resource = Constants.ROLE;
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();
    expectedPrivileges.add(new RolePrivilege(1L, "test", 1L, "Test"));
    when(roleDeviceTypePrivilegesRepo.getPrivileges(id)).thenReturn(expectedPrivileges);

    List<RolePrivilege> actualPrivileges = userRolePrivileges.getDeviceTypePrivileges(id, resource);
    assertNotNull(actualPrivileges);
    assertEquals(expectedPrivileges, actualPrivileges);
  }

  @Test
  void testGetEntityPrivilegesWithValidInput() {
    long id = 1L;
    String resource = Constants.ROLE;
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();
    expectedPrivileges.add(new RolePrivilege(1L, "test", 1L, "Test"));
    when(roleEntityPrivilegesRepo.getPrivileges(id)).thenReturn(expectedPrivileges);

    List<RolePrivilege> actualPrivileges = userRolePrivileges.getEntityPrivileges(id, resource);
    assertNotNull(actualPrivileges);
    assertEquals(expectedPrivileges, actualPrivileges);
  }

  @Test
  void testGetEntityPrivilegeList() {
    long id = 1L;
    List<String> expectedPrivileges = new ArrayList<>();
    expectedPrivileges.add("privilege1");
    expectedPrivileges.add("privilege2");

    when(privilegeProvider.getEntityPrivileges(id)).thenReturn(expectedPrivileges);

    List<String> actualPrivileges = userRolePrivileges.getEntityPrivilegeList(id);
    assertEquals(expectedPrivileges, actualPrivileges);
  }

  @Test
  void testGetDeviceGroupPrivilegeList() {
    long id = 1L;
    List<Long> expectedPrivileges = new ArrayList<>();
    expectedPrivileges.add(123L);
    expectedPrivileges.add(456L);

    when(privilegeProvider.getDeviceGroupPrivileges(id)).thenReturn(expectedPrivileges);

    List<Long> actualPrivileges = userRolePrivileges.getDeviceGroupPrivilegeList(id);

    assertEquals(expectedPrivileges, actualPrivileges);
  }

  @Test
  void testGetDeviceTypePrivilegeMap() {
    long id = 1L;
    Map<Long, Map<DeviceTypeOperation, List<String>>> expectedPrivileges = new HashMap<>();
    Map<DeviceTypeOperation, List<String>> operationMap = new HashMap<>();
    List<String> operationPrivileges = new ArrayList<>();
    operationPrivileges.add("privilege1");
    operationPrivileges.add("privilege2");
    operationMap.put(DeviceTypeOperation.read, operationPrivileges);
    expectedPrivileges.put(id, operationMap);
    when(privilegeProvider.getDeviceTypePrivileges(id)).thenReturn(expectedPrivileges);

    Map<Long, Map<DeviceTypeOperation, List<String>>> actualPrivileges =
        userRolePrivileges.getDeviceTypePrivilegeMap(id);

    assertEquals(expectedPrivileges, actualPrivileges);
  }

  @Test
  void testGetUserDevicePrivileges() {
    long userId = 1L;
    List<Privileges> expectedPrivileges = new ArrayList<>();
    when(userDevicePrivilegeRepo.getPrivileges(userId)).thenReturn(expectedPrivileges);

    List<Privileges> actualPrivileges = userRolePrivileges.getUserDevicePrivileges(userId);
    assertEquals(expectedPrivileges, actualPrivileges);
    verify(userDevicePrivilegeRepo).getPrivileges(userId);
  }

  @Test
  void testGetCardPrivileges() {
    long id = 1L;
    List<RolePrivilege> expectedPrivileges = new ArrayList<>();
    when(roleCardPrivilegesRepo.getPrivileges(id)).thenReturn(expectedPrivileges);

    List<RolePrivilege> privileges = userRolePrivileges.getCardPrivileges(id);

    assertEquals(expectedPrivileges, privileges);
  }

  @Test
  void testDeleteMeasureEventGroupsByRoleId() {
    long roleId = 1L;

    userRolePrivileges.deleteMeasureEventGroupsByRoleId(roleId);

    verify(measureEventGroupPrivilegeRepo).deleteGroupMappingsByRoleId(roleId);
  }

  @Test
  void testDeleteOrgPrivilegesByRoleId() {
    long roleId = 1L;

    userRolePrivileges.deleteOrgPrivilegesByRoleId(roleId);

    verify(rolesOrgPrivilegeRepository).deleteByRoleId(roleId);
  }

  @Test
  void testAddTerritories() {
    long userId = 1L;
    ResourcePrivilege resprivilage = new ResourcePrivilege();
    resprivilage.setResourceid(1);
    resprivilage.setPrivilegeid(1);
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
    resourcePrivileges.add(resprivilage);

    when(userTerritoryRepo.getUserTerritories(userId)).thenReturn(Arrays.asList(2));
    when(countryRepo.findById(1)).thenReturn(new Country(1, "countryCode", "countryName"));

    userRolePrivileges.addTerritories(userId, resourcePrivileges);

    verify(userTerritoryRepo).getUserTerritories(1);
  }

  @Test
  void testRemoveTerritories() {
    long userId = 1L;
    ResourcePrivilege resprivilage = new ResourcePrivilege();
    resprivilage.setResourceid(1);
    resprivilage.setPrivilegeid(1);
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
    resourcePrivileges.add(resprivilage);

    Country country = new Country(1, "countryCode", "countryName");
    when(countryRepo.findById(1)).thenReturn(country);
    when(userTerritoryRepo.deleteByUserAndCountry(any(AuthUser.class), any(Country.class)))
        .thenReturn(1L);

    userRolePrivileges.removeTerritories(userId, resourcePrivileges);

    verify(userTerritoryRepo, times(resourcePrivileges.size()))
        .deleteByUserAndCountry(any(AuthUser.class), any(Country.class));
  }

  @Test
  void testGetUserTerritories() {
    long userId = 1L;
    List<Integer> territories = new ArrayList<>();
    territories.add(1);
    territories.add(2);
    when(userTerritoryRepo.getUserTerritories(userId)).thenReturn(territories);

    List<Privileges> result = userRolePrivileges.getUserTerritories(userId);

    assertNotNull(result);
  }

  @Test
  void testRemoveAllTerritories() {
    long userId = 1L;
    userRolePrivileges.removeAllTerritories(userId);
    verify(userTerritoryRepo, times(1)).deleteByUser(any(AuthUser.class));
  }

  @Test
  void testRemoveTerritories_RemovesTerritorySuccessfully() {
    long userId = 1L;
    ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
    resourcePrivilege.setResourceid(10L);
    List<ResourcePrivilege> resourcePrivileges = Arrays.asList(resourcePrivilege);

    Country country = new Country();
    when(countryRepo.findById((int) resourcePrivilege.getResourceid())).thenReturn(country);

    userRolePrivileges.removeTerritories(userId, resourcePrivileges);

    verify(countryRepo).findById((int) resourcePrivilege.getResourceid());
    verify(userTerritoryRepo).deleteByUserAndCountry(any(AuthUser.class), eq(country));
  }

  @Test
  void testGetUserTerritories_ReturnsPrivileges() {
    long userId = 1L;
    List<Integer> territories = Arrays.asList(100, 200);
    when(userTerritoryRepo.getUserTerritories(userId)).thenReturn(territories);

    List<Privileges> result = userRolePrivileges.getUserTerritories(userId);

    assertNotNull(result);
    assertEquals(2, result.size());
    assertEquals(100, result.get(0).getResourceId());
    assertEquals(200, result.get(1).getResourceId());
  }

  @Test
  void testRemoveAllTerritories_DeletesAll() {
    long userId = 1L;
    userRolePrivileges.removeAllTerritories(userId);
    verify(userTerritoryRepo).deleteByUser(any(AuthUser.class));
  }

  @Test
  void testAutoAddUserDevicePrivileges_AssignsPrivilegesAndSendsMailAndSms() {
    UserProfile user = new UserProfile();
    user.setUserId(1L);
    Organization org = new Organization(1);
    user.setOrg(org);
    Role role = new Role();
    role.setRoleId(2);
    user.setRole(role);

    Privilege privilege = new Privilege(1, "resource", Constants.ASSIGN_DEVICE);
    DeviceType deviceType = new DeviceType();
    deviceType.setDeviceTypeId(3);
    Device device = new Device();
    device.setDeviceType(deviceType);
    device.setUuid("uuid");
    device.setDeviceId(5L);

    ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
    resourcePrivilege.setPrivilegeid(1L);
    resourcePrivilege.setResourceid(5L);
    List<ResourcePrivilege> resourcePrivileges = Arrays.asList(resourcePrivilege);

    when(privilegeRepo.findById(1L)).thenReturn(Optional.of(privilege));
    when(deviceRepo.findById(5L)).thenReturn(Optional.of(device));
    RoleDeviceTypePrivilege rdtp = new RoleDeviceTypePrivilege();
    when(roleDeviceTypePrivilegesRepository.findByDeviceTypeIdAndRoleId(3, 2))
        .thenReturn(Arrays.asList(rdtp));
    when(userDeviceAssignmentTrackRepository
            .findByUserAndDeviceAndAssignedTimestampNotNullAndUnassignedTimestampNull(user, device))
        .thenReturn(null);
    when(userDeviceAssignmentTrackRepository.findByUser(user)).thenReturn(new ArrayList<>());

    AuthenticatedUser authUser = mock(AuthenticatedUser.class);
    when(authUser.getId()).thenReturn("99");

    try (var mocked = Mockito.mockStatic(UserhubUtils.class)) {
      mocked.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      userRolePrivileges.autoAddUserDevicePrivileges(user, resourcePrivileges);

      verify(userDevicePrivilegeRepo).saveAll(anyList());
      verify(userOrgPrivileges).addDevicesToOrg(eq(org.getId()), anyList());
      verify(userDeviceAssignmentTrackRepository).saveAll(anyList());
    }
  }

  @Test
  void testValidateFirstAccountCreationOrNot_ReturnsZeroWhenNoAssignments() throws Exception {
    UserProfile user = new UserProfile();
    when(userDeviceAssignmentTrackRepository.findByUser(user)).thenReturn(new ArrayList<>());
    java.lang.reflect.Method method =
        UserRolePrivileges.class.getDeclaredMethod(
            "validateFirstAccountCreationOrNot", UserProfile.class);
    method.setAccessible(true);
    int result = (int) method.invoke(userRolePrivileges, user);
    assertEquals(0, result);
  }
}
