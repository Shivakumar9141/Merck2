package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RoleDeviceGroupPrivilegeTest {

  private RoleDeviceGroupPrivilege privilege;

  @BeforeEach
  public void setUp() {
    privilege = new RoleDeviceGroupPrivilege();
  }

  @Test
  public void testGettersAndSetters() {
    // Test ID
    privilege.setId(1L);
    assertEquals(1L, privilege.getId());

    // Test Role
    Role role = new Role();
    privilege.setRole(role);
    assertEquals(role, privilege.getRole());

    // Test Privilege
    Privilege priv = new Privilege();
    privilege.setPrivilege(priv);
    assertEquals(priv, privilege.getPrivilege());

    // Test Customer
    Customer customer = new Customer();
    privilege.setCustomer(customer);
    assertEquals(customer, privilege.getCustomer());

    // Test DeviceLocation
    DeviceLocation location = new DeviceLocation();
    privilege.setDeviceLocation(location);
    assertEquals(location, privilege.getDeviceLocation());

    // Test DeviceTypeId
    privilege.setDeviceTypeId(2L);
    assertEquals(2L, privilege.getDeviceTypeId());
  }

  @Test
  public void testDefaultConstructor() {
    assertNull(privilege.getRole());
    assertNull(privilege.getPrivilege());
    assertNull(privilege.getCustomer());
    assertNull(privilege.getDeviceLocation());
  }
}
