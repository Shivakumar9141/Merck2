package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@ExtendWith(MockitoExtension.class)
public class UserProfileRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private UserProfileRepositoryJdbc userProfileRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    // MockitoExtension initializes mocks
  }

  @Test
  public void testGetUserOrgDetails_Success() throws CustomException {
    // Arrange
    List<Long> userIdList = Arrays.asList(1L, 2L);
    List<UserDataDTO> expectedUserData = new ArrayList<>();
    expectedUserData.add(
        UserDataDTO.builder().userId(1L).orgId(100L).userOrgCreatedVia("API").build());
    expectedUserData.add(
        UserDataDTO.builder().userId(2L).orgId(200L).userOrgCreatedVia("UI").build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedUserData);

    // Act
    List<UserDataDTO> result = userProfileRepositoryJdbc.getUserOrgDetails(userIdList);

    // Assert
    assertEquals(2, result.size());
    assertEquals(Long.valueOf(1L), result.get(0).getUserId());
    assertEquals(Long.valueOf(100L), result.get(0).getOrgId());
    assertEquals("API", result.get(0).getUserOrgCreatedVia());
    assertEquals(Long.valueOf(2L), result.get(1).getUserId());
    assertEquals(Long.valueOf(200L), result.get(1).getOrgId());
    assertEquals("UI", result.get(1).getUserOrgCreatedVia());

    verify(namedParameterJdbcTemplate)
        .query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class));
  }

  @Test
  public void testGetUserOrgDetails_EmptyList() throws CustomException {
    // Arrange
    List<Long> emptyUserIdList = new ArrayList<>();

    // Act
    List<UserDataDTO> result = userProfileRepositoryJdbc.getUserOrgDetails(emptyUserIdList);

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testGetUserOrgDetails_ExceptionHandling() {
    // Arrange
    List<Long> userIdList = Arrays.asList(1L, 2L);
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act & Assert
    assertThrows(
        CustomException.class, () -> userProfileRepositoryJdbc.getUserOrgDetails(userIdList));
  }

  @Test
  public void testGetUserOrgDetails_ReturnsCorrectData() throws CustomException {
    List<Long> userIdList = Arrays.asList(10L, 20L);
    List<UserDataDTO> mockResult =
        Arrays.asList(
            UserDataDTO.builder().userId(10L).orgId(101L).userOrgCreatedVia("PORTAL").build(),
            UserDataDTO.builder().userId(20L).orgId(202L).userOrgCreatedVia("API").build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockResult);

    List<UserDataDTO> result = userProfileRepositoryJdbc.getUserOrgDetails(userIdList);

    assertEquals(2, result.size());
    assertEquals(Long.valueOf(10L), result.get(0).getUserId());
    assertEquals(Long.valueOf(101L), result.get(0).getOrgId());
    assertEquals("PORTAL", result.get(0).getUserOrgCreatedVia());
    assertEquals(Long.valueOf(20L), result.get(1).getUserId());
    assertEquals(Long.valueOf(202L), result.get(1).getOrgId());
    assertEquals("API", result.get(1).getUserOrgCreatedVia());
  }

  @Test
  public void testGetUserOrgDetails_WithEmptyUserIdList_ReturnsEmptyList() throws CustomException {
    List<Long> userIdList = new ArrayList<>();
    List<UserDataDTO> result = userProfileRepositoryJdbc.getUserOrgDetails(userIdList);
    assertEquals(0, result.size());
  }

  @Test
  public void testGetUserOrgDetails_WhenJdbcThrowsException_ThrowsCustomException() {
    List<Long> userIdList = Arrays.asList(1L, 2L);
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenThrow(new RuntimeException("DB error"));

    assertThrows(
        CustomException.class, () -> userProfileRepositoryJdbc.getUserOrgDetails(userIdList));
  }
}
