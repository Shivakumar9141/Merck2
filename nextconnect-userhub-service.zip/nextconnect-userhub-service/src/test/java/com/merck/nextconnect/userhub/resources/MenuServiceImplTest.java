package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.MenuGroupRequest;
import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuInfoDTO;
import com.merck.nextconnect.userhub.model.MenuManagementRequest;
import com.merck.nextconnect.userhub.model.MenuManagementResponse;
import com.merck.nextconnect.userhub.model.MenuUpdate;
import com.merck.nextconnect.userhub.model.MenuUpdateRequest;
import com.merck.nextconnect.userhub.model.MenuUpdateRequestDTO;
import com.merck.nextconnect.userhub.repo.jdbc.MenuManagementRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserMenuRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.impl.MenuServiceImpl;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

public class MenuServiceImplTest {

  @Mock private MenuManagementRepositoryJdbc menuJdbc;

  @Mock private UserMenuRepository userMenuRepository;

  @Mock private UserRepository userRepository;

  @InjectMocks private MenuServiceImpl menuService;
  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    userMenuRepository = mock(UserMenuRepository.class);
    ReflectionTestUtils.setField(menuService, "userMenuRepository", userMenuRepository);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
    //  mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
  }

  @Test
  public void testGetMenuGroups() {
    MenuGroupRequest request = new MenuGroupRequest();
    request.setRoleId(123);
    when(menuJdbc.getMenuGroup(any(), anyString())).thenReturn(Collections.emptyList());
    List<MenuGroupResponse> result = menuService.getMenuGroups(request);
    assertNotNull(result);
    assertEquals(0, result.size());
  }

  @Test
  public void testGetMenuInfo() throws CustomException {
    MenuManagementRequest request = new MenuManagementRequest();
    request.setUserId(123);
    request.setRoleId(456);
    request.setMenuGroupName("Group1");
    MenuInfoDTO dto = new MenuInfoDTO();
    dto.setMenuId(1);
    dto.setMenuKey("test");
    List<MenuInfoDTO> menuInfoList = new ArrayList<MenuInfoDTO>();
    menuInfoList.add(dto);
    List<Integer> menuIdList = new ArrayList<Integer>();
    menuIdList.add(2);

    // Mock authUser for hideSCMButtonForCustOfDistributors method
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(authUser.getRole()).thenReturn("SYSTEM_ADMIN");

    when(userMenuRepository.getDifferMenuId(
            request.getRoleId(), request.getUserId(), request.getMenuGroupName()))
        .thenReturn(menuIdList);
    when(userMenuRepository.getCountFromUserMenu(anyLong(), anyString())).thenReturn(0L);
    when(menuJdbc.getUserMenuCount(any(), anyString())).thenReturn(1);
    when(menuJdbc.getMenuInfo(any(), anyString())).thenReturn(menuInfoList);
    List<MenuManagementResponse> result = menuService.getMenuInfo(request);
    assertNotNull(result);
  }

  @Test
  public void testGetInsertQuery()
      throws NoSuchMethodException,
          SecurityException,
          IllegalAccessException,
          IllegalArgumentException,
          InvocationTargetException {
    Method method = MenuServiceImpl.class.getDeclaredMethod("getInsertQuery");
    method.setAccessible(true);
    StringBuilder result = (StringBuilder) method.invoke(menuService);
    assertNotNull(result);
  }

  @Test
  public void testUpdateUserMenu() throws CustomException {
    MenuUpdateRequest menuUpdateRequest = new MenuUpdateRequest();
    MenuUpdate menuUpdate = new MenuUpdate();
    menuUpdate.setMenuId(1);
    menuUpdate.setSequence(1);
    menuUpdate.setVisible(true);
    List<MenuUpdate> menus = new ArrayList<MenuUpdate>();
    menus.add(menuUpdate);
    menuUpdateRequest.setMenus(menus);
    MenuUpdateRequestDTO request = new MenuUpdateRequestDTO();
    request.setMenuUpdateRequest(menuUpdateRequest);
    doNothing().when(menuJdbc).batchUpdate(anyList(), anyString());
    // when(menuService.getUserMenu(anyString(), anyLong(), anyLong())).thenReturn(new
    // MenuManagementResponse());

    List<MenuManagementResponse> response = menuService.updateUserMenu(request);

    assertNotNull(response);
  }

  @Test
  public void testGetUserMenuInsertQuery()
      throws NoSuchMethodException,
          SecurityException,
          IllegalAccessException,
          IllegalArgumentException,
          InvocationTargetException {
    Method method = MenuServiceImpl.class.getDeclaredMethod("getUserMenuInsertQuery", String.class);
    method.setAccessible(true);
    StringBuilder result = (StringBuilder) method.invoke(menuService, "test");
    assertNotNull(result);
  }
}
