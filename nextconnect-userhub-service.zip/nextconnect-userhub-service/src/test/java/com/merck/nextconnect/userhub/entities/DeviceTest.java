package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DeviceTest {

  private Device device;
  private DeviceType deviceType;
  private static final String DEVICE_NAME = "TestDevice";
  private static final String SERIAL_NO = "SN12345";
  private static final String SECURITY_KEY = "SK98765";

  @BeforeEach
  public void setUp() {
    device = new Device();
    deviceType = new DeviceType();
    deviceType.setDeviceTypeId(1);
    deviceType.setDeviceType("TestType");
  }

  @Test
  public void testDefaultConstructor() {
    assertNotNull(device);
    assertFalse(device.isStatus());
    assertFalse(device.isDeleted());
  }

  @Test
  public void testParameterizedConstructor() {
    device = new Device(DEVICE_NAME, SERIAL_NO, SECURITY_KEY);

    assertEquals(DEVICE_NAME, device.getDevicename());
    assertEquals(SERIAL_NO, device.getSerialno());
    assertEquals(SECURITY_KEY, device.getSecuritykey());
  }

  @Test
  public void testGettersAndSetters() {
    // Set values
    long deviceId = 123L;
    boolean connectivity = true;
    boolean status = true;
    String uuid = "test-uuid";
    Timestamp installedDate = new Timestamp(System.currentTimeMillis());
    Timestamp shippedDate = new Timestamp(System.currentTimeMillis());
    boolean isDealer = true;
    String emailId = "test@example.com";
    String productCatalogNo = "CAT123";
    boolean deleted = true;
    String soldTo = "Customer1";
    String billTo = "Customer2";
    String smFirstName = "John";
    String smLastName = "Doe";
    String smDeviceId = "SM123";

    // Apply values
    device.setDeviceId(deviceId);
    device.setConnectivity(connectivity);
    device.setStatus(status);
    device.setUuid(uuid);
    device.setDevicename(DEVICE_NAME);
    device.setSerialno(SERIAL_NO);
    device.setSecuritykey(SECURITY_KEY);
    device.setDeviceType(deviceType);
    device.setInstalledDate(installedDate);
    device.setShippedDate(shippedDate);
    device.setDealer(isDealer);
    device.setEmailId(emailId);
    device.setProductCatalogNo(productCatalogNo);
    device.setDeleted(deleted);
    device.setSoldTo(soldTo);
    device.setBillTo(billTo);
    device.setSmFirstName(smFirstName);
    device.setSmLastName(smLastName);
    device.setSmDeviceId(smDeviceId);

    // Verify values
    assertEquals(deviceId, device.getDeviceId());
    assertEquals(connectivity, device.getConnectivity());
    assertEquals(status, device.isStatus());
    assertEquals(uuid, device.getUuid());
    assertEquals(DEVICE_NAME, device.getDevicename());
    assertEquals(SERIAL_NO, device.getSerialno());
    assertEquals(SECURITY_KEY, device.getSecuritykey());
    assertEquals(deviceType, device.getDeviceType());
    assertEquals(installedDate, device.getInstalledDate());
    assertEquals(shippedDate, device.getShippedDate());
    assertTrue(device.isDealer());
    assertEquals(emailId, device.getEmailId());
    assertEquals(productCatalogNo, device.getProductCatalogNo());
    assertTrue(device.isDeleted());
    assertEquals(soldTo, device.getSoldTo());
    assertEquals(billTo, device.getBillTo());
    assertEquals(smFirstName, device.getSmFirstName());
    assertEquals(smLastName, device.getSmLastName());
    assertEquals(smDeviceId, device.getSmDeviceId());
  }
}
