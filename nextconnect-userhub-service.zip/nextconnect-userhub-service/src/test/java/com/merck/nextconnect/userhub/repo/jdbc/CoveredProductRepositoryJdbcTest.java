package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.CoveredProductDTO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class CoveredProductRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetSmCoveredProductId_Success() {
    // Arrange
    Long deviceId = 123L;
    List<CoveredProductDTO> expectedProducts = new ArrayList<>();
    expectedProducts.add(CoveredProductDTO.builder().smCoveredProductId("CP001").build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedProducts);

    // Act
    List<CoveredProductDTO> result = coveredProductRepositoryJdbc.getSmCoveredProductId(deviceId);

    // Assert
    assertEquals(1, result.size());
    assertEquals("CP001", result.get(0).getSmCoveredProductId());
  }

  @Test
  public void testGetSmCoveredProductId_NullDeviceId() {
    // Act
    List<CoveredProductDTO> result = coveredProductRepositoryJdbc.getSmCoveredProductId(null);

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testGetSmCoveredProductId_ExceptionHandling() {
    // Arrange
    Long deviceId = 123L;
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    List<CoveredProductDTO> result = coveredProductRepositoryJdbc.getSmCoveredProductId(deviceId);

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testGetcoveredDevicesUnderSmServiceContract_Success() {
    // Arrange
    String smServiceContractId = "SC001";
    List<Long> expectedDeviceIds = Arrays.asList(101L, 102L);

    when(namedParameterJdbcTemplate.queryForList(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedDeviceIds);

    // Act
    List<Long> result =
        coveredProductRepositoryJdbc.getcoveredDevicesUnderSmServiceContract(smServiceContractId);

    // Assert
    assertEquals(2, result.size());
    assertEquals(Long.valueOf(101L), result.get(0));
    assertEquals(Long.valueOf(102L), result.get(1));
  }

  @Test
  public void testGetcoveredDevicesUnderSmServiceContract_BlankContractId() {
    // Act
    List<Long> result = coveredProductRepositoryJdbc.getcoveredDevicesUnderSmServiceContract("");

    // Assert
    assertEquals(0, result.size());
  }

  @Test
  public void testGetcoveredDevicesUnderSmServiceContract_ExceptionHandling() {
    // Arrange
    String smServiceContractId = "SC001";
    when(namedParameterJdbcTemplate.queryForList(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    List<Long> result =
        coveredProductRepositoryJdbc.getcoveredDevicesUnderSmServiceContract(smServiceContractId);

    // Assert
    assertEquals(0, result.size());
  }
}
