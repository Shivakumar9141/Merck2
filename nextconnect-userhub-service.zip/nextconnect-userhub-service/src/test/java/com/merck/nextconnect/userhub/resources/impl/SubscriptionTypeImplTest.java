package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.SubscriptionType;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.repo.jdbc.SubscriptionCategoriesRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.SubscriptionTypeRepository;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.util.Constants;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

public class SubscriptionTypeImplTest {

  @Mock private SubscriptionTypeRepository subscriptionTypeRepository;

  @Mock private SubscriptionCategoriesRepositoryJdbc subscriptionCategoriesRepositoryJdbc;

  @Mock private RoleRepository roleRepo;

  @Mock private IUser iuser;

  @Mock private SecurityContext securityContext;

  @Mock private Authentication authentication;

  @InjectMocks private SubscriptionTypeImpl subscriptionTypeImpl;

  private AuthenticatedUser authUser;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    // Setup security context with proper JwtUser
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123);
    jwtUser.setRoleId(1L);
    jwtUser.setUsername("testUser");

    authUser = new AuthenticatedUser(jwtUser, "password", new ArrayList<>());

    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(authUser);
    SecurityContextHolder.setContext(securityContext);

    // Set values for properties using ReflectionTestUtils
    ReflectionTestUtils.setField(subscriptionTypeImpl, "numberOfDaysAdvance", 7);
    ReflectionTestUtils.setField(subscriptionTypeImpl, "numberOfDaysAdvanceForFssSubscription", 14);
  }

  @Test
  public void testGetAllSubscription_CustomerRole() throws Exception {
    // Arrange
    Role role = new Role();
    role.setRoleId(1L);
    role.setName("Customer Role");

    when(roleRepo.findById(1L)).thenReturn(Optional.of(role));
    when(iuser.fetchUserType(123)).thenReturn(Constants.INDIRECT_CUSTOMER);

    // Create test data
    List<SubscriptionType> subscriptionTypes = createTestSubscriptionTypes();
    when(subscriptionCategoriesRepositoryJdbc.getSubscriptionCategoriesMapping(
            role.getName(), Constants.DISTRIBUTOR))
        .thenReturn(subscriptionTypes);

    // Act
    List<SubscriptionTypeDTO> result = subscriptionTypeImpl.getAllSubscription();

    // Assert
    assertNotNull(result);
    verify(roleRepo).findById(1L);
    verify(iuser).fetchUserType(123);
    verify(subscriptionCategoriesRepositoryJdbc)
        .getSubscriptionCategoriesMapping(role.getName(), Constants.DISTRIBUTOR);
  }

  @Test
  public void testGetAllSubscription_FssRole() throws Exception {
    // Arrange
    Role role = new Role();
    role.setRoleId(1L);
    role.setName("FSS Role");

    when(roleRepo.findById(1L)).thenReturn(Optional.of(role));
    when(iuser.fetchUserType(123)).thenReturn(Constants.DIRECT_CUSTOMER);

    // Create test data
    List<SubscriptionType> subscriptionTypes = createTestSubscriptionTypes();
    when(subscriptionCategoriesRepositoryJdbc.getSubscriptionCategoriesMapping(
            role.getName(), Constants.BUSINESS_UNIT))
        .thenReturn(subscriptionTypes);

    // Act
    List<SubscriptionTypeDTO> result = subscriptionTypeImpl.getAllSubscription();

    // Assert
    assertNotNull(result);
    verify(roleRepo).findById(1L);
    verify(iuser).fetchUserType(123);
    verify(subscriptionCategoriesRepositoryJdbc)
        .getSubscriptionCategoriesMapping(role.getName(), Constants.BUSINESS_UNIT);
  }

  private List<SubscriptionType> createTestSubscriptionTypes() {
    List<SubscriptionType> subscriptionTypes = new ArrayList<>();

    SubscriptionType type = new SubscriptionType();
    type.setSubscriptionTypeId(1L);
    type.setSubscriptionTypeName("Test Subscription Type");

    Set<SubscriptionCategory> categories = new HashSet<>();
    SubscriptionCategory category = new SubscriptionCategory();
    category.setSubscriptionCategoryId(1L);
    category.setCategoryName("Product Availability");
    categories.add(category);

    type.setSubscriptionCategories(categories);
    subscriptionTypes.add(type);

    return subscriptionTypes;
  }
}
