package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.UserAvgRatingCount;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingsDTO;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

public class UserFeedBackRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;

  private List<String> rolesList;
  private List<UserDataDTO> mockUserData;
  private List<UserFeedBackRatingsDTO> mockRatings;
  private UserAvgRatingCount mockAvgRating;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);

    // Setup test data
    rolesList = Arrays.asList("Admin", "SuperAdmin");
    ReflectionTestUtils.setField(userFeedBackRepositoryJdbc, "rolesList", rolesList);

    // Mock user data
    mockUserData = new ArrayList<>();
    UserDataDTO userData =
        UserDataDTO.builder()
            .userId(1L)
            .firstName("John")
            .lastName("Doe")
            .customerOrgName("Test Org")
            .language("English")
            .feedback("Great service")
            .rating(5)
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .build();
    mockUserData.add(userData);

    // Mock ratings
    mockRatings = new ArrayList<>();
    UserFeedBackRatingsDTO rating = UserFeedBackRatingsDTO.builder().ratings(5).count(10).build();
    mockRatings.add(rating);

    // Mock average rating
    mockAvgRating = UserAvgRatingCount.builder().rating(4.5f).userRatingCount(20L).build();
  }

  @Test
  public void testGetAllFeedBacks() {
    // Arrange
    String userId = "123";
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockUserData);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllFeedBacks(userId);

    // Assert
    assertNotNull(result);
    assertEquals(mockUserData.size(), result.size());
    assertEquals(mockUserData.get(0).getUserId(), result.get(0).getUserId());
    verify(namedParameterJdbcTemplate)
        .query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class));
  }

  @Test
  public void testGetAllUsersFeedBacks() {
    // Arrange
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockUserData);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUsersFeedBacks();

    // Assert
    assertNotNull(result);
    assertEquals(mockUserData.size(), result.size());
    verify(namedParameterJdbcTemplate)
        .query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class));
  }

  @Test
  public void testGetAllRatings() {
    // Arrange
    Long userId = 123L;
    String filteredQuery = " AND feedback.created_date > '2023-01-01'";
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockRatings);

    // Act
    List<UserFeedBackRatingsDTO> result =
        userFeedBackRepositoryJdbc.getAllRatings(userId, filteredQuery);

    // Assert
    assertNotNull(result);
    assertEquals(mockRatings.size(), result.size());
    assertEquals(mockRatings.get(0).getRatings(), result.get(0).getRatings());
    verify(namedParameterJdbcTemplate)
        .query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class));
  }

  @Test
  public void testGetUserTerritories() {
    // Arrange
    String userId = "123";
    List<String> territories = Arrays.asList("US", "UK", "DE");
    when(namedParameterJdbcTemplate.queryForList(
            anyString(), any(MapSqlParameterSource.class), eq(String.class)))
        .thenReturn(territories);

    // Act
    List<String> result = userFeedBackRepositoryJdbc.getUserTerritories(userId);

    // Assert
    assertNotNull(result);
    assertEquals(territories.size(), result.size());
    assertEquals(territories.get(0), result.get(0));
    verify(namedParameterJdbcTemplate)
        .queryForList(anyString(), any(MapSqlParameterSource.class), eq(String.class));
  }

  @Test
  public void testGetUserFeedBackCountForFSE() {
    // Arrange
    String userId = "123";
    List<String> fseRolesList = Arrays.asList("FSE", "SeniorFSE");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    Long expectedCount = 15L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result =
        userFeedBackRepositoryJdbc.getUserFeedBackCountForFSE(
            userId, fseRolesList, startDate, endDate);

    // Assert
    assertEquals(expectedCount, result);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), any(MapSqlParameterSource.class), eq(Long.class));
  }

  @Test
  public void testGetUserFeedBackAvgRatingForFSE() {
    // Arrange
    String userId = "123";
    List<String> fseRolesList = Arrays.asList("FSE", "SeniorFSE");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockAvgRating);

    // Act
    UserAvgRatingCount result =
        userFeedBackRepositoryJdbc.getUserFeedBackAvgRatingForFSE(
            userId, fseRolesList, startDate, endDate);

    // Assert
    assertNotNull(result);
    assertEquals(mockAvgRating.getRating(), result.getRating(), 0.001);
    assertEquals(mockAvgRating.getUserRatingCount(), result.getUserRatingCount());
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class));
  }

  @Test
  public void testGetAllFeedBacksWithFilters() {
    // Arrange
    String userId = "123";
    String filteredQuery = " AND feedback.created_date > '2023-01-01'";
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockUserData);

    // Act
    List<UserDataDTO> result =
        userFeedBackRepositoryJdbc.getAllFeedBacksWithFilters(userId, filteredQuery);

    // Assert
    assertNotNull(result);
    assertEquals(mockUserData.size(), result.size());
    verify(namedParameterJdbcTemplate)
        .query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class));
  }

  @Test
  public void testGetTotalUsers() {
    // Arrange
    List<String> rolesList = Arrays.asList("Admin", "SuperAdmin");
    String filteredQuery = " AND feedback.created_date > '2023-01-01'";
    Long expectedCount = 100L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result = userFeedBackRepositoryJdbc.getTotalUsers(rolesList, filteredQuery);

    // Assert
    assertEquals(expectedCount, result);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), any(MapSqlParameterSource.class), eq(Long.class));
  }

  @Test
  public void testGetAllUsersFeedBacksWithFilters() {
    // Arrange
    String filteredQuery = " AND feedback.rating > 3";
    List<String> mockRolesList = Arrays.asList("ADMIN", "MANAGER");

    // Set up the rolesList field using reflection
    ReflectionTestUtils.setField(userFeedBackRepositoryJdbc, "rolesList", mockRolesList);

    // Mock data
    List<UserDataDTO> expectedResults = new ArrayList<>();
    expectedResults.add(
        UserDataDTO.builder()
            .firstName("John")
            .userId(123L)
            .lastName("Doe")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Test Org")
            .language("English")
            .feedback("Great service")
            .rating(4)
            .build());

    // Mock the JDBC template response
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedResults);

    // Act
    List<UserDataDTO> result =
        userFeedBackRepositoryJdbc.getAllUsersFeedBacksWithFilters(filteredQuery);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("John", result.get(0).getFirstName());
    assertEquals("Doe", result.get(0).getLastName());
    assertEquals(Long.valueOf(123), result.get(0).getUserId());
    assertEquals("Test Org", result.get(0).getCustomerOrgName());
    assertEquals("English", result.get(0).getLanguage());
    assertEquals("Great service", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(4), result.get(0).getRating());

    // Verify SQL parameter was set correctly
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(mockRolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsersFeedBacksForDistributorAdminWithFilters() {
    // Arrange
    List<String> roles = Arrays.asList("DISTRIBUTOR_ADMIN", "DISTRIBUTOR_USER");
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);
    String filteredQuery = " AND feedback.rating > 3";

    List<UserDataDTO> expectedResults = new ArrayList<>();
    expectedResults.add(
        UserDataDTO.builder()
            .firstName("John")
            .userId(123L)
            .lastName("Doe")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Test Org")
            .language("English")
            .feedback("Great service")
            .rating(4)
            .build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedResults);

    // Act
    List<UserDataDTO> result =
        userFeedBackRepositoryJdbc.getAllUsersFeedBacksForDistributorAdminWithFilters(
            roles, accessibleOrgs, filteredQuery);

    // Assert
    assertEquals(1, result.size());
    assertEquals("John", result.get(0).getFirstName());
    assertEquals("Doe", result.get(0).getLastName());
    assertEquals(Long.valueOf(123L), result.get(0).getUserId());
    assertEquals("Test Org", result.get(0).getCustomerOrgName());
    assertEquals("English", result.get(0).getLanguage());
    assertEquals("Great service", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(4), result.get(0).getRating());

    // Verify SQL parameter values
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetAllFeedBacksForDistributorFSEWithFilters() {
    // Arrange
    String userId = "123";
    List<String> roles = Arrays.asList("FSE", "Distributor");
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);
    String filteredQuery = " AND feedback.rating > 3";

    List<UserDataDTO> expectedResults = new ArrayList<>();
    expectedResults.add(
        UserDataDTO.builder()
            .firstName("John")
            .userId(123L)
            .lastName("Doe")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Test Org")
            .language("English")
            .feedback("Great service")
            .rating(4)
            .build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedResults);

    // Act
    List<UserDataDTO> result =
        userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSEWithFilters(
            userId, roles, accessibleOrgs, filteredQuery);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("John", result.get(0).getFirstName());
    assertEquals("Doe", result.get(0).getLastName());
    assertEquals(Long.valueOf(123), result.get(0).getUserId());
    assertEquals("Test Org", result.get(0).getCustomerOrgName());
    assertEquals("English", result.get(0).getLanguage());
    assertEquals("Great service", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(4), result.get(0).getRating());

    // Verify SQL parameter values
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));

    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetAllUsersFeedBackAvgRating() {
    // Arrange
    List<String> roles = Arrays.asList("Role1", "Role2");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";

    UserAvgRatingCount expectedResult =
        UserAvgRatingCount.builder().rating(4.5f).userRatingCount(10L).build();

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedResult);

    // Act
    UserAvgRatingCount result =
        userFeedBackRepositoryJdbc.getAllUsersFeedBackAvgRating(roles, startDate, endDate);

    // Assert
    assertNotNull(result);
    assertEquals(4.5f, result.getRating(), 0.001);
    assertEquals(Long.valueOf(10L), result.getUserRatingCount());

    // Verify parameter values
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), any(RowMapper.class));

    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(startDate, capturedParams.getValue("startDate"));
    assertEquals(endDate, capturedParams.getValue("endDate"));
  }

  @Test
  public void testGetUserFeedBackAvgRatingForDistributorFSE() {
    // Arrange
    String userId = "123";
    List<String> roles = Arrays.asList("DISTRIBUTOR_FSE");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);

    UserAvgRatingCount expectedResult =
        UserAvgRatingCount.builder().rating(4.5f).userRatingCount(10L).build();

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedResult);

    // Act
    UserAvgRatingCount result =
        userFeedBackRepositoryJdbc.getUserFeedBackAvgRatingForDistributorFSE(
            userId, roles, startDate, endDate, accessibleOrgs);

    // Assert
    assertNotNull(result);
    assertEquals(4.5f, result.getRating(), 0.001);
    assertEquals(Long.valueOf(10L), result.getUserRatingCount());

    // Verify parameter values
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), any(RowMapper.class));

    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(startDate, capturedParams.getValue("startDate"));
    assertEquals(endDate, capturedParams.getValue("endDate"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetUserFeedBackAvgRatingForDistributorAdmin() {
    // Arrange
    List<String> distAdminRolesList = Arrays.asList("DistributorAdmin", "DistributorManager");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);

    UserAvgRatingCount expectedResult =
        UserAvgRatingCount.builder().rating(4.5f).userRatingCount(10L).build();

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedResult);

    // Act
    UserAvgRatingCount result =
        userFeedBackRepositoryJdbc.getUserFeedBackAvgRatingForDistributorAdmin(
            distAdminRolesList, startDate, endDate, accessibleOrgs);

    // Assert
    assertNotNull(result);
    assertEquals(expectedResult.getRating(), result.getRating(), 0.001);
    assertEquals(expectedResult.getUserRatingCount(), result.getUserRatingCount());

    // Verify SQL parameters
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), any(RowMapper.class));

    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(distAdminRolesList, capturedParams.getValue("roles"));
    assertEquals(startDate, capturedParams.getValue("startDate"));
    assertEquals(endDate, capturedParams.getValue("endDate"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetUserFeedBackCountForDistributorFSE_Success() {
    // Arrange
    String userId = "123";
    List<String> roles = Arrays.asList("ROLE1", "ROLE2");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);
    Long expectedCount = 5L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result =
        userFeedBackRepositoryJdbc.getUserFeedBackCountForDistributorFSE(
            userId, roles, startDate, endDate, accessibleOrgs);

    // Assert
    assertEquals(expectedCount, result);
  }

  @Test
  public void testGetUserFeedBackCountForDistributorFSE_NoResults() {
    // Arrange
    String userId = "123";
    List<String> roles = Arrays.asList("ROLE1", "ROLE2");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);
    Long expectedCount = 0L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result =
        userFeedBackRepositoryJdbc.getUserFeedBackCountForDistributorFSE(
            userId, roles, startDate, endDate, accessibleOrgs);

    // Assert
    assertEquals(expectedCount, result);
  }

  @Test
  public void testGetUserFeedBackCountForDistributorAdmin() {
    // Arrange
    List<String> distAdminRolesList = Arrays.asList("DISTRIBUTOR_ADMIN", "DISTRIBUTOR_USER");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    List<Integer> accessibleOrgs = Arrays.asList(1, 2, 3);

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(5L);

    // Act
    Long result =
        userFeedBackRepositoryJdbc.getUserFeedBackCountForDistributorAdmin(
            distAdminRolesList, startDate, endDate, accessibleOrgs);

    // Assert
    assertEquals(Long.valueOf(5), result);

    // Verify parameter values
    ArgumentCaptor<MapSqlParameterSource> paramsCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramsCaptor.capture(), eq(Long.class));

    MapSqlParameterSource capturedParams = paramsCaptor.getValue();
    assertEquals(distAdminRolesList, capturedParams.getValue("roles"));
    assertEquals(startDate, capturedParams.getValue("startDate"));
    assertEquals(endDate, capturedParams.getValue("endDate"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetAllFeedBacks_ReturnsExpectedResults() {
    // Arrange
    String userId = "123";
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Alice")
            .userId(123L)
            .lastName("Smith")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org1")
            .language("EN")
            .feedback("Excellent")
            .rating(5)
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllFeedBacks(userId);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Alice", result.get(0).getFirstName());
    assertEquals("Smith", result.get(0).getLastName());
    assertEquals(Long.valueOf(123L), result.get(0).getUserId());
    assertEquals("Org1", result.get(0).getCustomerOrgName());
    assertEquals("EN", result.get(0).getLanguage());
    assertEquals("Excellent", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(5), result.get(0).getRating());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllFeedBacks_EmptyResult() {
    // Arrange
    String userId = "456";
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(new ArrayList<>());

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllFeedBacks(userId);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());
    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsersFeedBacks_ReturnsExpectedResults() {
    // Arrange
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Alice")
            .userId(123L)
            .lastName("Smith")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org1")
            .language("EN")
            .feedback("Excellent")
            .rating(5)
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUsersFeedBacks();

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Alice", result.get(0).getFirstName());
    assertEquals("Smith", result.get(0).getLastName());
    assertEquals(Long.valueOf(123L), result.get(0).getUserId());
    assertEquals("Org1", result.get(0).getCustomerOrgName());
    assertEquals("EN", result.get(0).getLanguage());
    assertEquals("Excellent", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(5), result.get(0).getRating());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsersFeedBacks_EmptyResult() {
    // Arrange
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(new ArrayList<>());

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUsersFeedBacks();

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUserFSE_ReturnsExpectedResults() {
    // Arrange
    String userId = "123";
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Jane")
            .userId(456L)
            .lastName("Doe")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org2")
            .countryCode("DE")
            .language("DE")
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUserFSE(userId);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Jane", result.get(0).getFirstName());
    assertEquals("Doe", result.get(0).getLastName());
    assertEquals(Long.valueOf(456L), result.get(0).getUserId());
    assertEquals("Org2", result.get(0).getCustomerOrgName());
    assertEquals("DE", result.get(0).getCountryCode());
    assertEquals("DE", result.get(0).getLanguage());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsers_ReturnsExpected_Results() {
    // Arrange
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Bob")
            .userId(789L)
            .lastName("Marley")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org3")
            .countryCode("US")
            .language("EN")
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUsers();

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Bob", result.get(0).getFirstName());
    assertEquals("Marley", result.get(0).getLastName());
    assertEquals(Long.valueOf(789L), result.get(0).getUserId());
    assertEquals("Org3", result.get(0).getCustomerOrgName());
    assertEquals("US", result.get(0).getCountryCode());
    assertEquals("EN", result.get(0).getLanguage());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllRatingsForDistributorFSE_ReturnsExpectedResults() {
    // Arrange
    Long userId = 123L;
    List<Integer> accessibleOrgs = Arrays.asList(1, 2);
    List<String> roleList = Arrays.asList("FSE");
    String filteredQuery = " AND feedback.rating > 3";
    List<UserFeedBackRatingsDTO> expected =
        Arrays.asList(UserFeedBackRatingsDTO.builder().ratings(5).count(2).build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expected);

    // Act
    List<UserFeedBackRatingsDTO> result =
        userFeedBackRepositoryJdbc.getAllRatingsForDistributorFSE(
            userId, accessibleOrgs, roleList, filteredQuery);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(Integer.valueOf(5), result.get(0).getRatings());
    assertEquals(Integer.valueOf(2), result.get(0).getCount());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(roleList, capturedParams.getValue("roleList"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetAllFeedBacksForDistributorFSE_ReturnsExpectedResults() {
    // Arrange
    String userId = "123";
    List<String> roles = Arrays.asList("FSE");
    List<Integer> accessibleOrgs = Arrays.asList(1, 2);
    List<UserDataDTO> expected =
        Arrays.asList(
            UserDataDTO.builder()
                .firstName("Sam")
                .userId(321L)
                .lastName("Wilson")
                .createdDate(new Timestamp(System.currentTimeMillis()))
                .customerOrgName("Org4")
                .language("FR")
                .feedback("Good job")
                .rating(4)
                .build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expected);

    // Act
    List<UserDataDTO> result =
        userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSE(userId, roles, accessibleOrgs);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Sam", result.get(0).getFirstName());
    assertEquals("Wilson", result.get(0).getLastName());
    assertEquals(Long.valueOf(321L), result.get(0).getUserId());
    assertEquals("Org4", result.get(0).getCustomerOrgName());
    assertEquals("FR", result.get(0).getLanguage());
    assertEquals("Good job", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(4), result.get(0).getRating());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetAllUsersRatingsForDistributorAdmin_ReturnsExpectedResults() {
    // Arrange
    Long userId = 123L;
    List<Integer> accessibleOrgs = Arrays.asList(1, 2);
    List<String> roleList = Arrays.asList("ADMIN");
    String filteredQuery = " AND feedback.rating > 3";
    List<UserFeedBackRatingsDTO> expected =
        Arrays.asList(UserFeedBackRatingsDTO.builder().ratings(4).count(3).build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expected);

    // Act
    List<UserFeedBackRatingsDTO> result =
        userFeedBackRepositoryJdbc.getAllUsersRatingsForDistributorAdmin(
            userId, accessibleOrgs, roleList, filteredQuery);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(Integer.valueOf(4), result.get(0).getRatings());
    assertEquals(Integer.valueOf(3), result.get(0).getCount());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(roleList, capturedParams.getValue("roles"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetAllUsersFeedBacksForDistributorAdmin_ReturnsExpectedResults() {
    // Arrange
    List<String> roles = Arrays.asList("ADMIN");
    List<Integer> accessibleOrgs = Arrays.asList(1, 2);
    List<UserDataDTO> expected =
        Arrays.asList(
            UserDataDTO.builder()
                .firstName("Anna")
                .userId(654L)
                .lastName("Taylor")
                .createdDate(new Timestamp(System.currentTimeMillis()))
                .customerOrgName("Org5")
                .language("IT")
                .feedback("Nice support")
                .rating(5)
                .build());

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expected);

    // Act
    List<UserDataDTO> result =
        userFeedBackRepositoryJdbc.getAllUsersFeedBacksForDistributorAdmin(roles, accessibleOrgs);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Anna", result.get(0).getFirstName());
    assertEquals("Taylor", result.get(0).getLastName());
    assertEquals(Long.valueOf(654L), result.get(0).getUserId());
    assertEquals("Org5", result.get(0).getCustomerOrgName());
    assertEquals("IT", result.get(0).getLanguage());
    assertEquals("Nice support", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(5), result.get(0).getRating());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetTotalFSEUsers_ReturnsExpectedResults() {
    // Arrange
    Long userId = 123L;
    List<String> rolesList = Arrays.asList("FSE");
    String filteredQuery = " AND profile.created_on > '2023-01-01'";
    Long expectedCount = 7L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result = userFeedBackRepositoryJdbc.getTotalFSEUsers(userId, rolesList, filteredQuery);

    // Assert
    assertEquals(expectedCount, result);

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), eq(Long.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("rolesList"));
  }

  @Test
  public void testGetTotalDistributorFSEUsers_ReturnsExpectedResults() {
    // Arrange
    Long userId = 123L;
    List<String> rolesList = Arrays.asList("FSE");
    List<Integer> accessibleOrgs = Arrays.asList(1, 2);
    String filteredQuery = " AND profile.created_on > '2023-01-01'";
    Long expectedCount = 3L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result =
        userFeedBackRepositoryJdbc.getTotalDistributorFSEUsers(
            userId, rolesList, accessibleOrgs, filteredQuery);

    // Assert
    assertEquals(expectedCount, result);

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), eq(Long.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("rolesList"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetTotalUsersDistributorAdmin_ReturnsExpectedResults() {
    // Arrange
    List<String> rolesList = Arrays.asList("ADMIN");
    List<Integer> accessibleOrgs = Arrays.asList(1, 2);
    String filteredQuery = " AND profile.created_on > '2023-01-01'";
    Long expectedCount = 8L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result =
        userFeedBackRepositoryJdbc.getTotalUsersDistributorAdmin(
            rolesList, accessibleOrgs, filteredQuery);

    // Assert
    assertEquals(expectedCount, result);

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), eq(Long.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("rolesList"));
    assertEquals(accessibleOrgs, capturedParams.getValue("accessibleOrgs"));
  }

  @Test
  public void testGetTotalUsers_ReturnsExpectedResults() {
    // Arrange
    List<String> rolesList = Arrays.asList("ADMIN");
    String filteredQuery = " AND profile.created_on > '2023-01-01'";
    Long expectedCount = 12L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result = userFeedBackRepositoryJdbc.getTotalUsers(rolesList, filteredQuery);

    // Assert
    assertEquals(expectedCount, result);

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), eq(Long.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("rolesList"));
  }

  @Test
  public void testGetAllUserFSE_ReturnsExpected_Results() {
    // Arrange
    String userId = "123";
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Bob")
            .userId(456L)
            .lastName("Brown")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org2")
            .countryCode("US")
            .language("EN")
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUserFSE(userId);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Bob", result.get(0).getFirstName());
    assertEquals("Brown", result.get(0).getLastName());
    assertEquals(Long.valueOf(456L), result.get(0).getUserId());
    assertEquals("Org2", result.get(0).getCustomerOrgName());
    assertEquals("US", result.get(0).getCountryCode());
    assertEquals("EN", result.get(0).getLanguage());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUserFSE_EmptyResult() {
    // Arrange
    String userId = "789";
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(new ArrayList<>());

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUserFSE(userId);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsers_ReturnsExpectedResults() {
    // Arrange
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Carol")
            .userId(789L)
            .lastName("White")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org3")
            .countryCode("DE")
            .language("DE")
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUsers();

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Carol", result.get(0).getFirstName());
    assertEquals("White", result.get(0).getLastName());
    assertEquals(Long.valueOf(789L), result.get(0).getUserId());
    assertEquals("Org3", result.get(0).getCustomerOrgName());
    assertEquals("DE", result.get(0).getCountryCode());
    assertEquals("DE", result.get(0).getLanguage());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsers_EmptyResult() {
    // Arrange
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(new ArrayList<>());

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllUsers();

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllFeedBacks_ReturnsExpectedList() {
    // Arrange
    String userId = "789";
    List<UserDataDTO> expectedList = new ArrayList<>();
    UserDataDTO dto =
        UserDataDTO.builder()
            .firstName("Jane")
            .userId(789L)
            .lastName("Doe")
            .createdDate(new Timestamp(System.currentTimeMillis()))
            .customerOrgName("Org2")
            .language("FR")
            .feedback("Very good")
            .rating(4)
            .build();
    expectedList.add(dto);

    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllFeedBacks(userId);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("Jane", result.get(0).getFirstName());
    assertEquals("Doe", result.get(0).getLastName());
    assertEquals(Long.valueOf(789L), result.get(0).getUserId());
    assertEquals("Org2", result.get(0).getCustomerOrgName());
    assertEquals("FR", result.get(0).getLanguage());
    assertEquals("Very good", result.get(0).getFeedback());
    assertEquals(Integer.valueOf(4), result.get(0).getRating());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllFeedBacks_ReturnsEmptyList() {
    // Arrange
    String userId = "999";
    when(namedParameterJdbcTemplate.query(
            anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(new ArrayList<>());

    // Act
    List<UserDataDTO> result = userFeedBackRepositoryJdbc.getAllFeedBacks(userId);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .query(anyString(), paramCaptor.capture(), any(RowMapper.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(userId, capturedParams.getValue("userId"));
    assertEquals(rolesList, capturedParams.getValue("roles"));
  }

  @Test
  public void testGetAllUsersFeedBackCount_ReturnsExpectedCount() {
    // Arrange
    List<String> roles = Arrays.asList("FSE", "ADMIN");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    Long expectedCount = 42L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result = userFeedBackRepositoryJdbc.getAllUsersFeedBackCount(roles, startDate, endDate);

    // Assert
    assertNotNull(result);
    assertEquals(expectedCount, result);

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), eq(Long.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(startDate, capturedParams.getValue("startDate"));
    assertEquals(endDate, capturedParams.getValue("endDate"));
  }

  @Test
  public void testGetAllUsersFeedBackCount_ReturnsZeroWhenNoResults() {
    // Arrange
    List<String> roles = Arrays.asList("FSE", "ADMIN");
    String startDate = "2023-01-01";
    String endDate = "2023-12-31";
    Long expectedCount = 0L;

    when(namedParameterJdbcTemplate.queryForObject(
            anyString(), any(MapSqlParameterSource.class), eq(Long.class)))
        .thenReturn(expectedCount);

    // Act
    Long result = userFeedBackRepositoryJdbc.getAllUsersFeedBackCount(roles, startDate, endDate);

    // Assert
    assertNotNull(result);
    assertEquals(expectedCount, result);

    ArgumentCaptor<MapSqlParameterSource> paramCaptor =
        ArgumentCaptor.forClass(MapSqlParameterSource.class);
    verify(namedParameterJdbcTemplate)
        .queryForObject(anyString(), paramCaptor.capture(), eq(Long.class));
    MapSqlParameterSource capturedParams = paramCaptor.getValue();
    assertEquals(roles, capturedParams.getValue("roles"));
    assertEquals(startDate, capturedParams.getValue("startDate"));
    assertEquals(endDate, capturedParams.getValue("endDate"));
  }
}
