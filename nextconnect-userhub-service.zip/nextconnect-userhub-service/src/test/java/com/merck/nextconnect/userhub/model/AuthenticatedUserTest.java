package com.merck.nextconnect.userhub.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collection;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class AuthenticatedUserTest {

  private Long id;
  private String username;
  private String token;
  private Collection<GrantedAuthority> authorities;
  private AuthenticatedUser authenticatedUser;

  @BeforeEach
  public void setUp() {
    id = 123L;
    username = "testUser";
    token = "testToken";
    authorities = new ArrayList<>();
    authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

    authenticatedUser = new AuthenticatedUser(id, username, token, authorities);
  }

  @Test
  public void testGetId() {
    assertEquals(id, authenticatedUser.getId());
  }

  @Test
  public void testGetUsername() {
    assertEquals(username, authenticatedUser.getUsername());
  }

  @Test
  public void testGetToken() {
    assertEquals(token, authenticatedUser.getToken());
  }

  @Test
  public void testGetAuthorities() {
    assertEquals(authorities, authenticatedUser.getAuthorities());
  }

  @Test
  public void testGetPassword() {
    assertNull(authenticatedUser.getPassword());
  }

  @Test
  public void testIsAccountNonExpired() {
    assertTrue(authenticatedUser.isAccountNonExpired());
  }

  @Test
  public void testIsAccountNonLocked() {
    assertTrue(authenticatedUser.isAccountNonLocked());
  }

  @Test
  public void testIsCredentialsNonExpired() {
    assertTrue(authenticatedUser.isCredentialsNonExpired());
  }

  @Test
  public void testIsEnabled() {
    assertTrue(authenticatedUser.isEnabled());
  }
}
