package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.SubscriptionType;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class SubscriptionCategoriesRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private SubscriptionCategoriesRepositoryJdbc repository;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetSubscriptionCategoriesMapping() {
    // Arrange
    String roleName = "admin";
    String orgCreatedBy = "testOrg";

    // Mock the JDBC response
    when(namedParameterJdbcTemplate.query(
            eq(repository.SQL_SELECT_SUBSCRIPTION_CATEGORIES_MAPPING),
            any(MapSqlParameterSource.class),
            any(RowMapper.class)))
        .thenAnswer(
            invocation -> {
              // Simulate the row mapper execution with test data
              RowMapper<?> rowMapper = invocation.getArgument(2);
              java.sql.ResultSet rs = org.mockito.Mockito.mock(java.sql.ResultSet.class);
              org.mockito.Mockito.when(rs.getLong("type.subscription_type_id")).thenReturn(1L);
              org.mockito.Mockito.when(rs.getString("type.subscription_type_name"))
                  .thenReturn("Type1");
              org.mockito.Mockito.when(rs.getString("category"))
                  .thenReturn("Category1 - 101, Category2 - 102");

              return List.of(rowMapper.mapRow(rs, 0));
            });

    // Act
    List<SubscriptionType> result =
        repository.getSubscriptionCategoriesMapping(roleName, orgCreatedBy);

    // Assert
    assertEquals(1, result.size());
    SubscriptionType type = result.get(0);
    assertEquals((Long) 1L, type.getSubscriptionTypeId());
    assertEquals("Type1", type.getSubscriptionTypeName());

    Set<SubscriptionCategory> categories = type.getSubscriptionCategories();
    assertEquals(2, categories.size());

    boolean foundCategory1 = false;
    boolean foundCategory2 = false;

    for (SubscriptionCategory category : categories) {
      if (category.getCategoryName().equals("Category1")
          && category.getSubscriptionCategoryId() == 101L) {
        foundCategory1 = true;
      } else if (category.getCategoryName().equals("Category2")
          && category.getSubscriptionCategoryId() == 102L) {
        foundCategory2 = true;
      }
    }

    assertTrue(foundCategory1, "Category1 should be found");
    assertTrue(foundCategory2, "Category2 should be found");
  }

  @Test
  public void testGetSubscriptionCategoriesMappingWithEmptyCategory() {
    // Arrange
    String roleName = "admin";
    String orgCreatedBy = "testOrg";

    // Mock the JDBC response with empty category
    when(namedParameterJdbcTemplate.query(
            eq(repository.SQL_SELECT_SUBSCRIPTION_CATEGORIES_MAPPING),
            any(MapSqlParameterSource.class),
            any(RowMapper.class)))
        .thenAnswer(
            invocation -> {
              RowMapper<?> rowMapper = invocation.getArgument(2);
              java.sql.ResultSet rs = org.mockito.Mockito.mock(java.sql.ResultSet.class);
              org.mockito.Mockito.when(rs.getLong("type.subscription_type_id")).thenReturn(1L);
              org.mockito.Mockito.when(rs.getString("type.subscription_type_name"))
                  .thenReturn("Type1");
              org.mockito.Mockito.when(rs.getString("category")).thenReturn("");

              return List.of(rowMapper.mapRow(rs, 0));
            });

    // Act
    List<SubscriptionType> result =
        repository.getSubscriptionCategoriesMapping(roleName, orgCreatedBy);

    // Assert
    assertEquals(1, result.size());
    SubscriptionType type = result.get(0);
    assertEquals(Long.valueOf(1L), type.getSubscriptionTypeId());
    assertEquals("Type1", type.getSubscriptionTypeName());
    assertEquals(0, type.getSubscriptionCategories().size());
  }

  @Test
  public void testGetSubscriptionCategoriesMappingWithException() {
    // Arrange
    String roleName = "admin";
    String orgCreatedBy = "testOrg";

    // Mock the JDBC to throw exception
    when(namedParameterJdbcTemplate.query(
            eq(repository.SQL_SELECT_SUBSCRIPTION_CATEGORIES_MAPPING),
            any(MapSqlParameterSource.class),
            any(RowMapper.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    List<SubscriptionType> result =
        repository.getSubscriptionCategoriesMapping(roleName, orgCreatedBy);

    // Assert
    assertTrue(result.isEmpty());
  }
}
