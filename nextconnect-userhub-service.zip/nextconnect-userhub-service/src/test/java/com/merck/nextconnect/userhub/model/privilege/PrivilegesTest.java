package com.merck.nextconnect.userhub.model.privilege;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PrivilegesTest {

  private Privileges privileges;
  private long privilegeId;
  private String operation;
  private long resourceId;
  private String resourceType;

  @BeforeEach
  public void setUp() {
    privilegeId = 123L;
    operation = "READ";
    resourceId = 456L;
    resourceType = "USER";

    privileges = new Privileges(privilegeId, operation, resourceId, resourceType);
  }

  @Test
  public void testGetPrivilegeId() {
    assertEquals(privilegeId, privileges.getPrivilegeId());
  }

  @Test
  public void testSetPrivilegeId() {
    long newPrivilegeId = 789L;
    privileges.setPrivilegeId(newPrivilegeId);
    assertEquals(newPrivilegeId, privileges.getPrivilegeId());
  }

  @Test
  public void testGetResourceId() {
    assertEquals(resourceId, privileges.getResourceId());
  }

  @Test
  public void testSetResourceId() {
    long newResourceId = 789L;
    privileges.setResourceId(newResourceId);
    assertEquals(newResourceId, privileges.getResourceId());
  }

  @Test
  public void testGetResourceType() {
    assertEquals(resourceType, privileges.getResourceType());
  }

  @Test
  public void testSetResourceType() {
    String newResourceType = "ROLE";
    privileges.setResourceType(newResourceType);
    assertEquals(newResourceType, privileges.getResourceType());
  }

  @Test
  public void testGetOperation() {
    assertEquals(operation, privileges.getOperation());
  }

  @Test
  public void testSetOperation() {
    String newOperation = "WRITE";
    privileges.setOperation(newOperation);
    assertEquals(newOperation, privileges.getOperation());
  }

  @Test
  public void testDefaultConstructor() {
    Privileges emptyPrivileges = new Privileges();
    emptyPrivileges.setPrivilegeId(privilegeId);
    emptyPrivileges.setOperation(operation);
    emptyPrivileges.setResourceId(resourceId);
    emptyPrivileges.setResourceType(resourceType);

    assertEquals(privilegeId, emptyPrivileges.getPrivilegeId());
    assertEquals(operation, emptyPrivileges.getOperation());
    assertEquals(resourceId, emptyPrivileges.getResourceId());
    assertEquals(resourceType, emptyPrivileges.getResourceType());
  }
}
