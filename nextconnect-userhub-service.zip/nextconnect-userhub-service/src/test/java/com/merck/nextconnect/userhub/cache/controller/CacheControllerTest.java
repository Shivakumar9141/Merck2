package com.merck.nextconnect.userhub.cache.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.cache.service.CacheService;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class CacheControllerTest {

  @Mock private CacheService cacheService;

  @InjectMocks private CacheController cacheController;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetListOfMaps() {
    Map<String, String> maps = new HashMap<>();
    maps.put("map1", "value1");
    maps.put("map2", "value2");

    when(cacheService.getListOfMaps()).thenReturn(maps);

    ResponseEntity<Map<String, String>> response = cacheController.getListOfMaps();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(maps, response.getBody());
    verify(cacheService).getListOfMaps();
  }

  @Test
  public void testGetMapValues() throws JSONException {
    String mapName = "testMap";
    String resourceId = "123";
    String mapValues = "{\"key\":\"value\"}";

    when(cacheService.getMapValues(mapName, resourceId)).thenReturn(mapValues);

    ResponseEntity<String> response = cacheController.getMapValues(mapName, resourceId);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    JSONObject jsonResponse = new JSONObject(response.getBody());
    assertEquals(mapValues, jsonResponse.getString("result "));
    verify(cacheService).getMapValues(mapName, resourceId);
  }

  @Test
  public void testGetAllDistributedCacheValues() {
    Map<String, String> cacheValues = new HashMap<>();
    cacheValues.put("key1", "value1");
    cacheValues.put("key2", "value2");

    when(cacheService.getAllDistributedCacheValues()).thenReturn(cacheValues);

    ResponseEntity<Map<String, String>> response = cacheController.getAllDistributedCacheValues();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(cacheValues, response.getBody());
    verify(cacheService).getAllDistributedCacheValues();
  }

  @Test
  public void testGetCacheConfigurations() {
    Map<String, String> configs = new HashMap<>();
    configs.put("config1", "value1");
    configs.put("config2", "value2");

    when(cacheService.getConfigurationProperties()).thenReturn(configs);

    ResponseEntity<?> response = cacheController.getCacheConfigurations();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(configs, response.getBody());
    verify(cacheService).getConfigurationProperties();
  }

  @Test
  public void testClearCacheValues() throws JSONException {
    String mapName = "testMap";
    String resourceId = "123";
    String result = "Cache cleared successfully";

    when(cacheService.clearCacheValues(mapName, resourceId)).thenReturn(result);

    ResponseEntity<String> response = cacheController.clearCacheValues(mapName, resourceId);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    JSONObject jsonResponse = new JSONObject(response.getBody());
    assertEquals(result, jsonResponse.getString("result "));
    verify(cacheService).clearCacheValues(mapName, resourceId);
  }

  @Test
  public void testConfigureApplicationConfig() throws JSONException {
    String key = "testKey";
    String type = "testType";
    String value = "testValue";

    doNothing().when(cacheService).updateApplicationConfig(key, type, value);

    ResponseEntity<?> response = cacheController.configureApplicationConfig(key, type, value);

    assertEquals(HttpStatus.CREATED, response.getStatusCode());
    verify(cacheService).updateApplicationConfig(key, type, value);
  }
}
