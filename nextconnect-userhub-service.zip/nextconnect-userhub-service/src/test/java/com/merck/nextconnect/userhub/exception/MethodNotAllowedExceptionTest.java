package com.merck.nextconnect.userhub.exception;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;

public class MethodNotAllowedExceptionTest {

  @Test
  public void testConstructorWithMessage() {
    String errorMessage = "Method not allowed";
    MethodNotAllowedException exception = new MethodNotAllowedException(errorMessage);

    assertNotNull(exception);
    assertEquals(errorMessage, exception.getMessage());
  }

  @Test
  public void testConstructorWithCustomErrorCode() {
    CustomErrorCodes errorCode = CustomErrorCodes.USER_NOT_FOUND;
    MethodNotAllowedException exception = new MethodNotAllowedException(errorCode);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCodeAndParams() {
    CustomErrorCodes errorCode = CustomErrorCodes.USER_NOT_FOUND;
    List<String> params = Arrays.asList("param1", "param2");
    MethodNotAllowedException exception = new MethodNotAllowedException(errorCode, params);

    assertNotNull(exception);
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }
}
