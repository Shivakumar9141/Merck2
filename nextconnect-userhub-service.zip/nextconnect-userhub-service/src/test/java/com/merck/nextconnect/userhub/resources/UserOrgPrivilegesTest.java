package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.entities.AuthOrg;
import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.AuthPartnerPeripheralSupplierRepository;
import com.merck.nextconnect.authfilter.repository.jpa.PartnerTypeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.RolesOrgPrivilegeRepository;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.resources.IOrgPrivilegeProvider;
import com.merck.nextconnect.authfilter.resources.impl.OrgCardEntity;
import com.merck.nextconnect.authfilter.resources.impl.OrgDeviceEntity;
import com.merck.nextconnect.authfilter.resources.impl.OrgEntitesFactory;
import com.merck.nextconnect.authfilter.resources.org.IOrgBuilderFacade;
import com.merck.nextconnect.authfilter.resources.org.IOrgCreator;
import com.merck.nextconnect.authfilter.resources.org.impl.OrgFactory;
import com.merck.nextconnect.authfilter.resources.org.impl.labwaterpartner.LabwaterPartnerOrgProperties;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.model.org.OrgSettingsDto;
import com.merck.nextconnect.userhub.model.privilege.OrgPrivilege;
import com.merck.nextconnect.userhub.repository.jpa.OrgDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrgPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrgSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

public class UserOrgPrivilegesTest {

  @Mock private OrgPrivilegesRepository orgPrivilegesRepo;

  @Mock private OrgSettingsRepository orgSettingsRepo;

  @Mock private IOrgPermissions orgPermissions;

  @Mock private OrgEntitesFactory orgEntitesFactory;

  @Mock private IOrgPrivilegeProvider orgPrivilegeProvider;

  @Mock private OrganizationRepository orgRepo;

  @Mock private IOrgCreator orgCreator;

  @Mock private IOrgBuilderFacade orgBuilderFacade;

  @Mock private RolesOrgPrivilegeRepository rolesOrgPrivilegeRepo;

  @Mock private OrgFactory orgFactory;

  @Mock private PartnerTypeRepository partnerTypeRepo;

  @Mock private AuthPartnerPeripheralSupplierRepository authPartnerPeripheralSupplierRepo;

  @Mock private OrgDevicePrivilegeRepository orgDevicePrivilegeRepository;

  @InjectMocks private UserOrgPrivileges userOrgPrivileges;

  @Mock private AuthenticatedUser authUser;

  @Mock OrgCardEntity orgCardEntity;

  private Authentication authentication;

  private static final String CARD = "card";

  @Mock LabwaterPartnerOrgProperties labwaterPartnerOrgProperties;

  @Mock OrgDeviceEntity deviceEntity;

  @Mock OrgCardEntity cardEntity;

  @BeforeEach
  public void setUp() throws Exception {
    MockitoAnnotations.openMocks(this);
    ReflectionTestUtils.setField(userOrgPrivileges, "orgEntitesFactory", orgEntitesFactory);

    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
    when(authUser.getOrgId()).thenReturn(5);
    when(authUser.getId()).thenReturn("1");
    when(authUser.getRoleId()).thenReturn(1L);
    //  mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetOrgPrivileges() {
    List<OrgPrivilege> expectedPrivileges = new ArrayList<>();
    when(orgPrivilegesRepo.getPrivileges(5))
        .thenReturn(expectedPrivileges); // Changed from 1 to 5 to match authUser.getOrgId()
    List<OrgPrivilege> actualPrivileges = userOrgPrivileges.getOrgPrivileges();
    assertEquals(expectedPrivileges, actualPrivileges);
  }

  @Test
  public void testGetOrgSpecificSettings() {
    OrgSettingsDto expectedOrgSettings = new OrgSettingsDto();
    when(orgSettingsRepo.getOrgSettings(5)).thenReturn(expectedOrgSettings);
    OrgSettingsDto actualOrgSettings = userOrgPrivileges.getOrgSpecificSettings();
    assertEquals(expectedOrgSettings, actualOrgSettings);
  }

  @Test
  public void testHasPermission() {
    when(orgPermissions.hasPermission(5, 1)).thenReturn(true);
    assertTrue(userOrgPrivileges.hasPermission(1));
  }

  @Test
  public void testAddDevicesToOrg() {
    List<Long> deviceIds = Arrays.asList(1L, 2L);
    when(orgEntitesFactory.getOrgEntities("device")).thenReturn(deviceEntity);
    when(orgEntitesFactory.getOrgEntities("device").getAll(1)).thenReturn(Arrays.asList(1L));
    userOrgPrivileges.addDevicesToOrg(1, deviceIds);
  }

  @Test
  public void testHasCardAccess() {
    when(orgEntitesFactory.getOrgEntities(CARD)).thenReturn(cardEntity);
    when(orgEntitesFactory.getOrgEntities(CARD).hasAccess(5, 1)).thenReturn(true);
    assertTrue(userOrgPrivileges.hasCardAccess(1));
  }

  //  @Test
  public void testGetOrgs_WithSearchBy() {
    // Arrange
    String searchBy = "test";
    String type = null;
    OrgPrivileges orgPrivileges = OrgPrivileges.assign_device;

    List<AuthOrg> providerOrgs = new ArrayList<>();
    AuthOrg org1 = new AuthOrg();
    org1.setId(2);
    org1.setName("Test Org");
    org1.setType("Customer");
    org1.setStatus(true);
    providerOrgs.add(org1);

    Organization userOrg = new Organization();
    userOrg.setId(5);
    userOrg.setName("My Test Org");
    userOrg.setType("Customer");
    userOrg.setStatus(true);
    userOrg.setDeleted(false);

    // Mock repository methods
    when(orgPrivilegeProvider.getOrgsByRolePrivilege(
            anyInt(), any(OrgPrivileges.class), anyString()))
        .thenReturn(providerOrgs);

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(() -> UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);

      // Act
      List<OrgDto> result = userOrgPrivileges.getOrgs(orgPrivileges, searchBy, type);

      // Assert
      assertNotNull(result);
    }
  }

  //  @Test
  public void testGetOrgs_WithoutSearchBy() {
    // Arrange
    String searchBy = null;
    String type = "Customer";
    OrgPrivileges orgPrivileges = OrgPrivileges.assign_device;

    List<AuthOrg> providerOrgs = new ArrayList<>();
    AuthOrg org1 = new AuthOrg();
    org1.setId(2);
    org1.setName("Another Org");
    org1.setType("Customer");
    org1.setStatus(true);
    providerOrgs.add(org1);

    Organization userOrg = new Organization();
    userOrg.setId(5);
    userOrg.setName("My Org");
    userOrg.setType("Customer");
    userOrg.setStatus(true);
    userOrg.setDeleted(false);

    // Mock repository methods
    when(orgRepo.findById(authUser.getOrgId())).thenReturn(Optional.of(userOrg));
    when(orgPrivilegeProvider.getOrgsByRolePrivilege(
            anyInt(), any(OrgPrivileges.class), anyString()))
        .thenReturn(providerOrgs);

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(() -> UserhubUtils.getAuthenticatedUser()).thenReturn(authUser);

      // Act
      List<OrgDto> result = userOrgPrivileges.getOrgs(orgPrivileges, searchBy, type);

      // Assert
      assertNotNull(result);
    }
  }

  @Test
  public void testGetOrgs() {
    Organization org = new Organization(5);
    org.setId(5);
    org.setName("searchBy");
    org.setType("type");
    org.setDescription("desc");
    org.setStatus(true);
    org.setDeleted(false);

    AuthOrg authOrg = new AuthOrg();
    authOrg.setId(2);
    authOrg.setName("TestOrg");
    authOrg.setType("type");
    authOrg.setStatus(true);

    when(orgRepo.findById(authUser.getOrgId())).thenReturn(Optional.of(org));
    when(orgPrivilegeProvider.getOrgsByRolePrivilege(
            1, OrgPrivileges.valueOf("manage_accounts"), "type"))
        .thenReturn(Arrays.asList(authOrg));
    List<OrgDto> orgs =
        userOrgPrivileges.getOrgs(OrgPrivileges.valueOf("manage_accounts"), "searchBy", "type");
    assertNotNull(orgs);
  }

  @Test
  public void testGetOrgsSearchByNull() {
    Organization org = new Organization();
    org.setId(5);
    org.setName("searchBy");
    org.setType("type");
    org.setDescription("desc");
    org.setStatus(true);
    org.setDeleted(false);

    AuthOrg authOrg = new AuthOrg();
    authOrg.setId(2);
    authOrg.setName("AnotherOrg");
    authOrg.setType("type");
    authOrg.setStatus(true);

    when(orgRepo.findById(authUser.getOrgId())).thenReturn(Optional.of(org));
    when(orgPrivilegeProvider.getOrgsByRolePrivilege(
            1, OrgPrivileges.valueOf("manage_accounts"), "type"))
        .thenReturn(Arrays.asList(authOrg));
    List<OrgDto> orgs =
        userOrgPrivileges.getOrgs(OrgPrivileges.valueOf("manage_accounts"), "searchBy", "type");
    assertNotNull(orgs);
  }

  @Test
  void testCreateOrg_WithEmptyName() {
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setName("");

    assertThrows(DataValidationException.class, () -> userOrgPrivileges.createOrg(orgInfo));
  }

  @Test
  void testCreateOrg_WithDuplicateName() {
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setName("OrgName");
    when(orgCreator.hasOrgByName("OrgName")).thenReturn(true);

    assertThrows(DuplicateResourceException.class, () -> userOrgPrivileges.createOrg(orgInfo));
  }

  @Test
  public void testCreateOrg() throws DuplicateResourceException, DataValidationException {
    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setName("OrgName");
    when(orgCreator.hasOrgByName("OrgName")).thenReturn(false);
    when(orgBuilderFacade.buildOrg(orgInfo)).thenReturn(1);
    assertEquals(1, userOrgPrivileges.createOrg(orgInfo));
  }

  @Test
  public void testIsolateOrg() {
    userOrgPrivileges.isolateOrg(1);
  }

  @Test
  public void testAddCustomProperties() {
    List<OrgDto> orgs = Arrays.asList(new OrgDto(1, "name", "Partners", "description", true));
    Map<Integer, Map<String, Object>> orgCustomProperties = new HashMap<>();
    Map<String, Object> map1 = new HashMap<String, Object>();
    map1.put("String", new Object());
    Map<Integer, List<PartnerTypeEntity>> orgPartnerTypes = new HashMap<>();
    orgPartnerTypes.put(1, new ArrayList<PartnerTypeEntity>());
    List<Integer> partnerOrgIds = new ArrayList<Integer>();
    partnerOrgIds.add(1);
    orgCustomProperties.put(1, map1);
    when(orgFactory.getOrgCustomProperties(Constants.PARTNER))
        .thenReturn(labwaterPartnerOrgProperties);
    when(orgFactory.getOrgCustomProperties(Constants.PARTNER).getCustomProperties(partnerOrgIds))
        .thenReturn(orgCustomProperties);
    when(orgFactory
            .getOrgCustomProperties(Constants.PARTNER)
            .getPartnerTypesForOrg(Arrays.asList(1)))
        .thenReturn(orgPartnerTypes);

    List<OrgDto> actualOrgs = userOrgPrivileges.addCustomProperties(orgs);
    assertNotNull(actualOrgs);
  }
}
