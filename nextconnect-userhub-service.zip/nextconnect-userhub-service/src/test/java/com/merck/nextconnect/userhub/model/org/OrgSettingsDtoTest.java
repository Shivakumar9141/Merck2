package com.merck.nextconnect.userhub.model.org;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class OrgSettingsDtoTest {

  @Test
  public void testDefaultConstructor() {
    OrgSettingsDto dto = new OrgSettingsDto();

    assertNull(dto.getLogo());
    assertNull(dto.getTheme());
    assertNull(dto.getAppName());
  }

  @Test
  public void testParameterizedConstructor() {
    String logo = "test-logo.png";
    String theme = "dark";
    String appName = "NextConnect";

    OrgSettingsDto dto = new OrgSettingsDto(logo, theme, appName);

    assertEquals(logo, dto.getLogo());
    assertEquals(theme, dto.getTheme());
    assertEquals(appName, dto.getAppName());
  }

  @Test
  public void testSettersAndGetters() {
    OrgSettingsDto dto = new OrgSettingsDto();

    String logo = "updated-logo.png";
    String theme = "light";
    String appName = "Updated App";

    dto.setLogo(logo);
    dto.setTheme(theme);
    dto.setAppName(appName);

    assertEquals(logo, dto.getLogo());
    assertEquals(theme, dto.getTheme());
    assertEquals(appName, dto.getAppName());
  }
}
