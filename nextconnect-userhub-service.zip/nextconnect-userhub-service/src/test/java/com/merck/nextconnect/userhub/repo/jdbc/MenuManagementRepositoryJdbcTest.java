package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuInfoDTO;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@ExtendWith(MockitoExtension.class)
public class MenuManagementRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private MenuManagementRepositoryJdbc repository;

  private MapSqlParameterSource parameters;
  private String sql;

  @BeforeEach
  public void setUp() {
    parameters = new MapSqlParameterSource();
    sql = "SELECT * FROM test";
  }

  @Test
  public void getMenuGroup_shouldReturnMenuGroupList() {
    // Arrange
    List<MenuGroupResponse> expectedList = new ArrayList<>();
    expectedList.add(
        MenuGroupResponse.builder()
            .menuGroupId(1)
            .maxCount(5)
            .minCount(1)
            .menuGroupName("Test Group")
            .build());

    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<MenuGroupResponse> result = repository.getMenuGroup(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(1, result.get(0).getMenuGroupId());
    assertEquals("Test Group", result.get(0).getMenuGroupName());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getUserMenuCount_shouldReturnCount() {
    // Arrange
    when(namedParameterJdbcTemplate.queryForObject(sql, parameters, Integer.class)).thenReturn(5);

    // Act
    Integer result = repository.getUserMenuCount(parameters, sql);

    // Assert
    assertEquals(Integer.valueOf(5), result);
    verify(namedParameterJdbcTemplate).queryForObject(sql, parameters, Integer.class);
  }

  @Test
  public void insertMenuInfo_shouldReturnRowsAffected() {
    // Arrange
    when(namedParameterJdbcTemplate.update(sql, parameters)).thenReturn(1);

    // Act
    int result = repository.insertMenuInfo(parameters, sql);

    // Assert
    assertEquals(1, result);
    verify(namedParameterJdbcTemplate).update(sql, parameters);
  }

  @Test
  public void getMenuInfo_shouldReturnMenuInfoList() {
    // Arrange
    List<MenuInfoDTO> expectedList = new ArrayList<>();
    expectedList.add(
        MenuInfoDTO.builder()
            .menuId(1)
            .menuKey("test.key")
            .menuGroupId(2)
            .menuGroupName("Test Group")
            .build());

    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<MenuInfoDTO> result = repository.getMenuInfo(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals(1, result.get(0).getMenuId());
    assertEquals("test.key", result.get(0).getMenuKey());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void batchUpdate_shouldExecuteBatchUpdate() {
    // Arrange
    List<MapSqlParameterSource> paramList = new ArrayList<>();
    paramList.add(new MapSqlParameterSource("id", 1));
    paramList.add(new MapSqlParameterSource("id", 2));

    // Act
    repository.batchUpdate(paramList, sql);

    // Assert
    verify(namedParameterJdbcTemplate).batchUpdate(eq(sql), any(MapSqlParameterSource[].class));
  }

  @Test
  public void getMenuGroup_shouldReturnEmptyList_whenNoResults() {
    // Arrange
    List<MenuGroupResponse> emptyList = new ArrayList<>();
    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(emptyList);

    // Act
    List<MenuGroupResponse> result = repository.getMenuGroup(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(0, result.size());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuGroup_shouldReturnMultipleMenuGroups() {
    // Arrange
    List<MenuGroupResponse> expectedList = new ArrayList<>();
    expectedList.add(
        MenuGroupResponse.builder()
            .menuGroupId(1)
            .maxCount(10)
            .minCount(2)
            .menuGroupName("Group One")
            .build());
    expectedList.add(
        MenuGroupResponse.builder()
            .menuGroupId(2)
            .maxCount(20)
            .minCount(5)
            .menuGroupName("Group Two")
            .build());

    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<MenuGroupResponse> result = repository.getMenuGroup(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(2, result.size());
    assertEquals("Group One", result.get(0).getMenuGroupName());
    assertEquals("Group Two", result.get(1).getMenuGroupName());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuGroup_shouldThrowException_whenJdbcTemplateThrows() {
    // Arrange
    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenThrow(new RuntimeException("DB error"));

    // Act & Assert
    assertThrows(RuntimeException.class, () -> repository.getMenuGroup(parameters, sql));
  }

  @Test
  public void getMenuInfo_shouldReturnMenuInfoList_withAllFields() {
    // Arrange
    List<MenuInfoDTO> expectedList = new ArrayList<>();
    expectedList.add(
        MenuInfoDTO.builder()
            .menuSequence(1)
            .isVisible(true)
            .menuId(10)
            .menuKey("menu.key")
            .toolTip("Tooltip")
            .tag("tag1")
            .isMandatory(false)
            .iconUriImage("/img/icon.png")
            .menuGroupId(2)
            .maxCount(5)
            .minCount(1)
            .menuGroupName("GroupName")
            .build());

    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<MenuInfoDTO> result = repository.getMenuInfo(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    MenuInfoDTO dto = result.get(0);
    assertEquals(1, dto.getMenuSequence());
    assertTrue(dto.isVisible());
    assertEquals(10, dto.getMenuId());
    assertEquals("menu.key", dto.getMenuKey());
    assertEquals("Tooltip", dto.getToolTip());
    assertEquals("tag1", dto.getTag());
    assertFalse(dto.isMandatory());
    assertEquals("/img/icon.png", dto.getIconUriImage());
    assertEquals(2, dto.getMenuGroupId());
    assertEquals(5, dto.getMaxCount());
    assertEquals(1, dto.getMinCount());
    assertEquals("GroupName", dto.getMenuGroupName());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuInfo_shouldReturnEmptyList_whenNoResults() {
    // Arrange
    List<MenuInfoDTO> emptyList = new ArrayList<>();
    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(emptyList);

    // Act
    List<MenuInfoDTO> result = repository.getMenuInfo(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(0, result.size());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuInfo_shouldReturnMultipleMenuInfoDTOs() {
    // Arrange
    List<MenuInfoDTO> expectedList = new ArrayList<>();
    expectedList.add(
        MenuInfoDTO.builder()
            .menuSequence(1)
            .isVisible(true)
            .menuId(10)
            .menuKey("menu.key1")
            .toolTip("Tooltip1")
            .tag("tag1")
            .isMandatory(false)
            .iconUriImage("/img/icon1.png")
            .menuGroupId(2)
            .maxCount(5)
            .minCount(1)
            .menuGroupName("Group1")
            .build());
    expectedList.add(
        MenuInfoDTO.builder()
            .menuSequence(2)
            .isVisible(false)
            .menuId(11)
            .menuKey("menu.key2")
            .toolTip("Tooltip2")
            .tag("tag2")
            .isMandatory(true)
            .iconUriImage("/img/icon2.png")
            .menuGroupId(3)
            .maxCount(10)
            .minCount(2)
            .menuGroupName("Group2")
            .build());

    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(expectedList);

    // Act
    List<MenuInfoDTO> result = repository.getMenuInfo(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(2, result.size());
    assertEquals("menu.key1", result.get(0).getMenuKey());
    assertEquals("menu.key2", result.get(1).getMenuKey());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuInfo_shouldThrowException_whenJdbcTemplateThrows() {
    // Arrange
    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenThrow(new RuntimeException("DB error"));

    // Act & Assert
    assertThrows(RuntimeException.class, () -> repository.getMenuInfo(parameters, sql));
  }

  @Test
  public void getMenuGroup_shouldMapResultSetCorrectly() {
    // Arrange
    List<MenuGroupResponse> expectedList = new ArrayList<>();
    expectedList.add(
        MenuGroupResponse.builder()
            .menuGroupId(100)
            .maxCount(50)
            .minCount(10)
            .menuGroupName("Sample Group")
            .build());

    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenAnswer(
            invocation -> {
              RowMapper<MenuGroupResponse> rowMapper = invocation.getArgument(2);
              // Simulate ResultSet
              java.sql.ResultSet rs = mock(java.sql.ResultSet.class);
              when(rs.getInt("mg.menugroup_id")).thenReturn(100);
              when(rs.getInt("mg.max_count")).thenReturn(50);
              when(rs.getInt("mg.min_count")).thenReturn(10);
              when(rs.getString("mg.name")).thenReturn("Sample Group");
              List<MenuGroupResponse> list = new ArrayList<>();
              list.add(rowMapper.mapRow(rs, 0));
              return list;
            });

    // Act
    List<MenuGroupResponse> result = repository.getMenuGroup(parameters, sql);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    MenuGroupResponse group = result.get(0);
    assertEquals(100, group.getMenuGroupId());
    assertEquals(50, group.getMaxCount());
    assertEquals(10, group.getMinCount());
    assertEquals("Sample Group", group.getMenuGroupName());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuGroup_shouldReturnEmptyListIfNoResults() {
    // Arrange
    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenReturn(new ArrayList<>());

    // Act
    List<MenuGroupResponse> result = repository.getMenuGroup(parameters, sql);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());
    verify(namedParameterJdbcTemplate).query(eq(sql), eq(parameters), any(RowMapper.class));
  }

  @Test
  public void getMenuGroup_shouldThrowExceptionIfJdbcTemplateThrows() {
    // Arrange
    when(namedParameterJdbcTemplate.query(eq(sql), eq(parameters), any(RowMapper.class)))
        .thenThrow(new RuntimeException("DB error"));

    // Act & Assert
    assertThrows(RuntimeException.class, () -> repository.getMenuGroup(parameters, sql));
  }
}
