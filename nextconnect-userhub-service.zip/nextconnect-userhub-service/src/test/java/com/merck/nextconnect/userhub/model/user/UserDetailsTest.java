package com.merck.nextconnect.userhub.model.user;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserDetailsTest {

  private UserDetails userDetails;
  private UserSubscriptionDTO userSubscriptionDTO;
  private UserProfileSettingsDTO userProfileSettingsDTO;

  @BeforeEach
  public void setUp() {
    userDetails = new UserDetails();
    userSubscriptionDTO = new UserSubscriptionDTO();
    userProfileSettingsDTO = new UserProfileSettingsDTO();
  }

  @Test
  public void testGettersAndSetters() {
    // Test basic string properties
    userDetails.setLoginText("testLogin");
    userDetails.setFirstName("John");
    userDetails.setLastName("Doe");
    userDetails.setEmail("john.doe@example.com");
    userDetails.setIsdCode("91");
    userDetails.setPhone("1234567890");
    userDetails.setCountryCode("US");
    userDetails.setInvitedVia("email");

    assertEquals("testLogin", userDetails.getLoginText());
    assertEquals("John", userDetails.getFirstName());
    assertEquals("Doe", userDetails.getLastName());
    assertEquals("john.doe@example.com", userDetails.getEmail());
    assertEquals("91", userDetails.getIsdCode());
    assertEquals("1234567890", userDetails.getPhone());
    assertEquals("US", userDetails.getCountryCode());
    assertEquals("email", userDetails.getInvitedVia());

    // Test numeric properties
    userDetails.setBusinessDomainId(1);
    userDetails.setCountryId(2);
    userDetails.setDomainId(3L);
    userDetails.setRoleId(4L);
    userDetails.setDateFormatId(5);
    userDetails.setLanguageId(6);
    userDetails.setOrgId(7);
    userDetails.setTimeZoneId(8);

    assertEquals(1, userDetails.getBusinessDomainId());
    assertEquals(2, userDetails.getCountryId());
    assertEquals(3L, userDetails.getDomainId());
    assertEquals(4L, userDetails.getRoleId());
    assertEquals(5, userDetails.getDateFormatId());
    assertEquals(6, userDetails.getLanguageId());
    assertEquals(7, userDetails.getOrgId());
    assertEquals(Integer.valueOf(8), userDetails.getTimeZoneId());

    // Test boolean properties
    userDetails.setConsentStatus(true);
    userDetails.setPrivacyPolicyStatus(true);
    userDetails.setAutoCreated(true);
    userDetails.setRegistrationFlow(true);
    userDetails.setPlatformSubscription(true);

    assertTrue(userDetails.isConsentStatus());
    assertTrue(userDetails.isPrivacyPolicyStatus());
    assertTrue(userDetails.isAutoCreated());
    assertTrue(userDetails.isRegistrationFlow());
    assertTrue(userDetails.isPlatformSubscription());

    // Test object properties
    userDetails.setUserSubscriptionDTO(userSubscriptionDTO);
    userDetails.setUserProfileSettings(userProfileSettingsDTO);

    assertEquals(userSubscriptionDTO, userDetails.getUserSubscriptionDTO());
    assertEquals(userProfileSettingsDTO, userDetails.getUserProfileSettings());
  }

  @Test
  public void testBooleanDefaults() {
    // By default, boolean values should be false
    assertFalse(userDetails.isConsentStatus());
    assertFalse(userDetails.isPrivacyPolicyStatus());
    assertFalse(userDetails.isAutoCreated());
    assertFalse(userDetails.isRegistrationFlow());
    assertFalse(userDetails.isPlatformSubscription());
  }
}
