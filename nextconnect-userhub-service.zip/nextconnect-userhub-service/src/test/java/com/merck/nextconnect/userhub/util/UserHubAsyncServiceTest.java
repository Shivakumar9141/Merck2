package com.merck.nextconnect.userhub.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.helper.UserHubServiceMaxHelper;
import com.merck.nextconnect.userhub.model.CoveredProductDTO;
import com.merck.nextconnect.userhub.model.DeviceDTO;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.repo.jdbc.CoveredProductRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.DeviceRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.UserDevicePrivilegeRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.UserProfileRepositoryJdbc;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.exception.EmailException;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

public class UserHubAsyncServiceTest {

  @InjectMocks private UserHubAsyncService userHubAsyncService;

  @Mock private UserHubServiceMaxHelper userHubServiceMaxHelper;
  @Mock private UserDevicePrivilegeRepositoryJdbc userDevicePrivilegeRepositoryJdbc;
  @Mock private UserProfileRepositoryJdbc userProfileRepositoryJdbc;
  @Mock private CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;
  @Mock private DeviceRepositoryJdbc deviceRepositoryJdbc;
  @Mock private EmailTemplateService emailTemplateService;
  @Mock private EmailService emailService;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    ReflectionTestUtils.setField(userHubAsyncService, "environment", "test");
  }

  @Test
  public void testUpdateMymilliqActivtedCheckboxForDeviceAutoAssignment() {
    DeviceDTO deviceDTO = new DeviceDTO();
    deviceDTO.setSmDeviceId("sm123");
    when(deviceRepositoryJdbc.findSmDeviceIdByDeviceId(anyLong()))
        .thenReturn(Collections.singletonList(deviceDTO));
    CoveredProductDTO coveredProductDTO = new CoveredProductDTO();
    coveredProductDTO.setSmCoveredProductId("cp123");
    when(coveredProductRepositoryJdbc.getSmCoveredProductId(anyLong()))
        .thenReturn(Collections.singletonList(coveredProductDTO));

    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAutoAssignment(1L);

    verify(userHubServiceMaxHelper, times(1))
        .updateMymilliqActivatedCheckBoxIP(eq("sm123"), eq(true));
    verify(userHubServiceMaxHelper, times(1))
        .updateMymilliqActivatedCheckBoxCP(eq("cp123"), eq(true));
  }

  @Test
  public void testUpdateMymilliqActivtedCheckboxForDeviceAssignment_whenOrgAutoCreated() {
    Organization org = new Organization();
    org.setAutoCreated(true);
    org.setName("org1");
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(10L);
    userProfile.setOrg(org);

    ResourcePrivilege rp = new ResourcePrivilege();
    rp.setResourceid(100L);

    DeviceDTO deviceDTO = new DeviceDTO();
    deviceDTO.setSmDeviceId("sm123");
    when(deviceRepositoryJdbc.findSmDeviceIdByDeviceId(anyLong()))
        .thenReturn(Collections.singletonList(deviceDTO));
    CoveredProductDTO coveredProductDTO = new CoveredProductDTO();
    coveredProductDTO.setSmCoveredProductId("cp123");
    when(coveredProductRepositoryJdbc.getSmCoveredProductId(anyLong()))
        .thenReturn(Collections.singletonList(coveredProductDTO));

    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAssignment(
        Optional.of(userProfile), Arrays.asList(rp));

    verify(userHubServiceMaxHelper, times(1))
        .updateMymilliqActivatedCheckBoxIP(eq("sm123"), eq(true));
    verify(userHubServiceMaxHelper, times(1))
        .updateMymilliqActivatedCheckBoxCP(eq("cp123"), eq(true));
  }

  @Test
  public void testUpdateMymilliqActivtedCheckboxForDeviceAssignment_whenOrgNotAutoCreated() {
    Organization org = new Organization();
    org.setAutoCreated(false);
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(10L);
    userProfile.setOrg(org);

    ResourcePrivilege rp = new ResourcePrivilege();
    rp.setResourceid(100L);

    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAssignment(
        Optional.of(userProfile), Arrays.asList(rp));

    verify(userHubServiceMaxHelper, never())
        .updateMymilliqActivatedCheckBoxIP(anyString(), anyBoolean());
    verify(userHubServiceMaxHelper, never())
        .updateMymilliqActivatedCheckBoxCP(anyString(), anyBoolean());
  }

  @Test
  public void
      testUpdateMymilliqActivtedCheckboxForDeviceDeAssignment_whenOrgAutoCreated_andNoUsersLeft()
          throws Exception {
    Organization org = new Organization();
    org.setAutoCreated(true);
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(10L);
    userProfile.setOrg(org);

    ResourcePrivilege rp = new ResourcePrivilege();
    rp.setResourceid(100L);

    when(userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(anyLong()))
        .thenReturn(Collections.singletonList(10L));
    when(userProfileRepositoryJdbc.getUserOrgDetails(anyList()))
        .thenReturn(Collections.emptyList());

    DeviceDTO deviceDTO = new DeviceDTO();
    deviceDTO.setSmDeviceId("sm123");
    when(deviceRepositoryJdbc.findSmDeviceIdByDeviceId(anyLong()))
        .thenReturn(Collections.singletonList(deviceDTO));
    CoveredProductDTO coveredProductDTO = new CoveredProductDTO();
    coveredProductDTO.setSmCoveredProductId("cp123");
    when(coveredProductRepositoryJdbc.getSmCoveredProductId(anyLong()))
        .thenReturn(Collections.singletonList(coveredProductDTO));

    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceDeAssignment(
        Optional.of(userProfile), Arrays.asList(rp));

    verify(userHubServiceMaxHelper, times(1))
        .updateMymilliqActivatedCheckBoxIP(eq("sm123"), eq(false));
  }

  @Test
  public void
      testUpdateMymilliqActivtedCheckboxForDeviceDeAssignment_whenOrgAutoCreated_andUsersRemain()
          throws Exception {
    Organization org = new Organization();
    org.setAutoCreated(true);
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(10L);
    userProfile.setOrg(org);

    ResourcePrivilege rp = new ResourcePrivilege();
    rp.setResourceid(100L);

    when(userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(anyLong()))
        .thenReturn(Collections.singletonList(10L));
    UserDataDTO userDataDTO = new UserDataDTO();
    userDataDTO.setUserId(10L);
    userDataDTO.setOrgId(1L);
    userDataDTO.setUserOrgCreatedVia("auto");
    when(userProfileRepositoryJdbc.getUserOrgDetails(anyList()))
        .thenReturn(Collections.singletonList(userDataDTO));

    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceDeAssignment(
        Optional.of(userProfile), Arrays.asList(rp));

    verify(userHubServiceMaxHelper, never())
        .updateMymilliqActivatedCheckBoxIP(anyString(), anyBoolean());
  }

  @Test
  public void testSendEmailToUserForAssignedUnassignedSubscriptions_assigned() throws Exception {
    String fromEmail = "from@merck.com";
    String toEmail = "to@merck.com";
    String subject = Constants.SUBJECT_ASSIGNED;

    when(emailTemplateService.findLanguageIdByEmail(anyString())).thenReturn(1);
    EmailTemplate template = new EmailTemplate();
    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            anyString(), anyInt(), anyString()))
        .thenReturn(template);

    userHubAsyncService.sendEmailToUserForAssignedUnassignedSubscriptions(
        fromEmail, toEmail, subject);

    verify(emailService, times(1)).sendMail(any(EmailMessage.class), eq("test"));
  }

  @Test
  public void testSendEmailToUserForAssignedUnassignedSubscriptions_unassigned() throws Exception {
    String fromEmail = "from@merck.com";
    String toEmail = "to@merck.com";
    String subject = Constants.SUBJECT_UNASSIGNED;

    when(emailTemplateService.findLanguageIdByEmail(anyString())).thenReturn(1);
    EmailTemplate template = new EmailTemplate();
    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            anyString(), anyInt(), anyString()))
        .thenReturn(template);

    userHubAsyncService.sendEmailToUserForAssignedUnassignedSubscriptions(
        fromEmail, toEmail, subject);

    verify(emailService, times(1)).sendMail(any(EmailMessage.class), eq("test"));
  }

  @Test
  public void testSendEmailToUserForAssignedUnassignedSubscriptions_EmailException()
      throws Exception {
    String fromEmail = "from@merck.com";
    String toEmail = "to@merck.com";
    String subject = Constants.SUBJECT_ASSIGNED;

    when(emailTemplateService.findLanguageIdByEmail(anyString())).thenReturn(1);
    EmailTemplate template = new EmailTemplate();
    when(emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            anyString(), anyInt(), anyString()))
        .thenReturn(template);

    doThrow(new EmailException("fail"))
        .when(emailService)
        .sendMail(any(EmailMessage.class), anyString());

    userHubAsyncService.sendEmailToUserForAssignedUnassignedSubscriptions(
        fromEmail, toEmail, subject);

    verify(emailService, times(1)).sendMail(any(EmailMessage.class), eq("test"));
  }
}
