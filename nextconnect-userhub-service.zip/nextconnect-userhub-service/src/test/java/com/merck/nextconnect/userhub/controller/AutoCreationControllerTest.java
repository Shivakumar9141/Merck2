package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.resources.IAutoCreation;
import com.merck.nextconnect.userhub.resources.impl.AutoCreationimpl;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import com.merck.nextconnect.utils.model.OrgAndUserDetailResponse;
import jakarta.mail.MessagingException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

public class AutoCreationControllerTest {

  @Mock private IAutoCreation autoCreation;

  @Mock private AutoCreationimpl autoCreationimpl;

  @InjectMocks private AutoCreationController autoCreationController;

  @Mock private Authentication authentication;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();
    //    //  mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
  }

  @Test
  public void testCreateOrgAndUser()
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          ResourceNotFoundException,
          CustomException {
    // Arrange
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setDeviceId(17622351L);
    orgAndUserDetail.setFirstName("Test");
    orgAndUserDetail.setLastName("Test");
    OrgAndUserDetailResponse response = new OrgAndUserDetailResponse();
    response.setDeviceId(17622351L);
    when(autoCreation.create(orgAndUserDetail)).thenReturn(response);

    ResponseEntity<OrgAndUserDetailResponse> result =
        autoCreationController.createOrgAndUser(orgAndUserDetail);

    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertEquals(response, result.getBody());
    assertEquals(Long.valueOf(17622351), result.getBody().getDeviceId());
    verify(autoCreation, times(1)).create(orgAndUserDetail);
  }
}
