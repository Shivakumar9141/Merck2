package com.merck.nextconnect.userhub.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.sms.resources.SmsService;
import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;

public class SmsServiceValidationTest {

  private SmsServiceValidation smsServiceValidation;
  private SmsService smsServiceMock;

  // Removed loggerMock as it cannot be mocked for static final fields

  @BeforeEach
  public void setUp() {
    smsServiceValidation = new SmsServiceValidation();
    smsServiceMock = mock(SmsService.class);
    // Removed loggerMock initialization as it cannot be injected

    ReflectionTestUtils.setField(smsServiceValidation, "smsService", smsServiceMock);
    ReflectionTestUtils.setField(smsServiceValidation, "smsHost", "host");
    ReflectionTestUtils.setField(smsServiceValidation, "smsUsername", "user");
    ReflectionTestUtils.setField(smsServiceValidation, "smsPassword", "pass");
    // Removed setting static final logger field as it is not allowed
  }

  private UserProfile buildUserProfile(
      String isd, String phone, String first, String last, int langId) {
    UserProfile userProfile = new UserProfile();
    userProfile.setIsdCode(isd);
    userProfile.setPhone(phone);
    userProfile.setFirstName(first);
    userProfile.setLastName(last);
    Language lang = new Language();
    lang.setId(langId);
    userProfile.setLanguage(lang);
    return userProfile;
  }

  private Device buildDevice(String name) {
    Device device = new Device();
    device.setDevicename(name);
    return device;
  }

  @Test
  public void validateAndSendSMS_shouldCallSmsService_whenValidUserProfileAndDevice()
      throws JSONException {
    UserProfile userProfile = buildUserProfile("+1", "1234567890", "John", "Doe", 0);
    Device device = buildDevice("Device1");

    smsServiceValidation.validateAndSendSMS("template", "category", userProfile, device);

    verify(smsServiceMock, times(1))
        .sendSMSAsPerTemplate(
            eq("+11234567890"),
            eq("template"),
            eq("category"),
            eq("John Doe"),
            eq("Device1"),
            eq("host"),
            eq("user"),
            eq("pass"),
            eq(0) // Replace "en" with the appropriate int value, e.g., 0 or
            // userProfile.getLanguage().getId()
            );
  }

  @Test
  public void validateAndSendSMS_shouldNotCallSmsService_whenPhoneOrIsdMissing()
      throws JSONException {
    UserProfile userProfile = buildUserProfile("", "1234567890", "John", "Doe", 0);
    Device device = buildDevice("Device1");

    smsServiceValidation.validateAndSendSMS("template", "category", userProfile, device);

    verify(smsServiceMock, never())
        .sendSMSAsPerTemplate(any(), any(), any(), any(), any(), any(), any(), any(), anyInt());
  }

  @Test
  public void validateAndSendSMS_shouldHandleNullDeviceNameGracefully() throws JSONException {
    UserProfile userProfile = buildUserProfile("+1", "1234567890", "John", "Doe", 0);
    Device device = buildDevice(null);

    smsServiceValidation.validateAndSendSMS("template", "category", userProfile, device);

    ArgumentCaptor<String> systemNameCaptor = ArgumentCaptor.forClass(String.class);
    verify(smsServiceMock)
        .sendSMSAsPerTemplate(
            anyString(),
            anyString(),
            anyString(),
            anyString(),
            systemNameCaptor.capture(),
            anyString(),
            anyString(),
            anyString(),
            eq(0));
    assertEquals("", systemNameCaptor.getValue());
  }

  @Test
  public void validateAndSendSMS_shouldCatchAndLogExceptionFromSmsService() throws JSONException {
    UserProfile userProfile = buildUserProfile("+1", "1234567890", "John", "Doe", 0);
    Device device = buildDevice("Device1");

    doThrow(new RuntimeException("SMS error"))
        .when(smsServiceMock)
        .sendSMSAsPerTemplate(any(), any(), any(), any(), any(), any(), any(), any(), anyInt());

    smsServiceValidation.validateAndSendSMS("template", "category", userProfile, device);
  }

  @Test
  public void validateAndSendSMS_shouldHandleNullUserProfileFields() throws JSONException {
    UserProfile userProfile = buildUserProfile(null, null, null, null, 0);
    Device device = buildDevice("Device1");

    smsServiceValidation.validateAndSendSMS("template", "category", userProfile, device);

    verify(smsServiceMock, never())
        .sendSMSAsPerTemplate(any(), any(), any(), any(), any(), any(), any(), any(), anyInt());
    // Removed loggerMock verifications as logger cannot be mocked or injected
  }
}
