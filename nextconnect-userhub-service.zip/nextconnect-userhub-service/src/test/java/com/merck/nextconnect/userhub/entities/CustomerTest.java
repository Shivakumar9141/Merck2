package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CustomerTest {

  private Customer customer;
  private long customerId;
  private String customerName;

  @BeforeEach
  public void setUp() {
    customerId = 123L;
    customerName = "Test Customer";
    customer = new Customer();
    customer.setCustomerId(customerId);
    customer.setCustomerName(customerName);
  }

  @Test
  public void testGetCustomerId() {
    assertEquals(customerId, customer.getCustomerId());
  }

  @Test
  public void testGetCustomerName() {
    assertEquals(customerName, customer.getCustomerName());
  }

  @Test
  public void testSetCustomerId() {
    long newId = 456L;
    customer.setCustomerId(newId);
    assertEquals(newId, customer.getCustomerId());
  }

  @Test
  public void testSetCustomerName() {
    String newName = "Updated Customer";
    customer.setCustomerName(newName);
    assertEquals(newName, customer.getCustomerName());
  }
}
