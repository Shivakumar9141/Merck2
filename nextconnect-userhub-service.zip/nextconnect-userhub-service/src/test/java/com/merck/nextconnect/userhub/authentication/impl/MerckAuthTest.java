package com.merck.nextconnect.userhub.authentication.impl;

import static org.junit.Assert.*;

import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.util.Constants;
import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class MerckAuthTest {

  private MerckAuth merckAuth;

  @BeforeEach
  public void setUp() {
    merckAuth = new MerckAuth();
    ReflectionTestUtils.setField(merckAuth, "globalAuthUrl", "ldap://global");
    ReflectionTestUtils.setField(merckAuth, "dnapAuthUrl", "ldap://dnap");
    ReflectionTestUtils.setField(merckAuth, "dneuAuthUrl", "ldap://dneu");
    ReflectionTestUtils.setField(merckAuth, "dnlaAuthUrl", "ldap://dnla");
    ReflectionTestUtils.setField(merckAuth, "dnnaAuthUrl", "ldap://dnna");
  }

  private Login buildLogin(String domain) {
    Login login = new Login();
    login.setUserdomain(domain);
    login.setUsername("testuser");
    login.setPassword("testpass");
    return login;
  }

  @Test
  public void authenticate_shouldReturnTrue_whenLdapConnectionSucceeds() throws Exception {
    try (MockedConstruction<InitialLdapContext> mocked =
        Mockito.mockConstruction(InitialLdapContext.class, (mock, context) -> {})) {
      Login login = buildLogin(Constants.MERCK_GLOBAL);
      boolean result = merckAuth.authenticate(login);
      assertTrue(result);
    }
  }

  @Test
  public void authenticate_shouldReturnFalse_whenNamingExceptionThrown() throws Exception {
    try (MockedConstruction<InitialLdapContext> mocked =
        Mockito.mockConstruction(
            InitialLdapContext.class,
            (mock, context) -> {
              throw new NamingException("LDAP error");
            })) {
      Login login = buildLogin(Constants.MERCK_DNAP);
      boolean result = merckAuth.authenticate(login);
      assertFalse(result);
    }
  }

  @Test
  public void authenticate_shouldReturnFalse_whenOtherExceptionThrown() throws Exception {
    try (MockedConstruction<InitialLdapContext> mocked =
        Mockito.mockConstruction(
            InitialLdapContext.class,
            (mock, context) -> {
              throw new RuntimeException("Other error");
            })) {
      Login login = buildLogin(Constants.MERCK_DNEU);
      boolean result = merckAuth.authenticate(login);
      assertFalse(result);
    }
  }

  @Test
  public void getProviderUrl_shouldReturnCorrectUrlForEachDomain() {
    assertEquals(
        "ldap://global",
        ReflectionTestUtils.invokeMethod(merckAuth, "getProviderUrl", Constants.MERCK_GLOBAL));
    assertEquals(
        "ldap://dnap",
        ReflectionTestUtils.invokeMethod(merckAuth, "getProviderUrl", Constants.MERCK_DNAP));
    assertEquals(
        "ldap://dneu",
        ReflectionTestUtils.invokeMethod(merckAuth, "getProviderUrl", Constants.MERCK_DNEU));
    assertEquals(
        "ldap://dnla",
        ReflectionTestUtils.invokeMethod(merckAuth, "getProviderUrl", Constants.MERCK_DNLA));
    assertEquals(
        "ldap://dnna",
        ReflectionTestUtils.invokeMethod(merckAuth, "getProviderUrl", Constants.MERCK_DNNA));
    assertNull(ReflectionTestUtils.invokeMethod(merckAuth, "getProviderUrl", "UNKNOWN_DOMAIN"));
  }
}
