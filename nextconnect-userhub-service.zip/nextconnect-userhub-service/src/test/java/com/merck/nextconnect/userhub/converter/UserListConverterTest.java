package com.merck.nextconnect.userhub.converter;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.model.UserCountryDTO;
import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import com.merck.nextconnect.userhub.response.OrganizationResponseEntity;
import com.merck.nextconnect.userhub.response.RoleResponseEntity;
import com.merck.nextconnect.userhub.response.UserDomainResponseEntity;
import com.merck.nextconnect.userhub.response.UserListResponseEntity;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.Region;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class UserListConverterTest {

  private AuthenticatedUser authUser;

  @BeforeEach
  public void setUp() {
    authUser = mock(AuthenticatedUser.class);
    Mockito.when(authUser.getRole()).thenReturn("SOME_ROLE");
  }

  @Test
  public void toResponseEntity_shouldReturnNull_whenUserProfileIsNull() {
    try (MockedStatic<UserhubUtils> mocked = Mockito.mockStatic(UserhubUtils.class)) {
      mocked.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      assertNull(UserListConverter.toResponseEntity((UserProfile) null));
    }
  }

  @Test
  public void toResponseEntity_shouldMapFieldsCorrectly() {
    UserProfile userProfile = new UserProfile();
    userProfile.setUserId(1L);
    userProfile.setLoginName("login");
    userProfile.setFirstName("first");
    userProfile.setLastName("last");
    userProfile.setEmail("email@test.com");
    userProfile.setIsdCode("+1");
    userProfile.setPhone("1234567890");
    userProfile.setStatus("active");
    userProfile.setConsentStatus(true);
    userProfile.setPrivacyPolicyStatus(true);
    userProfile.setTimeZoneId(0); // Replace 0 with the appropriate Integer timeZoneId for your test
    Country country = new Country();
    country.setId((int) 10L);
    country.setCountryCode("US");
    country.setCountryName("United States");
    Region region = new Region();
    region.setRegionName("North America");
    country.setRegion(region);
    userProfile.setCountry(country);
    Role role = new Role();
    role.setRoleId(2L);
    role.setName("USER");
    userProfile.setRole(role);
    UserDomain userDomain = new UserDomain();
    userDomain.setDomainId(3L);
    userDomain.setDomainName("domain");
    userProfile.setUserDomain(userDomain);
    // Assuming there is a Language class with a constructor that takes a language
    // code
    Language language = new Language();
    userProfile.setLanguage(language);
    Organization org = new Organization();
    org.setId((int) 4L);
    org.setName("OrgName");
    org.setStatus(true);
    org.setType("type");
    userProfile.setOrg(org);
    // Create a UserProfileSettingsDTO object as required by the setter
    UserProfileSettingsDTO settingsDTO = new UserProfileSettingsDTO();
    // Set fields on settingsDTO as needed for your test
    userProfile.setUserProfileSettings(settingsDTO);
    userProfile.setCoveredTerritory(true);
    userProfile.setPlatformSubscription(true);
    // Assuming BusinessDomainDTO has a constructor that takes a String or a setter
    // for name
    BusinessDomainDTO businessDomainDTO = new BusinessDomainDTO();
    businessDomainDTO.setDomainName("business");
    userProfile.setBusinessDomain(businessDomainDTO);
    userProfile.setUserImage("image.png");
    userProfile.setIsDomainVisible(true);
    userProfile.setAutoCreated(true);
    userProfile.setCreatedBy("creator");
    userProfile.setCreatedBy("2024-01-01");
    userProfile.setCreatedBy("ADMIN");
    userProfile.setInvitedOrActivatedTs(java.sql.Timestamp.valueOf("2024-01-02 00:00:00"));
    userProfile.setInvitedVia("email");
    userProfile.setVisible(true);
    userProfile.setValidated(true);

    try (MockedStatic<UserhubUtils> mocked = Mockito.mockStatic(UserhubUtils.class)) {
      mocked.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      UserListResponseEntity response = UserListConverter.toResponseEntity(userProfile);

      assertNotNull(response);
      assertEquals(userProfile.getUserId(), response.getUserId());
      assertEquals(userProfile.getLoginName(), response.getLoginName());
      assertEquals(userProfile.getFirstName(), response.getFirstName());
      assertEquals(userProfile.getLastName(), response.getLastName());
      assertEquals(userProfile.getEmail(), response.getEmail());
      assertEquals(userProfile.getIsdCode(), response.getIsdCode());
      assertEquals(userProfile.getPhone(), response.getPhone());
      assertEquals(userProfile.getStatus(), response.getStatus());
      assertEquals(userProfile.isConsentStatus(), response.isConsentStatus());
      assertEquals(userProfile.isPrivacyPolicyStatus(), response.isPrivacyPolicyStatus());
      assertEquals(userProfile.getTimeZoneId(), response.getTimeZoneId());
      assertNotNull(response.getCountry());
      assertEquals(userProfile.getCountry().getId(), response.getCountry().getId());
      assertNotNull(response.getRole());
      assertEquals(userProfile.getRole().getRoleId(), response.getRole().getRoleId());
      assertNotNull(response.getUserDomain());
      assertEquals(
          userProfile.getUserDomain().getDomainId(), response.getUserDomain().getDomainId());
      assertEquals(userProfile.getDateFormat(), response.getDateFormat());
      assertEquals(userProfile.getLanguage(), response.getLanguage());
      assertNotNull(response.getOrg());
      assertEquals(userProfile.getOrg().getId(), response.getOrg().getId());
      assertEquals(userProfile.getUserProfileSettings(), response.getUserProfileSettings());
      assertEquals(userProfile.getCoveredTerritory(), response.getCoveredTerritory());
      assertEquals(userProfile.getCoveredTerritory(), response.getCoveredTerritory());
      assertEquals(userProfile.getBusinessDomain(), response.getBusinessDomain());
      assertEquals(userProfile.getUserImage(), response.getUserImage());
      assertEquals(userProfile.getIsDomainVisible(), response.getIsDomainVisible());
      assertEquals(userProfile.isAutoCreated(), response.isAutoCreated());
      assertEquals(userProfile.getCreatedBy(), response.getCreatedBy());
      assertEquals(userProfile.getCreatedOn(), response.getCreatedOn());
      assertEquals(userProfile.getCreatedRole(), response.getCreatedRole());
      assertEquals(userProfile.getInvitedOrActivatedTs(), response.getInvitedOrActivatedTs());
      assertEquals(userProfile.getInvitedVia(), response.getInvitedVia());
      assertEquals(userProfile.getVisible(), response.getVisible());
      assertEquals(userProfile.isValidated(), response.isValidated());
    }
  }

  @Test
  public void toResponseEntity_shouldSetDeleteAndUpdateUserBasedOnRole() throws Exception {
    Role role = new Role();
    role.setRoleId(2L);
    // Use a role name that matches the logic in UserListConverter for non-deletable/updatable
    role.setName(Constants.LW_BUSINESS_MANAGER); // or use the actual constant/role name
    UserProfile userProfile = new UserProfile();
    userProfile.setRole(role);

    try (MockedStatic<UserhubUtils> mocked = Mockito.mockStatic(UserhubUtils.class)) {
      AuthenticatedUser bmUser = mock(AuthenticatedUser.class);
      Mockito.when(bmUser.getRole()).thenReturn(Constants.LW_BUSINESS_MANAGER);
      mocked.when(UserhubUtils::getAuthenticatedUser).thenReturn(bmUser);

      UserListResponseEntity response = UserListConverter.toResponseEntity(userProfile);
      // Adjust assertions to match the expected logic for the role
      assertEquals(true, response.isDeleteUser());
      assertEquals(true, response.isUpdateUser());
    }
  }

  @Test
  public void toDTO_shouldReturnNull_whenCountryIsNull() {
    assertNull(UserListConverter.toDTO(null));
  }

  @Test
  public void toDTO_shouldMapCountryFields() {
    Country country = new Country();
    country.setId((int) 1L);
    country.setCountryCode("IN");
    country.setCountryName("India");
    Region region = new Region();
    region.setRegionName("APAC");
    country.setRegion(region);

    UserCountryDTO dto = UserListConverter.toDTO(country);
    assertNotNull(dto);
    assertEquals(country.getId(), dto.getId());
    assertEquals(country.getCountryCode(), dto.getCountryCode());
    assertEquals(country.getCountryName(), dto.getCountryName());
    assertEquals(country.getRegion(), dto.getRegion());
  }

  @Test
  public void toResponseEntityRole_shouldReturnNull_whenRoleIsNull() {
    assertNull(UserListConverter.toResponseEntity((Role) null));
  }

  @Test
  public void toResponseEntityRole_shouldMapRoleFields() {
    Role role = new Role();
    role.setRoleId(5L);
    role.setName("ADMIN");

    RoleResponseEntity response = UserListConverter.toResponseEntity(role);
    assertNotNull(response);
    assertEquals(role.getRoleId(), response.getRoleId());
    assertEquals(role.getName(), response.getName());
  }

  @Test
  public void toResponseEntityUserDomain_shouldReturnNull_whenUserDomainIsNull() {
    assertNull(UserListConverter.toResponseEntity((UserDomain) null));
  }

  @Test
  public void toResponseEntityUserDomain_shouldMapFields() {
    UserDomain userDomain = new UserDomain();
    userDomain.setDomainId(7L);
    userDomain.setDomainName("domainName");

    UserDomainResponseEntity response = UserListConverter.toResponseEntity(userDomain);
    assertNotNull(response);
    assertEquals(userDomain.getDomainId(), response.getDomainId());
    assertEquals(userDomain.getDomainName(), response.getDomainName());
  }

  @Test
  public void toResponseEntityOrganization_shouldReturnNull_whenOrgIsNull() {
    assertNull(UserListConverter.toResponseEntity((Organization) null));
  }

  @Test
  public void toResponseEntityOrganization_shouldMapFields() {
    Organization org = new Organization();
    org.setId((int) 8L);
    org.setName("Org");
    org.setStatus(true);
    org.setType("type");

    OrganizationResponseEntity response = UserListConverter.toResponseEntity(org);
    assertNotNull(response);
    assertEquals(org.getId(), response.getId());
    assertEquals(org.getName(), response.getName());
    assertEquals(org.getStatus(), response.getStatus());
    assertEquals(org.getType(), response.getType());
  }
}
