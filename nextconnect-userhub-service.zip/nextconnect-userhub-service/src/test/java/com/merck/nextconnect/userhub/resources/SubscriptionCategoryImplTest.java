package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.repository.jpa.SubscriptionCategoryRepository;
import com.merck.nextconnect.userhub.resources.impl.SubscriptionCategoryImpl;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class SubscriptionCategoryImplTest {

  @Mock private SubscriptionCategoryRepository subscriptionCategoryRepository;

  @InjectMocks private SubscriptionCategoryImpl subscriptionCategoryImpl;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testFindOneByCategoryId() {
    // Arrange
    Long categoryId = 123L;
    SubscriptionCategory expectedCategory = new SubscriptionCategory();
    when(subscriptionCategoryRepository.findById(categoryId))
        .thenReturn(Optional.of(expectedCategory));

    // Act
    SubscriptionCategory actualCategory = subscriptionCategoryImpl.findOneByCategoryId(categoryId);

    // Verify
    verify(subscriptionCategoryRepository).findById(categoryId);
    assertEquals(expectedCategory, actualCategory);
  }
}
