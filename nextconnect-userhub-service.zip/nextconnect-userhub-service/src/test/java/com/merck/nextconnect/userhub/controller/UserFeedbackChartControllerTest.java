package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.model.UserFeedbackTrend;
import com.merck.nextconnect.userhub.model.UserRatingTrend;
import com.merck.nextconnect.userhub.resources.UserFeedBackChartService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
public class UserFeedbackChartControllerTest {

  @Mock private UserFeedBackChartService userFeedBackChartService;

  @InjectMocks private UserFeedbackChartController controller;

  @Test
  void testGetUserFeedBackTrend() {
    long duration = 6L; // Example duration
    UserFeedbackTrend feedbackTrendData = new UserFeedbackTrend();
    when(userFeedBackChartService.getUserFeedBackTrend(duration)).thenReturn(feedbackTrendData);
    ResponseEntity<?> responseEntity = controller.getUserFeedBackTrend(duration);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(feedbackTrendData, responseEntity.getBody());
  }

  @Test
  void testGetUserRatingTrend() {
    long duration = 6L; // Example duration
    UserRatingTrend ratingTrendData = new UserRatingTrend();
    when(userFeedBackChartService.getUserRatingTrend(duration)).thenReturn(ratingTrendData);
    ResponseEntity<?> responseEntity = controller.getUserRatingTrend(duration);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(ratingTrendData, responseEntity.getBody());
  }
}
