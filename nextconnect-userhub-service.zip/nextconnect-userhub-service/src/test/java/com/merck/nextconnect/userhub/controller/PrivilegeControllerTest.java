package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import com.merck.nextconnect.userhub.resources.Iprivileges;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class PrivilegeControllerTest {

  @Mock private Iprivileges iprivileges;

  @InjectMocks private PrivilegeController privilegeController;

  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testAddPrivilege() {
    PrivilegeInfo privilegeInfo = new PrivilegeInfo();
    ResponseEntity<?> responseEntity = privilegeController.addPrivilege(privilegeInfo);
    assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
  }

  @Test
  public void testDeletePrivilege() {
    ResponseEntity<?> responseEntity = privilegeController.deletePrivilege(123L);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
  }

  @Test
  public void testGetPrivileges() {
    List<Privilege> privileges = new ArrayList<>();
    Mockito.when(iprivileges.getAll(Mockito.anyString())).thenReturn(privileges);
    ResponseEntity<List<Privilege>> responseEntity = privilegeController.getPrivileges("");
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  public void testGetEntities() {
    List<Entities> entities = new ArrayList<>();
    Mockito.when(iprivileges.getAllEntities()).thenReturn(entities);
    ResponseEntity<List<Entities>> responseEntity = privilegeController.getEntities();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }
}
