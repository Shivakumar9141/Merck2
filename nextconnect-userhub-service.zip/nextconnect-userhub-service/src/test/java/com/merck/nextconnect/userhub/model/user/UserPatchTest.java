package com.merck.nextconnect.userhub.model.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserPatchTest {

  private UserPatch userPatch;

  @BeforeEach
  public void setUp() {
    userPatch = new UserPatch();
  }

  @Test
  public void testStatusGetterAndSetter() {
    assertNull(userPatch.getStatus());
    userPatch.setStatus(true);
    assertEquals(true, userPatch.getStatus());
  }

  @Test
  public void testRoleIdGetterAndSetter() {
    assertNull(userPatch.getRoleId());
    userPatch.setRoleId(123L);
    assertEquals(Long.valueOf(123), userPatch.getRoleId());
  }

  @Test
  public void testCountryIdGetterAndSetter() {
    assertNull(userPatch.getCountryId());
    userPatch.setCountryId(456);
    assertEquals(Integer.valueOf(456), userPatch.getCountryId());
  }

  @Test
  public void testTimeZoneIdGetterAndSetter() {
    assertNull(userPatch.getTimeZoneId());
    userPatch.setTimeZoneId(789);
    assertEquals(Integer.valueOf(789), userPatch.getTimeZoneId());
  }

  @Test
  public void testPhoneNumberGetterAndSetter() {
    assertNull(userPatch.getPhoneNumber());
    userPatch.setPhoneNumber("1234567890");
    assertEquals("1234567890", userPatch.getPhoneNumber());
  }

  @Test
  public void testLanguageIdGetterAndSetter() {
    assertNull(userPatch.getLanguageId());
    userPatch.setLanguageId(101);
    assertEquals(Integer.valueOf(101), userPatch.getLanguageId());
  }

  @Test
  public void testDateFormatIdGetterAndSetter() {
    assertNull(userPatch.getDateFormatId());
    userPatch.setDateFormatId(202);
    assertEquals(Integer.valueOf(202), userPatch.getDateFormatId());
  }

  @Test
  public void testFirstNameGetterAndSetter() {
    assertNull(userPatch.getFirstName());
    userPatch.setFirstName("John");
    assertEquals("John", userPatch.getFirstName());
  }

  @Test
  public void testLastNameGetterAndSetter() {
    assertNull(userPatch.getLastName());
    userPatch.setLastName("Doe");
    assertEquals("Doe", userPatch.getLastName());
  }

  @Test
  public void testIsdCodeGetterAndSetter() {
    assertNull(userPatch.getIsdCode());
    userPatch.setIsdCode("91");
    assertEquals("91", userPatch.getIsdCode());
  }

  @Test
  public void testBusinessDomainIdGetterAndSetter() {
    assertEquals(0, userPatch.getBusinessDomainId());
    userPatch.setBusinessDomainId(303);
    assertEquals(303, userPatch.getBusinessDomainId());
  }
}
