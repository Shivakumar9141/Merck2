package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.exception.CustomAuthenticationException;
import com.merck.nextconnect.authfilter.model.AuthToken;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.authfilter.repository.hazelcast.TokenStore;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.authfilter.util.JwtTokenValidator;
import com.merck.nextconnect.userhub.UserhubBaseTest;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.UserInfo;
import com.merck.nextconnect.userhub.model.user.UserLoginInfo;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IAuthentication;
import com.merck.nextconnect.userhub.response.SamlAuthResponse;
import com.merck.nextconnect.userhub.service.LoginService;
import com.merck.nextconnect.userhub.util.LoginUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.naming.AuthenticationException;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * This Junit class is used to test LoginController
 *
 * @author X240390 (bina.kumari@external.merckgroup.com)
 */
public class LoginControllerTest extends UserhubBaseTest {

  @InjectMocks private LoginController loginController;

  @Mock private LoginService loginService;

  private MockHttpServletRequest request = new MockHttpServletRequest();

  private MockHttpServletResponse response = new MockHttpServletResponse();

  @Mock private LoginUtil loginUtil;
  @Mock private IAuthentication authentication;
  @Mock private Authentication authentications;
  @Mock private AuthenticatedUser authUser;

  @Mock private JwtTokenValidator jwtTokenValidator;

  @Mock private JwtTokenGenerator jwtTokenGenerator;
  @Mock private TokenStore tokenStore;
  @Mock private UserRepository userRepo;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
    authentications = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentications);
    SecurityContextHolder.setContext(securityContext);
    authentications = SecurityContextHolder.getContext().getAuthentication();
    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);
    Mockito.lenient().when(authUser.getUsername()).thenReturn("testuser");

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testLogin() throws AuthenticationException, AccessDeniedException {
    Login login = new Login();
    Mockito.when(loginUtil.validateLoginRequest(Mockito.any())).thenReturn(true);
    AuthToken authToken = new AuthToken();
    authToken.setToken("accessToken");
    authToken.setRefreshToken("refreshToken");
    Mockito.when(authentication.login(login)).thenReturn(authToken);
    assertEquals(200, loginController.login(login).getStatusCode().value());
  }

  @Test
  public void testLoginValidateRequestFalse()
      throws AuthenticationException, AccessDeniedException {
    Login login = new Login();
    Mockito.when(loginUtil.validateLoginRequest(Mockito.any())).thenReturn(false);
    assertEquals(400, loginController.login(login).getStatusCode().value());
  }

  @Test
  public void testLoginSsoReply() throws AuthenticationException, IOException, ServletException {
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();
    request.setParameter("SAMLResponse", "SAMLResponse");
    samlAuthResponse.setStatusCode(200);
    samlAuthResponse.setStatusMessage("Success");
    AuthToken authToken = new AuthToken();
    authToken.setToken("accessToken");
    authToken.setRefreshToken("refreshToken");
    samlAuthResponse.setAuthToken(authToken);
    Mockito.when(authentication.loginBySaml(Mockito.anyString())).thenReturn(samlAuthResponse);
    loginController.loginSsoReply("SAMLResponse", request, response);
  }

  @Test
  public void testLoginSsoReplyFailure_Status400()
      throws AuthenticationException, IOException, ServletException {
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();
    samlAuthResponse.setStatusCode(400);
    samlAuthResponse.setStatusMessage("Success");
    AuthToken authToken = new AuthToken();
    authToken.setToken("accessToken");
    authToken.setRefreshToken("refreshToken");
    samlAuthResponse.setAuthToken(authToken);
    Mockito.when(authentication.loginBySaml(Mockito.anyString())).thenReturn(samlAuthResponse);
    loginController.loginSsoReply("SAMLResponse", request, response);
  }

  @Test
  public void testLoginSsoReplySAMLisNULL()
      throws AuthenticationException, IOException, ServletException {
    String samlResponse = "validSAMLResponse";
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();

    samlAuthResponse.setStatusCode(400); // Assume SAML response status code is 400

    Mockito.when(authentication.loginBySaml(samlResponse)).thenReturn(samlAuthResponse);

    loginController.loginSsoReply(samlResponse, request, response);
    verify(authentication).loginBySaml(samlResponse);
  }

  @Test
  public void testLoginWithoutSamlRequest() throws AuthenticationException, AccessDeniedException {
    Login login = new Login();
    Mockito.when(loginUtil.validateLoginRequest(Mockito.any())).thenReturn(true);
    AuthToken authToken = new AuthToken();
    authToken.setToken("accessToken");
    authToken.setRefreshToken("refreshToken");
    Mockito.when(authentication.login(login)).thenReturn(authToken);
    assertEquals(200, loginController.login(login).getStatusCode().value());
  }

  @Test
  public void testLoginAuthTokenNullForCredentials()
      throws AuthenticationException, AccessDeniedException {
    Login login = new Login();
    when(loginUtil.validateLoginRequest(login)).thenReturn(true);
    AuthToken authToken = new AuthToken();
    when(authentication.login(any())).thenReturn(authToken);

    try {
      loginController.login(login);
    } catch (LoginAuthenticationException e) {
      assertEquals("Username or Password is incorrect", e.getMessage());
    }
  }

  @Test
  public void testGetUserDetails_Success() throws ResourceNotFoundException {

    UserInfo expectedUserInfo = new UserInfo();
    // Mock with argument matchers to match any call pattern
    when(authentication.getUserInfo(anyLong(), anyString(), anyInt())).thenReturn(expectedUserInfo);
    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    ResponseEntity<UserInfo> responseEntity = loginController.getUserDetails();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedUserInfo, responseEntity.getBody());
  }

  @Test
  public void testGetUserLoginTypes_Success() throws ResourceNotFoundException {

    UserLoginInfo userLoginInfo = new UserLoginInfo();
    List<String> list = new ArrayList<>();
    list.add("A");
    list.add("B");
    userLoginInfo.setAuthenticationTypes(list);
    when(authentication.getLoginTypes("test")).thenReturn(userLoginInfo);
    ResponseEntity<UserLoginInfo> responseEntity = loginController.getUserLoginTypes("test");
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(userLoginInfo, responseEntity.getBody());
  }

  @Test
  public void testlogout_Success() throws ResourceNotFoundException {

    HttpServletRequest http = Mockito.mock(HttpServletRequest.class);

    when(http.getHeader("Authorization")).thenReturn("Bearer authToken");

    // JwtTokenValidator jwtTokenValidator = Mockito.mock(JwtTokenValidator.class);
    // jwtTokenValidator.setJwtTokenValidator(jwtTokenValidator);

    ResponseEntity<?> responseEntity = loginController.logout(http);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(jwtTokenValidator).invalidateToken("authToken");
  }

  @Test
  public void testGetAccessToken_Success()
      throws JSONException, CustomAuthenticationException, CustomException {
    String accessToken = "mockedAccessToken";
    when(jwtTokenGenerator.updateAccessToken()).thenReturn(accessToken);

    ResponseEntity<String> response = loginController.getAccessToken();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertTrue(response.getBody().contains(accessToken));
  }

  @Test
  public void testGetAccessTokenFromCacheForSSO_Success() throws Exception {
    // Arrange
    Map<String, String> atomCacheId = new HashMap<>();
    String cacheIdValue = "testCacheId";
    atomCacheId.put("atomCacheId", cacheIdValue);
    String expectedToken = "cachedAuthToken";

    when(authentication.getTokenFromCacheByHash(cacheIdValue)).thenReturn(expectedToken);
    doNothing().when(tokenStore).removeAuthToken(cacheIdValue);

    // Act
    ResponseEntity<String> response = loginController.getAccessTokenFromCacheForSSO(atomCacheId);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(expectedToken, response.getBody());
    verify(authentication).getTokenFromCacheByHash(cacheIdValue);
    verify(tokenStore).removeAuthToken(cacheIdValue);
  }

  @Test
  public void testGetAccessTokenFromCacheForSSO_EmptyMap() throws CustomException {
    // Arrange
    Map<String, String> emptyMap = new HashMap<>();

    // Act
    ResponseEntity<String> response = loginController.getAccessTokenFromCacheForSSO(emptyMap);

    // Assert
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    verifyNoInteractions(authentication);
    verifyNoInteractions(tokenStore);
  }

  @Test
  public void testGetAccessTokenFromCacheForSSO_NullMap() throws CustomException {
    // Act
    ResponseEntity<String> response = loginController.getAccessTokenFromCacheForSSO(null);

    // Assert
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    verifyNoInteractions(authentication);
    verifyNoInteractions(tokenStore);
  }

  @Test
  public void testGetAccessTokenFromCacheForSSO_ExceptionThrown() throws Exception {
    // Arrange
    Map<String, String> atomCacheId = new HashMap<>();
    String cacheIdValue = "testCacheId";
    atomCacheId.put("atomCacheId", cacheIdValue);

    when(authentication.getTokenFromCacheByHash(cacheIdValue))
        .thenThrow(new RuntimeException("Test exception"));

    // Act
    ResponseEntity<String> response = loginController.getAccessTokenFromCacheForSSO(atomCacheId);

    // Assert
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    verify(authentication).getTokenFromCacheByHash(cacheIdValue);
    verifyNoInteractions(tokenStore);
  }

  @Test
  public void testValidateToken_Success() {
    // Arrange
    String jti = "valid-token";
    JwtUser jwtUser = new JwtUser();
    jwtUser.setId(123L);
    UserProfile expectedUserProfile = new UserProfile();

    when(jwtTokenValidator.parseToken(jti)).thenReturn(jwtUser);
    when(userRepo.getUserById(jwtUser.getId())).thenReturn(expectedUserProfile);

    // Act
    ResponseEntity<UserProfile> response = loginController.validateToken(jti);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(expectedUserProfile, response.getBody());
    verify(jwtTokenValidator).parseToken(jti);
    verify(userRepo).getUserById(jwtUser.getId());
  }

  @Test
  public void testValidateToken_AuthenticationException() {
    // Arrange
    String jti = "invalid-token";
    com.merck.nextconnect.authfilter.exception.LoginAuthenticationException authException =
        new com.merck.nextconnect.authfilter.exception.LoginAuthenticationException(
            "Invalid token");

    when(jwtTokenValidator.parseToken(jti)).thenThrow(authException);

    // Act & Assert
    LoginAuthenticationException thrown =
        assertThrows(LoginAuthenticationException.class, () -> loginController.validateToken(jti));

    assertEquals("Invalid token", thrown.getMessage());
    verify(jwtTokenValidator).parseToken(jti);
    verify(userRepo, never()).getUserById(anyLong());
  }
}
