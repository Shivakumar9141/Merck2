package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.repo.jdbc.CoveredProductRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.GenericJdbc;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.impl.AutoCreationimpl;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserHubAsyncService;
import com.merck.nextconnect.userhub.validator.UserhubValidator;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import com.merck.nextconnect.utils.model.OrgAndUserDetailResponse;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

/** Converted to JUnit 5 */
@ExtendWith(MockitoExtension.class)
class AutoCreationimplTest {

  @Mock private UserhubValidator userhubValidator;

  @Mock private IOrganization organization;

  @Mock private UserRepository userRepo;

  @Mock private RoleRepository roleRepo;

  @Mock private IUser iuser;

  @InjectMocks AutoCreationimpl autoCreationService;

  @Mock private IprivilegeProvider privilegeProvider;

  @Mock CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;

  @Mock UserHubAsyncService userHubAsyncService;

  @Mock GenericJdbc genericJdbc;

  @BeforeEach
  void setup() {
    // MockitoExtension initializes mocks; set the iuser mock into autoCreationService (parity with
    // original)
    ReflectionTestUtils.setField(autoCreationService, "iuser", iuser);
  }

  @Test
  void testCreateNewOrgAndUser_Success() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service contract");
    orgAndUserDetail.setDeviceId(2L);

    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("Active");
    userProfile.setUserId(1);
    userProfile.setOrg(new Organization(1));

    OrgInfo orgInfo = new OrgInfo();
    orgInfo.setType(Constants.CUSTOMER);
    orgInfo.setTemplate(Constants.LABWATER_CUSTOMER_TEMPLATE);
    orgInfo.setName("ORG_null_null");
    orgInfo.setDesc(
        StringUtils.isBlank(orgAndUserDetail.getCustomerName())
            ? "Account/Customer name was not provided"
            : orgAndUserDetail.getCustomerName());
    orgInfo.setHistoricalDataSubscription(24L);
    orgInfo.setStatus(true);
    orgInfo.setAutoCreated(true);
    orgInfo.setCreatedVia(orgAndUserDetail.getInvitedVia());

    List<Long> userDeviceIds = new ArrayList<>();
    userDeviceIds.add(1L);

    when(organization.getOrgByName(anyString())).thenReturn(null);
    when(userRepo.getUserByEmail(orgAndUserDetail.getEmail())).thenReturn(userProfile);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(organization.create(orgInfo)).thenReturn(1);
    when(privilegeProvider.getAuthUserDevices(userProfile.getUserId())).thenReturn(userDeviceIds);
    doNothing().when(userHubAsyncService).updateMymilliqActivtedCheckboxForDeviceAutoAssignment(2L);
    doNothing().when(genericJdbc).updateDeviceAccessRequestStatusApproved(2L, 1L);

    // Act
    OrgAndUserDetailResponse response = autoCreationService.create(orgAndUserDetail);

    // Assert
    assertNotNull(response);
  }

  @Test
  void testCreateNewOrgAndUser_isValidOrgDetailsPresent_False() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();

    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(false);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(true);

    assertThrows(DataValidationException.class, () -> autoCreationService.create(orgAndUserDetail));
  }

  @Test
  void testCreateNewOrgAndUser_isValidUserInviteDetailsPresent_False() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service contract");

    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("status");
    userProfile.setUserId(1);
    userProfile.setOrg(new Organization(1));

    when(organization.getOrgByName(anyString())).thenReturn(null);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(false);
    when(organization.create(any(OrgInfo.class))).thenReturn(0);

    assertThrows(CustomException.class, () -> autoCreationService.create(orgAndUserDetail));
  }

  @Test
  void testCreateNewOrgAndUser_OrgId_0() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service");

    when(organization.getOrgByName(anyString())).thenReturn(new Organization(0));
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);

    // expecting CustomException based on original behavior
    assertThrows(CustomException.class, () -> autoCreationService.create(orgAndUserDetail));
  }

  @Test
  void testCreateNewOrgAndUser_OrgId_Null() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service");

    when(organization.getOrgByName(anyString())).thenReturn(null);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);

    // original expected DataValidationException when orgId missing
    assertThrows(DataValidationException.class, () -> autoCreationService.create(orgAndUserDetail));
  }

  @Test
  void testCreateNewOrgAndUser_UserProfile_Null() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service");
    orgAndUserDetail.setDealer(true);

    UserDetails userDetails = new UserDetails();
    userDetails.setDomainId(1);
    userDetails.setEmail("test@example.com");
    userDetails.setInvitedVia("Service");
    userDetails.setAutoCreated(true);
    userDetails.setLoginText("test@example.com");
    userDetails.setOrgId(1);
    userDetails.setRoleId(1);

    UserDomain userdomain = new UserDomain();
    userdomain.setDomainId(1);
    List<UserDomain> userDomainList = new ArrayList<>();
    userDomainList.add(userdomain);

    when(organization.getOrgByName(anyString())).thenReturn(new Organization(1));
    when(userRepo.getUserByEmail(orgAndUserDetail.getEmail())).thenReturn(null);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(true);

    // original expected a generic Exception
    assertThrows(Exception.class, () -> autoCreationService.create(orgAndUserDetail));
  }

  @Test
  void testCreateUser_Org_Status_False() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service");
    orgAndUserDetail.setDealer(true);

    Organization org = new Organization();
    org.setStatus(false);
    org.setId(1);

    when(organization.getOrgByName(anyString())).thenReturn(org);
    when(userRepo.getUserByEmail(orgAndUserDetail.getEmail())).thenReturn(null);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(true);

    OrgAndUserDetailResponse response = autoCreationService.create(orgAndUserDetail);
    assertNotNull(response);
  }

  @Test
  void testCheckAndAssignDevice_Else() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service contract");

    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("status");
    userProfile.setUserId(1);
    userProfile.setOrg(new Organization(2));

    when(organization.getOrgByName(anyString())).thenReturn(null);
    when(userRepo.getUserByEmail(orgAndUserDetail.getEmail())).thenReturn(userProfile);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(organization.create(any(OrgInfo.class))).thenReturn(1);

    OrgAndUserDetailResponse response = autoCreationService.create(orgAndUserDetail);
    assertNotNull(response);
  }

  @Test
  void testAssignDeviceToUser_Else() throws Exception {
    OrgAndUserDetail orgAndUserDetail = new OrgAndUserDetail();
    orgAndUserDetail.setEmail("test@example.com");
    orgAndUserDetail.setInvitedVia("Service contract");
    orgAndUserDetail.setSmServiceContractId("1");

    UserProfile userProfile = new UserProfile();
    userProfile.setStatus("Active");
    userProfile.setUserId(1);
    userProfile.setOrg(new Organization(1));

    List<Long> userDeviceIds = new ArrayList<>();
    userDeviceIds.add(1L);

    when(organization.getOrgByName(anyString())).thenReturn(null);
    when(userRepo.getUserByEmail(orgAndUserDetail.getEmail())).thenReturn(userProfile);
    when(userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail)).thenReturn(true);
    when(organization.create(any(OrgInfo.class))).thenReturn(1);
    when(privilegeProvider.getAuthUserDevices(userProfile.getUserId())).thenReturn(userDeviceIds);

    when(coveredProductRepositoryJdbc.getcoveredDevicesUnderSmServiceContract(
            orgAndUserDetail.getSmServiceContractId()))
        .thenReturn(userDeviceIds);

    OrgAndUserDetailResponse response = autoCreationService.create(orgAndUserDetail);
    assertNotNull(response);
  }
}
