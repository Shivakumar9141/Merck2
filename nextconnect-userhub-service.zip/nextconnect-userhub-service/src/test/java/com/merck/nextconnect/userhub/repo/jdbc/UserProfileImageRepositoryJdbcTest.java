package com.merck.nextconnect.userhub.repo.jdbc;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.exception.CustomException;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@ExtendWith(MockitoExtension.class)
public class UserProfileImageRepositoryJdbcTest {

  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @InjectMocks private UserProfileImageRepositoryJdbc userProfileImageRepositoryJdbc;

  @BeforeEach
  public void setUp() {
    // MockitoExtension initializes mocks, nothing to do here
  }

  @Test
  public void testFetchUserThumbnailBlobImage_Success() {
    // Arrange
    Long userId = 123L;
    String expectedImage = "base64EncodedThumbnailImage";
    when(namedParameterJdbcTemplate.queryForObject(
            eq(UserProfileImageRepositoryJdbc.SQL_SELECT_THUMBNAIL_BLOB_IMAGE_BY_USER_ID),
            any(Map.class),
            eq(String.class)))
        .thenReturn(expectedImage);

    // Act
    String result = userProfileImageRepositoryJdbc.fetchUserThumbnailBlobImage(userId);

    // Assert
    assertEquals(expectedImage, result);
  }

  @Test
  public void testFetchUserThumbnailBlobImage_EmptyResult() {
    // Arrange
    Long userId = 123L;
    when(namedParameterJdbcTemplate.queryForObject(
            eq(UserProfileImageRepositoryJdbc.SQL_SELECT_THUMBNAIL_BLOB_IMAGE_BY_USER_ID),
            any(Map.class),
            eq(String.class)))
        .thenThrow(new EmptyResultDataAccessException(1));

    // Act
    String result = userProfileImageRepositoryJdbc.fetchUserThumbnailBlobImage(userId);

    // Assert
    assertNull(result);
  }

  @Test
  public void testFetchUserThumbnailBlobImage_Exception() {
    // Arrange
    Long userId = 123L;
    when(namedParameterJdbcTemplate.queryForObject(
            eq(UserProfileImageRepositoryJdbc.SQL_SELECT_THUMBNAIL_BLOB_IMAGE_BY_USER_ID),
            any(Map.class),
            eq(String.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act
    String result = userProfileImageRepositoryJdbc.fetchUserThumbnailBlobImage(userId);

    // Assert
    assertNull(result);
  }

  @Test
  public void testFetchUserBlobImage_Success() throws CustomException {
    // Arrange
    Long userId = 123L;
    String expectedImage = "base64EncodedBlobImage";
    when(namedParameterJdbcTemplate.queryForObject(
            eq(UserProfileImageRepositoryJdbc.SQL_SELECT_BLOB_IMAGE_BY_USER_ID),
            any(Map.class),
            eq(String.class)))
        .thenReturn(expectedImage);

    // Act
    String result = userProfileImageRepositoryJdbc.fetchUserBlobImage(userId);

    // Assert
    assertEquals(expectedImage, result);
  }

  @Test
  public void testFetchUserBlobImage_EmptyResult() throws CustomException {
    // Arrange
    Long userId = 123L;
    when(namedParameterJdbcTemplate.queryForObject(
            eq(UserProfileImageRepositoryJdbc.SQL_SELECT_BLOB_IMAGE_BY_USER_ID),
            any(Map.class),
            eq(String.class)))
        .thenThrow(new EmptyResultDataAccessException(1));

    // Act
    String result = userProfileImageRepositoryJdbc.fetchUserBlobImage(userId);

    // Assert
    assertNull(result);
  }

  @Test
  public void testFetchUserBlobImage_Exception() {
    // Arrange
    Long userId = 123L;
    when(namedParameterJdbcTemplate.queryForObject(
            eq(UserProfileImageRepositoryJdbc.SQL_SELECT_BLOB_IMAGE_BY_USER_ID),
            any(Map.class),
            eq(String.class)))
        .thenThrow(new RuntimeException("Database error"));

    // Act & Assert
    assertThrows(
        CustomException.class, () -> userProfileImageRepositoryJdbc.fetchUserBlobImage(userId));
  }

  @Test
  public void testDeleteUserImage_Success() throws CustomException {
    // Arrange
    Long userId = 123L;

    // Act
    userProfileImageRepositoryJdbc.deleteUserImage(userId);

    // Assert
    verify(namedParameterJdbcTemplate)
        .update(
            eq(UserProfileImageRepositoryJdbc.SQL_DELETE_USER_PROFILE_IMAGE_BY_USER_ID),
            any(Map.class));
  }

  @Test
  public void testDeleteUserImage_Exception() {
    // Arrange
    Long userId = 123L;
    doThrow(new RuntimeException("Database error"))
        .when(namedParameterJdbcTemplate)
        .update(anyString(), any(Map.class));

    // Act & Assert
    assertThrows(
        CustomException.class, () -> userProfileImageRepositoryJdbc.deleteUserImage(userId));
  }
}
