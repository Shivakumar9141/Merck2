package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.resources.IRegion;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Region;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class RegionControllerTest {

  @Mock private IRegion iRegion;

  @InjectMocks private RegionController regionController;

  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties (lenient to avoid unnecessary stubbing warnings)
    Mockito.lenient().when(authUser.getId()).thenReturn("123");
    Mockito.lenient().when(authUser.getOrgId()).thenReturn(5);
    Mockito.lenient().when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetRegions() {
    List<Region> regions = new ArrayList<>();
    regions.add(new Region(1, "Region1"));
    regions.add(new Region(2, "Region2"));

    when(iRegion.getRegions(Constants.EMPTY_STRING)).thenReturn(regions);

    ResponseEntity<List<Region>> responseEntity = regionController.getRegions("");
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(regions, responseEntity.getBody());
  }

  @Test
  public void testGetRegionsWithNullSearchBy() {
    List<Region> regions = new ArrayList<>();
    regions.add(new Region(1, "Region1"));
    regions.add(new Region(2, "Region2"));

    when(iRegion.getRegions(Constants.EMPTY_STRING)).thenReturn(regions);
    ResponseEntity<List<Region>> responseEntity = regionController.getRegions(null);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(regions, responseEntity.getBody());
  }
}
