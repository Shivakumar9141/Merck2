package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.repository.jpa.UserDetailsRepository;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UsersListingFacets;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.model.user.UserList;
import com.merck.nextconnect.userhub.model.user.UserPatch;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserProfileSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserSpecification;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserImplTest {

  @Mock private UserRepository userRepo;

  @Mock private RoleRepository roleRepo;

  @Mock private OrganizationRepository orgRepo;

  @Mock private CountryRepository countryRepository;

  @Mock private UserProfileSettingsRepository userProfileSettingsRepository;

  @Mock private JwtTokenGenerator jwtTokenGenerator;

  @Mock private UserSpecification userSpecification;

  @Mock private PhoneNumberValidator phoneNumberValidator;

  @Mock private IOrgPermissions orgPermissions;

  @Mock private IprivilegeProvider privilegeProvider;

  @Mock private UserOrgPrivileges userOrgPrivileges;

  @Mock private UserRolePrivileges userRolePrivileges;

  @Mock private SecurityContext securityContext;

  @Mock
  private com.merck.nextconnect.authfilter.repository.jpa.AuthUserDevicePrivilegeRepository
      userDevicePrivilegeRepo;

  @Mock
  private com.merck.nextconnect.userhub.repo.jdbc.BusinessDomainRepositoryJdbc
      businessDomainRepositoryJdbc;

  @Mock
  private com.merck.nextconnect.userhub.repository.jpa.UserSubscriptionRepository
      userSubscriptionRepository;

  @Mock private UserDetailsRepository userCredentialsRepo;

  @Mock
  private com.merck.nextconnect.userhub.repo.jdbc.UserProfileImageRepositoryJdbc
      userProfileImageRepositoryJdbc;

  @Mock private com.merck.nextconnect.userhub.mail.MailTemplate mailTemplate;

  @Mock
  private com.merck.nextconnect.userhub.repository.jpa.RoleEntityPrivilegesRepository
      roleEntityPrivilegesRepository;

  @InjectMocks private UserImpl userImpl;

  private AuthenticatedUser authUser;
  private UserProfile userProfile;
  private Organization organization;
  private Role role;
  private Country country;
  private Language language;
  private DateFormat dateFormat;
  private UserDomain userDomain;

  @BeforeEach
  void setUp() {
    // Setup auth user
    List<SimpleGrantedAuthority> authorities = new ArrayList<>();
    authorities.add(new SimpleGrantedAuthority("READ_USER"));
    authorities.add(new SimpleGrantedAuthority("assign_device"));
    authorities.add(new SimpleGrantedAuthority("assign_territories"));
    authorities.add(new SimpleGrantedAuthority("has_territories"));

    com.merck.nextconnect.authfilter.model.JwtUser jwtUser =
        new com.merck.nextconnect.authfilter.model.JwtUser();
    jwtUser.setId(1L);
    jwtUser.setRoleId(1L);
    jwtUser.setOrgId(1);
    jwtUser.setUsername("testuser");
    jwtUser.setRole("SUPER_ADMIN");
    jwtUser.setSystemDefinedRole(true);

    authUser = new AuthenticatedUser(jwtUser, "password", authorities);

    // Setup organization
    organization = new Organization();
    organization.setId(1);
    organization.setName("Test Org");
    organization.setType("Business Unit");
    organization.setStatus(true);

    // Setup role
    role = new Role();
    role.setRoleId(1L);
    role.setName("SUPER_ADMIN");
    role.setSystemDefined(true);
    role.setOrg(organization);

    // Setup country
    country = new Country();
    country.setId(1);
    country.setCountryName("United States");
    country.setCountryCode("US");

    // Setup language
    language = new Language();
    language.setId(1);
    language.setValue("English");
    language.setCode("en");

    // Setup date format
    dateFormat = new DateFormat();
    dateFormat.setId(1);
    dateFormat.setDateFormat("MM/dd/yyyy");

    // Setup user domain
    userDomain = new UserDomain();
    userDomain.setDomainId(1);
    userDomain.setAuthenticationProvider(Constants.NEXTCONNECT_AUTH);

    // Setup user profile
    userProfile = new UserProfile();
    userProfile.setUserId(1L);
    userProfile.setLoginName("testuser");
    userProfile.setFirstName("Test");
    userProfile.setLastName("User");
    userProfile.setEmail("test@example.com");
    userProfile.setIsdCode("1");
    userProfile.setPhone("1234567890");
    userProfile.setOrg(organization);
    userProfile.setRole(role);
    userProfile.setCountry(country);
    userProfile.setLanguage(language);
    userProfile.setDateFormat(dateFormat);
    userProfile.setUserDomain(userDomain);
    userProfile.setStatus("Active");
    userProfile.setCreatedOn(Timestamp.from(Instant.now()));
    userProfile.setInvitedOrActivatedTs(Timestamp.from(Instant.now()));
    userProfile.setConsentStatus(true);
    userProfile.setPrivacyPolicyStatus(true);
    userProfile.setDeleted(false);

    // Mock SecurityContextHolder
    org.springframework.security.core.Authentication authentication =
        Mockito.mock(org.springframework.security.core.Authentication.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(authUser);
    SecurityContextHolder.setContext(securityContext);
  }

  @Test
  void testGetAll_Success() {
    // Arrange
    FetchCriteria fetchCriteria = new FetchCriteria();
    fetchCriteria.setPageNo(1);
    fetchCriteria.setPageLimit(10);

    List<UserProfile> userProfiles = Collections.singletonList(userProfile);
    Page<UserProfile> pagedUsers = new PageImpl<>(userProfiles, PageRequest.of(0, 10), 1);

    when(userSpecification.specification(any(FetchCriteria.class)))
        .thenReturn((Specification<UserProfile>) (root, query, cb) -> null);
    when(userRepo.findAll(any(Specification.class), any(PageRequest.class))).thenReturn(pagedUsers);
    when(securityContext.getAuthentication().getPrincipal()).thenReturn(authUser);

    // Act
    UserList result = userImpl.getAll(fetchCriteria);

    // Assert
    assertNotNull(result);
    assertEquals("1", result.getTotalPages());
    assertEquals(1, result.getRecordCount());
    assertEquals(1, result.getUsers().size());
  }

  @Test
  void testUpdateStatusAndRole_SelfUpdate_throwsAccessDeniedException() throws Exception {
    // Arrange
    UserPatch userPatch = new UserPatch();
    userPatch.setStatus(true);

    when(userRepo.getUserById(anyLong(), anyList())).thenReturn(userProfile);

    // Act & Assert
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      assertThrows(AccessDeniedException.class, () -> userImpl.updateStatusAndRole(1L, userPatch));
    }
  }

  @Test
  void testDelete_SelfDelete_throwsAccessDeniedException() throws Exception {
    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
      assertThrows(AccessDeniedException.class, () -> userImpl.delete(1L));
    }
  }

  @Test
  void testValidateMailId_Success() throws Exception {
    // Arrange
    String email = "test@example.com";
    List<UserProfile> userProfiles = Collections.singletonList(userProfile);

    when(userRepo.findByEmailAndStatusAndDeleted(eq(email), anyString(), eq(false)))
        .thenReturn(userProfiles);
    when(userSubscriptionRepository.findByEmailAndDeletedAndUserProfileDeleted(
            eq(email), eq(false), eq(false)))
        .thenReturn(new ArrayList<>());

    // Act
    boolean result = userImpl.validateMailId(email);

    // Assert
    assertTrue(result);
  }

  @Test
  void testValidateMailId_UserDoesNotExist_throwsDataValidationException() throws Exception {
    // Arrange
    String email = "nonexistent@example.com";
    when(userRepo.findByEmailAndStatusAndDeleted(anyString(), anyString(), anyBoolean()))
        .thenReturn(new ArrayList<>());

    // Act & Assert
    assertThrows(DataValidationException.class, () -> userImpl.validateMailId(email));
  }

  @Test
  void testFetchOne_Success() {
    // Arrange
    Long userId = 1L;

    when(userRepo.getUserById(eq(userId), anyList())).thenReturn(userProfile);

    // Act
    UserProfile result = userImpl.fetchOne(userId);

    // Assert
    assertNotNull(result);
    assertEquals("testuser", result.getLoginName());
    assertEquals("test@example.com", result.getEmail());
  }

  @Test
  void testFetchOne_UserNotFound() {
    // Arrange
    Long userId = 999L;
    when(userRepo.getUserById(eq(userId), anyList())).thenReturn(null);

    // Act & Assert
    assertThrows(Exception.class, () -> userImpl.fetchOne(userId));
  }

  @Test
  void testGenerateToken_Success() {
    // Arrange
    Long userId = 1L;

    when(userRepo.getUserById(eq(userId), anyList())).thenReturn(userProfile);

    // Act
    String token = userImpl.generateToken(userId);

    // Assert
    assertNotNull(token);
    // Verify the token is a valid UUID format (jti)
    assertFalse(token.isEmpty());
    Mockito.verify(jwtTokenGenerator, Mockito.times(1))
        .generateAndPersistTokenForPassword(anyString(), anyString(), eq(userId));
  }

  @Test
  void testGetUserListingFacets_Success() {
    // Arrange
    List<UserProfile> userProfiles = Collections.singletonList(userProfile);
    when(userSpecification.specification(any(FetchCriteria.class)))
        .thenReturn((Specification<UserProfile>) (root, query, cb) -> null);
    when(userRepo.findAll(any(Specification.class))).thenReturn(userProfiles);

    // Act
    UsersListingFacets result = userImpl.getUserListingFacets();

    // Assert
    assertNotNull(result);
  }

  @Test
  void testFindByEmailAndStatus_Success() {
    // Arrange
    String email = "test@example.com";
    String status = "Active";

    when(userRepo.findByEmailAndStatus(eq(email), eq(status))).thenReturn(userProfile);

    // Act
    UserProfile result = userImpl.findByEmailAndStatus(email, status);

    // Assert
    assertNotNull(result);
    assertEquals(email, result.getEmail());
    assertEquals(status, result.getStatus());
  }

  @Test
  void testFindByEmailAndStatus_NotFound_returnsNull() {
    // Arrange
    String email = "notfound@example.com";
    String status = "Active";

    when(userRepo.findByEmailAndStatus(eq(email), eq(status))).thenReturn(null);

    // Act
    UserProfile result = userImpl.findByEmailAndStatus(email, status);

    // Assert
    assertNull(result);
  }

  @Test
  void testSearchMailId_Success() {
    // Arrange
    String mailId = "test@example.com";
    List<String> expectedEmails = List.of("test@example.com", "test.user@example.com");

    when(userRepo.findByEmailStartingWithIgnoreCase(eq(mailId))).thenReturn(expectedEmails);

    // Act
    List<String> result = userImpl.searchMailId(mailId);

    // Assert
    assertNotNull(result);
    assertEquals(2, result.size());
    assertTrue(result.contains("test@example.com"));
  }

  //    @Test
  //    void testDelete_Success() throws Exception {
  //        // Arrange
  //        Long userId = 2L; // Different from authenticated user's ID
  //        UserProfile targetUser = new UserProfile();
  //        targetUser.setUserId(userId);
  //        targetUser.setEmail("target@example.com");
  //        targetUser.setOrg(organization);
  //        targetUser.setRole(role);
  //        targetUser.setStatus("Active");
  //
  //        when(userRepo.getUserById(eq(userId), anyList())).thenReturn(targetUser);
  //        when(userRepo.save(any(UserProfile.class))).thenReturn(targetUser);
  //        when(userDevicePrivilegeRepo.getDevices(eq(userId))).thenReturn(new ArrayList<>());
  //        when(userSubscriptionRepository.findByEmailOrCreatedByAndDeleted(
  //                eq("target@example.com"), eq("target@example.com")))
  //                .thenReturn(new ArrayList<>());
  //
  //        try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
  //            utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);
  //
  //            // Act
  //            userImpl.delete(userId);
  //
  //            // Assert - verify that save was called (soft delete)
  //            Mockito.verify(userRepo, Mockito.times(1)).save(any(UserProfile.class));
  //        }
  //    }

  @Test
  void testDelete_UserNotFound() {
    // Arrange
    Long userId = 999L;
    when(userRepo.getUserById(eq(userId), anyList())).thenReturn(null);

    try (MockedStatic<UserhubUtils> utilities = Mockito.mockStatic(UserhubUtils.class)) {
      utilities.when(UserhubUtils::getAuthenticatedUser).thenReturn(authUser);

      // Act & Assert
      assertThrows(Exception.class, () -> userImpl.delete(userId));
    }
  }

  @Test
  void testValidateConsent_Success() {
    // Arrange
    com.merck.nextconnect.userhub.model.user.UserDetails userDetails =
        new com.merck.nextconnect.userhub.model.user.UserDetails();
    userDetails.setConsentStatus(true);
    userDetails.setPrivacyPolicyStatus(true);

    // Act & Assert - should not throw exception
    assertDoesNotThrow(() -> userImpl.validateConsent(userDetails));
  }

  @Test
  void testValidateConsent_MissingConsent_throwsDataValidationException() {
    // Arrange
    com.merck.nextconnect.userhub.model.user.UserDetails userDetails =
        new com.merck.nextconnect.userhub.model.user.UserDetails();
    userDetails.setConsentStatus(false);

    // Act & Assert
    assertThrows(DataValidationException.class, () -> userImpl.validateConsent(userDetails));
  }
}
