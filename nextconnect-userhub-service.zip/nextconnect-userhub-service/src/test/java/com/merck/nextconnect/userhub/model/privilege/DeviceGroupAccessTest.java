package com.merck.nextconnect.userhub.model.privilege;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DeviceGroupAccessTest {

  private DeviceGroupAccess deviceGroupAccess;

  @BeforeEach
  public void setUp() {
    deviceGroupAccess = new DeviceGroupAccess();
  }

  @Test
  public void testResourceId() {
    long resourceId = 123L;
    deviceGroupAccess.setResourceId(resourceId);
    assertEquals(resourceId, deviceGroupAccess.getResourceId());
  }

  @Test
  public void testPrivilegeId() {
    long privilegeId = 456L;
    deviceGroupAccess.setPrivilegeId(privilegeId);
    assertEquals(privilegeId, deviceGroupAccess.getPrivilegeId());
  }

  @Test
  public void testLocationId() {
    long locationId = 789L;
    deviceGroupAccess.setLocationId(locationId);
    assertEquals(locationId, deviceGroupAccess.getLocationId());
  }

  @Test
  public void testDeviceGroupId() {
    long deviceGroupId = 101L;
    deviceGroupAccess.setDeviceGroupId(deviceGroupId);
    assertEquals(deviceGroupId, deviceGroupAccess.getDeviceGroupId());
  }
}
