package com.merck.nextconnect.userhub.resources;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.repository.jpa.DateFormatRepository;
import com.merck.nextconnect.userhub.resources.impl.DateFormatImpl;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DateFormatImplTest {

  @Mock private DateFormatRepository dateFormatRepo;

  @InjectMocks private DateFormatImpl dateFormatImpl;

  @Test
  void testGetDateFormats() {
    // Given
    List<DateFormat> mockDateFormatList = new ArrayList<>();
    DateFormat mockDateFormat1 = new DateFormat();
    mockDateFormat1.setId(1);
    mockDateFormat1.setDateFormat("dd/MM/yyyy");
    mockDateFormatList.add(mockDateFormat1);

    when(dateFormatRepo.findAll()).thenReturn(mockDateFormatList);

    // When
    List<DateFormat> result = dateFormatImpl.getDateFormats();

    // Then
    assertEquals(mockDateFormatList.size(), result.size());
    assertEquals(mockDateFormatList.get(0).getId(), result.get(0).getId());
    assertEquals(mockDateFormatList.get(0).getDateFormat(), result.get(0).getDateFormat());
  }
}
