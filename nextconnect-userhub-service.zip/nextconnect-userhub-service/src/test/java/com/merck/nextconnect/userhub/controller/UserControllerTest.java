package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.UserhubBaseTest;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UsersListingFacets;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.model.HotlineUserType;
import com.merck.nextconnect.userhub.model.UserProfileImageDTO;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.user.Credentials;
import com.merck.nextconnect.userhub.model.user.ResetCredential;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.model.user.UserEmail;
import com.merck.nextconnect.userhub.model.user.UserList;
import com.merck.nextconnect.userhub.model.user.UserPatch;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import com.merck.nextconnect.userhub.response.UserListResponseEntity;
import com.merck.nextconnect.userhub.response.UserProfileResponseEntity;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * This Junit class is used to test UserController
 *
 * @author X240390 (bina.kumari@external.merckgroup.com)
 */
public class UserControllerTest extends UserhubBaseTest {

  @InjectMocks UserController userController;

  @Mock IUser iuser;

  List<UserProfile> users = new ArrayList<>();

  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @Before
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties
    when(authUser.getId()).thenReturn("123");

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetUser() {
    assertTrue(true);
    // assertEquals("testName2",
    // userController.getUser(1).getBody().getFirstName());
    // assertEquals("testLocation2",
    // userController.getUser(1).getBody().getLocation());
    // assertEquals("testRole",
    // userController.getUser(1).getBody().getRole().getName());

  }

  @Test
  public void testGetAllUsers() {
    // Setup
    String sortBy = "name";
    String orderBy = "asc";
    List<String> filterBy = List.of("active:true");
    String searchBy = "john";
    Integer page = 2;
    Integer pageLimit = 10;

    UserList mockUserList = new UserList();
    List<UserListResponseEntity> mockUsers = new ArrayList<>();
    mockUserList.setUsers(mockUsers);
    mockUserList.setTotalPages("5");
    mockUserList.setRecordCount(45);

    FetchCriteria expectedCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    when(iuser.getAll(any(FetchCriteria.class))).thenReturn(mockUserList);

    // Execute
    ResponseEntity<List<UserListResponseEntity>> response =
        userController.getAllUsers(sortBy, orderBy, filterBy, searchBy, page, pageLimit);

    // Verify
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(mockUsers, response.getBody());
    assertEquals("5", response.getHeaders().getFirst("x-pagination-count"));
    assertEquals("45", response.getHeaders().getFirst("x-record-count"));
    verify(iuser)
        .getAll(
            argThat(
                criteria ->
                    criteria.getSortBy().equals(expectedCriteria.getSortBy())
                        && criteria.getOrderBy().equals(expectedCriteria.getOrderBy())
                        && criteria.getFilterBy().equals(expectedCriteria.getFilterBy())
                        && criteria.getSearchBy().equals(expectedCriteria.getSearchBy())
                        && criteria.getPageNo() == expectedCriteria.getPageNo()
                        && criteria.getPageLimit() == expectedCriteria.getPageLimit()));
  }

  @Test
  public void testGetAllUsers_WithDefaultPagination() {
    // Setup
    UserList mockUserList = new UserList();
    List<UserListResponseEntity> mockUsers = new ArrayList<>();
    mockUserList.setUsers(mockUsers);
    mockUserList.setTotalPages("1");
    mockUserList.setRecordCount(10);

    when(iuser.getAll(any(FetchCriteria.class))).thenReturn(mockUserList);

    // Execute - with null page and pageLimit
    ResponseEntity<List<UserListResponseEntity>> response =
        userController.getAllUsers(null, null, null, null, null, null);

    // Verify default values (page=1, pageLimit=20)
    verify(iuser)
        .getAll(argThat(criteria -> criteria.getPageNo() == 1 && criteria.getPageLimit() == 20));
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  public void testGetUsersFacets() throws Exception {
    UsersListingFacets expectedFacets = new UsersListingFacets();
    when(iuser.getUserListingFacets()).thenReturn(expectedFacets);
    ResponseEntity<UsersListingFacets> responseEntity = userController.getUsersFacets();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedFacets, responseEntity.getBody());
  }

  @Test
  public void testAddUser() throws Exception {
    UserDetails userDetails = new UserDetails();
    UserProfile expectedUser = new UserProfile();
    long userId = 1L;
    expectedUser.setUserId(userId);

    when(iuser.add(userDetails)).thenReturn(expectedUser);
    ResponseEntity<UserProfile> responseEntity = userController.addUser(userDetails);
    assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    assertEquals(expectedUser, responseEntity.getBody());
    assertEquals("/users/" + userId, responseEntity.getHeaders().getLocation().toString());
  }

  @Test
  public void testDeleteUser() throws Exception {
    long userId = 1L;
    doNothing().when(iuser).delete(userId);
    ResponseEntity<?> responseEntity = userController.deleteUser(userId);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
    verify(iuser).delete(userId);

    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testUpdateUser() throws Exception {
    long userId = 1L;
    UserDetails userDetails = new UserDetails();
    doNothing().when(iuser).update(userId, userDetails);

    ResponseEntity<?> responseEntity = userController.updateUser(userId, userDetails);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).update(userId, userDetails);

    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testGetUser_Success() {
    // Arrange
    long userId = 1L;
    UserProfileResponseEntity mockUser = UserProfileResponseEntity.builder().build();
    mockUser.setUserId(userId);
    when(iuser.fetchOneUser(userId)).thenReturn(mockUser);

    // Act
    ResponseEntity<UserProfileResponseEntity> response = userController.getUser(userId);

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(mockUser, response.getBody());
    // Verify audit logging occurred
    // If you want to verify audit logging, you would need to mock the static AuditLogger
  }

  @Test
  public void testGetUser_NotFound() {
    // Arrange
    long userId = 999L;
    when(iuser.fetchOneUser(userId)).thenReturn(null);

    // Act
    ResponseEntity<UserProfileResponseEntity> response = userController.getUser(userId);

    // Assert
    assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void testResetUserCredentials()
      throws NumberFormatException,
          AccessDeniedException,
          DataValidationException,
          ResourceNotFoundException {
    ResetCredential resetCredentials = new ResetCredential();
    resetCredentials.setNewPassword("newPassword123");
    resetCredentials.setConfirmPassword("newPassword123");

    // Mock authUser.getRole() to not equal Constants.PASSWORDUPDATE so validatePassword is called
    when(authUser.getRole()).thenReturn("USER");
    when(authUser.getId()).thenReturn("123");

    // Stub both methods that will be called
    doNothing().when(iuser).validatePassword(any(ResetCredential.class), any(Long.class));
    doNothing().when(iuser).resetCredentials(any(Credentials.class), any(Long.class));

    ResponseEntity<?> responseEntity = userController.resetUserCredentials(resetCredentials);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

    verify(iuser).validatePassword(resetCredentials, Long.parseLong(authUser.getId()));
    verify(iuser).resetCredentials(any(Credentials.class), any(Long.class));
  }

  @Test
  public void testTriggerPasswordReset()
      throws AddressException, MessagingException, CustomException {
    UserEmail userEmail = new UserEmail();
    doNothing().when(iuser).triggerPasswordReset(userEmail.getEmail());
    ResponseEntity<String> responseEntity = userController.triggerPasswordReset(userEmail);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).triggerPasswordReset(userEmail.getEmail());
  }

  @Test
  public void testSetStatus()
      throws ResourceNotFoundException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    long userId = 1L;
    UserPatch userPatch = new UserPatch();
    doNothing().when(iuser).updateStatusAndRole(userId, userPatch);
    ResponseEntity<?> responseEntity = userController.setStatus(userId, userPatch);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).updateStatusAndRole(userId, userPatch);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testResetCredentialsByAdmin()
      throws DataValidationException, ResourceNotFoundException {
    long userId = 1L;
    Credentials credentials = new Credentials();
    doNothing().when(iuser).resetCredentials(credentials, userId);
    ResponseEntity<?> responseEntity = userController.resetCredentialsByAdmin(credentials, userId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).resetCredentials(credentials, userId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testInviteUser() throws AddressException, MessagingException, CustomException {
    long userId = 1L;

    doNothing().when(iuser).inviteUser(userId);
    ResponseEntity<String> responseEntity = userController.inviteUser(userId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).inviteUser(userId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testGetPrivileges() throws ResourceNotFoundException {
    long userId = 1L;
    String filterBy = "someFilter";
    List<Privileges> expectedPrivileges = new ArrayList<>();
    when(iuser.getPrivileges(userId, filterBy)).thenReturn(expectedPrivileges);
    ResponseEntity<List<Privileges>> responseEntity =
        userController.getPrivileges(userId, filterBy);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).getPrivileges(userId, filterBy);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testAddPrivileges() throws ResourceNotFoundException {
    long userId = 1L;
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
    ResponseEntity<?> responseEntity = userController.addPrivileges(userId, resourcePrivileges);
    assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    verify(iuser).addPrivileges(userId, resourcePrivileges);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testDeletePrivileges() throws ResourceNotFoundException {
    long userId = 1L;
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
    ResponseEntity<?> responseEntity = userController.deletePrivileges(userId, resourcePrivileges);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
    verify(iuser).deletePrivileges(userId, resourcePrivileges);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
  }

  @Test
  public void testInviteUserFromServiceMax() throws MessagingException, CustomException {
    String emailId = "test@example.com";
    ResponseEntity<String> responseEntity = userController.inviteUserFromServiceMax(emailId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).inviteUserFromServiceMax(emailId);
  }

  @Test
  public void testGetUserImage() throws CustomException {
    long userId = 123;
    UserProfileImageDTO userProfileImageDTO = new UserProfileImageDTO();
    when(iuser.fetchImage(userId)).thenReturn(userProfileImageDTO);
    ResponseEntity<UserProfileImageDTO> responseEntity = userController.getUserImage(userId);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    verify(iuser).fetchImage(userId);
  }

  @Test
  public void testDeleteUserImage() throws CustomException {
    long userId = 123;
    ResponseEntity<?> responseEntity = userController.deleteUserImage(userId);
    assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
    verify(iuser).deleteImage(userId);
  }

  @Test
  public void testGetContactHotlineUserType_Success() throws CustomException {
    // Arrange
    String userId = "123";
    String userType = "ADMIN";
    AuthenticatedUser authUser = mock(AuthenticatedUser.class);
    when(authUser.getId()).thenReturn(userId);

    when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(iuser.fetchUserType(Integer.valueOf(userId))).thenReturn(userType);

    // Act
    ResponseEntity<HotlineUserType> response = userController.getContactHotlineUserType();

    // Assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(userType, response.getBody().getUserType());
  }

  @Test
  public void testGetContactHotlineUserType_UserNotFound() throws CustomException {
    // Arrange
    String userId = "123";
    AuthenticatedUser authUser = mock(AuthenticatedUser.class);
    when(authUser.getId()).thenReturn(userId);

    when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
    when(iuser.fetchUserType(Integer.valueOf(userId))).thenReturn(null);

    // Act & Assert
    assertThrows(CustomException.class, () -> userController.getContactHotlineUserType());
  }
}
