package com.merck.nextconnect.userhub.model.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CredentialsTest {

  private String newPassword;
  private String confirmPassword;
  private Credentials credentials;

  @BeforeEach
  public void setUp() {
    newPassword = "newPassword123";
    confirmPassword = "newPassword123";
    credentials = new Credentials(newPassword, confirmPassword);
  }

  @Test
  public void testGetNewPassword() {
    assertEquals(newPassword, credentials.getNewPassword());
  }

  @Test
  public void testSetNewPassword() {
    String updatedPassword = "updatedPassword456";
    credentials.setNewPassword(updatedPassword);
    assertEquals(updatedPassword, credentials.getNewPassword());
  }

  @Test
  public void testGetConfirmPassword() {
    assertEquals(confirmPassword, credentials.getConfirmPassword());
  }

  @Test
  public void testSetConfirmPassword() {
    String updatedConfirmPassword = "updatedPassword456";
    credentials.setConfirmPassword(updatedConfirmPassword);
    assertEquals(updatedConfirmPassword, credentials.getConfirmPassword());
  }

  @Test
  public void testDefaultConstructor() {
    Credentials emptyCredentials = new Credentials();
    assertEquals(null, emptyCredentials.getNewPassword());
    assertEquals(null, emptyCredentials.getConfirmPassword());
  }
}
