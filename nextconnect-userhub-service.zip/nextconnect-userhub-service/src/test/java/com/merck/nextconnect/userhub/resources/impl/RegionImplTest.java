package com.merck.nextconnect.userhub.resources.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.model.CountryDTO;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.Region;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.RegionRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class RegionImplTest {

  @Mock private RegionRepository regionRepository;
  @Mock private CountryRepository countryRepository;

  @InjectMocks private RegionImpl regionImpl;

  private Region region1;
  private Region region2;

  @BeforeEach
  void setUp() {
    region1 = new Region();
    region1.setRegionId(1);
    region1.setRegionName("Europe");

    region2 = new Region();
    region2.setRegionId(2);
    region2.setRegionName("Asia");
  }

  @Test
  void getRegions_ReturnsRegionsMatchingSearch() {
    // Arrange
    String search = "eu";
    List<Region> repoResult = Arrays.asList(region1);
    when(regionRepository.findByRegionNameContainingIgnoreCaseOrderByRegionNameAsc(search))
        .thenReturn(repoResult);

    // Act
    List<Region> result = regionImpl.getRegions(search);

    // Assert
    assertNotNull(result);
    assertEquals(1, result.size());
    assertSame(region1, result.get(0));
    verify(regionRepository, times(1))
        .findByRegionNameContainingIgnoreCaseOrderByRegionNameAsc(search);
  }

  @Test
  void getRegions_ReturnsEmptyListWhenNoMatch() {
    // Arrange
    String search = "nonexistent";
    when(regionRepository.findByRegionNameContainingIgnoreCaseOrderByRegionNameAsc(search))
        .thenReturn(Collections.emptyList());

    // Act
    List<Region> result = regionImpl.getRegions(search);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());
    verify(regionRepository, times(1))
        .findByRegionNameContainingIgnoreCaseOrderByRegionNameAsc(search);
  }

  @Test
  void getCountryByRegionId_ReturnsMappedCountryDTOs() {
    // Arrange
    List<Integer> regionIds = Arrays.asList(1, 2);

    Country c1 = new Country(11, "DE", "Germany");
    c1.setRegion(region1);

    Country c2 = new Country(12, "FR", "France");
    c2.setRegion(region1);

    List<Country> countries = Arrays.asList(c1, c2);
    when(countryRepository.findByRegion_regionIdInOrderByCountryNameAsc(regionIds))
        .thenReturn(countries);

    // Act
    List<CountryDTO> result = regionImpl.getCountryByRegionId(regionIds);

    // Assert
    assertNotNull(result);
    assertEquals(2, result.size());

    CountryDTO dto1 = result.get(0);
    assertEquals(11, dto1.getCountryId());
    assertEquals("DE", dto1.getCountryCode());
    assertEquals("Germany", dto1.getCountryName());
    assertSame(region1, dto1.getRegion());

    CountryDTO dto2 = result.get(1);
    assertEquals(12, dto2.getCountryId());
    assertEquals("FR", dto2.getCountryCode());
    assertEquals("France", dto2.getCountryName());
    assertSame(region1, dto2.getRegion());

    verify(countryRepository, times(1)).findByRegion_regionIdInOrderByCountryNameAsc(regionIds);
  }

  @Test
  void getCountryByRegionId_ReturnsEmptyListWhenNoCountries() {
    // Arrange
    List<Integer> regionIds = Arrays.asList(99);
    when(countryRepository.findByRegion_regionIdInOrderByCountryNameAsc(regionIds))
        .thenReturn(new ArrayList<>());

    // Act
    List<CountryDTO> result = regionImpl.getCountryByRegionId(regionIds);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());
    verify(countryRepository, times(1)).findByRegion_regionIdInOrderByCountryNameAsc(regionIds);
  }
}
