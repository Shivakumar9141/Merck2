package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RoleDeviceTypePrivilegeTest {

  private RoleDeviceTypePrivilege roleDeviceTypePrivilege;
  private Role role;
  private Privilege privilege;
  private DeviceType deviceType;

  @BeforeEach
  public void setUp() {
    roleDeviceTypePrivilege = new RoleDeviceTypePrivilege();
    role = new Role();
    role.setRoleId(1L);
    role.setName("TestRole");

    privilege = new Privilege();
    privilege.setprivilegeId(2L);
    privilege.setOperation("TestOperation");

    deviceType = new DeviceType();
    deviceType.setDeviceTypeId(3L);
    deviceType.setDeviceType("TestDeviceType");
  }

  @Test
  public void testGettersAndSetters() {
    roleDeviceTypePrivilege.setId(100L);
    roleDeviceTypePrivilege.setRole(role);
    roleDeviceTypePrivilege.setPrivilege(privilege);
    roleDeviceTypePrivilege.setDeviceType(deviceType);

    assertEquals(100L, roleDeviceTypePrivilege.getId());
    assertEquals(role, roleDeviceTypePrivilege.getRole());
    assertEquals(privilege, roleDeviceTypePrivilege.getPrivilege());
    assertEquals(deviceType, roleDeviceTypePrivilege.getDeviceType());
  }

  @Test
  public void testDefaultConstructor() {
    RoleDeviceTypePrivilege newPrivilege = new RoleDeviceTypePrivilege();
    assertEquals(0L, newPrivilege.getId());
    assertEquals(null, newPrivilege.getRole());
    assertEquals(null, newPrivilege.getPrivilege());
    assertEquals(null, newPrivilege.getDeviceType());
  }

  @Test
  public void testToString() {
    roleDeviceTypePrivilege.setId(100L);
    roleDeviceTypePrivilege.setRole(role);
    roleDeviceTypePrivilege.setPrivilege(privilege);
    roleDeviceTypePrivilege.setDeviceType(deviceType);

    String toString = roleDeviceTypePrivilege.toString();
    assertNotNull(toString);
    // If toString is implemented, we should at least verify it doesn't throw exceptions
    // and returns a non-null value. The exact format can be tested if needed.
  }
}
