package com.merck.nextconnect.userhub.model.role;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RoleDeviceGroupTest {

  private RoleDeviceGroup roleDeviceGroup;
  private long privilegeId;
  private long locationId;
  private String locationName;
  private long deviceGroupId;
  private String deviceGroupName;

  @BeforeEach
  public void setUp() {
    privilegeId = 1L;
    locationId = 2L;
    locationName = "Test Location";
    deviceGroupId = 3L;
    deviceGroupName = "Test Device Group";

    roleDeviceGroup =
        new RoleDeviceGroup(privilegeId, locationId, locationName, deviceGroupId, deviceGroupName);
  }

  @Test
  public void testGetPrivilegeId() {
    assertEquals(privilegeId, roleDeviceGroup.getPrivilegeId());
  }

  @Test
  public void testSetPrivilegeId() {
    long newPrivilegeId = 10L;
    roleDeviceGroup.setPrivilegeId(newPrivilegeId);
    assertEquals(newPrivilegeId, roleDeviceGroup.getPrivilegeId());
  }

  @Test
  public void testGetLocationId() {
    assertEquals(locationId, roleDeviceGroup.getLocationId());
  }

  @Test
  public void testSetLocationId() {
    long newLocationId = 20L;
    roleDeviceGroup.setLocationId(newLocationId);
    assertEquals(newLocationId, roleDeviceGroup.getLocationId());
  }

  @Test
  public void testGetLocationName() {
    assertEquals(locationName, roleDeviceGroup.getLocationName());
  }

  @Test
  public void testSetLocationName() {
    String newLocationName = "New Test Location";
    roleDeviceGroup.setLocationName(newLocationName);
    assertEquals(newLocationName, roleDeviceGroup.getLocationName());
  }

  @Test
  public void testGetDeviceGruopId() {
    assertEquals(deviceGroupId, roleDeviceGroup.getDeviceGruopId());
  }

  @Test
  public void testSetDeviceGruopId() {
    long newDeviceGroupId = 30L;
    roleDeviceGroup.setDeviceGruopId(newDeviceGroupId);
    assertEquals(newDeviceGroupId, roleDeviceGroup.getDeviceGruopId());
  }

  @Test
  public void testGetDeviceGroupName() {
    assertEquals(deviceGroupName, roleDeviceGroup.getDeviceGroupName());
  }

  @Test
  public void testSetDeviceGroupName() {
    String newDeviceGroupName = "New Test Device Group";
    roleDeviceGroup.setDeviceGroupName(newDeviceGroupName);
    assertEquals(newDeviceGroupName, roleDeviceGroup.getDeviceGroupName());
  }

  @Test
  public void testDefaultConstructor() {
    RoleDeviceGroup emptyRoleDeviceGroup = new RoleDeviceGroup();
    emptyRoleDeviceGroup.setPrivilegeId(privilegeId);
    emptyRoleDeviceGroup.setLocationId(locationId);
    emptyRoleDeviceGroup.setLocationName(locationName);
    emptyRoleDeviceGroup.setDeviceGruopId(deviceGroupId);
    emptyRoleDeviceGroup.setDeviceGroupName(deviceGroupName);

    assertEquals(privilegeId, emptyRoleDeviceGroup.getPrivilegeId());
    assertEquals(locationId, emptyRoleDeviceGroup.getLocationId());
    assertEquals(locationName, emptyRoleDeviceGroup.getLocationName());
    assertEquals(deviceGroupId, emptyRoleDeviceGroup.getDeviceGruopId());
    assertEquals(deviceGroupName, emptyRoleDeviceGroup.getDeviceGroupName());
  }
}
