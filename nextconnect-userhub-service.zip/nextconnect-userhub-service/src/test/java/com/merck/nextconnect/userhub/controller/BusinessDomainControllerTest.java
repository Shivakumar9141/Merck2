package com.merck.nextconnect.userhub.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.resources.IBusinessDomainService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@MockitoSettings(strictness = Strictness.LENIENT)
public class BusinessDomainControllerTest {

  @Mock private IBusinessDomainService businessDomainService;

  @InjectMocks private BusinessDomainController controller;

  @Test
  public void testFetchAllBusinessDomain() throws DataValidationException {
    boolean includeGeneric = false;
    List<BusinessDomainDTO> expectedBusinessDomains = new ArrayList<>();
    when(businessDomainService.getAllBusinessDomain(includeGeneric))
        .thenReturn(expectedBusinessDomains);
    ResponseEntity<List<BusinessDomainDTO>> responseEntity =
        controller.fetchAllBusinessDomain(includeGeneric);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(expectedBusinessDomains, responseEntity.getBody());
  }
}
