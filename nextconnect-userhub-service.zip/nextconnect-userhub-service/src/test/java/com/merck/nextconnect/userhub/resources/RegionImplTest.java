package com.merck.nextconnect.userhub.resources;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.merck.nextconnect.userhub.UserhubBaseTest;
import com.merck.nextconnect.userhub.model.CountryDTO;
import com.merck.nextconnect.userhub.resources.impl.RegionImpl;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.Region;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.RegionRepository;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.util.ReflectionTestUtils;

public class RegionImplTest extends UserhubBaseTest {

  @Mock private RegionRepository regionRepository;
  @Mock private CountryRepository countryRepository;
  @InjectMocks private RegionImpl regionImpl;

  @Before
  public void setUp() {
    regionRepository = mock(RegionRepository.class);
    countryRepository = mock(CountryRepository.class);
    regionImpl = new RegionImpl();
    ReflectionTestUtils.setField(regionImpl, "countryRepository", countryRepository);
    ReflectionTestUtils.setField(regionImpl, "regionRepository", regionRepository);
  }

  @Test
  public void testGetRegions() {
    String searchBy = "TestRegion";
    List<Region> mockRegionList = new ArrayList<>();
    Region mockRegion = new Region();
    mockRegion.setRegionId(1);
    mockRegion.setRegionName("TestRegion");
    mockRegionList.add(mockRegion);
    when(regionRepository.findByRegionNameContainingIgnoreCaseOrderByRegionNameAsc(searchBy))
        .thenReturn(mockRegionList);
    List<Region> result = regionImpl.getRegions(searchBy);
    assertEquals(mockRegionList.size(), result.size());
    assertEquals(mockRegionList.get(0).getRegionId(), result.get(0).getRegionId());
    assertEquals(mockRegionList.get(0).getRegionName(), result.get(0).getRegionName());
  }

  @Test
  public void testGetCountryByRegionId() {

    List<Integer> regionIdList = new ArrayList<>();
    regionIdList.add(1);
    regionIdList.add(2);

    List<Country> mockCountryDTOList = new ArrayList<>();
    Country mockCountryDTO1 = new Country();
    mockCountryDTO1.setId(1);
    mockCountryDTO1.setCountryName("TestCountry1");
    mockCountryDTO1.setRegion(new Region());
    mockCountryDTOList.add(mockCountryDTO1);
    when(countryRepository.findByRegion_regionIdInOrderByCountryNameAsc(regionIdList))
        .thenReturn(mockCountryDTOList);
    List<CountryDTO> result = regionImpl.getCountryByRegionId(regionIdList);
    assertEquals(mockCountryDTOList.size(), result.size());
    assertEquals(mockCountryDTOList.get(0).getId(), result.get(0).getCountryId());
    assertEquals(mockCountryDTOList.get(0).getCountryName(), result.get(0).getCountryName());
    assertEquals(mockCountryDTOList.get(0).getRegion(), result.get(0).getRegion());
  }
}
