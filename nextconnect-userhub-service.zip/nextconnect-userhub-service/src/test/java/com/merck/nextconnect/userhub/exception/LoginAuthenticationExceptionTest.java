package com.merck.nextconnect.userhub.exception;

import static org.junit.jupiter.api.Assertions.*;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import org.junit.jupiter.api.Test;

public class LoginAuthenticationExceptionTest {

  @Test
  public void testConstructorWithMessage() {
    String errorMessage = "Invalid login credentials";
    LoginAuthenticationException exception = new LoginAuthenticationException(errorMessage);

    assertNotNull(exception);
    assertEquals(errorMessage, exception.getMessage());
    assertNull(exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCode() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    LoginAuthenticationException exception = new LoginAuthenticationException(errorCode);

    assertNotNull(exception);
    assertEquals(errorCode.getDescription(), exception.getMessage());
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }

  @Test
  public void testConstructorWithCustomErrorCodeAndMessage() {
    CustomErrorCodes errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR;
    String customMessage = "Custom error message";
    LoginAuthenticationException exception =
        new LoginAuthenticationException(errorCode, customMessage);

    assertNotNull(exception);
    assertEquals(customMessage, exception.getMessage());
    assertEquals(errorCode.getErrorCode(), exception.getErrorCode());
  }
}
