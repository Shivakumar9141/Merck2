package com.merck.nextconnect.userhub.cache.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.userhub.cache.repository.CacheRepository;
import com.merck.nextconnect.userhub.cache.util.CacheUtil;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.convert.ConversionService;

public class CacheServiceImplTest {

  @Mock private CacheRepository cacheRepository;
  @Mock private ConversionService conversionService;
  @InjectMocks private CacheServiceImpl cacheService;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetMapValues() {
    String mapName = "testMap";
    String resourceId = "123";
    String expectedValue = "testValue";

    when(cacheRepository.getMapValues(mapName, resourceId)).thenReturn(expectedValue);

    String result = cacheService.getMapValues(mapName, resourceId);

    assertEquals(expectedValue, result);
    verify(cacheRepository).getMapValues(mapName, resourceId);
  }

  @Test
  public void testClearCacheValues() {
    String mapName = "testMap";
    String resourceId = "123";
    String expectedValue = "clearedValue";

    when(cacheRepository.clearCacheValues(mapName, resourceId)).thenReturn(expectedValue);

    String result = cacheService.clearCacheValues(mapName, resourceId);

    assertEquals(expectedValue, result);
    verify(cacheRepository).clearCacheValues(mapName, resourceId);
  }

  @Test
  public void testGetConfigurationProperties() {
    String expectedMembers = "member1,member2";

    when(cacheRepository.getMembers()).thenReturn(expectedMembers);

    Map<String, String> result = cacheService.getConfigurationProperties();

    assertEquals(expectedMembers, result.get("members"));
    verify(cacheRepository).getMembers();
  }

  @Test
  public void testGetListOfMaps() {
    Map<String, String> expectedMaps = CacheUtil.HazelcastMapInfo;

    Map<String, String> result = cacheService.getListOfMaps();

    assertEquals(expectedMaps, result);
  }

  @Test
  public void testGetAllDistributedCacheValues() {
    Map<String, String> expectedValues = new HashMap<>();
    expectedValues.put("key1", "value1");

    when(cacheRepository.getAllDistributedCacheValues()).thenReturn(expectedValues);

    Map<String, String> result = cacheService.getAllDistributedCacheValues();

    assertEquals(expectedValues, result);
    verify(cacheRepository).getAllDistributedCacheValues();
  }

  @Test
  public void testUpdateApplicationConfig() {
    String key = "testKey";
    String type = "java.lang.String";
    String value = "testValue";
    com.hazelcast.map.IMap<String, Object> mockMap = mock(com.hazelcast.map.IMap.class);

    when(cacheRepository.getApplicationConfigMap()).thenReturn(mockMap);
    when(conversionService.canConvert(String.class, String.class)).thenReturn(true);
    when(conversionService.convert(value, String.class)).thenReturn(value);

    cacheService.updateApplicationConfig(key, type, value);

    verify(cacheRepository).getApplicationConfigMap();
    verify(mockMap).put(key, value);
  }

  @Test
  public void testConvertWithNullType() throws Exception {
    String value = "testValue";

    Object result = invokeConvertMethod(null, value);

    assertEquals(value, result);
  }

  @Test
  public void testConvertWithUnsupportedType() {
    String type = "com.example.CustomType";
    String value = "testValue";

    Exception exception = assertThrows(Exception.class, () -> invokeConvertMethod(type, value));

    Throwable cause = exception.getCause();
    assertTrue(cause instanceof IllegalArgumentException);
    assertEquals("Unsupported target type: " + type, cause.getMessage());
  }

  @Test
  public void testConvertWithUnknownType() {
    String type = "java.lang.NonExistentType";
    String value = "testValue";

    try {
      invokeConvertMethod(type, value);
      fail("Expected IllegalArgumentException was not thrown");
    } catch (Exception e) {
      Throwable cause = e.getCause();
      assertTrue(cause instanceof IllegalArgumentException);
      assertEquals("Unknown target type: " + type, cause.getMessage());
    }
  }

  @Test
  public void testConvertWithUndefinedConversion() {
    String type = "java.lang.Integer";
    String value = "testValue";

    when(conversionService.canConvert(String.class, Integer.class)).thenReturn(false);

    Exception exception = assertThrows(Exception.class, () -> invokeConvertMethod(type, value));

    Throwable cause = exception.getCause();
    assertTrue(cause instanceof IllegalArgumentException);
    assertEquals("Conversion not defined for target type: " + type, cause.getMessage());
  }

  private Object invokeConvertMethod(String type, String value) throws Exception {
    java.lang.reflect.Method method =
        CacheServiceImpl.class.getDeclaredMethod("convert", String.class, String.class);
    method.setAccessible(true);
    return method.invoke(cacheService, type, value);
  }
}
