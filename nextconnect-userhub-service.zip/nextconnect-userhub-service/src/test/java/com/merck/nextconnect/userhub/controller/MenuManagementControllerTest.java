package com.merck.nextconnect.userhub.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.MenuGroupRequest;
import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuManagementRequest;
import com.merck.nextconnect.userhub.model.MenuManagementResponse;
import com.merck.nextconnect.userhub.model.MenuUpdateRequest;
import com.merck.nextconnect.userhub.model.MenuUpdateRequestDTO;
import com.merck.nextconnect.userhub.resources.MenuService;
import com.merck.nextconnect.userhub.resources.ServiceImpl;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class MenuManagementControllerTest {

  @InjectMocks private MenuManagementController menuController;
  @Mock private MenuService mockMenuService;
  @Mock private Authentication authentication;
  @Mock private ServiceImpl serviceImpl;
  @Mock private AuthenticatedUser authUser;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);
    authentication = Mockito.mock(Authentication.class);
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    authentication = SecurityContextHolder.getContext().getAuthentication();

    // Mock servlet request attributes to prevent IllegalStateException
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServletRequestAttributes attributes = new ServletRequestAttributes(request);
    RequestContextHolder.setRequestAttributes(attributes);

    // Mock authUser properties to prevent NumberFormatException
    when(authUser.getId()).thenReturn("123");
    when(authUser.getOrgId()).thenReturn(5);
    when(authUser.getRoleId()).thenReturn(1L);

    Mockito.when(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .thenReturn(authUser);
  }

  @Test
  public void testGetMenuGroups() {
    List<MenuGroupResponse> mockResponse = new ArrayList<>();
    when(mockMenuService.getMenuGroups(any(MenuGroupRequest.class))).thenReturn(mockResponse);
    ResponseEntity<List<MenuGroupResponse>> responseEntity = menuController.get();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(mockResponse, responseEntity.getBody());
  }

  @Test
  public void testGetUserMenuResponse() throws CustomException {
    String menuGroupName = "testMenuGroup";
    List<MenuManagementResponse> mockResponse = new ArrayList<>();
    when(mockMenuService.getMenuInfo(any(MenuManagementRequest.class))).thenReturn(mockResponse);
    ResponseEntity<List<MenuManagementResponse>> responseEntity =
        menuController.getUserMenuResponse(menuGroupName);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(mockResponse, responseEntity.getBody());
  }

  @Test
  public void testUpdateMenuSequence() throws CustomException {
    MenuUpdateRequest mockRequest = new MenuUpdateRequest();
    List<MenuManagementResponse> mockResponse = new ArrayList<>();
    when(mockMenuService.updateUserMenu(any(MenuUpdateRequestDTO.class))).thenReturn(mockResponse);
    ResponseEntity<List<MenuManagementResponse>> responseEntity =
        menuController.updateMenuSequence(mockRequest);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(mockResponse, responseEntity.getBody());
  }
}
