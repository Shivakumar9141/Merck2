package com.merck.nextconnect.userhub.entities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserDevicePrivilegeTest {

  private UserDevicePrivilege userDevicePrivilege;
  private UserProfile userProfile;
  private Privilege privilege;
  private Device device;

  @BeforeEach
  public void setUp() {
    userDevicePrivilege = new UserDevicePrivilege();
    userProfile = new UserProfile();
    privilege = new Privilege();
    device = new Device();
  }

  @Test
  public void testConstructor() {
    assertNotNull(userDevicePrivilege);
  }

  @Test
  public void testGetSetId() {
    long id = 123L;
    userDevicePrivilege.setId(id);
    assertEquals(id, userDevicePrivilege.getId());
  }

  @Test
  public void testGetSetUser() {
    userDevicePrivilege.setUser(userProfile);
    assertEquals(userProfile, userDevicePrivilege.getUser());
  }

  @Test
  public void testGetSetPrivilege() {
    userDevicePrivilege.setPrivilege(privilege);
    assertEquals(privilege, userDevicePrivilege.getPrivilege());
  }

  @Test
  public void testGetSetDevices() {
    userDevicePrivilege.setDevices(device);
    assertEquals(device, userDevicePrivilege.getDevices());
  }
}
