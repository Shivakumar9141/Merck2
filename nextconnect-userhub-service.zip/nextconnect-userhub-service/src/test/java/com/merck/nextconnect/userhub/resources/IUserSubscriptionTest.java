package com.merck.nextconnect.userhub.resources;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.SubscriptionCategoryDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.junit.Test;

public class IUserSubscriptionTest {

  @Test
  public void testReminderDaysValidation_ValidDays() throws DataValidationException {
    // Arrange
    SubscriptionTypeDTO subscriptionTypeDTO = new SubscriptionTypeDTO();
    List<SubscriptionCategoryDTO> categories = new ArrayList<>();

    SubscriptionCategoryDTO category = new SubscriptionCategoryDTO();
    category.setStatus(true);
    category.setNumberOfDaysAdvance(15); // Valid days (between 0 and 30)
    categories.add(category);

    subscriptionTypeDTO.setSubscriptionCategories(new HashSet<>(categories));

    // Act & Assert - No exception should be thrown
    IUserSubscription.reminderDaysValidation(subscriptionTypeDTO);
  }

  @Test
  public void testReminderDaysValidation_NegativeDays() {
    // Arrange
    SubscriptionTypeDTO subscriptionTypeDTO = new SubscriptionTypeDTO();
    List<SubscriptionCategoryDTO> categories = new ArrayList<>();

    SubscriptionCategoryDTO category = new SubscriptionCategoryDTO();
    category.setStatus(true);
    category.setNumberOfDaysAdvance(-1); // Invalid days (negative)
    categories.add(category);

    subscriptionTypeDTO.setSubscriptionCategories(new HashSet<>(categories));

    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () -> IUserSubscription.reminderDaysValidation(subscriptionTypeDTO));

    assertTrue(exception.getMessage().contains(CustomErrorCodes.INVALID_DAYS.getDescription()));
  }

  @Test
  public void testReminderDaysValidation_ExcessiveDays() {
    // Arrange
    SubscriptionTypeDTO subscriptionTypeDTO = new SubscriptionTypeDTO();
    List<SubscriptionCategoryDTO> categories = new ArrayList<>();

    SubscriptionCategoryDTO category = new SubscriptionCategoryDTO();
    category.setStatus(true);
    category.setNumberOfDaysAdvance(31); // Invalid days (> 30)
    categories.add(category);

    subscriptionTypeDTO.setSubscriptionCategories(new HashSet<>(categories));

    // Act & Assert
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () -> IUserSubscription.reminderDaysValidation(subscriptionTypeDTO));

    assertTrue(exception.getMessage().contains(CustomErrorCodes.INVALID_DAYS.getDescription()));
  }

  @Test
  public void testReminderDaysValidation_InactiveCategory() throws DataValidationException {
    // Arrange
    SubscriptionTypeDTO subscriptionTypeDTO = new SubscriptionTypeDTO();
    List<SubscriptionCategoryDTO> categories = new ArrayList<>();

    SubscriptionCategoryDTO category = new SubscriptionCategoryDTO();
    category.setStatus(false); // Inactive category
    category.setNumberOfDaysAdvance(31); // Would be invalid if active
    categories.add(category);

    subscriptionTypeDTO.setSubscriptionCategories(new HashSet<>(categories));

    // Act & Assert - No exception should be thrown since category is inactive
    IUserSubscription.reminderDaysValidation(subscriptionTypeDTO);
  }

  @Test
  public void testReminderDaysValidation_MixedCategories() {
    // Arrange
    SubscriptionTypeDTO subscriptionTypeDTO = new SubscriptionTypeDTO();
    List<SubscriptionCategoryDTO> categories = new ArrayList<>();

    // Valid category
    SubscriptionCategoryDTO validCategory = new SubscriptionCategoryDTO();
    validCategory.setStatus(true);
    validCategory.setNumberOfDaysAdvance(15);
    categories.add(validCategory);

    // Invalid category
    SubscriptionCategoryDTO invalidCategory = new SubscriptionCategoryDTO();
    invalidCategory.setStatus(true);
    invalidCategory.setNumberOfDaysAdvance(35);
    categories.add(invalidCategory);

    subscriptionTypeDTO.setSubscriptionCategories(new HashSet<>(categories));

    // Act & Assert - Should throw exception due to the invalid category
    DataValidationException exception =
        assertThrows(
            DataValidationException.class,
            () -> IUserSubscription.reminderDaysValidation(subscriptionTypeDTO));

    assertTrue(exception.getMessage().contains(CustomErrorCodes.INVALID_DAYS.getDescription()));
  }
}
