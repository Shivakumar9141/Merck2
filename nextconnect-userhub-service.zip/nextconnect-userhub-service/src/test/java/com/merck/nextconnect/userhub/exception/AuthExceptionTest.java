package com.merck.nextconnect.userhub.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class AuthExceptionTest {

  @Test
  public void shouldCreateExceptionWithMessage() {
    // Given
    String errorMessage = "Invalid authentication token";

    // When
    AuthException exception = new AuthException(errorMessage);

    // Then
    assertEquals(errorMessage, exception.getMessage());
    assertTrue(exception instanceof org.springframework.security.core.AuthenticationException);
  }
}
