package com.merck.nextconnect.userhub.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class SubscriptionTypeDTOTest {

  @Test
  public void testSubscriptionTypeDTOBuilder() {
    // Arrange
    Long id = 123L;
    String name = "Test Subscription";
    String isdCode = "91";
    String phones = "1234567890";
    Set<SubscriptionCategoryDTO> categories = new HashSet<>();

    // Act
    SubscriptionTypeDTO dto =
        SubscriptionTypeDTO.builder()
            .subscriptionTypeId(id)
            .subscriptionTypeName(name)
            .isdCode(isdCode)
            .phones(phones)
            .subscriptionCategories(categories)
            .build();

    // Assert
    assertEquals(id, dto.getSubscriptionTypeId());
    assertEquals(name, dto.getSubscriptionTypeName());
    assertEquals(isdCode, dto.getIsdCode());
    assertEquals(phones, dto.getPhones());
    assertEquals(categories, dto.getSubscriptionCategories());
  }

  @Test
  public void testNoArgsConstructor() {
    // Act
    SubscriptionTypeDTO dto = new SubscriptionTypeDTO();

    // Assert
    assertNotNull(dto);
  }

  @Test
  public void testAllArgsConstructor() {
    // Arrange
    Long id = 123L;
    String name = "Test Subscription";
    String isdCode = "91";
    String phones = "1234567890";
    Set<SubscriptionCategoryDTO> categories = new HashSet<>();

    // Act
    SubscriptionTypeDTO dto = new SubscriptionTypeDTO(id, name, isdCode, phones, categories);

    // Assert
    assertEquals(id, dto.getSubscriptionTypeId());
    assertEquals(name, dto.getSubscriptionTypeName());
    assertEquals(isdCode, dto.getIsdCode());
    assertEquals(phones, dto.getPhones());
    assertEquals(categories, dto.getSubscriptionCategories());
  }

  @Test
  public void testToString() {
    // Arrange
    Long id = 123L;
    String name = "Test Subscription";
    String isdCode = "91";
    String phones = "1234567890";
    Set<SubscriptionCategoryDTO> categories = new HashSet<>();
    SubscriptionTypeDTO dto = new SubscriptionTypeDTO(id, name, isdCode, phones, categories);

    // Act
    String result = dto.toString();

    // Assert
    String expected =
        "SubscriptionTypeDTO [subscriptionTypeId=123, subscriptionTypeName=Test Subscription, "
            + "isdCode=91, phones=1234567890, subscriptionCategories="
            + categories
            + "]";
    assertEquals(expected, result);
  }
}
