package com.merck.nextconnect.userhub.util;

import java.util.Arrays;
import java.util.List;

public final class Constants {

  public static final String DEVICE = "device";
  public static final String DEVICEGROUP = "devicegroup";
  public static final String ENTITY = "entity";
  public static final String DEVICETYPE = "devicetype";
  public static final String USER = "user";
  public static final String ROLE = "role";
  public static final String INVITE_USER = "inviteUser";
  public static final String RESET_PASSWORD = "resetPassword";
  public static final String ACCESSTOKEN = "accessToken";
  public static final String NEXTCONNECT_INVITATION = "Nextconnect Invitation";
  public static final String NEXTCONNECT_PASSWORD_UPDATE = "Nextconnect Password Update";
  public static final String MILLIQ_CONNECT_INVITATION = "MyMilli-Q™ Invitation";
  public static final String MILLIQ_CONNECT_PASSWORD_UPDATE = "MyMilli-Q™ Password Update";
  public static final String LOGIN_URL = "http://localhost:4001/login";
  public static final String RESET_PASSWORD_URL = "http://localhost:4001/resetpassword";
  public static final String STATUS = "status";
  public static final String STATUS_FILTER_PREFIX = "status.";
  public static final String ROLE_FILTER_PREFIX = "role.";
  public static final String ORG_NAME_FILTER_PREFIX = "org.";
  public static final String ORG_ID_FILTER_PREFIX = "orgId.";
  public static final String COUNTRY_CODE_FILTER_PREFIX = "countryCode.";
  public static final String READ = "read";
  public static final String CREATE = "create";
  public static final String UPDATE = "update";
  public static final String DELETE = "delete";
  public static final String NEXTCONNECT_AUTH = "nextconnect_auth";
  public static final String SIAL_AUTH = "sial_auth";
  public static final String MERCK_AUTH = "merck_auth";
  public static final String NEXTCONNECT = "nextconnect";
  public static final String SIAL = "sial";
  public static final String MERCK = "merck";
  public static final String MERCK_GLOBAL = "GLOBAL";
  public static final String MERCK_DNAP = "DNAP";
  public static final String MERCK_DNEU = "DNEU";
  public static final String MERCK_DNLA = "DNLA";
  public static final String MERCK_DNNA = "DNNA";
  public static final String EMPTY_STRING = "";
  public static final long SUPER_ADMIN_ROLE_ID = 3;
  public static final String GET = "GET";
  public static final String POST = "POST";
  public static final String PUT = "PUT";
  public static final String PATCH = "PATCH";
  public static final String PRIVILEGE = "PRIVILEGE";
  public static final String PASSWORDUPDATE = "passwordUpdate";
  public static final String READ_USER = "read_user";
  public static final String SYSTEM_DEFINED = "systemDefined";
  public static final String ROLE_ID = "roleId";
  public static final int DEFAULT_DATE_FORMAT = 1;
  public static final int DEFAULT_LANGUAGE = 1;
  public static final String ACCESS_ALL = "accessAll";
  public static final String COUNTRY = "country";
  public static final String LANGUAGE = "language";
  public static final String DATE_FORMAT = "date format";
  public static final String DOMAIN = "domain";
  public static final String CARD = "card";
  public static final String ACTIVE = "Active";
  public static final String ORG = "org";
  public static final String LABWATER_TEMPLATE = "labwater";
  public static final String UNSUBSCRIBE_USER_EMAIL_TEMPLATE = "UNSUBSCRIBE_USER";
  public static final String UNSUBSCRIBE_USER_EMAIL_SUBJECT = "Unsubscription confirmation";
  public static final String EMAIL_SUCCESS_STATUS = "SUCCESS";
  public static final String USERHUB = "Userhub";
  public static final String EMAIL_CHAR_SET = "UTF-8";
  public static final String EMAIL_CONTENT_TYPE = "text/html";
  public static final String UNSUBSCRIBE_USER = "Unsubscribe user";
  public static final String Region = "region";
  public static final String CREATE_ORG = "create_org";
  public static final String PARTNER = "Partners";
  public static final String REGISTERED_COUNTRY_ALERT_SUBJECT =
      "Your MyMilli-Q™ registered country has changed";
  public static final String EMAIL_PENDING_STATUS = "PENDING";
  public static final String TERRITORY = "territory";
  public static final String ORG_NAME = "org";
  public static final String ORG_ID = "orgId";
  public static final String COUNTRY_CODE = "countryCode";
  public static final String PASSWORD_POLICY = "PASSWORD_POLICY";
  public static final String VALIDITY_DAYS = "VALIDITY_DAYS";
  public static final String PASSWORD_HISTORY_THRESHOLD = "PASSWORD_HISTORY_THRESHOLD";
  public static final String SERVICE_ADMIN = "LW-Service Admin";
  public static final String SUPER_ADMIN = "LW-super admin";
  public static final String FSE_USER = "LW-FSE";
  public static final String INVITE_TEMPLATE = "INVITE_USER";
  public static final String REGISTRATION_LINK = "registration_link";
  public static final String NEXTCONNECT_ENV = "nextconnect_env";
  public static final String LOGIN_NAME = "login_name";
  public static final String PASSWORD_FORGOT = "PASSWORD_FORGOT";
  public static final String RESET_URL = "reset_url";
  public static final String ICS_SERVICE_COORDINATOR = "ICS-Service Coordinator";

  public static final String FSS_USER = "LW-MCS";
  public static final String LW_BUSINESS_MANAGER = "LW-Business manager"; // NCIOT-12105
  public static final String ORG_TYPE_BUSINESS_UNIT = "BUSINESS UNIT"; // NCIOT-12118,12122
  public static final String LW_SERVICE_COORDINATOR =
      "ICS-Service Coordinator"; // NCIOT-12118,12122

  public static final String CUSTOMER_ADMIN = "Customer Admin";
  public static final String CUSTOMER_MANAGER = "Customer Manager";
  public static final String QUALITY_MANAGER = "Quality Manager";
  public static final String TECHNICAL_USER = "Technical User";
  public static final String EXTERNAL_CUSTOMER_TECH = "External Customer Tech"; // NCIOT-12105
  public static final String LW_MCS = "LW-MCS";
  public static final String DISTRIBUTOR_ADMIN = "Distributor Admin";
  public static final String DISTRIBUTOR_FSE = "Distributor FSE";
  public static final String ANY_ALARM = "Any alarm";
  public static final String ANY_ALARM_STOP = "Any alarm stop";
  public static final String ANY_ALERT = "Any alert";
  public static final String CUSTOM_EVENTS = "Custom events";
  public static final String NON_VALIDATED_PACK = "Non-validated pack";
  public static final String ANY_WATER_QUALITY_RELATED_ALARM = "Any water quality related alarm";
  public static final String ANY_CONSUMABLE_OVERDUES_GREATER_THAN_30_DAYS =
      "Any consumable overdues >30 days";
  public static final String END_OF_SERVICE_CONTRACT = "End of Service Contract"; // NCIOT-14990
  public static final List<String> CATEGORIES =
      Arrays.asList(
          ANY_ALARM,
          ANY_ALERT,
          ANY_WATER_QUALITY_RELATED_ALARM,
          NON_VALIDATED_PACK,
          ANY_CONSUMABLE_OVERDUES_GREATER_THAN_30_DAYS,
          CUSTOM_EVENTS);
  public static final String LW_SERVICE_ADMIN = "LW-Service Admin";
  public static final String LW_SUPER_ADMIN = "LW-super admin";
  public static final String LW_FSE = "LW-FSE";
  public static final String RATING = "rating";
  public static final String ROLES = "roles";
  public static final String ORG_NAMES = "cusorg";
  public static final String COUNTRY_CODES = "countryCode";
  public static final String COUNTRYS = "country";
  public static final String RATING_FILTER_PREFIXS = "rating.";
  public static final String ROLE_FILTER_PREFIXS = "roles.";
  public static final String USERS_CONSTANT = "user.";
  public static final String ORG_NAME_FILTER_PREFIXS = "cusorg.";
  public static final String COUNTRY_CODE_FILTER_PREFIXS = "countryCode.";
  public static final String CREATE_ORGS = "create_org";
  public static final String ONE = "1";
  public static final String TWO = "2";
  public static final String THREE = "3";
  public static final String FOUR = "4";
  public static final String FIVE = "5";
  public static final String TWELVE = "12";
  public static final String SIX = "6";
  public static final String NOFEEDBACK = "oldFeedBack.None";
  public static final String FEEDBACK_RANGE_PREFIXS = "oldFeedBack.";
  public static final String FEEDBACK_RANGE = "oldFeedBack";
  public static final String NOFEEDBACK_CONSTANT = "no feedback";
  public static final String SIX_MONTHS_CONSTANT = "6 months";
  public static final String TWLEVE_MONTHS_CONSTANT = "12 months";
  public static final String PARTNER_ADMIN = "Partner Admin";
  public static final String PARTNER_HOTLINE = "Partner Hotline";
  public static final String ANY_CSA_DUE_DATE = "Any CSA due date";
  public static final String END_OF_WARRANTY = "End of warranty";
  public static final String ANY_CONTRACT_OVERDUE = "Any contract overdue";
  public static final String SERVICE_VISIT_REMINDER = "Service visit reminder";
  public static final String ANY_CONSUMABLE_SPARE_PART_RELATED_ALARM_OR_ALERT =
      "Any consumable & spare part related alarm or alert";
  public static final List<String> CUSTOMER_ROLES =
      Arrays.asList(
          CUSTOMER_ADMIN, TECHNICAL_USER, QUALITY_MANAGER, EXTERNAL_CUSTOMER_TECH); // NCIOT-9370
  public static final List<String> CUST_REGISTRATION_CATEGORIES =
      Arrays.asList(
          ANY_CONSUMABLE_SPARE_PART_RELATED_ALARM_OR_ALERT,
          SERVICE_VISIT_REMINDER,
          END_OF_SERVICE_CONTRACT,
          END_OF_WARRANTY,
          ANY_CSA_DUE_DATE);
  public static final List<String> CUST_ALL_CATEGORIES =
      Arrays.asList(
          ANY_ALARM_STOP,
          ANY_ALARM,
          ANY_ALERT,
          ANY_WATER_QUALITY_RELATED_ALARM,
          ANY_CONSUMABLE_SPARE_PART_RELATED_ALARM_OR_ALERT,
          END_OF_WARRANTY,
          SERVICE_VISIT_REMINDER,
          ANY_CSA_DUE_DATE,
          CUSTOM_EVENTS,
          END_OF_SERVICE_CONTRACT);
  public static final List<String> CUST_CATEGORIES_WITHOUT_PREVENANCE_DELAY =
      Arrays.asList(
          ANY_ALARM_STOP,
          ANY_ALARM,
          ANY_ALERT,
          ANY_WATER_QUALITY_RELATED_ALARM,
          ANY_CONSUMABLE_SPARE_PART_RELATED_ALARM_OR_ALERT);

  public static final List<String> FSS_ROLES =
      Arrays.asList(
          LW_MCS, DISTRIBUTOR_ADMIN, DISTRIBUTOR_FSE, LW_SERVICE_COORDINATOR); // NCIOT-9369
  public static final List<String> FSS_ALL_CATEGORIES =
      Arrays.asList(
          NON_VALIDATED_PACK,
          ANY_CONSUMABLE_OVERDUES_GREATER_THAN_30_DAYS,
          END_OF_SERVICE_CONTRACT,
          END_OF_WARRANTY);
  public static final List<String> FSS_CATEGORIES_WITHOUT_PREVENANCE_DELAY =
      Arrays.asList(NON_VALIDATED_PACK, ANY_CONSUMABLE_OVERDUES_GREATER_THAN_30_DAYS);
  public static final String CREATE_ALL_ORG_TYPE_PRIVILEGE = "custpartnerdist_createorg";
  public static final String CREATE_PARTNER_ORG_TYPE_PRIVILEGE = "partner_createorg";
  public static final String CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE = "cust_createorg";
  public static final String FILTER_STATUS_PREFIX = "status.";
  public static final String FILTER_TYPE_PREFIX = "type.";
  public static final String TYPE = "type";
  public static final String ASCENDING = "asc";
  public static final String NAME = "name";
  public static final String DELETED = "deleted";
  public static final String PARENT = "parent";
  public static final String ID = "id";
  public static final String DEFAULT_TEMPLATE = "DEFAULT TEMPLATE";
  public static final String CREATED_ON = "createdOn";
  public static final String CREATED_DATE = "createdDate";
  public static final String EMAIL_SUBSCRIPTION = "Email Subscription";
  public static final String ORG_TYPE_CUSTOMER = "Customers";
  public static final String ORG_TYPE_PARTNER = "Partners";
  public static final String FULL_YEAR_HISTORICAL_DATA = "-1";

  public static final String CUSTOMER = "Customers";

  public static final String DEVICE_ASSIGNMENT_MAIL_SUBJECT =
      "Assignement status of your devices has been detected.";
  public static final String DEVICE_ASSIGNMENT_SMS = "DEVICE_ASSIGNMENT_SMS";
  public static final String DEVICE_UNASSIGNMENT_SMS = "DEVICE_UNASSIGNMENT_SMS";
  public static final String USER_MANAGEMENT_FOR_FSS_ROLE =
      "user_management_for_fss"; // NCIOT-12110

  public static final String LABWATER_CUSTOMER_TEMPLATE = "labwater_customer";
  public static final String LABWATER_DISTRIBUTOR_TEMPLATE = "labwater_distributor";
  public static final String DISTRIBUTOR = "Distributors";
  public static final String UNDERSCORE = "_";
  public static final String MANUAL = "MANUAL";
  public static final String AUTO_INVITE_USER_TEMPLATE = "AUTO_INVITE_USER";
  public static final String FIRST_NAME = "first_name";
  public static final String LAST_NAME = "last_name";
  public static final String SELF_REGISTRATION_FAILURE = "SELF_REGISTRATION_FAILURE";
  public static final String SELF_REGISTRATION_FAILURE_SUBJECT =
      "Self Registration to MyMilli-Q™ Failure";
  public static final String MILLI_Q_CONNECT = "MilliQ Connect";
  public static final String REGISTRATION = "Registration";
  public static final String SELF_REGISTRATION_TO_MYMILLIQ_FAILURE =
      "Self Registration to MyMilli-Q™ Failure";
  public static final String OPEN = "Open";
  public static final String SELF_REGISTRATION_CA_EMAIL_CONFIG = "SELF_REGISTRATION_CA_EMAIL";
  public static final String GRACE_PERIOD = "GRACE_PERIOD";
  public static final String SERVICE_CONTRACT_GRACE_PERIOD_VALUE =
      "SERVICE_CONTRACT_GRACE_PERIOD_VALUE";
  public static final String WARRANTY_PERIOD = "WARRANTY_PERIOD";
  public static final String WARRANTY_PERIOD_VALUE = "WARRANTY_PERIOD_VALUE";
  public static final String LABWATER = "LABWATER";
  public static final String USER_PROFILE_STATUS = "USER_PROFILE_STATUS";
  public static final String SELF_REGISTRATION_INVALIDATE_SUBJECT = "Self Registration Invalid";
  public static final String DEACTIVATED = "deactivated";
  public static final String ACTIVATED = "activated";
  public static final List<String> CP_SERVICE_LEVEL =
      Arrays.asList(
          "Total",
          "Essential",
          "Advanced",
          "Advanced Pharma",
          "Essential Pharma",
          "Total Pharma",
          "Proactive",
          "Proactive Pharma",
          "eCare™",
          "Extended Warranty",
          "Total Predict");
  public static final String WARRANTY_GRACE_PERIOD_VALUE = "WARRANTY_GRACE_PERIOD_VALUE";
  public static final String SELF_REGISTRATION_INVITE_USER = "SELF_REGISTRATION_INVITE_USER";
  public static final String SELECT_SR_STATUS_FROM_SERVICE_MAX =
      "select+SVMXC__Status__c+from+SVMXC__Service_Request__c+where+";
  public static final String SERIAL_NO_USER_TO_REGISTER =
      "Mymilliq_SN_of_System_Used_to_Register__c";
  public static final String EQUALS = "=";
  public static final String AND = "and";
  public static final String CUSTOMER_EMAIL_C = "Mymilliq_Customer_Email__c";
  public static final String SR_TYPE = "SVMXC__Type__c";
  public static final String APOSTROPHE = "'";
  public static final String SR_STATUS = "SVMXC__Status__c";
  public static final String IN = "in";
  public static final String OPEN_BRACKET = "(";
  public static final String CLOSE_BRACKET = ")";
  public static final String COMMA = ",";
  public static final String IN_PROGRESS = "In+progress";
  public static final String SELF_REGISTRATION_TO_MYMILLIQ_FAILURE_WITHOUT_SPACE =
      "Self+Registration+to+MyMilli-Q™+Failure";
  public static final String NOT_AVAILABLE = "N/A";

  public static final String SELF_REGISTRATION_CA_NOT_FOUND =
      "Self Registration Customer Admin not found for validation";
  public static final String ORG_LIST_IN_ADD_USER = "ORG_LIST_IN_ADD_USER";

  public static final String ORG_TYPE_DISTRIBUTOR = "Distributors"; // NCIOT-12118,12122
  public static final String USER_MANAGEMENT_FOR_ICS_SERVICE_CORDINATOR_ROLE =
      "user_management_for_service_coordinator"; // NCIOT-12111
  public static final String SM = "SM";

  public static final String SUBJECT_ASSIGNED =
      "Notification of events for devices has been detected";
  public static final String SUBJECT_UNASSIGNED = SUBJECT_ASSIGNED + " ";
  public static final String RECIPIENTS_ASSIGNED_NOTIFICATION_FSE_CUSTOMER_DISTRIBUTOR =
      "RECIPIENTS_ASSIGNED_NOTIFICATION_FSE_CUSTOMER_DISTRIBUTOR";
  public static final String RECIPIENTS_UNASSIGNED_NOTIFICATION_FSE_CUSTOMER_DISTRIBUTOR =
      "RECIPIENTS_UNASSIGNED_NOTIFICATION_FSE_CUSTOMER_DISTRIBUTOR";

  public static final String ORG_CAPITAL = "ORG";
  public static final String BUSINESS_UNIT = "Business Unit";

  public static final String VIEW_COVERED_TERRITORIES = "view_covered_territories";
  public static final String GREATER_THAN_SIX_MONTHS = "> 6 Months";
  public static final String LESS_THAN_SIX_MONTHS = "< 6 Months";
  public static final String NONE_CONSTANT = "None";
  public static final String ORG_NAME_CONSTRINT = "org.name";
  public static final String ORG_USER_NAME = "user.org.name";
  public static final String USER_ROLE_NAME = "user.role.name";
  public static final String ROLE_NAME = "role.name";
  public static final String USER_COUNTRY_COUNTRY_CODE = "user.country.countryCode";
  public static final String COUNTRY_COUNTRYCODE = "country.countryCode";
  public static final String USER_EMAIL = "user.email";
  public static final String EMAIL = "email";
  public static final String UNKNOWN = "Unknown";
  public static final List<String> BUSINESS_UNIT_ROLES_MCS_ICS =
      Arrays.asList(LW_MCS, LW_SERVICE_COORDINATOR);
  public static final List<String> LABWATER_BUSINESS_ROLES =
      Arrays.asList(
          LW_SUPER_ADMIN,
          LW_SERVICE_ADMIN,
          LW_FSE,
          LW_BUSINESS_MANAGER,
          LW_MCS,
          ICS_SERVICE_COORDINATOR); // NCIOT-1696

  public static final String ACTIVE_USER_STATUS = "Active";
  public static final String INPROGRESS_USER_STATUS = "In Progress";
  public static final String INACTIVE_USER_STATUS = "Inactive";
  public static final List<String> USER_STATUS =
      Arrays.asList(ACTIVE_USER_STATUS, INPROGRESS_USER_STATUS, INACTIVE_USER_STATUS);

  public static final String NO_FILTER = "no_filter";
  public static final String USA_COUNTRY_CODE = "US";
  public static final String CANADA_COUNTRY_CODE = "CA";
  public static final String OTHER = "OTH";
  public static final String MANAGE_DEVICE_TYPE_PRIVILEGE = "manage_deviceTypeManagement";
  public static final String FEEDBACK_DISTRIBUTOR_ROLES =
      "Technical User,Quality Manager,Customer Admin";
  public static final List<String> ROLES_CREATED_BY_FSS =
      Arrays.asList(
          CUSTOMER_ADMIN,
          QUALITY_MANAGER,
          TECHNICAL_USER,
          EXTERNAL_CUSTOMER_TECH,
          LW_SERVICE_COORDINATOR,
          FSS_USER);
  public static final List<String> ROLES_CREATED_BY_ICS_COORDINATOR =
      Arrays.asList(
          CUSTOMER_ADMIN,
          QUALITY_MANAGER,
          TECHNICAL_USER,
          EXTERNAL_CUSTOMER_TECH,
          PARTNER_ADMIN,
          PARTNER_HOTLINE,
          DISTRIBUTOR_ADMIN,
          LW_SERVICE_COORDINATOR,
          FSS_USER,
          DISTRIBUTOR_FSE);
  public static final String VIEW_RATING_FEEDBACK_PRVLG = "view_ratingfeedback"; // NCIOT-16412
  public static final List<String> BUSINESS_UNIT_ROLES =
      Arrays.asList(
          LW_SUPER_ADMIN,
          LW_BUSINESS_MANAGER,
          LW_SERVICE_ADMIN,
          LW_MCS,
          LW_SERVICE_COORDINATOR,
          LW_FSE);
  public static final List<String> MANUALLY_CREATED_ORG_DELETE_ACCESS_ROLES =
      Arrays.asList(SERVICE_ADMIN, LW_SERVICE_COORDINATOR, DISTRIBUTOR_ADMIN);
  public static final String FEED_TREND_DATE_FORMAT = "yyyy-MM-dd";
  public static final Integer FEEDBACK_INTERVAL_IN_DAYS = 7;
  public static final Long FEEDBACK_DURATION_THREE_MONTHS = 3L;
  public static final Long DEFAULT_LONG_NUMBER_ONE = 1L;
  public static final String HYPHEN = "-";
  public static final String FEED_BACK_DATE_FORMAT_FOR_THREE_MONTHS = "dd/MM/yyyy";
  public static final String SLASH_STRING = "/";
  public static final String INVITE_USER_AUTO_ORG_SELF_REG = "INVITE_USER_AUTO_ORG_SELF_REG";
  public static final String INVITE_USER_LABWATER_ROLE_MANUAL = "INVITE_USER_LABWATER_ROLE_MANUAL";
  public static final String INVITE_USER_NON_LABWATER_ROLE_MANUAL =
      "INVITE_USER_NON_LABWATER_ROLE_MANUAL";

  public static final String YES = "YES";
  public static final String DISTRIBUTOR_ROLE = "DISTRIBUTOR";
  public static final String CUSTOMER_ROLE = "CUSTOMER";

  public static final List<String> ROLES_CANT_BE_DELETED_BY_BM =
      Arrays.asList(CUSTOMER_ADMIN, TECHNICAL_USER, QUALITY_MANAGER, EXTERNAL_CUSTOMER_TECH);
  public static final List<String> ROLES_CANT_BE_DELETED_BY_SM =
      Arrays.asList(
          CUSTOMER_ADMIN,
          TECHNICAL_USER,
          QUALITY_MANAGER,
          EXTERNAL_CUSTOMER_TECH,
          PARTNER_HOTLINE,
          DISTRIBUTOR_FSE);
  public static final List<String> ROLES_CANT_BE_DELETED_BY_MCS =
      Arrays.asList(
          CUSTOMER_ADMIN,
          TECHNICAL_USER,
          QUALITY_MANAGER,
          EXTERNAL_CUSTOMER_TECH,
          PARTNER_ADMIN,
          PARTNER_HOTLINE,
          DISTRIBUTOR_ADMIN,
          DISTRIBUTOR_FSE);
  public static final List<String> ROLES_CANT_BE_DELETED_BY_ICS =
      Arrays.asList(
          CUSTOMER_ADMIN,
          TECHNICAL_USER,
          QUALITY_MANAGER,
          PARTNER_ADMIN,
          PARTNER_HOTLINE,
          DISTRIBUTOR_ADMIN,
          DISTRIBUTOR_FSE,
          EXTERNAL_CUSTOMER_TECH);
  public static final List<String> ROLES_CANT_BE_UPDATED_BY_BM =
      Arrays.asList(EXTERNAL_CUSTOMER_TECH);
  public static final List<String> ROLES_CANT_BE_UPDATED_BY_SM =
      Arrays.asList(EXTERNAL_CUSTOMER_TECH, DISTRIBUTOR_FSE, PARTNER_HOTLINE);
  public static final List<String> ROLES_CANT_BE_UPDATED_BY_ICS =
      Arrays.asList(EXTERNAL_CUSTOMER_TECH, DISTRIBUTOR_FSE);
  public static final List<String> ROLES_CANT_BE_UPDATED_BY_MCS =
      Arrays.asList(
          EXTERNAL_CUSTOMER_TECH,
          DISTRIBUTOR_ADMIN,
          DISTRIBUTOR_FSE,
          PARTNER_ADMIN,
          PARTNER_HOTLINE);

  public static final List<String> CUSTOMER_ROLES_EXCLUDING_CUST_QUALITY =
      Arrays.asList(CUSTOMER_ADMIN, TECHNICAL_USER, EXTERNAL_CUSTOMER_TECH);
  public static final String SERVICE_CONTRACT_MANAGEMENT = "SERVICE_CONTRACT_MANAGEMENT";

  public static final List<String> COUNTRY_FILTER_ROLES =
      Arrays.asList(
          SUPER_ADMIN,
          LW_BUSINESS_MANAGER,
          SERVICE_ADMIN,
          ICS_SERVICE_COORDINATOR,
          LW_MCS,
          DISTRIBUTOR_ADMIN);
  public static final String CUSTOMER_ADMIN_INACTIVE = "CUSTOMER_ADMIN_INACTIVE";
  public static final String USER_VALIDATION_BY_CA = "USER_VALIDATION_BY_CA";
  public static final String COUNTRY_CHANGE = "COUNTRY_CHANGE";
  public static final String SERVICE_ROLE = "isServiceRole";

  public static final String ASSIGN_DEVICE = "assign_device";
  public static final String SELF_REGISTRATION_SMS = "SELF_REGISTRATION_SMS";
  public static final String SMS_SELF_REG_CA = "SMS_SELF_REG_CA";
  public static final String CA_EMAIL = "caEmail";
  public static final String CA_PHONE_NUMBER = "caPhoneNumber";
  public static final String CA_NAME = "caName";
  public static final String SYSTEM_NAME = "systemName";
  public static final String CA_LANGUAGE = "caLanguage";
  public static final String SELF_USER_EMAIL = "userEmail";
  public static final String DIRECT_CUSTOMER = "Direct Customer";
  public static final String INDIRECT_CUSTOMER = "Indirect Customer";
}
