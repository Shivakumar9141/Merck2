package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.SelfRegisteredUserDeviceMapping;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author SHATHWAR Made changes as per NCIOT-12313.
 */
public interface SelfRegisteredUserDeviceRepository
    extends JpaRepository<SelfRegisteredUserDeviceMapping, Long> {

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userId
   * @return SelfRegisteredUserDeviceMapping
   */
  SelfRegisteredUserDeviceMapping findByUserProfileUserId(long userId);

  List<SelfRegisteredUserDeviceMapping> findAllByUserProfileUserId(long userId);
}
