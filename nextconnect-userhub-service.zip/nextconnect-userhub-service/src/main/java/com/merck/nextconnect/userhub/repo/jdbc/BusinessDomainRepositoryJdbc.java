package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * Repository for Business Domain
 *
 * @author SSHREEBE
 */
@Repository
public class BusinessDomainRepositoryJdbc {

  private static final Logger LOGGER = LoggerFactory.getLogger(BusinessDomainRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterjdbcTemplate;

  private static final String SQL_SELECT_ALL_BUSINESS_DOMAIN =
      "Select domain_id as domainId, domain_name as domainName from nc_business_domain";

  private static final String SQL_BUSINESS_DOMAIN_FOR_USER =
      "SELECT d.domain_id as domainId, d.domain_name as domainName FROM nc_business_domain d INNER JOIN nc_user_business_domain u ON d.domain_id=u.domain_id where u.user_id=:userId";

  // NCIOT-1696
  public List<BusinessDomainDTO> obtainAllBusinessDomain() {
    try {

      Map<String, Object> namedParameters = new HashMap<>();
      List<Map<String, Object>> businessDomainList =
          namedParameterjdbcTemplate.queryForList(SQL_SELECT_ALL_BUSINESS_DOMAIN, namedParameters);
      return businessDomainList.stream()
          .map(
              e -> {
                BusinessDomainDTO details = new BusinessDomainDTO();
                details.setDomainId((Integer) e.get("domainId"));
                details.setDomainName((String) e.get("domainName"));

                return details;
              })
          .collect(Collectors.toList());

    } catch (Exception e) {
      LOGGER.error("Exception occured while obatining the data ", e);
    }
    return Collections.emptyList();
  }

  public BusinessDomainDTO fetchDomainForUser(Long userId) {
    BusinessDomainDTO businessDomainDTO = null;
    try {

      Map<String, Object> namedParameters = new HashMap<>();
      namedParameters.put("userId", userId);
      LOGGER.info("SQL_BUSINESS_DOMAIN_FOR_USER : {} ", SQL_BUSINESS_DOMAIN_FOR_USER);
      businessDomainDTO =
          (BusinessDomainDTO)
              namedParameterjdbcTemplate.queryForObject(
                  SQL_BUSINESS_DOMAIN_FOR_USER,
                  namedParameters,
                  new BeanPropertyRowMapper(BusinessDomainDTO.class));
      LOGGER.info("businessDomainDTO : {}", businessDomainDTO);

      return businessDomainDTO;

    } catch (Exception e) {
      LOGGER.error("Exception occured while fetching domain for the user ", e);
    }
    return businessDomainDTO;
  }
}
