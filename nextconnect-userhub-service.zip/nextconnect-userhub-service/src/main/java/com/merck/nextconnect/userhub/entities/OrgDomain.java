package com.merck.nextconnect.userhub.entities;

import com.merck.nextconnect.utils.common.entities.UserDomain;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "NC_ORG_DOMAIN")
public class OrgDomain {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @ManyToOne
  @JoinColumn(name = "ORG_ID")
  private Organization org;

  @ManyToOne
  @JoinColumn(name = "DOMAIN_ID")
  private UserDomain domain;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Organization getOrg() {
    return org;
  }

  public void setOrg(Organization org) {
    this.org = org;
  }

  public UserDomain getDomain() {
    return domain;
  }

  public void setDomain(UserDomain domain) {
    this.domain = domain;
  }
}
