package com.merck.nextconnect.userhub.helper;

import com.merck.nextconnect.userhub.repo.jdbc.CoveredProductRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.DeviceRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpClientErrorException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpServerErrorException;
import com.merck.nextconnect.utils.hazelcast.service.ServiceMaxTokenService;
import com.merck.nextconnect.utils.servicemax.model.ServiceMaxAuthInfo;
import com.merck.nextconnect.utils.servicemax.resources.ServiceMaxService;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class UserHubServiceMaxHelper {

  static final Logger LOGGER = LoggerFactory.getLogger(UserHubServiceMaxHelper.class);

  @Value("${servicemax.service.ip.url}")
  private String smInstalledProductURL;

  @Value("${servicemax.service.cp.url}")
  private String smCoveredProductURL;

  @Value("${servicemax.service.query.url}")
  private String smServiceURL;

  @Value("${servicemax.hazelcast.validity}")
  private Long tokenValidity;

  @Value("${servicemax.client.id}")
  private String smClientId;

  @Value("${servicemax.client.secret}")
  private String smClientSecret;

  @Value("${servicemax.username}")
  private String smUserName;

  @Value("${servicemax.password}")
  private String smPassword;

  @Value("${servicemax.token.url}")
  private String smTockenURL;

  @Value("${servicemax.api.max.retry}")
  private Integer maxRetry;

  @Autowired private ServiceMaxService serviceMaxService;

  @Autowired ServiceMaxTokenService serviceMaxTokenService;

  @Autowired CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;

  @Autowired DeviceRepositoryJdbc deviceRepositoryJdbc;

  @Autowired UserDevicePrivilegeRepository userDevicePrivilegeRepo;

  private static final String GET_IP_REQUEST_QUERY =
      "q=SELECT+Network__c+FROM+SVMXC__Installed_Product__c+WHERE+Id=";
  private static final String GET_CP_REQUEST_QUERY =
      "q=SELECT+Network__c+FROM+SVMXC__Service_Contract_Products__c+WHERE+Id=";
  private static final String FLAG_IP = "IP";
  private static final String FLAG_CP = "CP";
  private static final String RECORDS = "records";

  public String getSMToken() throws CustomHttpClientErrorException, CustomHttpServerErrorException {
    return serviceMaxService.getAuthToken(
        smTockenURL,
        ServiceMaxAuthInfo.builder()
            .smClientId(smClientId)
            .smClientSecret(smClientSecret)
            .smUserName(smUserName)
            .smPassword(smPassword)
            .build(),
        tokenValidity);
  }

  public ServiceMaxAuthInfo getServiceMaxAuthInfo() {
    return ServiceMaxAuthInfo.builder()
        .smClientId(smClientId)
        .smClientSecret(smClientSecret)
        .smUserName(smUserName)
        .smPassword(smPassword)
        .build();
  }

  public void updateMymilliqActivatedCheckBoxIP(String smDeviceId, boolean isMymilliqActivated) {

    Boolean isMyMilliqActivatedCheckboxTicked =
        isMyMilliqActivatedCheckboxTicked(FLAG_IP, smDeviceId);

    LOGGER.debug(
        "isMymilliqActivated : {} isMyMilliqActivatedCheckboxTicked {}",
        isMymilliqActivated,
        isMyMilliqActivatedCheckboxTicked);

    if (isMymilliqActivated) {
      if (isMyMilliqActivatedCheckboxTicked == null || isMyMilliqActivatedCheckboxTicked) {
        LOGGER.debug(
            "Not updating as MymilliqActivated CheckBox for smDeviceId : {} is {}",
            smDeviceId,
            isMyMilliqActivatedCheckboxTicked);
      } else {
        LOGGER.debug(
            "updating MymilliqActivated CheckBox for smDeviceId : {} as {} ",
            smDeviceId,
            isMymilliqActivated);

        Map<String, Object> params = new HashMap<String, Object>();
        params.put(com.merck.nextconnect.utils.common.Constants.NETWORK_C, isMymilliqActivated);

        invokeUpdateServiceMaxObjectAPI(smInstalledProductURL + smDeviceId, params);
      }
    } else {
      if (isMyMilliqActivatedCheckboxTicked == null || !isMyMilliqActivatedCheckboxTicked) {
        LOGGER.debug(
            "Not updating as MymilliqActivated CheckBox for smDeviceId : {} is {}",
            smDeviceId,
            isMyMilliqActivatedCheckboxTicked);
      } else {
        LOGGER.debug(
            "updating MymilliqActivated CheckBox for smDeviceId : {} as {} ",
            smDeviceId,
            isMymilliqActivated);

        Map<String, Object> params = new HashMap<String, Object>();
        params.put(com.merck.nextconnect.utils.common.Constants.NETWORK_C, isMymilliqActivated);

        invokeUpdateServiceMaxObjectAPI(smInstalledProductURL + smDeviceId, params);
      }
    }
  }

  public void updateMymilliqActivatedCheckBoxCP(
      String smCoveredProductId, boolean isMymilliqActivated) {

    Boolean isMyMilliqActivatedCheckboxTicked =
        isMyMilliqActivatedCheckboxTicked(FLAG_CP, smCoveredProductId);

    LOGGER.debug(
        "isMymilliqActivated : {} isMyMilliqActivatedCheckboxTicked {}",
        isMymilliqActivated,
        isMyMilliqActivatedCheckboxTicked);

    if (isMymilliqActivated) {
      if (isMyMilliqActivatedCheckboxTicked == null || isMyMilliqActivatedCheckboxTicked) {
        LOGGER.debug(
            "Not updating as MymilliqActivated CheckBox for smCoveredProductId : {} is {}",
            smCoveredProductId,
            isMyMilliqActivatedCheckboxTicked);
      } else {
        LOGGER.debug(
            "updating MymilliqActivated CheckBox for smCoveredProductId : {} as {} ",
            smCoveredProductId,
            isMymilliqActivated);
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(com.merck.nextconnect.utils.common.Constants.NETWORK_C, isMymilliqActivated);

        invokeUpdateServiceMaxObjectAPI(smCoveredProductURL + smCoveredProductId, params);
      }
    } else {
      if (isMyMilliqActivatedCheckboxTicked == null || !isMyMilliqActivatedCheckboxTicked) {
        LOGGER.debug(
            "Not updating as MymilliqActivated CheckBox for smCoveredProductId : {} is {}",
            smCoveredProductId,
            isMyMilliqActivatedCheckboxTicked);
      } else {
        LOGGER.debug(
            "updating MymilliqActivated CheckBox for smCoveredProductId : {} as {} ",
            smCoveredProductId,
            isMymilliqActivated);
        Map<String, Object> params = new HashMap<String, Object>();
        params.put(com.merck.nextconnect.utils.common.Constants.NETWORK_C, isMymilliqActivated);

        invokeUpdateServiceMaxObjectAPI(smCoveredProductURL + smCoveredProductId, params);
      }
    }
  }

  public void invokeUpdateServiceMaxObjectAPI(String serviceUrl, Map<String, Object> params) {
    serviceMaxService.invokeUpdateServiceMaxObjectAPI(
        getServiceMaxAuthInfo(), smTockenURL, tokenValidity, maxRetry, serviceUrl, params);
  }

  /**
   * Check if the MymilliQActivated check box is already ticked in service max
   *
   * @param flag
   * @param id
   * @return
   */
  private Boolean isMyMilliqActivatedCheckboxTicked(String flag, String id) {
    Boolean isMyMilliqActivatedCheckboxTicked = null;
    try {
      String sql = "";
      if (FLAG_IP.equalsIgnoreCase(flag)) {
        sql = GET_IP_REQUEST_QUERY;
      } else if (FLAG_CP.equalsIgnoreCase(flag)) {
        sql = GET_CP_REQUEST_QUERY;
      }
      String query = sql + Constants.APOSTROPHE + id + Constants.APOSTROPHE;

      StringBuilder serviceMaxURL = new StringBuilder();
      serviceMaxURL.append(smServiceURL);
      serviceMaxURL.append(query);

      ResponseEntity<String> response =
          serviceMaxService.getServiceMaxData(
              getServiceMaxAuthInfo(),
              smTockenURL,
              tokenValidity,
              maxRetry,
              serviceMaxURL.toString());

      if (response != null) {
        JSONObject jsonResponse = new JSONObject(response.getBody());
        JSONObject record = jsonResponse.getJSONArray(RECORDS).getJSONObject(0);
        isMyMilliqActivatedCheckboxTicked =
            record.getBoolean(com.merck.nextconnect.utils.common.Constants.NETWORK_C);
        return isMyMilliqActivatedCheckboxTicked;
      }

    } catch (Exception e) {
      LOGGER.error("Exception occured :", e);
    }
    return isMyMilliqActivatedCheckboxTicked;
  }
}
