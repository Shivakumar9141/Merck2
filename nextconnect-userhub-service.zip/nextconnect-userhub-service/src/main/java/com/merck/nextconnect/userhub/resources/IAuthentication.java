package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.authfilter.model.AuthToken;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.UserInfo;
import com.merck.nextconnect.userhub.model.user.UserLoginInfo;
import com.merck.nextconnect.userhub.response.SamlAuthResponse;
import org.springframework.stereotype.Service;

/**
 * interface to perform user authentication
 *
 * @author <a href="mailto:shihas.arakkal@sial.com"/>Shihas Arakkal
 */
@Service
public interface IAuthentication {

  /**
   * authenticate the user
   *
   * @param login - user loginame and password
   * @return AuthToken - user tokens
   * @throws AccessDeniedException
   */
  AuthToken login(Login login) throws AccessDeniedException;

  /**
   * gets the user login info
   *
   * @param loginText - user loginame
   * @return UserLoginInfo - user info
   */
  UserLoginInfo getLoginTypes(String loginText);

  /**
   * gets the user info
   *
   * @param userId - user id
   * @param username - user name
   * @return UserDetail - user details
   * @throws ResourceNotFoundException
   */
  UserInfo getUserInfo(long userId, String username, int orgId) throws ResourceNotFoundException;

  /**
   * authenticate the user by saml response
   *
   * @param saml response
   * @return AuthToken - user tokens
   */
  SamlAuthResponse loginBySaml(String samlResponse);

  String getTokenFromCacheByHash(String token) throws Exception;
}
