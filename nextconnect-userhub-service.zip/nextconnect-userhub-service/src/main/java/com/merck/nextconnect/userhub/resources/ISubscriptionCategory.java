package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import org.springframework.stereotype.Component;

@Component
public interface ISubscriptionCategory {

  public SubscriptionCategory findOneByCategoryId(Long categoryId);
}
