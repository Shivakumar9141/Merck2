package com.merck.nextconnect.userhub.entities;

import java.util.List;

public class UsersListingFacets {
  private List<String> role;
  private List<String> status;
  private List<String> org;
  private List<String> countryCode;

  public List<String> getRole() {
    return role;
  }

  public List<String> getStatus() {
    return status;
  }

  public List<String> getOrg() {
    return org;
  }

  public void setOrg(List<String> org) {
    this.org = org;
  }

  public void setRole(List<String> role) {
    this.role = role;
  }

  public void setStatus(List<String> status) {
    this.status = status;
  }

  public List<String> getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(List<String> countryCode) {
    this.countryCode = countryCode;
  }
}
