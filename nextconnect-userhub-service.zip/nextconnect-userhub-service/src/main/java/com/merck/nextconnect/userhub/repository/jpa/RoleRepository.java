package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Role;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * interface talks with role table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface RoleRepository extends JpaRepository<Role, Long> {

  @Query("from Role r where r.roleId = :id and r.org.id = :org")
  Role getRoleByOrg(@Param("id") long id, @Param("org") int org);

  @Query("from Role r where lower(r.name) = lower(:name) and r.org.id = :org")
  Role getRoleByName(@Param("name") String name, @Param("org") int org);

  @Transactional
  @Modifying
  @Query("UPDATE Role r SET r.name = :name where " + "r.roleId = :id and r.org.id = :org")
  int update(@Param("name") String name, @Param("id") long id, @Param("org") int org);

  @Query("from Role r where r.systemDefined = false and r.org.id = :org and r.isServiceRole=false")
  List<Role> getUserDefinedRoles(@Param("org") int org);

  @Query(
      "from Role r where r.systemDefined = false and r.org.id = :org or r.roleId = :id and r.isServiceRole=false")
  List<Role> getAllForSystemDefinedRoles(@Param("id") long id, @Param("org") int org);

  @Transactional
  @Modifying
  @Query("delete from Role r where r.roleId = :id and r.org.id = :org")
  int deleteByOrgId(@Param("id") long id, @Param("org") int org);

  @Query("from Role r where r.org.id = :org and r.isServiceRole=false")
  List<Role> getRoles(@Param("org") int org);

  // NCIOT-16412
  @Query(
      value =
          "select * from nc_roles where system_defined = 0 and org_id = :org or role_id = :id or org_id in (select id from nc_org where type = 'Customers')",
      nativeQuery = true)
  List<Role> getAllForSystemDefinedRolesWithCustomer(@Param("id") long id, @Param("org") int org);

  // NCIOT-16412
  @Query(
      "from Role r where lower(r.name) = lower(:name) and r.org.id in (select o.id from r.org o where o.type='Customers' or (o.type = 'DEFAULT TEMPLATE' and o.name='LABWATER_DEFAULT_TEMPLATE'))")
  List<Role> getCustomerTypeRolesByName(@Param("name") String name);
}
