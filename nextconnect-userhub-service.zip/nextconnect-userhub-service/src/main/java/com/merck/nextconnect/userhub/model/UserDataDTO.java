package com.merck.nextconnect.userhub.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.merck.nextconnect.userhub.util.JsonDateSerializer;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class UserDataDTO {

  private Long userId;
  private String firstName;
  private String lastName;
  private String customerOrgName;
  private String language;
  private String countryName;

  @JsonSerialize(using = JsonDateSerializer.class)
  private Date createdDate;

  private Integer rating;
  private String feedback;
  private String countryCode;
  private String role;
  private String email;
  private Long orgId;
  private String userOrgCreatedVia;
}
