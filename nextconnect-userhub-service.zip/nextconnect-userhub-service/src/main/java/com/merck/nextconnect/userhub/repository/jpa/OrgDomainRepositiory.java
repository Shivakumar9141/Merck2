package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.OrgDomain;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgDomainRepositiory extends JpaRepository<OrgDomain, Integer> {

  @Query("select d.domain from OrgDomain d where d.org.id = :org")
  List<UserDomain> getDomains(@Param("org") int org);
}
