/** */
package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import jakarta.mail.MessagingException;
import org.springframework.stereotype.Component;

/** */
@Component
public interface IUserSupport {
  /**
   * add a user
   *
   * @param userDetails - userDetails
   * @return UserProfile
   * @throws DuplicateResourceException
   * @throws DataValidationException
   * @throws MessagingException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws com.merck.nextconnect.userhub.exception.AccessDeniedException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   */
  UserProfile add(UserDetails userDetails)
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          AccessDeniedException,
          com.merck.nextconnect.userhub.exception.DataValidationException;
}
