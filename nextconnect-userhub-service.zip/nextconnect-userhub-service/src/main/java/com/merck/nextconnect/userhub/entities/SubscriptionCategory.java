package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "nc_subscription_category")
public class SubscriptionCategory implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "subscription_category_id")
  private Long subscriptionCategoryId;

  @Column(name = "category_name")
  private String categoryName;

  @Column(name = "type")
  private String type;

  @Column(name = "status")
  private String status;

  @Column(name = "remarks")
  private String remarks;

  @Column(name = "created_ts")
  private Timestamp createdTimestamp;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "last_updated_by")
  private String lastUpdatedBy;

  @Column(name = "last_updated_ts")
  private Timestamp lastUpdatedTimestamp;

  @ManyToOne // (fetch = FetchType.EAGER)
  @JoinColumn(name = "subscription_type_id")
  private SubscriptionType subscriptionType;
}
