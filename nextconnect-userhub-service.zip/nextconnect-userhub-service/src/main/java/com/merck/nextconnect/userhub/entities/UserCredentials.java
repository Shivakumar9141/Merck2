package com.merck.nextconnect.userhub.entities;

import com.merck.nextconnect.userhub.model.user.AccountStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "NC_USER_CREDENTIALS")
public class UserCredentials {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long credentialId;

  private String loginText;

  private String passwordHash;

  private Timestamp createdTime;

  private String status;

  @OneToOne
  @JoinColumn(name = "USER_ID")
  private UserProfile userProfile;

  public UserCredentials() {}

  public UserCredentials(String loginText, String passwordHash) {
    this.loginText = loginText;
    this.passwordHash = passwordHash;
    this.status = AccountStatus.ACTIVE.value();
    this.createdTime = new Timestamp(new Date().getTime());
  }

  public long getCredentialId() {
    return credentialId;
  }

  public void setCredentialId(long credentialId) {
    this.credentialId = credentialId;
  }

  public String getLoginText() {
    return loginText;
  }

  public void setLoginText(String loginText) {
    this.loginText = loginText;
  }

  public String getPasswordHash() {
    return passwordHash;
  }

  public void setPasswordHash(String passwordHash) {
    this.passwordHash = passwordHash;
  }

  public UserProfile getUserProfile() {
    return userProfile;
  }

  public void setUserProfile(UserProfile userProfile) {
    this.userProfile = userProfile;
  }

  public Timestamp getCreatedTime() {
    return createdTime;
  }

  public void setCreatedTime(Timestamp createdTime) {
    this.createdTime = createdTime;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }
}
