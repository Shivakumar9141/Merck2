package com.merck.nextconnect.userhub.model;

import com.merck.nextconnect.authfilter.entities.AuthPartnerPeripheralSupplier;
import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import java.util.List;
import lombok.Data;

@Data
public class OrgPartnerBrandPartnerTypeDTO {

  private long orgId;
  private AuthPartnerPeripheralSupplier brand;
  private List<PartnerTypeEntity> partnerTypes;
}
