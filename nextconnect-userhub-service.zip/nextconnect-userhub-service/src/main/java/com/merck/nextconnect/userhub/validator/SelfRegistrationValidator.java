package com.merck.nextconnect.userhub.validator;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.springframework.stereotype.Service;

/**
 * @author SHATHWAR Made changes as per NCIOT-12313.
 */
@Service
public interface SelfRegistrationValidator {
  /**
   * Made changes as per NCIOT-12313.
   *
   * @param device
   * @param userProfile
   * @param country
   * @param selfRegistrationDTO
   * @param roleOfInterest
   * @throws DataValidationException
   */
  void selfRegistrationValidator(
      UserProfile userProfile,
      Country country,
      SelfRegistrationDTO selfRegistrationDTO,
      RoleOfInterest roleOfInterest)
      throws DataValidationException;

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userProfileOfSelfRegisteredUser
   * @param userProfileOfUserValidating
   * @throws DataValidationException
   */
  void selfRegistrationUserValidationValidator(
      UserProfile userProfileOfSelfRegisteredUser, UserProfile userProfileOfUserValidating)
      throws DataValidationException;

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param device
   * @param userProfile
   * @param country
   * @param selfRegistrationDTO
   * @param roleOfInterest
   * @throws DataValidationException
   */
  void selfRegistrationValidator(
      UserProfile userProfile, Country country, SelfRegistrationDTO selfRegistrationDTO)
      throws DataValidationException;

  /**
   * The validation for selfRegistration input Object and cache Objects.
   *
   * @param input
   * @param cache
   * @throws DataValidationException
   */
  void selfRegistrationDataValidation(SelfRegistrationDTO input, SelfRegistrationDTO cache)
      throws DataValidationException;
}
