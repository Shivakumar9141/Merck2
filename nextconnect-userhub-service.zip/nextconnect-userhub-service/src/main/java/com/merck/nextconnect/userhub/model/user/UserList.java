package com.merck.nextconnect.userhub.model.user;

import com.merck.nextconnect.userhub.response.UserListResponseEntity;
import java.util.List;

public class UserList {

  private List<UserListResponseEntity> users;
  private String totalPages;
  private long recordCount;

  public List<UserListResponseEntity> getUsers() {
    return users;
  }

  public void setUsers(List<UserListResponseEntity> convertedUsers) {
    this.users = convertedUsers;
  }

  public String getTotalPages() {
    return totalPages;
  }

  public void setTotalPages(String totalPages) {
    this.totalPages = totalPages;
  }

  public long getRecordCount() {
    return recordCount;
  }

  public void setRecordCount(long recordCount) {
    this.recordCount = recordCount;
  }
}
