package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.util.EntityPrivileges;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.OrganizationType;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.OrgFilter;
import com.merck.nextconnect.userhub.model.OrgPartnerBrandPartnerTypeDTO;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.resources.IOrganization;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.model.FetchCriteria;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriTemplate;

@Component
@RestController
@RequestMapping("/api/v1/orgs")
public class OrgController {

  static final Logger logger = LoggerFactory.getLogger(OrgController.class);

  @Autowired IOrganization organization;

  @Autowired private UserOrgPrivileges userOrgPrivileges;

  /**
   * List all orgs
   *
   * @return orgs
   */
  @Operation(description = "List all orgs", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET)
  @PreAuthorize(EntityPrivileges.CREATE_USER_SW_REPORT) // pentest
  public ResponseEntity<List<OrgDto>> getOrgs(
      @Parameter(name = "operation", description = "operation", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "operation", required = false)
          String operation,
      @Parameter(name = "type", description = "type", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "type", required = false)
          String type,
      @Parameter(name = "searchBy", description = "searchBy", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy) {
    List<OrgDto> orgs = new ArrayList<OrgDto>();
    orgs = organization.getAll(operation, searchBy, type, Constants.ORG_LIST_IN_ADD_USER);
    return new ResponseEntity<List<OrgDto>>(orgs, HttpStatus.OK);
  }

  @Operation(description = "user domains", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/{id}/domains")
  @PreAuthorize(EntityPrivileges.CREATE_USER)
  public ResponseEntity<List<UserDomain>> userDomain(
      @Parameter(name = "id", description = "id of the org", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id", required = true)
          Integer id) {
    List<UserDomain> domains = organization.getDomains(id);
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.DOMAIN, Constants.GET, null));
    return new ResponseEntity<>(domains, HttpStatus.OK);
  }

  @Operation(description = "Create org", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST)
  @PreAuthorize(EntityPrivileges.CREATE_ORG)
  public ResponseEntity<?> createOrg(
      @Parameter(name = "org", description = "org details", schema = @Schema(defaultValue = ""))
          @RequestBody
          OrgInfo orgInfo)
      throws DuplicateResourceException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    int orgId = organization.create(orgInfo);
    logger.info("Start: update historical data subscription");
    // Change for - NCIOT-11195,NCIOT-11196,NCIOT-11197
    if (orgInfo.getHistoricalDataSubscription() != null) {
      logger.info(
          "orgInfo:: historicalDataSubscription --> {}", orgInfo.getHistoricalDataSubscription());
      organization.updateOrgSetting(orgId, orgInfo.getHistoricalDataSubscription());
    }
    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(new UriTemplate("/orgs/{orgId}").expand(orgId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ORG, Constants.POST, null));
    return new ResponseEntity<>(headers, HttpStatus.CREATED);
  }

  @Operation(description = "Update org", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.PUT, value = "/{id}")
  @PreAuthorize(EntityPrivileges.CREATE_ORG)
  public ResponseEntity<?> updateOrg(
      @Parameter(name = "id", description = "org id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          int orgId,
      @Parameter(name = "org", description = "org details", schema = @Schema(defaultValue = ""))
          @RequestBody
          OrgInfo orgInfo)
      throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          CustomException {

    organization.update(orgInfo, orgId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(orgId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ORG, Constants.PUT, properties));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(description = "facets for org listing", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/orgs-facets")
  public ResponseEntity<List<String>> getFacets(
      @Parameter(name = "operation", description = "operation", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "operation", required = false)
          String operation)
      throws Exception {
    List<String> orgFacets = organization.getFacets(operation);
    return new ResponseEntity<List<String>>(orgFacets, HttpStatus.OK);
  }

  @Operation(description = "Delete org", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}")
  @PreAuthorize(EntityPrivileges.CREATE_ORG)
  public ResponseEntity<?> deleteOrg(
      @Parameter(name = "id", description = "org id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          int orgId)
      throws ResourceNotFoundException, CustomException, EmailException {
    organization.delete(orgId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(orgId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ORG, Constants.DELETE, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  /**
   * NCIOT-11333,11332,11286 List of Organization Types based on privileges
   *
   * @return
   * @throws Exception
   */
  @Operation(description = "List all Organization Types", tags = "Organization Types")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/types")
  public ResponseEntity<List<OrganizationType>> getOrganizationType() throws Exception {
    logger.info("Start: getOrganizationType");

    HttpHeaders headers = new HttpHeaders();
    List<OrganizationType> orgtypes = organization.getOrganizationType();
    if (Optional.ofNullable(orgtypes).isPresent()) {
      logger.info("End: getOrganizationType");
      return new ResponseEntity<List<OrganizationType>>(orgtypes, HttpStatus.OK);
    }
    logger.info("End: getOrganizationType failure");
    return new ResponseEntity<List<OrganizationType>>(orgtypes, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * Made changes as per NCIOT-11283
   *
   * @return OrgFilter
   */
  @Operation(description = "Org filter", tags = "Org")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/filter")
  public ResponseEntity<OrgFilter> filter() {
    return new ResponseEntity<>(organization.getFilter(), HttpStatus.OK);
  }

  /**
   * Made changes as per NCIOT-11283
   *
   * @param sortBy
   * @param orderBy
   * @param filterBy
   * @param searchBy
   * @param page
   * @param pageLimit
   * @return List<OrgDto>
   * @throws CustomException if any error occurs while quering the database based on fetchcriteria
   */
  @Operation(
      summary = "List of all organization with filter",
      tags = "Org",
      description =
          "This API is used to fetch the list of organization based on search term and filters from NextConnect platform.")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/list")
  @PreAuthorize(EntityPrivileges.CREATE_ORG) // pentest
  public ResponseEntity<List<OrgDto>> getOrgs(
      @Parameter(
              name = "sortBy",
              description = "Sort on a organization",
              schema = @Schema(defaultValue = "name"))
          @RequestParam(value = "sortBy", required = false)
          String sortBy,
      @Parameter(
              name = "orderBy",
              description = "Order by ascending/descending asc/desc",
              schema = @Schema(defaultValue = "asc"))
          @RequestParam(value = "orderBy", required = false)
          String orderBy,
      @Parameter(
              name = "filterBy",
              description = "List of status or org type",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          List<String> filterBy,
      @Parameter(
              name = "searchBy",
              description = "search category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy,
      @Parameter(name = "page", description = "page number", schema = @Schema(defaultValue = "0"))
          @RequestParam(value = "page", required = false)
          Integer page,
      @Parameter(
              name = "pageLimit",
              description = "per page limit",
              schema = @Schema(defaultValue = "10"))
          @RequestParam(value = "pageLimit", required = false)
          Integer pageLimit)
      throws CustomException {

    logger.info("Start of getOrgs");
    if (page == null) {
      page = 1;
    }
    if (pageLimit == null) {
      pageLimit = 10;
    }

    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    Page<Organization> orgList = organization.getAllOrgs(fetchCriteria);
    HttpHeaders headers = new HttpHeaders();
    headers.set(
        "x-pagination-count", String.valueOf(orgList != null ? orgList.getTotalPages() : 0));
    headers.set("x-record-count", String.valueOf(orgList != null ? orgList.getTotalElements() : 0));
    List<OrgDto> orgs = new ArrayList<>();
    if (orgList != null) {
      orgs = organization.orgListConvertor(orgList.getContent());
    }
    logger.info("End of getOrgs");
    return new ResponseEntity<>(
        userOrgPrivileges.addCustomProperties(orgs), headers, HttpStatus.OK);
  }

  /**
   * NCIOT-12118,12122,12123 List of Brand and partner types based Organization Types
   *
   * @return
   * @throws Exception
   */
  @Operation(summary = "List all Brand and Partner Types", tags = "Organization Types")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/brandPartnerTypes")
  public ResponseEntity<OrgPartnerBrandPartnerTypeDTO> getOrgBrandPartnerTypes(
      @Parameter(name = "orgId", description = "orgId", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "orgId", required = false)
          Integer orgId)
      throws Exception {
    logger.info("Start: getPartnerBrandPartnerTypes");
    OrgPartnerBrandPartnerTypeDTO orgBrandPartnerType = organization.getOrgBrandPartnerTypes(orgId);
    if (Optional.ofNullable(orgBrandPartnerType).isPresent()) {
      logger.info("End: getPartnerBrandPartnerTypes");
      return new ResponseEntity<OrgPartnerBrandPartnerTypeDTO>(orgBrandPartnerType, HttpStatus.OK);
    }
    logger.info("End: getPartnerBrandPartnerTypes failure");
    return new ResponseEntity<OrgPartnerBrandPartnerTypeDTO>(
        orgBrandPartnerType, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * NCIOT-17007 : MCOSAT-1911 : REQ-4007
   *
   * @param orgId
   * @param orgInfo
   * @return
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws CustomException
   * @throws EmailException
   */
  @Operation(
      summary = "Update org status",
      tags = "Org",
      description = "This API is used by Service Max application to update the org status")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PatchMapping(value = "/{id}")
  @PreAuthorize(EntityPrivileges.UPDATE_ORG)
  public ResponseEntity<?> updateOrgStatus(
      @Parameter(name = "id", description = "org id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          int orgId,
      @Parameter(name = "org", description = "org details", schema = @Schema(defaultValue = ""))
          @RequestBody
          OrgInfo orgInfo)
      throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          CustomException {
    organization.updateOrgStatus(orgInfo, orgId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(orgId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ORG, Constants.PATCH, properties));
    return new ResponseEntity<>(HttpStatus.OK);
  }
}
