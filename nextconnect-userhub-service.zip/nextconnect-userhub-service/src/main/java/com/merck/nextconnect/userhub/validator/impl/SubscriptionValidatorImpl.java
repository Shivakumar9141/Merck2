/** */
package com.merck.nextconnect.userhub.validator.impl;

import static com.merck.nextconnect.userhub.validations.helper.SubscriptionHelper.validateCountry;
import static com.merck.nextconnect.utils.validations.helper.StringValidationHelpers.notNullString;

import com.merck.nextconnect.userhub.validator.SubscriptionValidator;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Harshit Shrivastava 26-Nov-2018
 */
@Component
public class SubscriptionValidatorImpl implements SubscriptionValidator {

  @Autowired private PhoneNumberValidator phoneNumberValidator;

  @Override
  public void validateSmsIsdSupportedCountries(Country country) throws DataValidationException {
    validateCountry.test(country).throwIfInvalid("ISD code");
  }

  @Override
  public void validateOtp(String isdCode, String phoneNumber, String otp)
      throws DataValidationException {

    notNullString.test(otp).throwIfInvalid("otp");
    phoneNumberValidator.validatePhoneNumber(isdCode, phoneNumber);
  }
}
