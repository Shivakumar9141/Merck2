package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.DeviceType;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.RoleDeviceTypePrivilege;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface RoleDeviceTypePrivilegesRepository
    extends JpaRepository<RoleDeviceTypePrivilege, Long> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.role.RolePrivilege(r.privilege.privilegeId,r.privilege.operation ,r.deviceType.deviceTypeId,r.privilege.resourceType)"
          + " from RoleDeviceTypePrivilege r  where r.role.roleId = :roleId")
  List<RolePrivilege> getPrivileges(@Param("roleId") long roleId);

  @Modifying
  @Transactional
  long deleteByRoleAndPrivilegeAndDeviceType(
      Role roles, Privilege privileges, DeviceType deviceType);

  @Modifying
  @Transactional
  long deleteByPrivilege(Privilege privileges);

  @Modifying
  @Transactional
  @Query("delete from RoleDeviceTypePrivilege r where r.role.roleId = :roleId")
  int deleteByRoleId(@Param("roleId") long roleId);

  /**
   * Changes made as per NCIOT-11630.
   *
   * @param deviceTypeId
   * @param roleId
   * @return List<RoleDeviceTypePrivilege>
   */
  @Query(
      "from RoleDeviceTypePrivilege r where r.deviceType.deviceTypeId = :deviceTypeId and r.role.roleId = :roleId")
  List<RoleDeviceTypePrivilege> findByDeviceTypeIdAndRoleId(
      @Param("deviceTypeId") long deviceTypeId, @Param("roleId") long roleId);
}
