package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author clukose
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuRequest {
  private long userId;
  private long roleId;
  private int orgId;
}
