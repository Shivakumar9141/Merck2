package com.merck.nextconnect.userhub.model;

import com.merck.nextconnect.userhub.model.org.OrgSettingsDto;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import java.util.List;

public class UserInfo {

  private long id;

  private String username;

  private String email;

  private String status;

  private String role;

  private String dateFormat;

  private String countryCode;

  private boolean isDomainVisible;

  private String languageCode;

  private long roleId;

  private int orgId;

  private Integer timeZone;

  private CountryTimezoneDTO countryTimezoneDTO;

  private String domainName;

  private String orgName; // NCIOT-9657

  private boolean isAutoCreated; // Changes made as per NCIOT-11630.

  private String firstName;

  private String lastName;

  private String invitedVia;

  private boolean isValidated;
  private List<MenuGroupResponse> menuGroups; // NCIOT-11851

  private String orgType;

  private String parentType;

  private int emailInviteCount;

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getDomainName() {
    return domainName;
  }

  public void setDomainName(String domainName) {
    this.domainName = domainName;
  }

  private List<Privileges> privileges;

  private OrgSettingsDto orgSettings;

  private UserProfileSettingsDTO userProfileSettings;

  public List<Privileges> getPrivileges() {
    return privileges;
  }

  public void setPrivileges(List<Privileges> privileges) {
    this.privileges = privileges;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getRole() {
    return role;
  }

  public void setRole(String role) {
    this.role = role;
  }

  public long getRoleId() {
    return roleId;
  }

  public void setRoleId(long roleId) {
    this.roleId = roleId;
  }

  public String getDateFormat() {
    return dateFormat;
  }

  public void setDateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public boolean isDomainVisible() {
    return isDomainVisible;
  }

  public void setDomainVisible(boolean isDomainVisible) {
    this.isDomainVisible = isDomainVisible;
  }

  public String getLanguageCode() {
    return languageCode;
  }

  public void setLanguageCode(String languageCode) {
    this.languageCode = languageCode;
  }

  public int getOrgId() {
    return orgId;
  }

  public void setOrgId(int orgId) {
    this.orgId = orgId;
  }

  public Integer getTimeZone() {
    return timeZone;
  }

  public void setTimeZone(Integer timeZone) {
    this.timeZone = timeZone;
  }

  public OrgSettingsDto getOrgSettings() {
    return orgSettings;
  }

  public void setOrgSettings(OrgSettingsDto orgSettings) {
    this.orgSettings = orgSettings;
  }

  public UserProfileSettingsDTO getUserProfileSettings() {
    return userProfileSettings;
  }

  public void setUserProfileSettings(UserProfileSettingsDTO userProfileSettings) {
    this.userProfileSettings = userProfileSettings;
  }

  public String getOrgName() {
    return orgName;
  }

  public void setOrgName(String orgName) {
    this.orgName = orgName;
  }

  public boolean isAutoCreated() {
    return isAutoCreated;
  }

  public void setAutoCreated(boolean isAutoCreated) {
    this.isAutoCreated = isAutoCreated;
  }

  public String getInvitedVia() {
    return invitedVia;
  }

  public void setInvitedVia(String invitedVia) {
    this.invitedVia = invitedVia;
  }

  public boolean isValidated() {
    return isValidated;
  }

  public void setValidated(boolean isValidated) {
    this.isValidated = isValidated;
  }

  public List<MenuGroupResponse> getMenuGroups() {
    return menuGroups;
  }

  public void setMenuGroups(List<MenuGroupResponse> menuGroups) {
    this.menuGroups = menuGroups;
  }

  public String getOrgType() {
    return orgType;
  }

  public void setOrgType(String orgType) {
    this.orgType = orgType;
  }

  public String getParentType() {
    return parentType;
  }

  public void setParentType(String parentType) {
    this.parentType = parentType;
  }

  public CountryTimezoneDTO getCountryTimezoneDTO() {
    return countryTimezoneDTO;
  }

  public void setCountryTimezoneDTO(CountryTimezoneDTO countryTimezoneDTO) {
    this.countryTimezoneDTO = countryTimezoneDTO;
  }

  public int getEmailInviteCount() {
    return emailInviteCount;
  }

  public void setEmailInviteCount(int emailInviteCount) {
    this.emailInviteCount = emailInviteCount;
  }
}
