package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.AuthUserDevicePrivilegeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.UserAccessTokenRepository;
import com.merck.nextconnect.authfilter.repository.jpa.UserTerritoryRepository;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.converter.UserListConverter;
import com.merck.nextconnect.userhub.converter.UserProfileConverter;
import com.merck.nextconnect.userhub.entities.BusinessDomain;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.SelfRegisteredUserDeviceMapping;
import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.UserBusinessDomain;
import com.merck.nextconnect.userhub.entities.UserCredentials;
import com.merck.nextconnect.userhub.entities.UserDeviceAssignmentTrack;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UserProfileSettings;
import com.merck.nextconnect.userhub.entities.UserSubscription;
import com.merck.nextconnect.userhub.entities.UsersListingFacets;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.mail.IMailService;
import com.merck.nextconnect.userhub.mail.MailTemplate;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.model.UserProfileImageDTO;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.user.Credentials;
import com.merck.nextconnect.userhub.model.user.ResetCredential;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.model.user.UserList;
import com.merck.nextconnect.userhub.model.user.UserPatch;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repo.jdbc.BusinessDomainRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.GenericJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.UserProfileImageRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.CoveredProductRepository;
import com.merck.nextconnect.userhub.repository.jpa.DateFormatRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrgDomainRepositiory;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleEntityPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.SelfRegisteredUserDeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.ServiceContractRepository;
import com.merck.nextconnect.userhub.repository.jpa.SubscriptionCategoryRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserBusinessDomainRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserCredentialsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDeviceAssignmentTrackRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDomainRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserProfileSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserSpecification;
import com.merck.nextconnect.userhub.repository.jpa.UserSubscriptionRepository;
import com.merck.nextconnect.userhub.resources.IAccountPolicy;
import com.merck.nextconnect.userhub.resources.IAuthentication;
import com.merck.nextconnect.userhub.resources.ISelfRegistrationService;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.resources.IUserSubscription;
import com.merck.nextconnect.userhub.response.UserListResponseEntity;
import com.merck.nextconnect.userhub.response.UserProfileResponseEntity;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.SmsServiceValidation;
import com.merck.nextconnect.userhub.util.UserHubAsyncService;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.userhub.validator.UserProfileValidator;
import com.merck.nextconnect.utils.common.ServiceRequestType;
import com.merck.nextconnect.utils.common.TemplateName;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.CountryLanguage;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.common.repository.jpa.CountryLanguageRepository;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.LanguageRepository;
import com.merck.nextconnect.utils.email.entities.ApplicationConfig;
import com.merck.nextconnect.utils.email.entities.EmailAttribute;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.exception.CustomSMException;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.model.SmsMessage;
import com.merck.nextconnect.utils.repository.jpa.NcSmsTemplateRepository;
import com.merck.nextconnect.utils.sms.dto.SmsDTO;
import com.merck.nextconnect.utils.sms.resources.SmsService;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.security.Keys;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.crypto.SecretKey;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

/**
 * service class to perform user operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public class UserImpl implements IUser {

  private static final String USER_STATUS = "Active";
  private static final String SELF = "SELF";
  private static final String OTHER = "OTHER";

  static final Logger logger = LoggerFactory.getLogger(UserImpl.class);

  @Autowired UserRepository userRepo;

  @Autowired RoleRepository roleRepo;

  @Autowired UserProfileSettingsRepository userProfileSettingsRepository;

  @Autowired private UserProfileImageRepositoryJdbc userProfileImageRepositoryJdbc;

  @Autowired private UserProfileValidator userProfileImageValidator;

  @Autowired UserCredentialsRepository userCredentialsRepo;

  @Autowired UserDomainRepository userDomainRepo;

  @Autowired JwtTokenGenerator jwtTokenGenerator;

  @Autowired UserRolePrivileges userRolePrivileges;

  @Autowired UserAccessTokenRepository userAccessTokenRepo;

  @Autowired private IMailService mailService;

  @Autowired UserSpecification userSpecification;

  @Autowired DateFormatRepository dateFormatRepo;

  @Autowired LanguageRepository languageRepo;

  @Autowired OrganizationRepository orgRepo;

  @Autowired IOrgPermissions orgPermissions;

  @Autowired private EmailTemplateService emailTemplateService;

  @Autowired private EmailService emailService;

  @Autowired private ISelfRegistrationService selfRegistrationService;

  @Autowired private UserBusinessDomainRepository userBusinessDomainRepo;

  @Autowired private BusinessDomainRepositoryJdbc businessDomainRepositoryJdbc;

  @Autowired IAuthentication authentication;

  @Autowired OrgDomainRepositiory orgDomainRepo;
  @Autowired private UserSubscriptionRepository userSubscriptionRepository;

  @Autowired UserOrgPrivileges userOrgPrivileges;

  @Autowired private IAccountPolicy accountPolicy;

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${user.password_pattern}")
  private String passwordPattern;

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Value("${nextconnect.usermgmtsearch.url}")
  private String userMgmtURL;

  private String firstNamePattern = "^[a-zA-Z].{0,29}$";

  private String lastNamePattern = "^(?=.*[a-zA-Z]).{1,60}$";

  @Autowired private IUserSubscription userSubscriptionService;

  @Autowired private PhoneNumberValidator phoneNumberValidator;

  @Autowired IprivilegeProvider privilegeProvider;

  @Autowired private MailTemplate mailTemplate;

  @Autowired private ApplicationConfigRepository applicationConfigRepository;

  @Autowired private CountryRepository countryRepository;

  @Autowired CountryLanguageRepository countryLanguageRepository;

  @Autowired private UserProfileValidator userProfileValidator;

  @Autowired private DeviceRepository deviceRepository;

  @Autowired private ServiceContractRepository serviceContractRepository;

  @Autowired private RoleEntityPrivilegesRepository roleEntityPrivilegesRepository;

  @Autowired private SubscriptionCategoryRepository subscriptionCategoryRepository;

  @Value("${nextconnect.subscription.numberofdaysadvance}")
  private int numberOfDaysAdvance;

  @Autowired private SmsServiceValidation smsService;

  @Autowired private CoveredProductRepository coveredProductRepository;

  @Autowired private SelfRegisteredUserDeviceRepository selfRegisteredUserDeviceRepository;

  @Autowired UserHubAsyncService userHubAsyncService;

  @Autowired UserTerritoryRepository userTerritoryRepo;

  @Autowired AuthUserDevicePrivilegeRepository userDevicePrivilegeRepo;

  @Autowired GenericJdbc genericJdbc;

  @Autowired private NcSmsTemplateRepository ncSmsTemplateRepository;

  @Value("${nextconnect.sms.url}")
  private String smsHost;

  @Value("${nextconnect.sms.username}")
  private String smsUsername;

  @Value("${nextconnect.sms.password}")
  private String smsPassword;

  @Autowired private SmsService smsServiceImpl;

  @Autowired private UserDeviceAssignmentTrackRepository userDeviceAssignmentTrackRepository;

  /**
   * add a user
   *
   * @param userDetails - userDetails
   * @return UserProfile
   * @throws DuplicateResourceException
   * @throws DataValidationException
   * @throws MessagingException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws com.merck.nextconnect.userhub.exception.AccessDeniedException
   */
  public UserProfile add(UserDetails userDetails)
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          com.merck.nextconnect.userhub.exception.AccessDeniedException {

    // validate the user's phone number
    phoneNumberValidator.validatePhoneNumberFormat(
        userDetails.getIsdCode(), userDetails.getPhone());

    /* Made changes as per NCIOT-12313. */
    AuthenticatedUser authUser =
        UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
            ? null
            : UserhubUtils.getAuthenticatedUser();
    if (userRepo.getUserByEmail(userDetails.getEmail()) != null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.USER_EMAIL_CONFLICT, Arrays.asList(userDetails.getEmail()));
    }
    String loginName = userDetails.getLoginText();
    // NCIOT-13711
    if (StringUtils.isBlank(loginName)) {
      new DataValidationException(CustomErrorCodes.USER_NAME_INVALID);
    }

    UserDomain userDomain = userDomainRepo.findById(userDetails.getDomainId()).orElse(null);
    Optional.ofNullable(userDomain)
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.INVALID_DOMAIN));
    /* Made changes as per NCIOT-12313. */
    if (!UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
        && userRepo.getUser(loginName, userDomain.getAuthenticationProvider(), authUser.getOrgId())
            != null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.USER_LOGIN_NAME_CONFLICT, Arrays.asList(loginName));
    }
    UserProfile user =
        new UserProfile(
            loginName,
            userDetails.getFirstName(),
            userDetails.getLastName(),
            userDetails.getEmail(),
            userDetails.getIsdCode(),
            userDetails.getPhone());
    long roleId = userDetails.getRoleId();
    Role role;
    if (userDetails.getOrgId() != 0) {
      /* Made changes as per NCIOT-12313. */
      if (!UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
        Optional.ofNullable(userDetails)
            .filter(
                uD -> orgPermissions.hasRoleAccess(uD.getOrgId(), OrgPrivileges.manage_accounts))
            .orElseThrow(
                () -> new AccessDeniedException("User doesnt have access to the given org"));
      }
      user.setOrg(orgRepo.findById(userDetails.getOrgId()).orElse(null));
      role = roleRepo.getRoleByOrg(roleId, userDetails.getOrgId());
    } else {
      user.setOrg(orgRepo.findById(authUser.getOrgId()).orElse(null));
      role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    }
    // NCIOT-11199
    Optional.of(user)
        .filter(u -> u.getOrg().getStatus().equals(true))
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.ACCESS_DENIED_SELECTED_ORG_DEACTIVATED));

    Optional.ofNullable(role)
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.INVALID_ROLE_SPECIFIED));
    /* Made changes as per NCIOT-12313. */
    if (!UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      Optional.ofNullable(userDetails)
          .filter(u -> u.getOrgId() == authUser.getOrgId())
          .ifPresent(
              u -> {
                validateActionForSystemDefinedRole(
                    authUser.getRoleId(), authUser.isSystemDefinedRole(), role);
              });
    }
    user.setRole(role);
    user.setUserDomain(userDomain);
    user.setStatus(UserStatus.PENDING.value());
    user.setDateFormat(dateFormatRepo.findById(Constants.DEFAULT_DATE_FORMAT).orElse(null));
    setLanguage(authUser, userDetails, user);
    /* Made changes as per NCIOT-12313. */
    user.setCreatedRole(
        UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
            ? null
            : authUser.getRoleId());
    /* Made changes as per NCIOT-12313. */
    user.setCreatedBy(
        UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
            ? "Self Registered"
            : authUser.getUsername());
    user.setCreatedOn(Timestamp.from(Instant.now()));
    user.setInvitedOrActivatedTs(Timestamp.from(Instant.now()));
    user.setAutoCreated(userDetails.isAutoCreated());
    user.setInvitedVia(
        StringUtils.isNotBlank(userDetails.getInvitedVia())
            ? userDetails.getInvitedVia()
            : Constants.MANUAL);
    if (UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      user.setCountry(countryRepository.findById(userDetails.getCountryId()));
    } else if (UserInvitedVia.INSTALLED_PRODUCT
            .value()
            .equalsIgnoreCase(userDetails.getInvitedVia())
        || UserInvitedVia.SERVIE_CONTRACT.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      user.setCountry(countryRepository.findByCountryCode(userDetails.getCountryCode()));
    }
    user.setEmailInviteCount(1);
    UserProfile userProfile = null; // NCIOT-16020
    synchronized (user) {
      if (userRepo.getUserByEmail(userDetails.getEmail()) == null)
        userProfile = userRepo.save(user);
    }
    if (userProfile == null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.USER_EMAIL_CONFLICT, Arrays.asList(userDetails.getEmail()));
    }
    try {
      sendEmail(userProfile, Constants.INVITE_USER);
    } catch (Exception e) {
      userAccessTokenRepo.deleteByUser(userProfile.getUserId());
      userRepo.deleteById(userProfile.getUserId());
      throw new DataValidationException(CustomErrorCodes.EMAIL_SENDING_ERROR);
    }
    return userProfile;
  }

  /**
   * Sets the language of based on country
   *
   * @param authUser
   * @param userDetails
   * @param user
   */
  private void setLanguage(AuthenticatedUser authUser, UserDetails userDetails, UserProfile user) {

    UserProfile authUserProfile = null;
    if (authUser != null) {
      authUserProfile = userRepo.getUserById(Long.valueOf(authUser.getId()));
    }
    logger.info(
        "invitedVia : {} , countryCode : {} , authUserOrgType : {} ",
        userDetails.getInvitedVia(),
        userDetails.getCountryCode(),
        (authUserProfile != null) ? authUserProfile.getOrg().getType() : "NA");

    if (UserInvitedVia.INSTALLED_PRODUCT.value().equalsIgnoreCase(userDetails.getInvitedVia())
        || UserInvitedVia.SERVIE_CONTRACT.value().equalsIgnoreCase(userDetails.getInvitedVia())
        || UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {

      if (StringUtils.isNotBlank(userDetails.getCountryCode())) {

        if (userDetails.getLanguageId() > 0) {
          user.setLanguage(languageRepo.findById(userDetails.getLanguageId()));
        } else {

          CountryLanguage countryLanguage =
              countryLanguageRepository.findByCountryCountryCode(userDetails.getCountryCode());
          user.setLanguage(countryLanguage.getLanguage());
        }
      } else {
        user.setLanguage(languageRepo.findById(Constants.DEFAULT_LANGUAGE));
      }
    } else if (Constants.ORG_TYPE_CUSTOMER.equalsIgnoreCase(authUserProfile.getOrg().getType())
        || Constants.ORG_TYPE_PARTNER.equalsIgnoreCase(authUserProfile.getOrg().getType())) {
      CountryLanguage countryLanguage =
          countryLanguageRepository.findByCountryCountryCode(
              authUserProfile.getCountry().getCountryCode());
      user.setLanguage(countryLanguage.getLanguage());
    } else if (Constants.ORG_TYPE_DISTRIBUTOR.equalsIgnoreCase(authUserProfile.getOrg().getType())
        || Constants.ORG_TYPE_BUSINESS_UNIT.equalsIgnoreCase(authUserProfile.getOrg().getType())) {
      user.setLanguage(languageRepo.findById(Constants.DEFAULT_LANGUAGE));
    }
  }

  /**
   * delete a user
   *
   * @param userId - id of the user
   * @throws ResourceNotFoundException
   */
  public void delete(long userId) throws ResourceNotFoundException, CustomException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Optional.ofNullable(authUser)
        .filter(a -> Long.parseLong(a.getId()) != userId)
        .orElseThrow(() -> new AccessDeniedException("Unauthorized to delete oneself"));
    UserProfile userProfile = userRepo.getUserById(userId, getAccessibleOrgs());
    Optional.ofNullable(userProfile)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    Optional.ofNullable(userProfile)
        .filter(u -> u.getOrg().getId() == authUser.getOrgId())
        .ifPresent(
            u -> {
              validateActionForSystemDefinedRole(
                  authUser.getRoleId(), authUser.isSystemDefinedRole(), userProfile.getRole());
            });

    deletePrivilegeValidation(authUser, userProfile);

    boolean isUserDelete = true;
    if (Constants.USER_STATUS.stream().anyMatch(userProfile.getStatus()::equalsIgnoreCase)) {
      isUserDelete = validateUserDeletion(userProfile, userProfile.getStatus());
    }
    if (isUserDelete) {
      deleteUser(userProfile);
    }
  }

  /**
   * @param authUser
   * @param userProfile
   * @throws DataValidationException
   */
  private void deletePrivilegeValidation(AuthenticatedUser authUser, UserProfile userProfile)
      throws DataValidationException {
    if (Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_BM.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_DELETE_USER);
    } else if (Constants.LW_SERVICE_ADMIN.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_SM.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_DELETE_USER);
    } else if (Constants.LW_MCS.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_MCS.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_DELETE_USER);
    } else if (Constants.LW_SERVICE_COORDINATOR.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_ICS.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_DELETE_USER);
    }
  }

  /**
   * @param userProfile
   * @param status
   * @return
   * @throws CustomException
   */
  private boolean validateUserDeletion(UserProfile userProfile, String status)
      throws CustomException {
    boolean isDevicesNotAssociated = false;
    boolean isOtherAdminUser = false;

    // check if user has a device(s) assigned to it
    List<Long> userdevices = userDevicePrivilegeRepo.getDevices(userProfile.getUserId());
    if (Optional.ofNullable(userdevices).isPresent() && !userdevices.isEmpty()) {
      if (status.equalsIgnoreCase(Constants.INACTIVE_USER_STATUS)) {
        isDevicesNotAssociated = true;
      } else {
        throw new CustomException(CustomErrorCodes.DEVICES_ASSIGNED_TO_USER);
      }

    } else {
      isDevicesNotAssociated = true;
    }
    // Check if a user profile is the only customer/distributor/partner admin of
    // this organization
    if (StringUtils.isNotBlank(userProfile.getOrg().getType())
        && userProfile.getOrg().getType().equalsIgnoreCase(Constants.ORG_TYPE_CUSTOMER)) {
      if (userProfile.getRole().getName().equalsIgnoreCase(Constants.CUSTOMER_ADMIN)
          && !userRepo.checkOtherAdminUsers(
              userProfile.getUserId(),
              userProfile.getOrg().getId(),
              userProfile.getOrg().getType(),
              Constants.CUSTOMER_ADMIN)) {
        throw new CustomException(CustomErrorCodes.ONLY_CUSTOMER_ADMIN_USER);
      } else {
        isOtherAdminUser = true;
      }
    } else if (StringUtils.isNotBlank(userProfile.getOrg().getType())
        && userProfile.getOrg().getType().equalsIgnoreCase(Constants.ORG_TYPE_PARTNER)) {
      if (userProfile.getRole().getName().equalsIgnoreCase(Constants.PARTNER_ADMIN)
          && !userRepo.checkOtherAdminUsers(
              userProfile.getUserId(),
              userProfile.getOrg().getId(),
              userProfile.getOrg().getType(),
              Constants.PARTNER_ADMIN)) {
        throw new CustomException(CustomErrorCodes.ONLY_PARTNER_ADMIN_USER);
      } else {
        isOtherAdminUser = true;
      }
    } else if (StringUtils.isNotBlank(userProfile.getOrg().getType())
        && userProfile.getOrg().getType().equalsIgnoreCase(Constants.ORG_TYPE_DISTRIBUTOR)) {
      if (userProfile.getRole().getName().equalsIgnoreCase(Constants.DISTRIBUTOR_ADMIN)
          && !userRepo.checkOtherAdminUsers(
              userProfile.getUserId(),
              userProfile.getOrg().getId(),
              userProfile.getOrg().getType(),
              Constants.DISTRIBUTOR_ADMIN)) {
        throw new CustomException(CustomErrorCodes.ONLY_DISTRIBUTOR_ADMIN_USER);
      } else {
        isOtherAdminUser = true;
      }
    } else {
      isOtherAdminUser = true;
    }
    logger.info(
        "UserImpl:validateUserDeletion() --> isDevicesNotAssociated {} and isOtherAdminUser {}",
        isDevicesNotAssociated,
        isOtherAdminUser);
    return (isDevicesNotAssociated && isOtherAdminUser);
  }

  /**
   * get all users
   *
   * @return UserList
   */
  public UserList getAll(FetchCriteria fetchCriteria) {
    Page<UserProfile> pagedUsers = getAllByFetchCriteria(fetchCriteria);
    List<UserProfile> users = pagedUsers.getContent();
    List<UserListResponseEntity> convertedUsers = new ArrayList<>();
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    for (UserProfile userProfile : users) {

      if (Constants.LW_SERVICE_COORDINATOR.equals(authUser.getRole())) {
        if (userProfile.getRole().getName().equals(Constants.SUPER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.FSE_USER)
            || userProfile.getRole().getName().equals(Constants.FSS_USER)
            || userProfile.getRole().getName().equals(Constants.DISTRIBUTOR_FSE)
            || userProfile.getRole().getName().equals(Constants.LW_BUSINESS_MANAGER)
            || userProfile.getRole().getName().equals(Constants.LW_SERVICE_COORDINATOR)
            || userProfile.getRole().getName().equals(Constants.CUSTOMER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.TECHNICAL_USER)
            || userProfile.getRole().getName().equals(Constants.QUALITY_MANAGER)
            || userProfile.getRole().getName().equals(Constants.EXTERNAL_CUSTOMER_TECH)
            || userProfile.getRole().getName().equals(Constants.PARTNER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.PARTNER_HOTLINE))
          userProfile.setVisible(false); // Modified for NCIOT-13891 - MMI-FS-ESERV-3509

      } else if (Constants.SUPER_ADMIN.equals(authUser.getRole())
          || Constants.SERVICE_ADMIN.equals(authUser.getRole())
          || Constants.LW_BUSINESS_MANAGER.equals(authUser.getRole())) {
        // As per comment provided in NCIOT-12113, Service Admin , Super Admin ,
        // Business Manager
        // shall be able to assign devices to MCS users.
        if (userProfile.getRole().getName().equals(Constants.SERVICE_ADMIN)
            || userProfile.getRole().getName().equals(Constants.SUPER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.FSE_USER)
            || userProfile.getRole().getName().equals(Constants.DISTRIBUTOR_FSE)
            || userProfile.getRole().getName().equals(Constants.LW_BUSINESS_MANAGER)
            || userProfile.getRole().getName().equals(Constants.LW_SERVICE_COORDINATOR)
            || userProfile.getRole().getName().equals(Constants.LW_MCS)
            || userProfile.getRole().getName().equals(Constants.PARTNER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.PARTNER_HOTLINE))
          // as per mail communication by Fabien MCS will have access to all devices
          userProfile.setVisible(false);
      } else {
        if (userProfile.getRole().getName().equals(Constants.SERVICE_ADMIN)
            || userProfile.getRole().getName().equals(Constants.SUPER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.FSE_USER)
            || userProfile.getRole().getName().equals(Constants.FSS_USER)
            || userProfile.getRole().getName().equals(Constants.DISTRIBUTOR_FSE)
            || userProfile.getRole().getName().equals(Constants.LW_BUSINESS_MANAGER)
            || userProfile.getRole().getName().equals(Constants.LW_SERVICE_COORDINATOR)
            || userProfile.getRole().getName().equals(Constants.LW_MCS)
            || userProfile.getRole().getName().equals(Constants.PARTNER_ADMIN)
            || userProfile.getRole().getName().equals(Constants.PARTNER_HOTLINE))
          userProfile.setVisible(false); // Modified for NCIOT-8783
      }
      convertedUsers.add(UserListConverter.toResponseEntity(userProfile));
    }

    String totalPages = String.valueOf(pagedUsers.getTotalPages());
    UserList userList = new UserList();
    userList.setUsers(convertedUsers);
    userList.setTotalPages(totalPages);
    userList.setRecordCount(pagedUsers.getTotalElements());
    return userList;
  }

  /**
   * get all users facets
   *
   * @return UsersListingFacets
   */
  public UsersListingFacets getUserListingFacets() {
    List<UserProfile> initialUserProfiles =
        userRepo.findAll(userSpecification.specification(new FetchCriteria()));
    if (initialUserProfiles == null || initialUserProfiles.isEmpty()) {
      return emptyUserListingFacets();
    }
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<String> auth =
        authUser.getAuthorities().stream().map(x -> String.valueOf(x)).collect(Collectors.toList());

    if (Constants.DISTRIBUTOR_ADMIN.equals(authUser.getRole())) {
      initialUserProfiles =
          initialUserProfiles.stream()
              .filter(
                  u -> !u.getRole().getName().equalsIgnoreCase(Constants.EXTERNAL_CUSTOMER_TECH))
              .collect(Collectors.toList());
    }
    List<UserProfile> userProfiles = initialUserProfiles;
    UsersListingFacets usersListingFacets = new UsersListingFacets();
    usersListingFacets.setRole(
        getUniqueList(
            userProfiles.stream().map(u -> u.getRole().getName()).collect(Collectors.toList())));
    usersListingFacets.setStatus(
        (getUniqueList(
            userProfiles.stream().map(UserProfile::getStatus).collect(Collectors.toList()))));
    if (Constants.COUNTRY_FILTER_ROLES.contains(authUser.getRole())) {
      usersListingFacets.setCountryCode(
          getUniqueList(
              userProfiles.stream()
                  .map(UserProfile::getCountry)
                  .filter(Objects::nonNull)
                  .map(Country::getCountryCode)
                  .collect(Collectors.toList())));
    }
    // NCIOT-11210 Adding organisation
    if (auth.contains(Constants.USER_MANAGEMENT_FOR_FSS_ROLE)) {
      usersListingFacets.setOrg(
          (getUniqueList(
              userProfiles.stream().map(u -> u.getOrg().getName()).collect(Collectors.toList()))));
    } else {
      Optional.ofNullable(authUser.getAuthorities())
          .filter(
              authorities ->
                  authorities.containsAll(AuthorityUtils.createAuthorityList(Constants.CREATE_ORG)))
          .ifPresent(
              x -> {
                usersListingFacets.setOrg(
                    (getUniqueList(
                        userProfiles.stream()
                            .map(u -> u.getOrg().getName())
                            .collect(Collectors.toList()))));
              });
    }
    return usersListingFacets;
  }

  private List<String> getUniqueList(List<String> list) {
    Set<String> uniqueSet = new HashSet<String>(list);
    List<String> uniqueList = new ArrayList<String>(uniqueSet);
    return uniqueList;
  }

  private UsersListingFacets emptyUserListingFacets() {
    UsersListingFacets usersListingFacets = new UsersListingFacets();
    usersListingFacets.setStatus(new ArrayList<>());
    usersListingFacets.setRole(new ArrayList<>());
    return usersListingFacets;
  }

  // NCIOT-1696
  private void validateBusinessDomain(int domainId, Long userId) throws DataValidationException {
    logger.info("userId --> {} and domainId {}", userId, domainId);
    UserProfile userProfile = userRepo.getUserById(userId);
    if (userProfile == null) {
      throw new DataValidationException(CustomErrorCodes.USER_NOT_FOUND);
    }
    if (domainId == 0
        && !Constants.LABWATER_BUSINESS_ROLES.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.APPLICATION_DOMAIN_IS_REQUIRED);
    }
  }

  /**
   * update a user
   *
   * @param user - user (userName,userDesc)
   * @return userId
   * @throws com.merck.nextconnect.utils.file.handler.exception.CustomException
   */
  public void update(long userId, UserDetails userDetails)
      throws com.merck.nextconnect.utils.file.handler.exception.CustomException, CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Timestamp consentTS;
    // validation for Business Domain
    validateBusinessDomain(userDetails.getBusinessDomainId(), userId);

    // validate the user's phone number
    phoneNumberValidator.validatePhoneNumberFormat(
        userDetails.getIsdCode(), userDetails.getPhone());

    // validate the user's SMS subscription phone number
    if (Optional.ofNullable(userDetails.getUserSubscriptionDTO()).isPresent()
        && Optional.ofNullable(userDetails.getUserSubscriptionDTO().getSubscriptionTypeDTOs())
            .isPresent()) {
      for (SubscriptionTypeDTO subscriptionTypeDTO :
          userDetails.getUserSubscriptionDTO().getSubscriptionTypeDTOs()) {
        IUserSubscription.reminderDaysValidation(subscriptionTypeDTO);
        if (subscriptionTypeDTO.getSubscriptionTypeId() == 2
            && Optional.ofNullable(subscriptionTypeDTO)
                .orElse(subscriptionTypeDTO)
                .getSubscriptionCategories()
                .stream()
                .filter(Objects::nonNull)
                .anyMatch(x -> x.isStatus() == true))
          phoneNumberValidator.validatePhoneNumber(
              subscriptionTypeDTO.getIsdCode(), subscriptionTypeDTO.getPhones());
      }
    }

    if (userId != (Long.parseLong(authUser.getId()))) {
      throw new AccessDeniedException("unauthorized to update profile");
    }
    userDetails.setFirstName(userDetails.getFirstName().trim());
    userDetails.setLastName(userDetails.getLastName().trim());
    Optional.ofNullable(userDetails.getFirstName())
        .filter(f -> UserhubUtils.validatePattern(firstNamePattern, f))
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.USER_FIRSTNAME_INVALID));
    Optional.ofNullable(userDetails.getLastName())
        .filter(f -> UserhubUtils.validatePattern(lastNamePattern, f))
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.USER_LASTNAME_INVALID));
    if (userDetails.getCountryId() == 0) {
      throw new DataValidationException(CustomErrorCodes.INVALID_COUNTRY);
    }
    String userStatus;
    UserProfile userProfile =
        userRepo.getUserById(userId, authUser.getOrgId(), authUser.getRoleId());
    validateCountryUpdate(userProfile, userDetails);
    if (!userProfile.isConsentStatus() || userDetails.isPrivacyPolicyStatus()) {
      if (userDetails.isConsentStatus() && userDetails.isPrivacyPolicyStatus()) {
        userDetails.setConsentStatus(true);
        userDetails.setPrivacyPolicyStatus(true);
        consentTS = Timestamp.from(Instant.now());
      } else {
        throw new DataValidationException("Please accept terms and privacy.");
      }
    } else {
      consentTS = userProfile.getConsentTS();
      userDetails.setConsentStatus(userProfile.isConsentStatus());
      userDetails.setPrivacyPolicyStatus(userProfile.isPrivacyPolicyStatus());
    }

    if (userProfile.getStatus().equals(UserStatus.PENDING.value())) {
      userStatus = UserStatus.ACTIVE.value();
      userProfile.setInvitedOrActivatedTs(Timestamp.from(Instant.now()));
      /*
       * Changes made as per NCIOT-11630. assigning the devices to user automatically
       * if the user is auto-created
       */
      if (userProfile.isAutoCreated()
          && !UserInvitedVia.MANUAL.value().equalsIgnoreCase(userProfile.getInvitedVia())) {
        userProfile.setFirstName(userDetails.getFirstName());
        userProfile.setLastName(userDetails.getLastName());
        userProfile.setIsdCode(userDetails.getIsdCode());
        userProfile.setPhone(userDetails.getPhone());
        assignDevices(userProfile);
      }
      jwtTokenGenerator.updateUserTokenInfo(userId);
      userProfile.setValidated(true);
      // Send confirmation invite to Customer Admin as part of Self-Registration
      if (UserInvitedVia.SELF_REGISTRATION
          == UserInvitedVia.getSource(userProfile.getInvitedVia())) {
        userProfile.setValidated(false);
        try {
          logger.info(
              "UserImpl.update() <-- attempting to send self-registration validation mail to CA for userProfile : {}",
              userProfile.getUserId());
          HashMap<String, String> smsMap = sendSelfRegistrationEmailToCA(userProfile);
          logger.info("Start self-registration sms -- " + smsMap);
          if (Objects.nonNull(smsMap) && !smsMap.isEmpty()) {
            logger.info("Inside self-registration sms -- " + smsMap);
            createSmsForSelfRegisteredUser(smsMap);
          }
        } catch (com.merck.nextconnect.utils.file.handler.exception.CustomException ex) {
          logger.error(
              "UserImpl.update() <-- failed to send self-registration validation mail to CA for userProfile : {}",
              userProfile.getUserId());
        }
      }
    } else {
      userStatus = userProfile.getStatus();
    }
    Optional.ofNullable(userDetails.getDateFormatId())
        .filter(d -> d.intValue() == 0)
        .ifPresent(
            d -> {
              userDetails.setDateFormatId(Constants.DEFAULT_DATE_FORMAT);
            });
    Optional.ofNullable(userDetails.getLanguageId())
        .filter(d -> d.intValue() == 0)
        .ifPresent(
            d -> {
              userDetails.setLanguageId(Constants.DEFAULT_LANGUAGE);
            });

    userRepo.updateUser(
        userId,
        userDetails.getFirstName(),
        userDetails.getLastName(),
        userDetails.getIsdCode(),
        userDetails.getPhone(),
        userDetails.getCountryId(),
        userStatus,
        userDetails.getDateFormatId(),
        userDetails.getLanguageId(),
        userDetails.isConsentStatus(),
        consentTS,
        userDetails.isPrivacyPolicyStatus(),
        authUser.getOrgId(),
        userDetails.getTimeZoneId(),
        userDetails.isPlatformSubscription());
    logger.info("user detials updated..: ");
    updateUserProfileSettings(userId, userDetails);
    saveBusinessDomainForUser(
        userId, userDetails.getBusinessDomainId(), userProfile.getRole().getName());

    Role role = roleRepo.findById(userProfile.getRole().getRoleId()).orElse(null);
    if (userDetails.isRegistrationFlow()
        && Constants.CUSTOMER_ROLES.stream().anyMatch(role.getName()::contains)) {
      updateUserSubscriptionWithDefaultValues(userDetails, userProfile);
    }

    if (!authUser.getRole().equals(Constants.PASSWORDUPDATE)
        && Optional.ofNullable(userDetails.getUserSubscriptionDTO()).isPresent()) {
      userSubscriptionService.save(userDetails.getUserSubscriptionDTO(), userId);
    } else {
      authUser.getStatus();
      Optional.ofNullable(userProfile)
          .filter(
              u ->
                  (!u.getUserDomain().getAuthenticationProvider().equals(Constants.NEXTCONNECT_AUTH)
                      && UserStatus.PENDING.value().equalsIgnoreCase(authUser.getStatus())))
          .ifPresent(u -> jwtTokenGenerator.removeTokenRecords(userId));
    }

    if (privilegeProvider.hasPrivilege(
        OrgPrivileges.has_territories.getPrivilegeId(),
        userProfile.getRole().getRoleId(),
        Constants.ROLE)) {
      ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
      resourcePrivilege.setPrivilegeid(OrgPrivileges.has_territories.getPrivilegeId());
      resourcePrivilege.setResourceid(userDetails.getCountryId());
      userRolePrivileges.addTerritories(userProfile.getUserId(), Arrays.asList(resourcePrivilege));
    }
  }

  /**
   * Method add user profile settings details
   *
   * @param userId
   * @param userDetails
   */
  private void updateUserProfileSettings(long userId, UserDetails userDetails) {
    if (Optional.ofNullable(userDetails.getUserProfileSettings()).isPresent()) {
      UserProfileSettings userProfileSettings = null;
      userProfileSettings = userProfileSettingsRepository.fetchUserProfileSettingByUserId(userId);
      if (Optional.ofNullable(userProfileSettings).isPresent()) {
        userProfileSettings.setDisplayPerPage(
            userDetails.getUserProfileSettings().getDisplayPerPage());
        userProfileSettings.setSubscribeUserFeedBackReport(
            userDetails.getUserProfileSettings().isSubscribeUserFeedBackReport());
      } else {
        userProfileSettings = new UserProfileSettings();
        UserProfile userProfile = new UserProfile();
        userProfile.setUserId(userId);
        userProfileSettings.setUserProfile(userProfile);
        userProfileSettings.setDisplayPerPage(
            userDetails.getUserProfileSettings().getDisplayPerPage());
        userProfileSettings.setSubscribeUserFeedBackReport(
            userDetails.getUserProfileSettings().isSubscribeUserFeedBackReport());
      }
      userProfileSettingsRepository.save(userProfileSettings);
    }
  }

  /**
   * //NCIOT-1696
   *
   * <p>Method to save the business domain for user
   *
   * @param userId
   * @param businessDomainIds
   */
  private void saveBusinessDomainForUser(Long userId, int businessDomainId, String role) {
    if (isDomainVisible(role)) {
      UserBusinessDomain userBusinessDomain = userBusinessDomainRepo.findByUserId(userId);
      logger.info("userBusinessDomain : {}", userBusinessDomain);
      if (Optional.ofNullable(userBusinessDomain).isPresent()) {
        userBusinessDomainRepo.updateBusinessDomainForUser(businessDomainId, userId);
      } else {
        UserBusinessDomain userBusiDomain = new UserBusinessDomain();
        BusinessDomain businessDomain = new BusinessDomain();
        businessDomain.setDomainId(businessDomainId);
        userBusiDomain.setUserId(userId);
        userBusiDomain.setBusinessDomain(businessDomain);
        userBusinessDomainRepo.save(userBusiDomain);
      }
    }
  }

  // NCIOT-1696
  private boolean isDomainVisible(String role) {
    if (Constants.LABWATER_BUSINESS_ROLES.contains(role)) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * get a user
   *
   * @param userId - id of the user
   * @return user
   */
  public UserProfile fetchOne(long userId) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Optional.ofNullable(authUser)
        .filter(a -> Long.parseLong(a.getId()) != userId)
        .ifPresent(
            a -> {
              Optional.ofNullable(authUser.getAuthorities())
                  .filter(
                      authorities ->
                          authorities.containsAll(
                              AuthorityUtils.createAuthorityList(Constants.READ_USER)))
                  .orElseThrow(() -> new AccessDeniedException("unauthorized to fetch user"));
            });
    UserProfile user = userRepo.getUserById(userId, getAccessibleOrgs());

    if (Optional.ofNullable(user).isPresent()) {
      user.setIsDomainVisible(isDomainVisible(user.getRole().getName()));
      if (isDomainVisible(user.getRole().getName())) {
        user.setBusinessDomain(businessDomainRepositoryJdbc.fetchDomainForUser(userId));
      }
      user.setUserImage(userProfileImageRepositoryJdbc.fetchUserThumbnailBlobImage(userId));
      user.setUserProfileSettings(userProfileSettingsRepository.fetchUserProfileSettings(userId));
      // NCIOT-15243
      // added covered territory ,privileges details
      if ((UserhubUtils.getAuthenticatedUser()
                  .getAuthorities()
                  .contains(new SimpleGrantedAuthority(OrgPrivileges.has_territories.name()))
              || UserhubUtils.getAuthenticatedUser()
                  .getAuthorities()
                  .contains(new SimpleGrantedAuthority(OrgPrivileges.assign_territories.name())))
          && roleEntityPrivilegesRepository.hasCoveredTerritoryAccess(
              Constants.VIEW_COVERED_TERRITORIES, user.getRole().getRoleId())) {
        user.setCoveredTerritory(true);
        List<Integer> territories = userTerritoryRepo.getUserTerritories(userId);
        user.setCoveredTerritory(territories);
      } else {
        user.setCoveredTerritory(false);
      }
    }

    Optional.ofNullable(user)
        .filter(u -> u.getOrg().getId() == authUser.getOrgId())
        .ifPresent(
            u -> {
              validateActionForSystemDefinedRole(
                  authUser.getRoleId(), authUser.isSystemDefinedRole(), user.getRole());
            });
    return user;
  }

  /**
   * Subscriptions enabled by default at registration
   *
   * @param userDetails
   * @param userProfile
   */
  private void updateUserSubscriptionWithDefaultValues(
      UserDetails userDetails, UserProfile userProfile) {

    Sort sort = Sort.by(Sort.Direction.ASC, "subscriptionType");
    List<SubscriptionCategory> subscriptionCategoryList =
        subscriptionCategoryRepository.findAll(sort);

    UserSubscription userSubscription = null;
    Set<UserSubscription> subscriptions = new HashSet<>();
    for (SubscriptionCategory category : subscriptionCategoryList) {
      if (Constants.CUST_REGISTRATION_CATEGORIES.stream()
              .anyMatch(category.getCategoryName()::equalsIgnoreCase)
          && category
              .getSubscriptionType()
              .getSubscriptionTypeName()
              .equalsIgnoreCase(Constants.EMAIL_SUBSCRIPTION)) {
        userSubscription = new UserSubscription();
        userSubscription.setUserProfile(userProfile);
        userSubscription.setStatus(true);
        userSubscription.setCreatedBy(userProfile.getEmail());
        userSubscription.setCustomMessage(StringUtils.EMPTY);
        userSubscription.setDeleted(false);
        userSubscription.setEmail(userProfile.getEmail());
        if (!Constants.CUST_CATEGORIES_WITHOUT_PREVENANCE_DELAY.stream()
            .anyMatch(category.getCategoryName()::equalsIgnoreCase)) {
          userSubscription.setNumberOfDaysAdvance(numberOfDaysAdvance);
        }
        userSubscription.setSubscriptionCategory(category);
        userSubscription.setSubscriptionType(category.getSubscriptionType());
        userSubscription.setCreatedTimestamp(Timestamp.from(Instant.now()));
        userSubscription.setLastUpdatedTimestamp(Timestamp.from(Instant.now()));
        userSubscription.setLastUpdatedBy(userProfile.getEmail());
        userSubscription.setIsdCode(userDetails.getIsdCode());
        userSubscription.setPhone(userDetails.getPhone());
        subscriptions.add(userSubscription);
      }
    }
    userSubscriptionRepository.saveAll(subscriptions);
  }

  /**
   * reset user credentials
   *
   * @param userId - id of the user
   * @return userCredentials - new credentials
   * @throws DataValidationException
   * @throws ResourceNotFoundException
   */
  public void resetCredentials(Credentials credentials, long userId)
      throws DataValidationException, ResourceNotFoundException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    if (!(credentials.getNewPassword() != ""
        && credentials.getNewPassword().equals(credentials.getConfirmPassword()))) {
      throw new LoginAuthenticationException("new and confirm passwords are not matching");
    }
    UserProfile userProfile = userRepo.getUserById(userId, getAccessibleOrgs());
    Optional.ofNullable(userProfile)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    Optional.ofNullable(authUser)
        .filter(a -> !a.getRole().equals(Constants.PASSWORDUPDATE))
        .ifPresent(
            a -> {
              Optional.ofNullable(userProfile)
                  .filter(u -> u.getOrg().getId() == authUser.getOrgId())
                  .ifPresent(
                      u -> {
                        validateActionForSystemDefinedRole(
                            authUser.getRoleId(),
                            authUser.isSystemDefinedRole(),
                            userProfile.getRole());
                      });
            });
    if (!UserhubUtils.validatePattern(passwordPattern, credentials.getNewPassword())) {
      throw new LoginAuthenticationException("The password does not meet the password policy");
    }

    if (!Constants.NEXTCONNECT_AUTH.equals(
        userProfile.getUserDomain().getAuthenticationProvider())) {
      throw new DataValidationException(
          "password is handled by user's Active Directory. please contact your Active Directory support Team");
    }

    String salt = BCrypt.gensalt(10);
    String passwordHash = BCrypt.hashpw(credentials.getNewPassword(), salt);
    UserCredentials userCredentials = new UserCredentials(userProfile.getLoginName(), passwordHash);
    // reset by admin
    Optional.ofNullable(authUser)
        .filter(a -> userId != (Long.parseLong(a.getId())))
        .ifPresent(
            a -> {
              Optional.ofNullable(userProfile.getStatus())
                  .filter(
                      s ->
                          (s.equals(UserStatus.ACTIVE.value())
                              || s.equals(UserStatus.IN_PROGRESS.value())))
                  .orElseThrow(() -> new AccessDeniedException("cannot reset password"));
              userProfile.setStatus(UserStatus.IN_PROGRESS.value());
            });
    // reset by user
    Optional.ofNullable(authUser)
        .filter(a -> userId == (Long.parseLong(a.getId())))
        .ifPresent(
            a -> {
              Optional.ofNullable(userProfile)
                  .filter(
                      u ->
                          UserhubUtils.validateConsentStatus(
                              u.isConsentStatus(), u.isPrivacyPolicyStatus()))
                  .orElseThrow(
                      () ->
                          new AccessDeniedException(
                              "User has to accept terms and policy by registering profile"));

              Optional.ofNullable(userProfile.getStatus())
                  .filter(
                      s ->
                          (s.equals(UserStatus.ACTIVE.value())
                              || s.equals(UserStatus.IN_PROGRESS.value())))
                  .ifPresent(
                      s -> {
                        userProfile.setStatus(UserStatus.ACTIVE.value());
                      });
              vaildatePasswordHistory(userId, credentials.getNewPassword());
            });
    userCredentials.setUserProfile(userProfile);
    userCredentialsRepo.deactivateCredentials(userId);
    accountPolicy.resetLockOut(userId);
    userCredentialsRepo.save(userCredentials);
    jwtTokenGenerator.removeTokenRecords(userId);
  }

  private void vaildatePasswordHistory(long userId, String newPassword) {
    int historyThreshold =
        Integer.valueOf(
            applicationConfigRepository
                .findByCategoryAndKey(
                    Constants.PASSWORD_POLICY, Constants.PASSWORD_HISTORY_THRESHOLD)
                .getValue());
    userCredentialsRepo.getPasswordHashes(userId, PageRequest.of(0, historyThreshold)).stream()
        .filter(p -> BCrypt.checkpw(newPassword, p))
        .findAny()
        .ifPresent(
            p -> {
              throw new LoginAuthenticationException(CustomErrorCodes.PASSWORD_EXISTS);
            });
  }

  /**
   * generate token for password update
   *
   * @param email - id of the user
   * @return token - password update token
   */
  public String generateToken(long userId) {
    String jti = UUID.randomUUID().toString();
    SecureRandom random = new SecureRandom();
    byte[] keyBytes = new byte[64];
    new SecureRandom().nextBytes(keyBytes);
    SecretKey secretKey = Keys.hmacShaKeyFor(keyBytes);
    jwtTokenGenerator.generateAndPersistTokenForPassword(
        Encoders.BASE64.encode(secretKey.getEncoded()), jti, userId);
    return jti;
  }

  @Override
  public void updateStatusAndRole(long userId, UserPatch userPatch)
      throws ResourceNotFoundException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Optional<UserProfile> userProfile =
        Optional.ofNullable(userRepo.getUserById(userId, getAccessibleOrgs()));
    userProfile.orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    userProfile
        .filter(u -> u.getUserId() != Long.parseLong(authUser.getId()))
        .orElseThrow(() -> new AccessDeniedException("user is unauthorized to update"));
    userProfile
        .filter(u -> u.getOrg().getId() == authUser.getOrgId())
        .ifPresent(
            u -> {
              validateActionForSystemDefinedRole(
                  authUser.getRoleId(),
                  authUser.isSystemDefinedRole(),
                  userProfile.get().getRole());
            });

    updatePrivilegeValidation(authUser, userProfile.get());
    // validate the user's phone number
    phoneNumberValidator.validatePhoneNumberFormat(
        userPatch.getIsdCode(), userPatch.getPhoneNumber());
    Optional<Boolean> status = Optional.ofNullable(userPatch.getStatus());

    status.ifPresent(
        s -> {
          String userStatus =
              s.booleanValue() ? UserStatus.ACTIVE.value() : UserStatus.INACTIVE.value();
          jwtTokenGenerator.removeTokenRecords(userId);
          userRepo.updateUserStatus(userId, userStatus);
          // MMI-FS-ESERV-4024 changes
          userProfile
              .filter(
                  u ->
                      (u.getRole().getOrg().getType().equalsIgnoreCase(Constants.ORG_TYPE_CUSTOMER)
                          || u.getRole()
                              .getOrg()
                              .getType()
                              .equalsIgnoreCase(Constants.ORG_TYPE_PARTNER)))
              .ifPresent(
                  user -> {
                    try {
                      emailService.sendEmailForProfileStatusChange(
                          user.getFirstName(),
                          user.getLastName(),
                          user.getEmail(),
                          UserStatus.ACTIVE.value().equalsIgnoreCase(userStatus)
                              ? Constants.ACTIVATED
                              : Constants.DEACTIVATED,
                          environment,
                          fromEmail);
                    } catch (EmailException e) {
                      logger.error(
                          ":::failed to send email to the user for activation/deactivate case -> "
                              + user.getEmail(),
                          e);
                    }
                  });
          userProfile.get().setStatus(userStatus);
        });
    Optional<Long> roleId = Optional.ofNullable(userPatch.getRoleId());
    roleId.ifPresent(
        rId -> {
          Role role = roleRepo.findById(rId).get();
          userProfile
              .filter(u -> u.getOrg().getId() == role.getOrg().getId())
              .orElseThrow(() -> new AccessDeniedException("Unauthorized to change the role"));
          userProfile
              .filter(u -> u.getOrg().getId() == authUser.getOrgId())
              .ifPresent(
                  u -> {
                    Optional.ofNullable(role)
                        .filter(r -> r.isSystemDefined())
                        .ifPresent(
                            r -> {
                              Optional.ofNullable(authUser)
                                  .filter(a -> a.getRoleId() == r.getRoleId())
                                  .orElseThrow(
                                      () ->
                                          new AccessDeniedException(
                                              "Unauthorized to change the role"));
                            });
                  });
          validateTerritoryOnRoleChange(userProfile.get(), userPatch.getRoleId());
          userProfile.get().setRole(new Role(userPatch.getRoleId()));
          jwtTokenGenerator.removeTokenRecords(userId);
        });

    Optional<String> firstName = Optional.ofNullable(userPatch.getFirstName());
    if (firstName.isPresent()) {
      userPatch.setFirstName(userPatch.getFirstName().trim());
      userProfile
          .get()
          .setFirstName(
              Optional.ofNullable(userPatch.getFirstName())
                  .filter(f -> UserhubUtils.validatePattern(firstNamePattern, f))
                  .orElseThrow(
                      () -> new DataValidationException(CustomErrorCodes.USER_FIRSTNAME_INVALID)));
    }

    Optional<String> lastName = Optional.ofNullable(userPatch.getLastName());
    if (lastName.isPresent()) {
      userPatch.setLastName(userPatch.getLastName().trim());
      userProfile
          .get()
          .setLastName(
              Optional.ofNullable(userPatch.getLastName())
                  .filter(f -> UserhubUtils.validatePattern(lastNamePattern, f))
                  .orElseThrow(
                      () -> new DataValidationException(CustomErrorCodes.USER_LASTNAME_INVALID)));
    }

    Optional<String> phoneNumber = Optional.ofNullable(userPatch.getPhoneNumber());
    Optional<String> isdCode = Optional.ofNullable(userPatch.getIsdCode());
    Optional<String> empty = Optional.ofNullable("");
    if ((phoneNumber.isPresent() && isdCode.isPresent())
        || (phoneNumber.equals(empty) && isdCode.equals(empty))) {
      userProfile.get().setIsdCode(userPatch.getIsdCode());
      userProfile.get().setPhone(userPatch.getPhoneNumber());
    }
    Optional<Integer> dateformat = Optional.ofNullable(userPatch.getDateFormatId());
    dateformat.ifPresent(
        p -> {
          userProfile.get().setDateFormat(new DateFormat(p));
        });
    Optional<Integer> languageId = Optional.ofNullable(userPatch.getLanguageId());
    languageId.ifPresent(
        p -> {
          userProfile.get().setLanguage(new Language(p));
        });
    logger.info("Saved data in User Repo {} and Details {}", authUser.getId(), userProfile.get());
    userRepo.save(userProfile.get());
    if (userProfile.get().getStatus().equals(UserStatus.ACTIVE.value())) {
      Optional<Integer> countryId = Optional.ofNullable(userPatch.getCountryId());
      countryId.ifPresent(
          c -> {
            Integer previousCountryId = userProfile.get().getCountry().getId();
            userProfile.get().setCountry(new Country(c));
            userProfile.get().setTimeZoneId(userPatch.getTimeZoneId());
            userRepo.save(userProfile.get());
            if (privilegeProvider.hasPrivilege(
                OrgPrivileges.has_territories.getPrivilegeId(),
                userProfile.get().getRole().getRoleId(),
                Constants.ROLE)) {
              ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
              resourcePrivilege.setPrivilegeid(OrgPrivileges.has_territories.getPrivilegeId());
              resourcePrivilege.setResourceid(previousCountryId);
              userRolePrivileges.removeTerritories(
                  userProfile.get().getUserId(), Arrays.asList(resourcePrivilege));
              resourcePrivilege.setResourceid(c);
              userRolePrivileges.addTerritories(
                  userProfile.get().getUserId(), Arrays.asList(resourcePrivilege));
            }
            try {
              mailTemplate.sendCountryUpdateAlertMail(userProfile.get().getEmail());
            } catch (CustomException e) {
              logger.error(
                  ":::failed to send email to the user -> " + userProfile.get().getEmail(), e);
            }
          });
    }
  }

  /**
   * @param authUser
   * @param userProfile
   * @throws DataValidationException
   */
  private void updatePrivilegeValidation(AuthenticatedUser authUser, UserProfile userProfile)
      throws DataValidationException {
    if (Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_BM.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_UPDATE_USER);
    } else if (Constants.LW_SERVICE_ADMIN.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_SM.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_UPDATE_USER);
    } else if (Constants.LW_MCS.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_MCS.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_UPDATE_USER);
    } else if (Constants.LW_SERVICE_COORDINATOR.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_ICS.contains(userProfile.getRole().getName())) {
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_UPDATE_USER);
    }
  }

  /**
   * get users by fetch criteria
   *
   * @param fetchCriteria - criteria to fetch users
   * @return userList
   */
  private Page<UserProfile> getAllByFetchCriteria(FetchCriteria fetchCriteria) {
    Page<UserProfile> pagedUsers = null;
    PageRequest page;
    // sort
    if (fetchCriteria.getSortBy() != null) {
      page = getSortedPageRequest(fetchCriteria);
    } else {
      page = PageRequest.of(fetchCriteria.getPageNo() - 1, fetchCriteria.getPageLimit());
    }
    pagedUsers = userRepo.findAll(userSpecification.specification(fetchCriteria), page);
    return pagedUsers;
  }

  private PageRequest getSortedPageRequest(FetchCriteria fetchCriteria) {
    PageRequest page;
    String sortBy = fetchCriteria.getSortBy();
    page =
        PageRequest.of(
            fetchCriteria.getPageNo() - 1,
            fetchCriteria.getPageLimit(),
            Direction.fromString(fetchCriteria.getOrderBy()),
            sortBy);
    return page;
  }

  @Override
  public void triggerPasswordReset(String email)
      throws AddressException, MessagingException, CustomException {
    UserProfile userProfile = userRepo.getUserByEmail(email);
    if (userProfile == null) {
      logger.error("error while resetting email,user user profile not found for  -{}", email);
      throw new ResourceNotFoundException(CustomErrorCodes.FORGOT_PASSWORD_FAILUE);
    }
    // NCIOT-11199
    Optional.of(userProfile)
        .filter(u -> u.getOrg().getStatus().equals(true))
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.ACCESS_DENIED_ORG_DEACTIVATED));
    if (userProfile != null) {
      if (!userProfile
          .getUserDomain()
          .getAuthenticationProvider()
          .equals(Constants.NEXTCONNECT_AUTH)) {
        throw new DataValidationException(
            "password is handled by user's Active Directory. please contact your Active Directory support Team");
      }
      if (userProfile.getStatus().equals(UserStatus.INACTIVE.value())) {
        throw new com.merck.nextconnect.userhub.exception.AccessDeniedException(
            CustomErrorCodes.ACCESS_DENIED_RESET_PASSWORD);
      }
    }
    if (userProfile != null) sendEmail(userProfile, Constants.RESET_PASSWORD);
  }

  /**
   * sending mail to user
   *
   * @param userProfile - user profile
   * @param action - action (invite user , password update)
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  private void sendEmail(UserProfile userProfile, String action)
      throws AddressException, MessagingException, CustomException {
    String jti = null;
    if (Constants.INVITE_USER.equals(action)) {
      jti = generateInvitationToken(userProfile);
    } else {
      jti = generateToken(userProfile.getUserId());
    }
    logger.info("Sending email to {}", userProfile.getEmail());
    mailService.send(userProfile, action, jti, environment);
    logger.info("Sent email successfully to {}", userProfile.getEmail());
  }

  /**
   * generate token for invitation email
   *
   * @param email - id of the user
   * @return token - update token
   */
  public String generateInvitationToken(UserProfile userProfile) {
    String jti = UUID.randomUUID().toString();
    byte[] keyBytes = new byte[64];
    new SecureRandom().nextBytes(keyBytes);
    SecretKey secretKey = Keys.hmacShaKeyFor(keyBytes);
    jwtTokenGenerator.generateAndPersistTokenForInvitationEmail(
        Encoders.BASE64.encode(secretKey.getEncoded()),
        jti,
        userProfile.getUserId(),
        userProfile.getInvitedOrActivatedTs());
    return jti;
  }

  /**
   * validates operations for users with system defined roles
   *
   * @param authRoleId - logged in user role id
   * @param authSystemDefinedRole - boolean
   * @param userRole - role
   */
  private void validateActionForSystemDefinedRole(
      long authRoleId, boolean authSystemDefinedRole, Role userRole) {
    Optional.ofNullable(userRole)
        .filter(r -> r.isSystemDefined())
        .ifPresent(
            r -> {
              Optional.ofNullable(authSystemDefinedRole)
                  .filter(s -> s.booleanValue())
                  .orElseThrow(
                      () -> new AccessDeniedException("unauthorized to perform this operation"));
              Optional.ofNullable(authSystemDefinedRole)
                  .filter(s -> s.booleanValue())
                  .ifPresent(
                      s -> {
                        Optional.ofNullable(authRoleId)
                            .filter(a -> a == r.getRoleId())
                            .orElseThrow(
                                () ->
                                    new AccessDeniedException(
                                        "unauthorized to operate on this user"));
                      });
            });
  }

  /**
   * validates nextconnect user's password
   *
   * @param password - password
   * @param userId - user id
   * @throws DataValidationException
   */
  public void validatePassword(ResetCredential credential, long userId)
      throws AccessDeniedException, DataValidationException {
    UserProfile userProfile = userRepo.findById(userId).orElse(null);
    Optional.ofNullable(userProfile)
        .filter(
            u -> u.getUserDomain().getAuthenticationProvider().equals(Constants.NEXTCONNECT_AUTH))
        .orElseThrow(
            () ->
                new AccessDeniedException(
                    "password is handled by user's Active Directory. please contact your Active Directory support Team"));
    UserCredentials userCredentials =
        userCredentialsRepo.getUserCredentials(
            userProfile.getLoginName(), Constants.NEXTCONNECT_AUTH);
    Optional.ofNullable(userCredentials)
        .filter(
            u -> BCrypt.checkpw(credential.getCurrentPassword(), userCredentials.getPasswordHash()))
        .orElseThrow(() -> new AccessDeniedException("incorrect password"));
    Optional.ofNullable(credential)
        .filter(c -> !c.getCurrentPassword().equals(c.getNewPassword()))
        .orElseThrow(
            () -> new DataValidationException("current and new passowrd should be different"));
  }

  /**
   * invite user by sending email invite
   *
   * @param userId - user id
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  public void inviteUser(long userId) throws AddressException, MessagingException, CustomException {
    UserProfile userProfile = userRepo.findById(userId).orElse(null);
    Optional.ofNullable(userProfile)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    Optional.ofNullable(userProfile)
        .filter(
            u ->
                userProfile.getStatus().equals(UserStatus.PENDING.value())
                    || userProfile
                        .getStatus()
                        .equals(UserStatus.EXPIRED.value())) // Changes made as per
        // NCIOT-11740.
        .orElseThrow(() -> new DataValidationException("user status has to be pending"));
    sendEmail(userProfile, Constants.INVITE_USER);
    userRepo.updateInvitedTs(userId, new Date());
  }

  public void validateConsent(UserDetails userDetails) throws DataValidationException {
    if (!userDetails.isConsentStatus() || !userDetails.isPrivacyPolicyStatus()) {
      throw new DataValidationException("Please accept terms and privacy.");
    }
  }

  @Override
  public List<Privileges> getPrivileges(long userId, String filterBy)
      throws ResourceNotFoundException {
    Optional.ofNullable(fetchOne(userId))
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    List<Privileges> userPrivileges = new ArrayList<>();
    switch (filterBy) {
      case Constants.DEVICE:
        validateAccess(OrgPrivileges.assign_device);
        userPrivileges = userRolePrivileges.getUserDevicePrivileges(userId);
        break;
      case Constants.TERRITORY:
        if (!(UserhubUtils.getAuthenticatedUser()
                .getAuthorities()
                .contains(new SimpleGrantedAuthority(OrgPrivileges.has_territories.name()))
            || UserhubUtils.getAuthenticatedUser()
                .getAuthorities()
                .contains(new SimpleGrantedAuthority(OrgPrivileges.assign_territories.name())))) {
          throw new AccessDeniedException("User does not have access to view assigned territories");
        }
        userPrivileges = userRolePrivileges.getUserTerritories(userId);
        break;
    }
    return userPrivileges;
  }

  // change for NCIOT-10694, NCIOT-10688 -- sending mail and sms notification on
  // device assignment
  @Override
  public void addPrivileges(long userId, List<ResourcePrivilege> resourcePrivileges)
      throws ResourceNotFoundException {
    Optional<UserProfile> userProfile = Optional.ofNullable(fetchOne(userId));
    userProfile.orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    if (resourcePrivileges.get(0).getPrivilegeid()
        == OrgPrivileges.assign_device.getPrivilegeId()) {
      validateAccess(OrgPrivileges.assign_device);
      userProfile
          .filter(
              u -> orgPermissions.hasRoleAccess(u.getOrg().getId(), OrgPrivileges.assign_device))
          .orElseThrow(() -> new AccessDeniedException("user doesnt have access to the given org"));
      userRolePrivileges.addUserDevicePrivileges(userProfile.get(), resourcePrivileges);
      userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAssignment(
          userProfile, resourcePrivileges);
      resourcePrivileges.stream()
          .forEach(
              resource -> {
                Optional<Device> device =
                    deviceRepository.findDeviceByDeviceId(resource.getResourceid());
                try {
                  device.orElseThrow(
                      () -> new ResourceNotFoundException(CustomErrorCodes.DEVICE_NOT_FOUND));
                  if (validateFirstAccountCreationOrNot(userProfile.get()) == 1) {
                    mailTemplate.sendDeviceAssignmentChangeMail(
                        userProfile.get(),
                        device.get(),
                        TemplateName.DEVICE_ASSIGNMENT_MAIL.getValue(),
                        TemplateName.DEVICE_ASSIGNMENT_MAIL.getValue(),
                        Constants.ACTIVE.toUpperCase());

                    smsService.validateAndSendSMS(
                        Constants.DEVICE_ASSIGNMENT_SMS,
                        Constants.DEVICE_ASSIGNMENT_SMS,
                        userProfile.get(),
                        device.get());

                    // updating tracker table
                    UserDeviceAssignmentTrack deviceAssignmentTrack =
                        userDeviceAssignmentTrackRepository
                            .findByUserAndDeviceAndAssignedTimestampNotNullAndUnassignedTimestampNull(
                                userProfile.get(), device.get());
                    if (deviceAssignmentTrack != null) {
                      deviceAssignmentTrack.setIsEmailTriggered(true);
                      userDeviceAssignmentTrackRepository.save(deviceAssignmentTrack);
                    }
                  }
                } catch (CustomException e) {
                  logger.error(
                      "Error occurred while sending mail to user : {} for device : {} with exception{}",
                      userProfile.get(),
                      device.get(),
                      e);
                } catch (JSONException e) {
                  logger.error(
                      "Error occurred while sending sms to user : {} for device : {} with exception{}",
                      userProfile.get(),
                      device.get(),
                      e);
                }
              });

    } else if (resourcePrivileges.get(0).getPrivilegeid()
        == OrgPrivileges.assign_territories.getPrivilegeId()) {
      validateActiveStatus(userProfile.get().getStatus());
      validateAccess(OrgPrivileges.assign_territories);
      validateHasTerritory(userProfile.get().getRole().getRoleId());
      userRolePrivileges.addTerritories(userProfile.get().getUserId(), resourcePrivileges);
    }
  }

  // change for NCIOT-10694, NCIOT-10688 -- sending mail and sms notification on
  // device
  // un-assignment
  @Override
  public void deletePrivileges(long userId, List<ResourcePrivilege> resourcePrivileges)
      throws ResourceNotFoundException {
    Optional<UserProfile> userProfile = Optional.ofNullable(fetchOne(userId));
    userProfile.orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    if (resourcePrivileges.get(0).getPrivilegeid()
        == OrgPrivileges.assign_device.getPrivilegeId()) {
      validateAccess(OrgPrivileges.assign_device);
      userProfile
          .filter(
              u -> orgPermissions.hasRoleAccess(u.getOrg().getId(), OrgPrivileges.assign_device))
          .orElseThrow(() -> new AccessDeniedException("user doesnt have access to the given org"));
      userRolePrivileges.deleteUserDevicePrivileges(userProfile.get(), resourcePrivileges);
      genericJdbc.deleteRequestDeviceForDeviceFromUser(
          resourcePrivileges.get(0).getResourceid(), userId);
      userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceDeAssignment(
          userProfile, resourcePrivileges);
      resourcePrivileges.stream()
          .forEach(
              resource -> {
                Optional<Device> device =
                    deviceRepository.findDeviceByDeviceId(resource.getResourceid());
                try {
                  device.orElseThrow(
                      () -> new ResourceNotFoundException(CustomErrorCodes.DEVICE_NOT_FOUND));
                  mailTemplate.sendDeviceAssignmentChangeMail(
                      userProfile.get(),
                      device.get(),
                      TemplateName.DEVICE_UNASSIGNMENT_MAIL.getValue(),
                      TemplateName.DEVICE_UNASSIGNMENT_MAIL.getValue(),
                      Constants.ACTIVE.toUpperCase());
                  smsService.validateAndSendSMS(
                      Constants.DEVICE_UNASSIGNMENT_SMS,
                      Constants.DEVICE_UNASSIGNMENT_SMS,
                      userProfile.get(),
                      device.get());

                } catch (CustomException e) {
                  logger.error(
                      "Error occurred while sending mail to user : {} for device : {} with exception{}",
                      userProfile.get(),
                      device.get(),
                      e);
                } catch (JSONException e) {
                  logger.error(
                      "Error occurred while sending sms to user : {} for device : {} with exception{}",
                      userProfile.get(),
                      device.get(),
                      e);
                }
              });
    } else if (resourcePrivileges.get(0).getPrivilegeid()
        == OrgPrivileges.assign_territories.getPrivilegeId()) {
      validateActiveStatus(userProfile.get().getStatus());
      validateAccess(OrgPrivileges.assign_territories);
      validateHasTerritory(userProfile.get().getRole().getRoleId());
      userRolePrivileges.removeTerritories(
          userProfile.get().getUserId(),
          removeUserCountryFromTerritory(
              resourcePrivileges, userProfile.get().getCountry().getId()));
    }
  }

  @Override
  public UserProfile findByEmailAndStatus(String eamil, String status) {
    return userRepo.findByEmailAndStatus(eamil, status);
  }

  @Override
  public List<String> searchMailId(String mailId) {
    return userRepo.findByEmailStartingWithIgnoreCase(mailId);
  }

  @Override
  public boolean validateMailId(String mailId)
      throws DataValidationException, DuplicateResourceException {
    List<UserProfile> userProfiles =
        userRepo.findByEmailAndStatusAndDeleted(mailId, USER_STATUS, false);
    if (userProfiles.size() > 0) {
      List<UserSubscription> userSubscriptions =
          userSubscriptionRepository.findByEmailAndDeletedAndUserProfileDeleted(
              mailId, false, false);
      if (userSubscriptions.size() == 0) return true;
      else throw new DuplicateResourceException(mailId + " is already subscribed");
    } else throw new DataValidationException(mailId + " doesn't exist");
  }

  public void unSubscribe(long userId, int orgId, long roleId, String environment)
      throws DataValidationException, EmailException, CustomException {
    UserProfile userProfile = userRepo.getUserById(userId, orgId, roleId);
    if (userProfile.getRole().isSystemDefined()) {
      List<UserProfile> userProfiles =
          userRepo.getUsersByRoleAndActive(
              userProfile.getRole().getRoleId(), userProfile.getOrg().getId());
      if (userProfiles.size() < 2) {
        throw new DataValidationException(CustomErrorCodes.LAST_USER_IN_SYSTEM_DEFINED_ROLE);
      } else {
        deleteUser(userProfile);
      }
    } else {
      deleteUser(userProfile);
    }
    sendUnsubscribeEmail(userProfile, environment);
  }

  private void sendUnsubscribeEmail(UserProfile userProfile, String environment)
      throws EmailException {
    EmailTemplate emailTemplate =
        emailTemplateService.findByCategoryAndLanguageId(
            Constants.UNSUBSCRIBE_USER_EMAIL_TEMPLATE, userProfile.getLanguage().getId());
    EmailMessage emailMessage = new EmailMessage();
    emailMessage.setEmailTemplate(emailTemplate);

    emailMessage.setEmailFrom(fromEmail);
    emailMessage.setEmailTo(userProfile.getEmail());
    emailMessage.setSubject(Constants.UNSUBSCRIBE_USER_EMAIL_SUBJECT);
    emailMessage.setStatus(Constants.EMAIL_SUCCESS_STATUS);
    emailMessage.setCreatedBy(Constants.USERHUB);
    emailMessage.setCreatedTimestamp(Timestamp.from(Instant.now()));
    emailMessage.setLastUpdatedBy(Constants.USERHUB);
    emailMessage.setLastUpdatedTimestamp(Timestamp.from(Instant.now()));
    emailMessage.setCharset(Constants.EMAIL_CHAR_SET);
    emailMessage.setContentType(Constants.EMAIL_CONTENT_TYPE);

    Set<EmailAttribute> emailAttributeSet = new HashSet<EmailAttribute>();
    emailMessage.setEmailAttributes(emailAttributeSet);
    emailService.sendMail(emailMessage, environment);
  }

  public void deleteUser(UserProfile userProfile) throws CustomException {

    try {
      userProfile.setDeleted(true);
      jwtTokenGenerator.removeTokenRecords(userProfile.getUserId());
      userCredentialsRepo.deleteByUserProfile(userProfile);
      userRepo.save(userProfile);
      logger.info(
          "removing the following record from the User Subscription table as the user is deleted : {}",
          userProfile.getEmail());
      userSubscriptionRepository.saveAll(
          userSubscriptionRepository
              .findByEmailOrCreatedByAndDeleted(userProfile.getEmail(), userProfile.getEmail())
              .stream()
              .map(
                  userToDelete ->
                      userToDelete.toBuilder()
                          .status(false)
                          .deleted(true)
                          .lastUpdatedBy(userProfile.getEmail())
                          .lastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()))
                          .deletedBy(
                              Long.valueOf(UserhubUtils.getAuthenticatedUser().getId())
                                      == userProfile.getUserId()
                                  ? SELF
                                  : OTHER)
                          .build())
              .collect(Collectors.toList()));
    } catch (Exception e) {
      logger.info("deleteUser -> delete -> deleteUser: {}", e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }

  private List<Integer> getAccessibleOrgs() {
    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));
    return accessibleOrgs;
  }

  private void validateAccess(OrgPrivileges orgPrivileges) {
    if (!UserhubUtils.getAuthenticatedUser()
        .getAuthorities()
        .contains(new SimpleGrantedAuthority(orgPrivileges.name()))) {
      throw new AccessDeniedException("User does not have access to perform this operation");
    }
  }

  private void validateActiveStatus(String userStatus) {
    if (!userStatus.equals(Constants.ACTIVE)) {
      throw new AccessDeniedException("User should be active to perform this operation");
    }
  }

  private void validateHasTerritory(long roleId) {
    if (!privilegeProvider.hasPrivilege(
        OrgPrivileges.has_territories.getPrivilegeId(), roleId, Constants.ROLE)) {
      throw new AccessDeniedException("Cannot assign territories to this user");
    }
  }

  private List<ResourcePrivilege> removeUserCountryFromTerritory(
      List<ResourcePrivilege> resourcePrivileges, int countryId) {
    return resourcePrivileges.stream()
        .filter(r -> countryId != (int) r.getResourceid())
        .collect(Collectors.toList());
  }

  private void validateTerritoryOnRoleChange(UserProfile userProfile, long newRole) {
    if (privilegeProvider.hasPrivilege(
        OrgPrivileges.has_territories.getPrivilegeId(),
        userProfile.getRole().getRoleId(),
        Constants.ROLE)) {
      userRolePrivileges.removeAllTerritories(userProfile.getUserId());
    }
    if (privilegeProvider.hasPrivilege(
            OrgPrivileges.has_territories.getPrivilegeId(), newRole, Constants.ROLE)
        && userProfile.getCountry() != null) {
      ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
      resourcePrivilege.setPrivilegeid(OrgPrivileges.has_territories.getPrivilegeId());
      resourcePrivilege.setResourceid(userProfile.getCountry().getId());
      userRolePrivileges.addTerritories(userProfile.getUserId(), Arrays.asList(resourcePrivilege));
    }
  }

  private void validateCountryUpdate(UserProfile userProfile, UserDetails userDetails) {
    if (!userProfile.getStatus().equals(UserStatus.PENDING.value())
        && privilegeProvider.hasPrivilege(
            OrgPrivileges.has_territories.getPrivilegeId(),
            userProfile.getRole().getRoleId(),
            Constants.ROLE)) {
      userDetails.setCountryId(userProfile.getCountry().getId());
    }
  }

  /**
   * Changes made as per NCIOT-11740. Re-inviting the auto-created user from service max.
   *
   * @param emailId
   */
  @Override
  public void inviteUserFromServiceMax(String emailId) throws MessagingException, CustomException {
    logger.info("Reinviting the user from SerivceMax {}", emailId);
    UserProfile userProfile = userRepo.getUserByEmail(emailId);
    Optional.ofNullable(userProfile)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.USER_NOT_FOUND));
    userProfileValidator.validateUserProfile(userProfile);
    inviteUser(userProfile.getUserId());
    userRepo.updateUserStatus(userProfile.getUserId(), UserStatus.PENDING.value());
    logger.info("Successfully reinvited the user from SerivceMax {}", emailId);
  }

  /**
   * Changes made as per NCIOT-11630. Devices are assigned to user if the user is auto-created.
   * Devices will be assigned based on from which object the user has been invited.
   *
   * @param userProfile
   */
  private void assignDevices(UserProfile userProfile) {
    logger.info(
        "Starting assigning the devices to user {}, user is invited via --> {}",
        userProfile.getUserId(),
        userProfile.getInvitedVia());
    String[] soldToBillTo = userProfile.getOrg().getName().split(Constants.UNDERSCORE);
    String soldTo = soldToBillTo[1];
    String billTo = soldToBillTo[2];

    if (UserInvitedVia.INSTALLED_PRODUCT.value().equalsIgnoreCase(userProfile.getInvitedVia())) {

      List<Device> devices =
          deviceRepository.findDeviceIdByEmailIdAndSoldToAndBillToAndDeletedAndStatus(
              userProfile.getEmail(), soldTo, billTo, false, true);
      assignDevicesToUser(
          devices.stream().map(Device::getDeviceId).collect(Collectors.toList()), userProfile);

      devices.stream()
          .forEach(
              d ->
                  userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAutoAssignment(
                      d.getDeviceId()));

    } else if (UserInvitedVia.SERVIE_CONTRACT
        .value()
        .equalsIgnoreCase(userProfile.getInvitedVia())) {

      List<String> serviceContractIds =
          serviceContractRepository.findDistinctServiceContractIdByEmailId(
              com.merck.nextconnect.utils.common.Constants.ACTIVE_SERVICE_CONTRACT_STATUS_LIST,
              userProfile.getEmail(),
              soldTo,
              billTo);

      List<Long> deviceIds = new ArrayList<>();

      if (!serviceContractIds.isEmpty()) {
        deviceIds = coveredProductRepository.getDeviceIdsFromServiceContractId(serviceContractIds);
      }

      if (!deviceIds.isEmpty()) {
        List<Device> devices =
            deviceRepository.findByDeviceIdInAndDeletedAndStatus(deviceIds, false, true);

        assignDevicesToUser(
            devices.stream().map(Device::getDeviceId).collect(Collectors.toList()), userProfile);

        devices.stream()
            .forEach(
                d ->
                    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAutoAssignment(
                        d.getDeviceId()));
      }
    }
    logger.info(
        "End of assigning the devices to user {},user is invited via --> {}",
        userProfile.getUserId(),
        userProfile.getInvitedVia());
  }

  /**
   * Changes made as per NCIOT-11630. Devices will be assigned to the user.
   *
   * @param deviceIds
   * @param userProfile
   */
  private void assignDevicesToUser(List<Long> deviceIds, UserProfile userProfile) {
    logger.info("Starting of assignDevicesToUser to user {}", userProfile.getUserId());
    if (!deviceIds.isEmpty()) {
      List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
      for (long deviceId : deviceIds) {
        ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
        resourcePrivilege.setResourceid(deviceId);
        resourcePrivilege.setPrivilegeid(OrgPrivileges.assign_device.getPrivilegeId());
        resourcePrivileges.add(resourcePrivilege);
      }
      userRolePrivileges.autoAddUserDevicePrivileges(userProfile, resourcePrivileges);
    }
    logger.info("End of assignDevicesToUser to user {}", userProfile.getUserId());
  }

  /**
   * sending self registration approval email
   *
   * @param userProfile - user profile
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  private HashMap<String, String> sendSelfRegistrationEmailToCA(UserProfile userProfile)
      throws com.merck.nextconnect.utils.file.handler.exception.CustomException {
    logger.info("inside the sendSelfRegistrationEmailToCA method..");
    List<SelfRegisteredUserDeviceMapping> userSelfRegistrationDeviceMapping =
        selfRegisteredUserDeviceRepository.findAllByUserProfileUserId(userProfile.getUserId());

    Device userSelfRegistrationDevice = null;

    if (Objects.isNull(userSelfRegistrationDeviceMapping)
        || userSelfRegistrationDeviceMapping.isEmpty()) {
      logger.error(
          "sendSelfRegistrationEmailToCA --> no device mapped with user : {}",
          userProfile.getUserId());
      // throw new
      // com.merck.nextconnect.utils.file.handler.exception.CustomException(com.merck.nextconnect.utils.file.util.CustomErrorCodes.NO_DEVICE_ASSOCIATED_TO_COMPLETE_SELF_REGISTERATION);
    } else if (userSelfRegistrationDeviceMapping.size() > 1) { // Not possible in theory
      logger.error(
          "sendSelfRegistrationEmailToCA --> multiple device mapped with user : {}",
          userProfile.getUserId());
      // throw new
      // com.merck.nextconnect.utils.file.handler.exception.CustomException(com.merck.nextconnect.utils.file.util.CustomErrorCodes.MULTIPLE_DEVICES_ASSIGNED_TO_SELF_REGISTERATION_USER);
    } else userSelfRegistrationDevice = userSelfRegistrationDeviceMapping.get(0).getDevice();

    UserProfile caUserProfile = null;
    // Check device warranty / contract
    caUserProfile =
        selfRegistrationService.getCAForDevice(
            userSelfRegistrationDevice, userProfile.getOrg().getId());

    if (!Optional.ofNullable(caUserProfile).isPresent()) {
      logger.error(
          "sendSelfRegistrationEmailToCA --> couldn't find appropriate Customer Admin for user_id : {}",
          userProfile.getUserId());
      try {
        if (userSelfRegistrationDevice.isDealer()) {
          selfRegistrationService.raiseInvalidCAServiceRequest(
              userProfile,
              userSelfRegistrationDevice,
              ServiceRequestType.SELF_REGISTRATION_TO_MYMILLIQ_VALIDATION_FAILURE.value());
          // change
          UserProfile inactiveCA =
              findOldestInactiveCA(userSelfRegistrationDevice, userProfile.getOrg().getId());
          List<UserProfile> distributorFseProfile =
              fetchDistributorRoles(userProfile.getOrg().getParent().getId());
          for (UserProfile distributorRoles : distributorFseProfile) {
            sendEmailToDistributorFSE(
                distributorRoles, userSelfRegistrationDevice, userProfile, inactiveCA);
          }
        } else {
          logger.error(
              "sendSelfRegistrationEmailToCA --> couldn't find appropriate Customer Admin for user_id : {}",
              userProfile.getUserId());

          selfRegistrationService.raiseInvalidCAServiceRequest(
              userProfile,
              userSelfRegistrationDevice,
              ServiceRequestType.SELF_REGISTRATION_TO_MYMILLIQ_VALIDATION_FAILURE.value());
        }
      } catch (CustomSMException | IOException ex) {
        logger.error(
            "sendSelfRegistrationEmailToCA --> failed to raise Service Request for invalid CA for user_id: {} with exception: ",
            userProfile.getUserId(),
            ex);
      }
      throw new com.merck.nextconnect.utils.file.handler.exception.CustomException(
          com.merck.nextconnect.utils.file.util.CustomErrorCodes.CUSTOMER_ADMIN_NOT_FOUND);
    }

    logger.info(
        "sendSelfRegistrationEmailToCA --> attempting to send validation email to Customer Admin : {} for userProfile : {}",
        caUserProfile.getEmail(),
        userProfile.getUserId());

    ApplicationConfig emailSubject =
        applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.SELF_REGISTRATION_CA_EMAIL_CONFIG,
            com.merck.nextconnect.utils.common.Constants.SUBJECT,
            Constants.ACTIVE);

    EmailTemplate emailTemplate =
        emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            Constants.USER_VALIDATION_BY_CA, caUserProfile.getLanguage().getId(), Constants.ACTIVE);

    EmailMessage emailValidationMessageCA =
        EmailMessage.builder()
            .emailTemplate(emailTemplate)
            .emailFrom(fromEmail)
            .emailTo(caUserProfile.getEmail())
            .subject(emailSubject.getValue())
            .status(com.merck.nextconnect.utils.common.Constants.EMAIL_SUCCESS_STATUS)
            .createdBy(Constants.USERHUB.toUpperCase())
            .createdTimestamp(Timestamp.from(Instant.now()))
            .lastUpdatedBy(Constants.USERHUB.toUpperCase())
            .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
            .charset(com.merck.nextconnect.utils.common.Constants.EMAIL_CHAR_SET)
            .contentType(com.merck.nextconnect.utils.common.Constants.EMAIL_CONTENT_TYPE)
            .build();

    Set<EmailAttribute> emailAttributes = new HashSet<>();

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("ca_name")
            .attributeValue(
                String.join(
                    " ",
                    StringUtils.defaultIfBlank(caUserProfile.getFirstName(), StringUtils.EMPTY),
                    StringUtils.defaultIfBlank(caUserProfile.getLastName(), StringUtils.EMPTY)))
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("user_email")
            .attributeValue(userProfile.getEmail())
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("user_country")
            .attributeValue(userProfile.getCountry().getCountryName())
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("system_name")
            .attributeValue(
                Objects.nonNull(userSelfRegistrationDevice)
                    ? userSelfRegistrationDevice.getDevicename()
                    : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE)
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("system_catalogue_number")
            .attributeValue(
                Objects.nonNull(userSelfRegistrationDevice)
                    ? userSelfRegistrationDevice.getProductCatalogNo()
                    : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE)
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("system_serial_number")
            .attributeValue(
                Objects.nonNull(userSelfRegistrationDevice)
                    ? userSelfRegistrationDevice.getSerialno()
                    : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE)
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("validation_link")
            .attributeValue(userMgmtURL.concat(userProfile.getEmail()))
            .emailMessage(emailValidationMessageCA)
            .build());

    emailValidationMessageCA.setEmailAttributes(emailAttributes);
    boolean mailSent = false;
    logger.info("Email attributes : " + emailValidationMessageCA.toString());
    try {
      mailSent = emailService.sendMail(emailValidationMessageCA, environment);
      logger.info(
          "Self registration approval email successfullys send to {}", caUserProfile.getEmail());
    } catch (EmailException ex) {
      logger.error("Failed to send self registration CA email -> ", ex);
    }

    HashMap<String, String> smsMap = null;
    logger.info("Self-reg sms creation process strat");
    // adding logic for sms DIC-8
    if (mailSent) {
      String systemName =
          Objects.nonNull(userSelfRegistrationDevice)
              ? userSelfRegistrationDevice.getDevicename()
              : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE;
      smsMap = getSelfRegSmsData(caUserProfile, userProfile.getEmail(), systemName);
    }
    return smsMap;
  }

  /**
   * Send email to Distributor FSE
   *
   * @param distributorFseProfile
   * @param device
   * @param userProfile
   */
  private void sendEmailToDistributorFSE(
      UserProfile distributorFseProfile,
      Device device,
      UserProfile userProfile,
      UserProfile inactiveCA) {
    logger.info("Inside sendEmailToDistributorFSE method..");
    ApplicationConfig emailSubject =
        applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.SELF_REGISTRATION_CA_EMAIL_CONFIG,
            com.merck.nextconnect.utils.common.Constants.SUBJECT,
            Constants.ACTIVE);

    EmailTemplate emailTemplate =
        emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
            Constants.CUSTOMER_ADMIN_INACTIVE,
            distributorFseProfile.getLanguage().getId(),
            Constants.ACTIVE);

    EmailMessage emailValidationMessageCA =
        EmailMessage.builder()
            .emailTemplate(emailTemplate)
            .emailFrom(fromEmail)
            .emailTo(distributorFseProfile.getEmail())
            .subject(emailSubject.getValue())
            .status(com.merck.nextconnect.utils.common.Constants.EMAIL_SUCCESS_STATUS)
            .createdBy(Constants.USERHUB.toUpperCase())
            .createdTimestamp(Timestamp.from(Instant.now()))
            .lastUpdatedBy(Constants.USERHUB.toUpperCase())
            .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
            .charset(com.merck.nextconnect.utils.common.Constants.EMAIL_CHAR_SET)
            .contentType(com.merck.nextconnect.utils.common.Constants.EMAIL_CONTENT_TYPE)
            .build();

    Set<EmailAttribute> emailAttributes = new HashSet<>();

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("distributor_customer")
            .attributeValue(
                String.join(
                    " ",
                    StringUtils.defaultIfBlank(
                        distributorFseProfile.getFirstName(), StringUtils.EMPTY),
                    StringUtils.defaultIfBlank(
                        distributorFseProfile.getLastName(), StringUtils.EMPTY)))
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("system_name")
            .attributeValue(
                Objects.nonNull(device)
                    ? device.getDevicename()
                    : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE)
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("system_catalogue_number")
            .attributeValue(
                Objects.nonNull(device)
                    ? device.getProductCatalogNo()
                    : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE)
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("system_serial_number")
            .attributeValue(
                Objects.nonNull(device)
                    ? device.getSerialno()
                    : com.merck.nextconnect.utils.common.Constants.NOT_AVAILABLE)
            .emailMessage(emailValidationMessageCA)
            .build());

    emailAttributes.add(
        EmailAttribute.builder()
            .attributeName("organisation")
            .attributeValue(userProfile.getOrg().getName())
            .emailMessage(emailValidationMessageCA)
            .build());
    // change for V6MILIQ-1464
    if (Objects.nonNull(inactiveCA)) {
      emailAttributes.add(
          EmailAttribute.builder()
              .attributeName("customer_admin")
              .attributeValue(
                  String.join(
                      " ",
                      StringUtils.defaultIfBlank(inactiveCA.getFirstName(), StringUtils.EMPTY),
                      StringUtils.defaultIfBlank(inactiveCA.getLastName(), StringUtils.EMPTY)))
              .emailMessage(emailValidationMessageCA)
              .build());
    }
    emailValidationMessageCA.setEmailAttributes(emailAttributes);
    logger.info("Email attributes for ds..:" + emailValidationMessageCA.toString());
    try {
      emailService.sendMail(emailValidationMessageCA, environment);
      logger.info(
          "Self registration approval email successfullys send to {}",
          distributorFseProfile.getEmail());
    } catch (EmailException ex) {
      logger.error("Failed to send self registration CA email -> ", ex);
    }
  }

  /**
   * Method to fetch Distributor FSE of an organization
   *
   * @param orgId
   * @return UserProfile - Distributor FSE
   */
  private List<UserProfile> fetchDistributorRoles(int orgId) {

    return userRepo.findDistributorRoles(orgId);
  }

  @Override
  public UserProfileImageDTO fetchImage(long userId) throws CustomException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Optional.ofNullable(authUser)
        .filter(a -> Long.parseLong(a.getId()) == userId)
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.UNAUTHORIZED_ACCESS));
    UserProfileImageDTO userProfileImageDTO = new UserProfileImageDTO();
    String blobImage = userProfileImageRepositoryJdbc.fetchUserBlobImage(userId);
    logger.debug("userId: {}, Image: {}", userId, blobImage);
    if (StringUtils.isBlank(blobImage)) {
      return userProfileImageDTO;
    }
    userProfileImageDTO.setUserImage(blobImage);
    return userProfileImageDTO;
  }

  @Transactional
  @Override
  public void deleteImage(long userId) throws CustomException, DataValidationException {
    UserProfile user = userRepo.getUserById(userId);
    if (!Optional.ofNullable(user).isPresent()) {
      throw new DataValidationException(CustomErrorCodes.USER_NOT_FOUND);
    }
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Optional.ofNullable(authUser)
        .filter(a -> Long.parseLong(a.getId()) == userId)
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.UNAUTHORIZED_ACCESS));
    logger.debug("Image is deleted for the userId:{}", userId);
    userProfileImageRepositoryJdbc.deleteUserImage(userId);
  }

  public UserProfileResponseEntity fetchOneUser(long userId) {
    return UserProfileConverter.toResponseEntity(fetchOne(userId));
  }

  private UserProfile findOldestInactiveCA(Device device, int userOrgId) {
    UserProfile inactiveCAProile = null;
    Role role = roleRepo.getRoleByName(Constants.CUSTOMER_ADMIN, userOrgId);
    inactiveCAProile =
        userRepo.getOldestInactiveUsersByRoleIdsAndActive(role.getRoleId(), userOrgId);
    return inactiveCAProile;
  }

  /** This method will check for userType for the contacthotline. returns String. */
  @Override
  public String fetchUserType(Integer userId) throws CustomException {
    String userType = null;
    UserProfile userProfile = userRepo.getUserById(userId);
    logger.info("Inside contactHotlineUserType method..");

    if (!Optional.ofNullable(userProfile).isPresent()) {
      logger.error("userId not found {}", userProfile);
      throw new CustomException(CustomErrorCodes.USER_NOT_FOUND);
    }
    String orgType = userProfile.getOrg().getType();
    if (!Optional.ofNullable(orgType).isPresent()) {
      logger.error("org not found {}", userProfile);
      throw new CustomException(CustomErrorCodes.ORG_NOT_FOUND);
    }
    if (orgType.equalsIgnoreCase("Customers")) {
      Organization parentOrg = userProfile.getOrg().getParent();
      if (parentOrg.getType().equalsIgnoreCase("Customers")
          || parentOrg.getType().equalsIgnoreCase("Business Unit")) {
        userType = Constants.DIRECT_CUSTOMER;
      } else {
        userType = Constants.INDIRECT_CUSTOMER;
      }
    } else {
      userType = orgType;
    }
    return userType;
  }

  public void createSmsForSelfRegisteredUser(HashMap<String, String> smsMap) {
    logger.info(
        "SMS to be sent for Customer Admin : "
            + smsMap.get(Constants.CA_NAME)
            + " Self-reg "
            + " Phone Number : "
            + smsMap.get(Constants.CA_PHONE_NUMBER));
    JSONObject sms = new JSONObject();

    try {

      JSONObject encoding = new JSONObject();
      encoding.put("invalidCharacters", "TO_UTF16");
      encoding.put("encoding", "utf-16");
      encoding.put("maxParts", "20");
      encoding.put("src", com.merck.nextconnect.utils.common.Constants.SENDER_ID);
      sms.put("options", encoding);

      String smsMessage =
          ncSmsTemplateRepository.getDataByCategoryAndConfigKeyAndLanguageId(
              Constants.SELF_REGISTRATION_SMS,
              Constants.SMS_SELF_REG_CA,
              Integer.parseInt(smsMap.get(Constants.CA_LANGUAGE)));

      Set<String> phonesList = new HashSet<>();
      JSONArray messages = new JSONArray();

      JSONObject text = new JSONObject();
      text.put(
          "text",
          String.format(
              smsMessage,
              smsMap.get(Constants.CA_NAME),
              smsMap.get(Constants.SELF_USER_EMAIL),
              smsMap.get(Constants.SYSTEM_NAME)));

      JSONArray recipientsArray = new JSONArray();
      JSONObject dst = new JSONObject();
      dst.put("dst", smsMap.get(Constants.CA_PHONE_NUMBER));

      recipientsArray.put(dst);

      phonesList.add(smsMap.get(Constants.CA_PHONE_NUMBER));
      text.put("recipients", recipientsArray);
      messages.put(text);

      sms.put("messages", messages);
      logger.info("SMS messages: {}", sms.get("messages"));
      smsServiceImpl.sendSms(
          SmsMessage.builder().phoneNumber(phonesList).jsonMessage(String.valueOf(sms)).build(),
          SmsDTO.builder().url(smsHost).username(smsUsername).password(smsPassword).build());

    } catch (HttpClientErrorException e) {
      logger.error(
          "HttpClientErrorException: Exception occurred while sending SMS for self-reg {}", sms, e);

    } catch (HttpServerErrorException e) {
      logger.error(
          "HttpServerErrorException: Exception occurred while sending SMS for self-reg {}", sms, e);
    } catch (JSONException e) {
      logger.error("JSONException: Exception occurred while sending SMS for self-reg {} :", e);

    } catch (Exception e) {
      logger.error("Exception occurred while sending SMS for self-reg :", e);
    }
  }

  /**
   * this method will create an smsMap with caUserProfile data.
   *
   * @param caUserProfile
   * @param userEmail
   * @param systemName
   * @return Map
   */
  private HashMap<String, String> getSelfRegSmsData(
      UserProfile caUserProfile, String userEmail, String systemName) {
    logger.info("Inside getSelfRegSmsData method..");
    HashMap<String, String> smsMap = new HashMap<String, String>();

    String phoneNumber =
        (StringUtils.isBlank(caUserProfile.getIsdCode()) ? "" : caUserProfile.getIsdCode())
            + (StringUtils.isBlank(caUserProfile.getPhone()) ? "" : caUserProfile.getPhone());

    String name =
        String.join(
            " ",
            StringUtils.defaultIfBlank(caUserProfile.getFirstName(), StringUtils.EMPTY),
            StringUtils.defaultIfBlank(caUserProfile.getLastName(), StringUtils.EMPTY));
    smsMap = new HashMap<String, String>();
    smsMap.put(Constants.CA_EMAIL, caUserProfile.getEmail());
    smsMap.put(Constants.CA_PHONE_NUMBER, phoneNumber);
    smsMap.put(Constants.CA_NAME, name);
    smsMap.put(Constants.SYSTEM_NAME, systemName);
    smsMap.put(Constants.SELF_USER_EMAIL, userEmail);
    smsMap.put(Constants.CA_LANGUAGE, Integer.toString(caUserProfile.getLanguage().getId()));

    return smsMap;
  }

  private int validateFirstAccountCreationOrNot(UserProfile userProfile) {
    List<UserDeviceAssignmentTrack> userDeviceAssignmentTrack =
        userDeviceAssignmentTrackRepository.findByUser(userProfile);
    if (!userDeviceAssignmentTrack.isEmpty() && userDeviceAssignmentTrack.size() == 1) {
      return 1;
    }
    return 0;
  }
}
