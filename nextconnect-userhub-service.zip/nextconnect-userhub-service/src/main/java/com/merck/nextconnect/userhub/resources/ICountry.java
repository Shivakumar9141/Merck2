package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.model.CountryTimezoneDTO;
import com.merck.nextconnect.utils.common.entities.Country;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface ICountry {

  List<Country> getCountries(String searchBy);

  public List<CountryTimezoneDTO> getCountriesTimezone(Integer countryId);

  public CountryTimezoneDTO getCountryTimezone(Integer countryTimezoneId);
}
