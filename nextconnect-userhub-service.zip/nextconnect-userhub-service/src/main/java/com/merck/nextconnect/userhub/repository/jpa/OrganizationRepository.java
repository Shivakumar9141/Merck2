package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.util.Constants;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganizationRepository
    extends JpaRepository<Organization, Integer>, JpaSpecificationExecutor<Organization> {

  @Query(
      "select Count(o) != 0 From Organization o where lower(o.name) = lower(:orgName) and o.parent.id = :parentOrg and o.id !=:orgId and o.deleted = false")
  boolean hasOrgByName(
      @Param("orgName") String orgName,
      @Param("parentOrg") int parentOrg,
      @Param("orgId") int orgId);

  @Query(
      "select o From Organization o where lower(o.name) = lower(:orgName) and o.parent.id = :parentOrg and o.deleted=false order by o.id desc limit 1")
  Organization getOrgByName(@Param("orgName") String orgName, @Param("parentOrg") int parentOrg);

  @Query(
      "select new com.merck.nextconnect.userhub.model.org.OrgDto(o.id,o.name,o.description,o.createdBy,o.createdDate,o.status,o.type,os.historicalDataSubscription,o.isAutoCreated) From Organization o, OrgSettings os where os.org = o and "
          + "o.parent.id = :orgId and lower(o.name) like CONCAT('%',lower(:searchBy),'%') and (:type is null or o.type = :type) and o.type !='DEFAULT TEMPLATE' "
          + "and o.deleted=false order by o.name asc")
  List<OrgDto> findChildOrgs(
      @Param("orgId") int orgId, @Param("searchBy") String searchBy, @Param("type") String type);

  @Query(
      "select o From Organization o where o.id =:orgId and o.type !='DEFAULT TEMPLATE' and o.deleted = false")
  Organization getOrg(@Param("orgId") int orgId);

  @Query(
      "select o From Organization o where o.id =:orgId and o.type !='DEFAULT TEMPLATE' and o.deleted = false")
  Optional<Organization> findOrgById(@Param("orgId") int orgId);

  @Query("select Count(o) != 0 From Organization o where o.parent.id = :orgId and o.deleted=false")
  boolean hasChildren(@Param("orgId") int orgId);

  @Query("select id from Organization where name =:name")
  int findIdByName(@Param("name") String name);

  /**
   * Made changes as per NCIOT-11283. Fetching all organization except Business unit and default
   * template type.
   *
   * @return List<Organization>
   */
  @Query(
      "from Organization o where o.type not in ('BUSINESS UNIT', 'DEFAULT TEMPLATE', 'ORG') and o.deleted=false")
  List<Organization> getAll();

  /**
   * Made changes as per NCIOT-11283. Fetching all Partner type organization where the parent is
   * logged in users organization.
   *
   * @param orgId
   * @return List<Organization>
   */
  @Query(
      "from Organization o where o.type = ('"
          + Constants.ORG_TYPE_PARTNER
          + "') and o.deleted=false and o.parent.id = :orgId")
  List<Organization> getAllPartnerOrgs(@Param("orgId") int orgId);

  /**
   * Made changes as per NCIOT-11283. Fetching all Customer type organization where the parent is
   * logged in users organization.
   *
   * @param orgId
   * @return List<Organization>
   */
  @Query(
      "from Organization o where o.type = ('"
          + Constants.ORG_TYPE_CUSTOMER
          + "') and o.deleted=false and o.parent.id = :orgId")
  List<Organization> getAllCustomerOrgs(@Param("orgId") int orgId);

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param orgName
   * @param type
   * @param status
   * @param parentId
   * @param isDeleted
   * @return Organization
   */
  Organization findByNameAndTypeAndStatusAndParentIdAndDeleted(
      String orgName, String type, boolean status, int parentId, boolean isDeleted);

  //  Organization findByNameAndTypeAndParentIdAndDeleted(
  //      String orgName, String type, int parentId, boolean isDeleted);

  @Query(
      "select o From Organization o where lower(o.name) = lower(:orgName) and o.type = :type and o.parent.id = :parentId and o.deleted = :isDeleted order by o.id desc limit 1")
  Organization findByNameAndTypeAndParentIdAndDeleted(
      @Param("orgName") String orgName,
      @Param("type") String type,
      @Param("parentId") int parentId,
      @Param("isDeleted") boolean isDeleted);

  Optional<List<Organization>> findByType(String type);

  @Query("select o.type from Organization o where o.id =:orgId and o.deleted=false")
  String getOrgTypeById(@Param("orgId") int orgId);

  @Query("select o From Organization o where o.id =:orgId and o.deleted=false")
  Organization findOrg(@Param("orgId") int orgId);

  @Query(
      value =
          "select d.id from( SELECT DISTINCT device.device_id, org.id FROM "
              + "((((nc_app.nc_devices device "
              + "JOIN nc_app.nc_users_device_privileges device_privileges ON ((device.device_id = device_privileges.device_id))) "
              + "JOIN nc_app.nc_org_devices device_org ON ((device.device_id = device_org.device_id))) "
              + "JOIN nc_app.nc_org org ON ((device_org.org_id = org.id)))) "
              + "WHERE device.deleted = FALSE "
              + "AND device.is_dealer = 1 "
              + "AND org.type IN ('Customers') "
              + "AND device.device_id in (:deviceId) "
              + ") d;",
      nativeQuery = true)
  List<Integer> findOrgIdForDistributorDevice(@Param("deviceId") Long deviceId);
}
