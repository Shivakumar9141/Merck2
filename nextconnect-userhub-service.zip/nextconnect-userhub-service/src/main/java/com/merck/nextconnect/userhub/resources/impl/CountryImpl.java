package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.model.CountryTimezoneDTO;
import com.merck.nextconnect.userhub.resources.ICountry;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.file.entities.CountryTimezone;
import com.merck.nextconnect.utils.repository.jpa.CountryTimezoneRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CountryImpl implements ICountry {

  @Autowired private CountryRepository countryRepository;

  @Autowired private CountryTimezoneRepository countryTimezoneRepository;

  @Override
  public List<Country> getCountries(String searchBy) {
    return countryRepository.findByCountryNameContainingIgnoreCaseOrderByCountryNameAsc(searchBy);
  }

  @Override
  public List<CountryTimezoneDTO> getCountriesTimezone(Integer countryId) {
    return (countryId == null
            ? countryTimezoneRepository.findAll()
            : countryTimezoneRepository.findByCountryId(countryId))
        .stream()
            .map(
                countryTimeZone ->
                    new CountryTimezoneDTO(
                        countryTimeZone.getId(),
                        countryTimeZone.getTimezoneName(),
                        countryTimeZone.getTimezoneDesc(),
                        countryTimeZone.getTimezoneOffset(),
                        countryTimeZone.getCountry().getId()))
            .collect(Collectors.toList());
  }

  public CountryTimezoneDTO getCountryTimezone(Integer countryTimezoneId) {
    CountryTimezone timezone = countryTimezoneRepository.findById(countryTimezoneId).get();
    return CountryTimezoneDTO.builder()
        .id(timezone.getId())
        .timezoneName(timezone.getTimezoneName())
        .timezoneDesc(timezone.getTimezoneDesc())
        .timezoneAbbr(timezone.getTimezoneOffset())
        .country(timezone.getCountry().getId())
        .build();
  }
}
