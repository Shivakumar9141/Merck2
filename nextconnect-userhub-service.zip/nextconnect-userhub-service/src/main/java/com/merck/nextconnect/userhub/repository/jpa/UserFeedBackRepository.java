package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserFeedBackEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserFeedBackRepository
    extends JpaRepository<UserFeedBackEntity, Long>, JpaSpecificationExecutor<UserFeedBackEntity> {

  @Query(
      value =
          "select * from nc_user_exp_feedback where user_id=:userId order by created_date desc limit 1",
      nativeQuery = true)
  UserFeedBackEntity getLatestFeedBack(@Param("userId") Long userId);

  @Query(
      value =
          "SELECT count(1) FROM nc_user_profile  up join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) and up.deleted=0 and up.role_id not in(select role_id from nc_roles where name in('LW-super admin', 'LW-Service Admin','LW-FSE'))and up.status='Active'",
      nativeQuery = true)
  long getCountofCustomers(@Param("userId") String userId);

  @Query(
      value =
          "SELECT count(1) FROM nc_user_profile up jon nc_users_device_privileges udp on up.user_id=:userId",
      nativeQuery = true)
  Long getTotalCustomers(@Param("userId") String userId);

  @Query(
      value =
          "SELECT count(1) FROM nc_user_exp_feedback where user_id in(select user_id from nc_users_device_privileges where user_id =:userId)",
      nativeQuery = true)
  Long getFeedBackCustomers(@Param("userId") String userId);

  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile  up where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId and up.deleted=0 and up.status='Active') and up.role_id not in(select role_id from nc_roles where name in(:rolesList))",
      nativeQuery = true)
  Long getTotalFSEUsers(@Param("userId") Long userId, @Param("rolesList") List<String> rolesList);

  @Query(
      value =
          "SELECT count(1) as Total_Users FROM nc_user_profile where role_id in (select role_id from  nc_roles where name not in (:rolesList)) and deleted=0 and status='Active'",
      nativeQuery = true)
  Long getTotalUsers(@Param("rolesList") List<String> rolesList);

  // NCIOT-11742
  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId and up.deleted=0 and up.status='Active')"
              + " and up.role_id  in(select role_id from nc_roles where name in(:rolesList)) and up.org_id in (:accessibleOrgs)",
      nativeQuery = true)
  Long getTotalDistributorFSEUsers(
      @Param("userId") Long userId,
      @Param("rolesList") List<String> rolesList,
      @Param("accessibleOrgs") List<Integer> accessibleOrgs);

  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile up "
              + "  inner join nc_roles nr on up.role_id=nr.role_id "
              + "  inner join nc_org org  on up.org_id=org.id "
              + "  where up.deleted=0 and up.status='Active' "
              + " and nr.name  in (:rolesList) and up.org_id in (:accessibleOrgs)",
      nativeQuery = true)
  Long getTotalUsersDistributorAdmin(
      @Param("rolesList") List<String> rolesList,
      @Param("accessibleOrgs") List<Integer> accessibleOrgs);

  @Query(
      value =
          "SELECT distinct org.id  FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId and up.deleted=0 and up.status='Active')"
              + " and up.role_id in (select role_id from nc_roles where name in (:roles) and org.parent=:orgId)",
      nativeQuery = true)
  List<Integer> getDistributorFSEOrgs(
      @Param("userId") Long userId,
      @Param("roles") List<String> roleNames,
      @Param("orgId") int orgId);

  @Query(
      value =
          "SELECT distinct org.id  FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId and up.deleted=0 and up.status='Active')",
      nativeQuery = true)
  List<Integer> getFSEOrgs(@Param("userId") Long userId);

  @Query(
      value =
          "SELECT distinct org.id  FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId and up.deleted=0 and up.status='Active')",
      nativeQuery = true)
  List<Integer> getFSSOrMCSOrgs(@Param("userId") Long userId);

  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile  up where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) and up.deleted=0 and up.status='Active' "
              + " and up.role_id  in(select role_id from nc_roles where name in(:rolesList)) and up.created_on <= :createdDate ",
      nativeQuery = true)
  Long getTotalFSEUsersWithDate(
      @Param("userId") Long userId,
      @Param("rolesList") List<String> rolesList,
      @Param("createdDate") String createdDate);

  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile  up join nc_roles nr on nr.role_id=up.role_id where up.deleted=0 and up.status='Active' and nr.name  in (:rolesList) and (up.created_on <= :createdDate) ",
      nativeQuery = true)
  Long getTotalUsersWithDate(
      @Param("rolesList") List<String> rolesList, @Param("createdDate") String createdDate);

  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId ) and up.deleted=0 and up.status='Active' "
              + " and (up.created_on <= :createdDate) and up.org_id in (:accessibleOrgs) "
              + " and up.role_id  in(select role_id from nc_roles where name in(:rolesList))",
      nativeQuery = true)
  Long getTotalDistributorFSEUsersWithDate(
      @Param("userId") Long userId,
      @Param("rolesList") List<String> rolesList,
      @Param("createdDate") String createdDate,
      @Param("accessibleOrgs") List<Integer> accessibleOrgs);

  @Query(
      value =
          "SELECT count(*) as Total_Users FROM nc_user_profile up "
              + "  inner join nc_roles nr on up.role_id=nr.role_id "
              + "  inner join nc_org org  on up.org_id=org.id "
              + "  where up.deleted=0 and up.status='Active' "
              + " and (up.created_on <= :createdDate) and up.org_id in (:accessibleOrgs) "
              + " and nr.name  in (:rolesList)",
      nativeQuery = true)
  Long getTotalUsersDistributorAdminWithDate(
      @Param("rolesList") List<String> rolesList,
      @Param("createdDate") String createdDate,
      @Param("accessibleOrgs") List<Integer> accessibleOrgs);

  @Query(
      value =
          "SELECT distinct org.id  FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.country_id =:countryId and up.user_id=:userId ",
      nativeQuery = true)
  List<Integer> getFSSORMCSOrgsByCountryId(
      @Param("userId") Long userId, @Param("countryId") Integer countryId);

  @Query(
      value =
          "select * from nc_user_exp_feedback where user_id in (select user_id from nc_user_profile where deleted=false and status='Active' and country_id=:countryId)",
      nativeQuery = true)
  List<UserFeedBackEntity> getAllFeedbackByCountry(@Param("countryId") Integer countryId);

  @Query(
      value =
          "SELECT distinct org.id  FROM nc_user_profile  up "
              + " join nc_org org on up.org_id=org.id "
              + " where up.deleted=0 and up.status='Active' and up.role_id in (select role_id from nc_roles where name in (:roles) and org.parent=:orgId)",
      nativeQuery = true)
  List<Integer> getDistributorAdminOrgs(
      @Param("roles") List<String> roleNames, @Param("orgId") int orgId);
}
