package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.PolicyTypeEntity;
import org.springframework.stereotype.Service;

@Service
public interface ILegalTermsService {

  PolicyTypeEntity getPolicyOrTerms(String languageCode, String type, String countryCode, int orgId)
      throws Exception;
}
