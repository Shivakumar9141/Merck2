package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.SubscriptionType;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.SubscriptionCategoryDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.repo.jdbc.SubscriptionCategoriesRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.SubscriptionTypeRepository;
import com.merck.nextconnect.userhub.resources.ISubscriptionType;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.util.Constants;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionTypeImpl implements ISubscriptionType {
  static final Logger LOGGER = LoggerFactory.getLogger(SubscriptionTypeImpl.class);
  @Autowired private SubscriptionTypeRepository subscriptionTypeRepository;

  @Autowired SubscriptionCategoriesRepositoryJdbc subscriptionCategoriesRepositoryJdbc;

  @Autowired RoleRepository roleRepo;

  @Autowired private IUser iuser;

  @Value("${nextconnect.subscription.numberofdaysadvance}")
  private int numberOfDaysAdvance;

  @Value("${nextconnect.subscription.fss.numberofdaysadvance}")
  private int numberOfDaysAdvanceForFssSubscription;

  @Override
  public List<SubscriptionTypeDTO> getAllSubscription() {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Role role = roleRepo.findById(authUser.getRoleId()).orElse(null);
    Sort sort = Sort.by(Sort.Direction.ASC, "subscriptionTypeId");
    String userType = null;
    String orgCreatedBy = null;
    if (Optional.ofNullable(authUser).isPresent()) {
      try {
        userType = iuser.fetchUserType(Integer.valueOf(authUser.getId()));
      } catch (NumberFormatException | CustomException e) {
        LOGGER.info("Exception occured in contactHotlineUserType() method", e);
      }
    }

    if (userType.equals(Constants.INDIRECT_CUSTOMER)) {
      orgCreatedBy = Constants.DISTRIBUTOR;
    } else {
      orgCreatedBy = Constants.BUSINESS_UNIT;
    }

    List<SubscriptionTypeDTO> allSubscriptionTypeDTOs =
        convertToDTO(
            subscriptionCategoriesRepositoryJdbc.getSubscriptionCategoriesMapping(
                role.getName(), orgCreatedBy),
            role);
    List<SubscriptionTypeDTO> filteredSubscriptionTypeDTOs =
        getFilteredSubscriptionsBasedOnRole(allSubscriptionTypeDTOs, role);

    return filteredSubscriptionTypeDTOs;
  }

  private List<SubscriptionTypeDTO> getFilteredSubscriptionsBasedOnRole(
      List<SubscriptionTypeDTO> allSubscriptionTypeDTOs, Role role) {
    Set<SubscriptionCategoryDTO> filterCategoryDTOs = null;
    List<SubscriptionTypeDTO> filteredSubscriptionTypeDTOs = new LinkedList<SubscriptionTypeDTO>();

    if (Constants.CUSTOMER_ROLES.stream().anyMatch(role.getName()::contains)) {
      for (SubscriptionTypeDTO subscriptionTypeDTO : allSubscriptionTypeDTOs) {
        filterCategoryDTOs = new TreeSet<>();
        for (SubscriptionCategoryDTO category : subscriptionTypeDTO.getSubscriptionCategories()) {
          if (Constants.CUST_ALL_CATEGORIES.stream()
              .anyMatch(category.getCategoryName()::equalsIgnoreCase)) {
            SubscriptionCategoryDTO filterCategoryDTO = new SubscriptionCategoryDTO();
            filterCategoryDTO.setCategoryName(category.getCategoryName());
            filterCategoryDTO.setSubscriptionCategoryId(category.getSubscriptionCategoryId());
            filterCategoryDTO.setEmails(category.getEmails());
            if (!Constants.CUST_CATEGORIES_WITHOUT_PREVENANCE_DELAY.stream()
                .anyMatch(category.getCategoryName()::equalsIgnoreCase)) {
              filterCategoryDTO.setNumberOfDaysAdvance(category.getNumberOfDaysAdvance());
            }
            filterCategoryDTOs.add(filterCategoryDTO);
          }
        }
        subscriptionTypeDTO.setSubscriptionCategories(filterCategoryDTOs);
        filteredSubscriptionTypeDTOs.add(subscriptionTypeDTO);
      }

    } else if (Constants.FSS_ROLES.stream().anyMatch(role.getName()::contains)) {
      for (SubscriptionTypeDTO subscriptionTypeDTO : allSubscriptionTypeDTOs) {
        filterCategoryDTOs = new TreeSet<>();
        for (SubscriptionCategoryDTO category : subscriptionTypeDTO.getSubscriptionCategories()) {
          if (Constants.FSS_ALL_CATEGORIES.stream()
              .anyMatch(category.getCategoryName()::equalsIgnoreCase)) {
            SubscriptionCategoryDTO filterCategoryDTO = new SubscriptionCategoryDTO();
            filterCategoryDTO.setCategoryName(category.getCategoryName());
            filterCategoryDTO.setSubscriptionCategoryId(category.getSubscriptionCategoryId());
            filterCategoryDTO.setEmails(category.getEmails());
            if (!Constants.FSS_CATEGORIES_WITHOUT_PREVENANCE_DELAY.stream()
                .anyMatch(category.getCategoryName()::equalsIgnoreCase)) {
              filterCategoryDTO.setNumberOfDaysAdvance(category.getNumberOfDaysAdvance());
            }
            filterCategoryDTOs.add(filterCategoryDTO);
          }
        }
        subscriptionTypeDTO.setSubscriptionCategories(filterCategoryDTOs);
        filteredSubscriptionTypeDTOs.add(subscriptionTypeDTO);
      }
    }
    return filteredSubscriptionTypeDTOs;
  }

  private List<SubscriptionTypeDTO> convertToDTO(
      List<SubscriptionType> subscriptionTypes, Role role) {
    List<SubscriptionTypeDTO> subscriptionTypeDTOs = new LinkedList<SubscriptionTypeDTO>();
    for (SubscriptionType subscriptionType : subscriptionTypes) {
      SubscriptionTypeDTO subscriptionTypeDTO = new SubscriptionTypeDTO();
      subscriptionTypeDTO.setSubscriptionTypeId(subscriptionType.getSubscriptionTypeId());
      subscriptionTypeDTO.setSubscriptionTypeName(subscriptionType.getSubscriptionTypeName());
      Set<SubscriptionCategoryDTO> subscriptionCategoryDTOs = new TreeSet<>();
      for (SubscriptionCategory subscriptionCategory :
          subscriptionType.getSubscriptionCategories()) {
        SubscriptionCategoryDTO subscriptionCategoryDTO = new SubscriptionCategoryDTO();
        subscriptionCategoryDTO.setCategoryName(subscriptionCategory.getCategoryName());
        subscriptionCategoryDTO.setSubscriptionCategoryId(
            subscriptionCategory.getSubscriptionCategoryId());
        if (Constants.CUSTOMER_ROLES.stream().anyMatch(role.getName()::contains)) {
          subscriptionCategoryDTO.setNumberOfDaysAdvance(numberOfDaysAdvance); // CHG***
        } else if (Constants.FSS_ROLES.stream().anyMatch(role.getName()::contains)) {
          subscriptionCategoryDTO.setNumberOfDaysAdvance(numberOfDaysAdvanceForFssSubscription);
        } else {
          subscriptionCategoryDTO.setNumberOfDaysAdvance(numberOfDaysAdvance);
        }
        subscriptionCategoryDTOs.add(subscriptionCategoryDTO);
      }
      subscriptionTypeDTO.setSubscriptionCategories(subscriptionCategoryDTOs);
      subscriptionTypeDTOs.add(subscriptionTypeDTO);
    }
    return subscriptionTypeDTOs;
  }
}
