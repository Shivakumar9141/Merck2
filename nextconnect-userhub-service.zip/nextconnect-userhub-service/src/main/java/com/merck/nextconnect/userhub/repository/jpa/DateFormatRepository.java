package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.utils.common.entities.DateFormat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface DateFormatRepository extends JpaRepository<DateFormat, Integer> {}
