package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "nc_legal_terms_lookup")
public class LegalTermsMapping {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  private int businessUnitId;

  private String countryCode;

  private String languageCode;

  @ManyToOne
  @JoinColumn(name = "policy_id")
  private PolicyTypeEntity policyTypeEntity;

  @ManyToOne
  @JoinColumn(name = "reference_id")
  private LegalTermsReference legalTermsReference;

  private String referenceValue;
}
