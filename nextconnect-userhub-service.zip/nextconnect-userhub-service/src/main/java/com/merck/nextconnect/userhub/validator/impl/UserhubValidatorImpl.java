/** */
package com.merck.nextconnect.userhub.validator.impl;

import static com.merck.nextconnect.utils.validations.helper.BooleanHelper.notNullBoolean;
import static com.merck.nextconnect.utils.validations.helper.StringValidationHelpers.notNullString;

import com.merck.nextconnect.userhub.validator.UserhubValidator;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * @author SHATHWAR
 */
@Service
public class UserhubValidatorImpl implements UserhubValidator {

  @Override
  public void validateOrgStatus(Boolean status) throws DataValidationException {
    notNullBoolean.test(status).throwIfInvalid("status");
  }

  @Override
  public void validateForNull(OrgAndUserDetail orgAndUserDetail) throws DataValidationException {
    notNullString.test(orgAndUserDetail.getInvitedVia()).throwIfInvalid("invited via");
    // notNullString.test(orgAndUserDetail.getCustomerName()).throwIfInvalid("customer
    // name");
    notNullString.test(orgAndUserDetail.getFirstName()).throwIfInvalid("first name");
    notNullString.test(orgAndUserDetail.getLastName()).throwIfInvalid("last name");
    notNullString.test(orgAndUserDetail.getEmail()).throwIfInvalid("email");
    notNullString.test(orgAndUserDetail.getBillTo()).throwIfInvalid("bill To");
    notNullString.test(orgAndUserDetail.getShipTo()).throwIfInvalid("ship To");
    notNullString.test(orgAndUserDetail.getSoldTo()).throwIfInvalid("sold To");
    // notNullLong.test(orgAndUserDetail.getDeviceId()).throwIfInvalid("device Id");
  }

  @Override
  public boolean isValidOrgDetailsPresent(OrgAndUserDetail orgAndUserDetail) {
    boolean isValidOrgDetailsPresent = true;
    if (StringUtils.isBlank(orgAndUserDetail.getSoldTo())
        || StringUtils.isBlank(orgAndUserDetail.getBillTo())
        || StringUtils.isBlank(orgAndUserDetail.getInvitedVia())
        || !validInvitedVia(orgAndUserDetail)) {
      isValidOrgDetailsPresent = false;
    }
    return isValidOrgDetailsPresent;
  }

  @Override
  public boolean isValidUserInviteDetailsPresent(OrgAndUserDetail orgAndUserDetail) {
    boolean isValidUserInviteDetailsPresent = true;
    if (StringUtils.isBlank(orgAndUserDetail.getFirstName())
        || StringUtils.isBlank(orgAndUserDetail.getLastName())
        || StringUtils.isBlank(orgAndUserDetail.getEmail())
        || StringUtils.isBlank(orgAndUserDetail.getInvitedVia())
        || StringUtils.isBlank(orgAndUserDetail.getSmAdminCountryCode())
        || !validInvitedVia(orgAndUserDetail)) {
      isValidUserInviteDetailsPresent = false;
    }
    return isValidUserInviteDetailsPresent;
  }

  private boolean validInvitedVia(OrgAndUserDetail orgAndUserDetail) {
    return (UserInvitedVia.INSTALLED_PRODUCT
            .value()
            .equalsIgnoreCase(orgAndUserDetail.getInvitedVia())
        || UserInvitedVia.SERVIE_CONTRACT
            .value()
            .equalsIgnoreCase(orgAndUserDetail.getInvitedVia()));
  }
}
