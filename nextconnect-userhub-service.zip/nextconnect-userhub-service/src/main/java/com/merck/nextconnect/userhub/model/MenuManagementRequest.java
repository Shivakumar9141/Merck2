package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author clukose
 */
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MenuManagementRequest {
  private long userId;
  private long roleId;
  private int orgId;
  private int menuGroupId;
  private String menuGroupName;
}
