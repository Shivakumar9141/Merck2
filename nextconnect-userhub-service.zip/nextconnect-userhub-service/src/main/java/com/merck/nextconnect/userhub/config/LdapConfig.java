package com.merck.nextconnect.userhub.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

/** ldap configuration class */
@Configuration
public class LdapConfig {

  @Value("${ldap.userDn}")
  private String userDn;

  @Value("${ldap.base}")
  private String base;

  @Value("${ldap.password}")
  private String password;

  @Value("${ldap.url}")
  private String url;

  @Bean(name = "sialLdap")
  public LdapTemplate getLdapTemplate1() {
    LdapTemplate ldapTemplate1 = new LdapTemplate();
    LdapContextSource source1 = new LdapContextSource();
    source1.setReferral("follow");
    source1.setUserDn(userDn);
    source1.setBase(base);
    source1.setPassword(password);
    source1.setUrl(url);
    source1.afterPropertiesSet();
    ldapTemplate1.setContextSource(source1);
    return ldapTemplate1;
  }
}
