package com.merck.nextconnect.userhub.constants;

public class UserhubConstants {

  public static final String SINGLE_SIGN_ON = "SINGLE_SIGN_ON";
  public static final String PUBLIC_KEY = "PUBLIC_KEY";
  public static final String ACTIVE = "ACTIVE";
  public static final String USER_PROFILE = "USER_PROFILE";
  public static final String THUMBNAIL_IMAGE_SCALE_HEIGHT = "THUMBNAIL_IMAGE_SCALE_HEIGHT";
  public static final String THUMBNAIL_IMAGE_SCALE_WIDTH = "THUMBNAIL_IMAGE_SCALE_WIDTH";
  public static final String BLOB_IMAGE_SCALE_HEIGHT = "BLOB_IMAGE_SCALE_HEIGHT";
  public static final String BLOB_IMAGE_SCALE_WIDTH = "BLOB_IMAGE_SCALE_WIDTH";
  public static final String USER_ID = "userId";
  public static final String USER_IMAGE = "userImage";
  public static final String THUMBNAIL_USER_IMAGE = "thumbnailUserImage";
  public static final String CREATED_DATE = "createdDate";
  public static final String MODIFIED_DATE = "modifiedDate";
  public static final String USER_DOMAIN = "USER_DOMAIN";
  public static final String DOMAIN_VISIBILITY = "DOMAIN_VISIBILITY";
}
