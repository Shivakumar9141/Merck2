package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

@Component
public class UserSpecification {
  static final Logger logger = LoggerFactory.getLogger(UserSpecification.class);

  @Autowired UserOrgPrivileges userOrgPrivileges;

  public Specification<UserProfile> specification(final FetchCriteria fetchCriteria) {
    return new Specification<UserProfile>() {
      @Override
      public Predicate toPredicate(
          Root<UserProfile> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
        List<Predicate> predicates = new ArrayList<>();
        // search
        Optional.ofNullable(fetchCriteria.getSearchBy())
            .ifPresent(
                f -> {
                  Expression<String> exp1 = cb.concat(root.<String>get("firstName"), " ");
                  exp1 = cb.concat(exp1, root.<String>get("lastName"));
                  predicates.add(
                      cb.or(
                          cb.like(
                              cb.lower(root.get("email")),
                              "%" + fetchCriteria.getSearchBy().toLowerCase() + "%"),
                          cb.like(
                              cb.lower(exp1),
                              "%" + fetchCriteria.getSearchBy().toLowerCase() + "%")));
                });
        // filter
        Optional.ofNullable(fetchCriteria.getFilterBy())
            .ifPresent(
                f -> {
                  Map<String, List<String>> filterMap =
                      getFilterValues(fetchCriteria.getFilterBy());
                  Optional.ofNullable(filterMap.get(Constants.STATUS))
                      .filter(fmap -> !filterMap.get(Constants.STATUS).isEmpty())
                      .ifPresent(
                          s -> {
                            predicates.add(
                                cb.in(root.get(Constants.STATUS))
                                    .value(filterMap.get(Constants.STATUS)));
                          });
                  Optional.ofNullable(filterMap.get(Constants.ROLE))
                      .filter(fmap -> !filterMap.get(Constants.ROLE).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.ROLE).get("name"))
                                    .value(filterMap.get(Constants.ROLE)));
                          });
                  Optional.ofNullable(filterMap.get(Constants.ORG_NAME))
                      .filter(fmap -> !filterMap.get(Constants.ORG_NAME).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.ORG).get("name"))
                                    .value(filterMap.get(Constants.ORG_NAME)));
                          });
                  Optional.ofNullable(filterMap.get(Constants.ORG_ID))
                      .filter(fmap -> !filterMap.get(Constants.ORG_ID).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.ORG).get("id"))
                                    .value(
                                        filterMap.get(Constants.ORG_ID).stream()
                                            .map(Integer::parseInt)
                                            .collect(Collectors.toList())));
                          });
                  Optional.ofNullable(filterMap.get(Constants.COUNTRY_CODE))
                      .filter(fmap -> !filterMap.get(Constants.COUNTRY_CODE).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.COUNTRY).get(Constants.COUNTRY_CODE))
                                    .value(filterMap.get(Constants.COUNTRY_CODE)));
                          });
                });
        // omitting soft delete
        predicates.add(cb.equal(root.get("deleted"), false));
        // ignoring users with system defined roles for users with user
        // defined roles
        List<Integer> accessibleOrgs = new ArrayList<>();
        AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();

        // NCIOT-12110 for FSS role only customer org type users should shown in User management
        // screen
        List<String> auth =
            authUser.getAuthorities().stream()
                .map(x -> String.valueOf(x))
                .collect(Collectors.toList());
        // NCIOT-15566 //// NCIOT-16515
        if (Constants.DISTRIBUTOR_ADMIN.equals(authUser.getRole())) {
          predicates.add(
              cb.not(
                  cb.equal(
                      root.get(Constants.ROLE).get("name"), Constants.EXTERNAL_CUSTOMER_TECH)));

        } else if (Constants.LW_SERVICE_ADMIN.equals(authUser.getRole())) {
          predicates.add(
              cb.in(root.get(Constants.ROLE).get("name"))
                  .value(Arrays.asList(Constants.SUPER_ADMIN, Constants.LW_BUSINESS_MANAGER))
                  .not());
        } else if (Constants.LW_BUSINESS_MANAGER.equals(authUser.getRole())) {
          predicates.add(
              cb.in(root.get(Constants.ROLE).get("name"))
                  .value(Arrays.asList(Constants.SUPER_ADMIN))
                  .not());
        }
        if (auth.contains(Constants.USER_MANAGEMENT_FOR_FSS_ROLE)) {
          //					accessibleOrgs
          //							.addAll(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null,
          // Constants.CUSTOMER)
          //									.stream().filter(o -> o.getOrgId() != authUser.getOrgId()).map(o ->
          // o.getOrgId())
          //									.collect(Collectors.toList()));
          //
          //					Optional.ofNullable(accessibleOrgs).filter(a -> a.isEmpty()).ifPresent(a -> {
          //
          //	predicates.add(cb.or(cb.equal(root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED),
          // false),
          //								cb.equal(root.get(Constants.ROLE).get("roleId"), authUser.getRoleId())));
          //					});
          //
          //					Optional.ofNullable(accessibleOrgs).filter(a -> !a.isEmpty()).ifPresent(a -> {
          //						predicates
          //								.add(cb.or((cb.and(
          //										(cb.or(cb.equal(root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED),
          // false),
          //												cb.equal(root.get(Constants.ROLE).get("roleId"),
          //														authUser.getRoleId()))),
          //										cb.in(root.get("org").get("id")).value(accessibleOrgs)))));
          //					});
          predicates.add(
              cb.in(root.get(Constants.ROLE).get("name")).value(Constants.ROLES_CREATED_BY_FSS));
        }
        // NCIOT-12111 User management for ICS-Service-Coordinator
        else if (auth.contains(Constants.USER_MANAGEMENT_FOR_ICS_SERVICE_CORDINATOR_ROLE)) {
          //					List<String> types = Arrays.asList(Constants.CUSTOMER, Constants.PARTNER,
          // Constants.DISTRIBUTOR);
          //					for (String type : types) {
          //						accessibleOrgs.addAll(userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts,
          // null, type)
          //								.stream().filter(o -> o.getOrgId() != authUser.getOrgId()).map(o ->
          // o.getOrgId())
          //								.collect(Collectors.toList()));
          //					}
          //					Optional.ofNullable(accessibleOrgs).filter(a -> a.isEmpty()).ifPresent(a -> {
          //
          //	predicates.add(cb.or(cb.equal(root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED),
          // false),
          //								cb.equal(root.get(Constants.ROLE).get("roleId"), authUser.getRoleId())));
          //					});
          //
          //					Optional.ofNullable(accessibleOrgs).filter(a -> !a.isEmpty()).ifPresent(a -> {
          //						predicates
          //								.add(cb.or((cb.and(
          //										(cb.or(cb.equal(root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED),
          // false),
          //												cb.equal(root.get(Constants.ROLE).get("roleId"),
          //														authUser.getRoleId()))),
          //										cb.in(root.get("org").get("id")).value(accessibleOrgs)))));
          //					});
          predicates.add(
              cb.in(root.get(Constants.ROLE).get("name"))
                  .value(Constants.ROLES_CREATED_BY_ICS_COORDINATOR));
        }
        //				else {
        accessibleOrgs.addAll(
            userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
                .filter(o -> o.getOrgId() != authUser.getOrgId())
                .map(o -> o.getOrgId())
                .collect(Collectors.toList()));

        Optional.ofNullable(accessibleOrgs)
            .filter(a -> a.isEmpty())
            .ifPresent(
                a -> {
                  predicates.add(
                      cb.or(
                          cb.equal(root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED), false),
                          cb.equal(root.get(Constants.ROLE).get("roleId"), authUser.getRoleId())));
                  predicates.add(cb.equal(root.get("org").get("id"), authUser.getOrgId()));
                });
        // logger.info("Fetching user details for these orgs -> {}", accessibleOrgs);

        Optional.ofNullable(accessibleOrgs)
            .filter(a -> !a.isEmpty())
            .ifPresent(
                a -> {
                  predicates.add(
                      cb.or(
                          (cb.and(
                              (cb.or(
                                  cb.equal(
                                      root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED),
                                      false),
                                  cb.equal(
                                      root.get(Constants.ROLE).get("roleId"),
                                      authUser.getRoleId()))),
                              cb.equal(root.get("org").get("id"), authUser.getOrgId()))),
                          cb.in(root.get("org").get("id")).value(accessibleOrgs)));
                });
        //				}
        predicates.add(cb.equal(root.get(Constants.ROLE).get(Constants.SERVICE_ROLE), false));
        return cb.and(predicates.toArray(new Predicate[0]));
      }

      private Map<String, List<String>> getFilterValues(List<String> filterBy) {
        Map<String, List<String>> filterMap = new HashMap<>();
        List<String> roleFilters = new ArrayList<>();
        List<String> statusFilters = new ArrayList<>();
        List<String> orgNameFilters = new ArrayList<>();
        List<String> orgIdFilters = new ArrayList<>();
        List<String> countryCodeFilters = new ArrayList<>();
        filterBy.stream()
            .forEach(
                afilterBy -> {
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.STATUS_FILTER_PREFIX))
                      .ifPresent(
                          s -> {
                            statusFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ROLE_FILTER_PREFIX))
                      .ifPresent(
                          r -> {
                            roleFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ORG_NAME_FILTER_PREFIX))
                      .ifPresent(
                          r -> {
                            orgNameFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ORG_ID_FILTER_PREFIX))
                      .ifPresent(
                          r -> {
                            orgIdFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.COUNTRY_CODE_FILTER_PREFIX))
                      .ifPresent(
                          r -> {
                            countryCodeFilters.add(afilterBy.split("\\.")[1]);
                          });
                });
        filterMap.put(Constants.STATUS, statusFilters);
        filterMap.put(Constants.ROLE, roleFilters);
        filterMap.put(Constants.ORG_NAME, orgNameFilters);
        filterMap.put(Constants.ORG_ID, orgIdFilters);
        filterMap.put(Constants.COUNTRY_CODE, countryCodeFilters);
        return filterMap;
      }
    };
  }
}
