package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MenuInfoDTO {

  private int menuId;
  private String menuKey;
  private int menuSequence;
  private boolean isVisible;
  private boolean isMandatory;
  private String iconUriImage;
  private String toolTip;
  private String tag;
  private int menuGroupId;
  private String menuGroupName;
  private int minCount;
  private int maxCount;
}
