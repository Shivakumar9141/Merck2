package com.merck.nextconnect.userhub.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuditLogger {

  private static Logger logger = LoggerFactory.getLogger("AUDIT");

  private static AuditLogger INSTANCE = new AuditLogger();

  private AuditLogger() {}

  public static AuditLogger getInstance() {
    return INSTANCE;
  }

  public void auditLog(String message) {
    logger.error(message);
  }
}
