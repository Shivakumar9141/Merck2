package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.entities.UIOutputDisplay;
import com.merck.nextconnect.userhub.resources.IUIOutputDisplay;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UIOutputDisplayController {

  @Autowired IUIOutputDisplay uiOutputDisplay;

  @Operation(description = "Output display per page dropdown values", tags = "UI Output display")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/outputDisplay")
  public ResponseEntity<List<UIOutputDisplay>> getDates() {
    return new ResponseEntity<>(uiOutputDisplay.getAll(), HttpStatus.OK);
  }
}
