package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserCredentials;
import com.merck.nextconnect.userhub.entities.UserProfile;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * interface talks with UserCredentials table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface UserCredentialsRepository extends JpaRepository<UserCredentials, Long> {

  @Query("select u.credentialId from UserCredentials u where " + "u.userProfile.userId = :id")
  long findUserRecord(@Param("id") long id);

  @Query(
      "from UserCredentials u where "
          + "lower(u.userProfile.loginName) = lower(:loginName) and u.userProfile.userDomain.authenticationProvider = :authProvider and u.userProfile.deleted=false and u.status in ('ACTIVE','LOCKED')")
  UserCredentials getUserCredentials(
      @Param("loginName") String loginName, @Param("authProvider") String authProvider);

  @Transactional
  @Modifying
  @Query("UPDATE UserCredentials u set u.status = 'INACTIVE' where u.userProfile.userId = :id")
  int deactivateCredentials(@Param("id") long id);

  @Query(
      "select u.passwordHash from UserCredentials u where u.userProfile.userId = :userId order by u.createdTime desc")
  List<String> getPasswordHashes(@Param("userId") long userId, Pageable pageable);

  @Modifying
  @Transactional
  long deleteByUserProfile(@Param("userProfile") UserProfile userProfile);

  @Transactional
  @Modifying
  @Query("UPDATE UserCredentials u set u.status = 'LOCKED' where u.credentialId = :credentialId")
  int lockUserAccount(@Param("credentialId") long credentialId);
}
