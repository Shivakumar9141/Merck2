package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.OrgPrivileges;
import com.merck.nextconnect.userhub.model.privilege.OrgPrivilege;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgPrivilegesRepository extends JpaRepository<OrgPrivileges, Integer> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.privilege.OrgPrivilege(r.privilege.privilegeId,r.privilege.operation,r.org.id,r.privilege.resourceType)"
          + " from OrgPrivileges r  where r.org.id = :orgId")
  List<OrgPrivilege> getPrivileges(@Param("orgId") int orgId);
}
