/** */
package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

/**
 * @author hshrivas
 */
public class FailedDependencyException extends CustomException {

  private static final long serialVersionUID = 1L;

  public FailedDependencyException(String msg) {
    super(msg);
  }

  public FailedDependencyException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes);
  }

  public FailedDependencyException(CustomErrorCodes customErrorCodes, List<String> params) {
    super(customErrorCodes, params);
  }
}
