package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.resources.UserFeedBackChartService;
import com.merck.nextconnect.utils.common.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/feedback/chart")
public class UserFeedbackChartController {

  @Autowired private UserFeedBackChartService userFeedBackChartService;

  @Operation(
      summary = "get user feed back trend ",
      tags = "User Experience FeedBack",
      description = "This API is used to get the user feeb back trend ")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Creates the notification"),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_400,
            description = "Bad request. Please check the fields."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_422,
            description = "Validation Exception"),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_424,
            description = "Failed dependency"),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Error Occurred.")
      })
  @GetMapping("/feedbacktrend")
  @PreAuthorize("hasAuthority('view_feedbacktrend')")
  ResponseEntity<?> getUserFeedBackTrend(
      @Parameter(name = "duration", description = "duration in months 3,6,9,12")
          @RequestParam(value = "duration", required = true)
          long duration) {

    return ResponseEntity.ok(userFeedBackChartService.getUserFeedBackTrend(duration));
  }

  @Operation(
      summary = "get user feed back trend ",
      tags = "User Experience FeedBack",
      description = "This API is used to get the user feeb back trend ")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Creates the notification"),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_400,
            description = "Bad request. Please check the fields."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_422,
            description = "Validation Exception"),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_424,
            description = "Failed dependency"),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Error Occurred.")
      })
  @GetMapping("/ratingtrend")
  @PreAuthorize("hasAuthority('view_feedbacktrend')")
  ResponseEntity<?> getUserRatingTrend(
      @Parameter(name = "duration", description = "duartion in months 3,6,9,12")
          @RequestParam(value = "duration", required = true)
          long duration) {

    return ResponseEntity.ok(userFeedBackChartService.getUserRatingTrend(duration));
  }
}
