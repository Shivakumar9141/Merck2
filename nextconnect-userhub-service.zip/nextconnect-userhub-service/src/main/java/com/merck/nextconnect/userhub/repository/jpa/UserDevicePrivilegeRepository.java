package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.UserDevicePrivilege;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDevicePrivilegeRepository extends JpaRepository<UserDevicePrivilege, Long> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.privilege.Privileges(u.privilege.privilegeId,u.privilege.operation,u.device.deviceId,u.privilege.resourceType)"
          + " from UserDevicePrivilege u  where u.user.userId = :userId")
  List<Privileges> getPrivileges(@Param("userId") long userId);

  @Modifying
  @Transactional
  long deleteByUserAndPrivilegeAndDevice(UserProfile user, Privilege privilege, Device device);

  @Query("select udp.device.deviceId from UserDevicePrivilege udp where udp.user.userId = :userId")
  List<Long> getDeviceIdsFromUserId(@Param("userId") long userId);
}
