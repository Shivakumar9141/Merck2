package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.LegalTermsMapping;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LegalTermsRepository extends JpaRepository<LegalTermsMapping, Long> {

  public Optional<List<LegalTermsMapping>> findByCountryCodeAndLanguageCodeAndBusinessUnitId(
      String countryCode, String languageCode, int businessUnitId);

  /**
   * @param countryCode
   * @param languageCode
   * @param id
   * @param type
   * @param referenceName
   * @param referenceValue
   * @return LegalTermsMapping
   */
  public Optional<LegalTermsMapping>
      findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
          String countryCode,
          String languageCode,
          int businessUnitId,
          String type,
          String referenceName,
          String referenceValue);
}
