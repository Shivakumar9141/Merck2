package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class UserFeedBackRatingsDTO {

  private Integer ratings;
  private Integer count;
  private Integer totalUserCount;
}
