package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.EmailSubscriptionValidationDTO;
import com.merck.nextconnect.userhub.model.InvalidEmailsDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Component;

@Component
public interface IUserSubscription {

  public static final String SERVICE_VISIT_REMINDER = "Service visit reminder";

  public boolean save(UserSubscriptionDTO userSubscriptionDTO, Long userId) throws CustomException;

  public InvalidEmailsDTO validateEmails(EmailSubscriptionValidationDTO emails)
      throws CustomException;

  public UserSubscriptionDTO fetchAllUserSubscription(Long userId) throws CustomException;

  public UserSubscriptionDTO fetchAllUserSubscriptionByUser(Long userId) throws CustomException;

  public void sendOTP(long userId, String isdCode, String phoneNumber)
      throws DataValidationException,
          CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException;

  public void validateOTP(long userId, String isdCode, String phoneNumber, String otp)
      throws DataValidationException,
          CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException;

  public static void reminderDaysValidation(SubscriptionTypeDTO subscriptionTypeDTO)
      throws DataValidationException {
    if (subscriptionTypeDTO.getSubscriptionCategories().stream()
        .filter(
            categoryDTO ->
                categoryDTO.isStatus() == true
                    && (categoryDTO.getNumberOfDaysAdvance() < 0
                        || categoryDTO.getNumberOfDaysAdvance() > 30))
        .findAny()
        .isPresent()) throw new DataValidationException(CustomErrorCodes.INVALID_DAYS);
  }

  public Pair<String, String> getUserPhoneAndEmail(long userId)
      throws DataValidationException, CustomException;
}
