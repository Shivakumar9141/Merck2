package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.resources.ICountry;
import com.merck.nextconnect.userhub.resources.ISelfRegistrationService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.common.repository.jpa.RoleOfInterestRepository;
import com.merck.nextconnect.utils.exception.CustomSMException;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.exception.FailedDependencyException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpClientErrorException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpServerErrorException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import javax.naming.AuthenticationException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author SHATHWAR Self registration controller. Made changes as per NCIOT-12313
 */
@Component
@RestController
@RequestMapping("/api/self-registration")
public class SelfRegistrationController {

  static final Logger LOGGER = LoggerFactory.getLogger(SelfRegistrationController.class);

  @Autowired private ISelfRegistrationService selfRegistrationService;

  @Autowired private ICountry iCountry;

  @Autowired private RoleOfInterestRepository roleOfInterestRepository;

  @Autowired private OrganizationRepository organizationRepository;

  @Operation(
      summary = "Self registration of user",
      tags = "Self Registration",
      description = "This API is used for self registration of the user.")
  @PostMapping
  public ResponseEntity<Boolean> selfRegistration(
      @Parameter(
              name = "SelfRegistrationDTO",
              description = "SelfRegistrationDTO",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          SelfRegistrationDTO selfRegistrationDTO,
      HttpServletRequest request)
      throws CustomException,
          DataValidationException,
          AuthenticationException,
          MessagingException,
          EmailException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          JSONException,
          FailedDependencyException,
          ParseException {
    return new ResponseEntity<>(
        selfRegistrationService.selfRegistration(selfRegistrationDTO, request.getSession().getId()),
        HttpStatus.OK);
  }

  @Operation(description = "get countries", tags = "Self Registration")
  @GetMapping("/countries")
  public ResponseEntity<List<Country>> getCountries() {
    return new ResponseEntity<>(iCountry.getCountries(Constants.EMPTY_STRING), HttpStatus.OK);
  }

  @Operation(description = "get role of interest", tags = "Self Registration")
  @GetMapping("/role-of-interest")
  public ResponseEntity<List<RoleOfInterest>> getRoleOfInterest(
      @Parameter(
              name = "businessUnitId",
              description = "business unit id",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "businessUnitId", required = true)
          int businessUnitId) {
    return new ResponseEntity<>(
        roleOfInterestRepository.findByBusinessUnit(businessUnitId), HttpStatus.OK);
  }

  @Operation(description = "get role of interest", tags = "Self Registration")
  @GetMapping("/labwater/role-of-interest")
  public ResponseEntity<List<RoleOfInterest>> getRoleOfInterestForLabwater() {

    return getRoleOfInterest(organizationRepository.findIdByName(Constants.LABWATER));
  }

  @Operation(
      summary = "Validation of the self registered user",
      tags = "Self Registration",
      description = "This API is used for validating the self registrated user.")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @PutMapping("/validate")
  @PreAuthorize("hasAnyAuthority('validate_selfregistereduser')")
  public ResponseEntity<?> validateSelfRegisteredUser(
      @Parameter(name = "userId", description = "userId", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "userId", required = true)
          long userId,
      @Parameter(name = "isValid", description = "isValid", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "isValid", required = true)
          boolean isValid)
      throws DataValidationException, ResourceNotFoundException, EmailException {
    selfRegistrationService.validateSelfRegisteredUser(userId, isValid);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Operation(
      summary = "Self registration of user",
      tags = "Self Registration",
      description = "This API is used for self registration of the user.")
  @PostMapping("/self-registration-validation")
  public ResponseEntity<List<RoleOfInterest>> selfRegistrationValidation(
      @Parameter(
              name = "SelfRegistrationDTO",
              description = "SelfRegistrationDTO",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          SelfRegistrationDTO selfRegistrationDTO,
      HttpServletRequest request)
      throws CustomException,
          DataValidationException,
          AuthenticationException,
          MessagingException,
          EmailException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          JSONException,
          FailedDependencyException,
          ParseException {
    return new ResponseEntity<>(
        selfRegistrationService.selfRegistrationValidation(
            selfRegistrationDTO, request.getSession().getId()),
        HttpStatus.OK);
  }
}
