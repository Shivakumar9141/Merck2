package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "NC_ROLES_DEVICE_GROUP_PRIVILEGES")
public class RoleDeviceGroupPrivilege {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @ManyToOne
  @JoinColumn(name = "ROLE_ID")
  private Role role;

  @ManyToOne
  @JoinColumn(name = "PRIVILEGE_ID")
  private Privilege privilege;

  // need to change to device group
  @ManyToOne
  @JoinColumn(name = "CUSTOMER_ID")
  private Customer customer;

  @ManyToOne
  @JoinColumn(name = "location_id")
  private DeviceLocation deviceLocation;

  private Long deviceTypeId;

  public RoleDeviceGroupPrivilege() {}

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public Role getRole() {
    return role;
  }

  public void setRole(Role role) {
    this.role = role;
  }

  public Privilege getPrivilege() {
    return privilege;
  }

  public void setPrivilege(Privilege privilege) {
    this.privilege = privilege;
  }

  public Customer getCustomer() {
    return customer;
  }

  public void setCustomer(Customer customer) {
    this.customer = customer;
  }

  public DeviceLocation getDeviceLocation() {
    return deviceLocation;
  }

  public void setDeviceLocation(DeviceLocation deviceLocation) {
    this.deviceLocation = deviceLocation;
  }

  public long getDeviceTypeId() {
    return deviceTypeId;
  }

  public void setDeviceTypeId(long deviceTypeId) {
    this.deviceTypeId = deviceTypeId;
  }
}
