package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UsersListingFacets;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.model.UserProfileImageDTO;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.user.Credentials;
import com.merck.nextconnect.userhub.model.user.ResetCredential;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.model.user.UserList;
import com.merck.nextconnect.userhub.model.user.UserPatch;
import com.merck.nextconnect.userhub.response.UserProfileResponseEntity;
import com.merck.nextconnect.utils.exception.EmailException;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import java.util.List;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

/**
 * interface to perform user operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface IUser {

  /**
   * add a user
   *
   * @param userDetails - userDetails
   * @return UserProfile
   * @throws DuplicateResourceException
   * @throws DataValidationException
   * @throws MessagingException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws com.merck.nextconnect.userhub.exception.AccessDeniedException
   */
  UserProfile add(UserDetails userDetails)
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          com.merck.nextconnect.userhub.exception.AccessDeniedException;

  /**
   * delete a user
   *
   * @param userId - id of the user
   * @throws ResourceNotFoundException
   */
  void delete(long userId) throws ResourceNotFoundException, CustomException;

  /**
   * get all users
   *
   * @return UserList
   */
  UserList getAll(FetchCriteria fetchCriteria);

  /**
   * get all users facets
   *
   * @return UsersListingFacets
   */
  UsersListingFacets getUserListingFacets();

  /**
   * update a user
   *
   * @param user - user (userName,userDesc)
   * @return userId
   * @throws DataValidationException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   */
  void update(long userId, UserDetails userDetails)
      throws DataValidationException,
          CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.CustomException;

  /**
   * get a user
   *
   * @param userId - id of the user
   * @return UserProfile
   */
  UserProfile fetchOne(long userId);

  /**
   * reset user credentials
   *
   * @param userCredentials - user credentials
   * @param userId - id of the user
   * @return userCredentials - new credentials
   * @throws DataValidationException
   * @throws ResourceNotFoundException
   */
  void resetCredentials(Credentials userCredentials, long userId)
      throws DataValidationException, ResourceNotFoundException;

  /**
   * generate token for password update
   *
   * @param email - email of the user
   * @param userId - id of the user
   * @return token - password update token
   */
  String generateToken(long userId);

  void updateStatusAndRole(long userId, UserPatch userPatch)
      throws ResourceNotFoundException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException;

  void triggerPasswordReset(String email)
      throws ResourceNotFoundException,
          DataValidationException,
          AddressException,
          MessagingException,
          CustomException;

  /**
   * validates nextconnect user's password
   *
   * @param credential - credential
   * @param userId - user id
   * @throws DataValidationException
   */
  void validatePassword(ResetCredential credential, long userId)
      throws AccessDeniedException, DataValidationException;

  /**
   * invite user by sending email invite
   *
   * @param userId - user id
   * @throws ResourceNotFoundException
   * @throws DataValidationException
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  void inviteUser(long userId)
      throws ResourceNotFoundException,
          DataValidationException,
          AddressException,
          MessagingException,
          CustomException;

  public void validateConsent(UserDetails userDetails) throws DataValidationException;

  List<Privileges> getPrivileges(long userId, String filterBy) throws ResourceNotFoundException;

  void addPrivileges(long userId, List<ResourcePrivilege> resourcePrivileges)
      throws ResourceNotFoundException;

  void deletePrivileges(long userId, List<ResourcePrivilege> resourcePrivileges)
      throws ResourceNotFoundException;

  public UserProfile findByEmailAndStatus(String email, String status);

  public List<String> searchMailId(String mailId);

  public boolean validateMailId(String mailId)
      throws DataValidationException, DuplicateResourceException;

  /**
   * Unsubscribe a user
   *
   * @param userId
   * @return void
   * @throws DataValidationException
   * @throws EmailException
   * @throws CustomException
   */
  void unSubscribe(long userId, int orgId, long roleId, String environment)
      throws DataValidationException, EmailException, CustomException;

  /**
   * Changes made as per NCIOT-11740.
   *
   * @param emailId
   * @throws MessagingException
   * @throws CustomException
   */
  void inviteUserFromServiceMax(String emailId) throws MessagingException, CustomException;

  /**
   * @param userProfile
   * @throws CustomException
   */
  public void deleteUser(UserProfile userProfile) throws CustomException;

  /**
   * This method fetches the User Profile Image
   *
   * @param userId
   * @return UserProfileImageDTO
   * @throws DataValidationException
   * @throws CustomException
   */
  public UserProfileImageDTO fetchImage(long userId)
      throws DataValidationException, CustomException;

  /**
   * This method deletes user profile image
   *
   * @param userId
   * @throws DataValidationException
   * @throws CustomException
   */
  public void deleteImage(long userId) throws DataValidationException, CustomException;

  /**
   * get a user
   *
   * @param userId - id of the user
   * @return UserProfileResponseEntity
   */
  UserProfileResponseEntity fetchOneUser(long userId);

  public String fetchUserType(Integer userId) throws CustomException;
}
