package com.merck.nextconnect.userhub.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserFeedBackFacets {

  private List<String> roles;
  private List<Integer> rating;
  private List<String> cusorg;
  private List<String> countryCode;
}
