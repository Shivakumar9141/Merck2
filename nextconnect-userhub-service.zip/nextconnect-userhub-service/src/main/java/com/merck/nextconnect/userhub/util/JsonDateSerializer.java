package com.merck.nextconnect.userhub.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JsonDateSerializer extends JsonSerializer<Timestamp> {

  static final Logger logger = LoggerFactory.getLogger(JsonDateSerializer.class);

  @Override
  public void serialize(Timestamp value, JsonGenerator gen, SerializerProvider provider) {
    DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
    String formattedDate = dateFormatter.format(value);
    try {
      gen.writeString(formattedDate);
    } catch (IOException e) {
      logger.error("error in parsing", e);
    }
  }
}
