package com.merck.nextconnect.userhub.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author clukose
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserRatingTrend {

  // average rating
  private List<DataModel> ratings;

  private List<DataModel> Duration;

  // users who has given ratings
  private List<DataModel> users;

  // total no of users
  private List<DataModel> totalUsers;
}
