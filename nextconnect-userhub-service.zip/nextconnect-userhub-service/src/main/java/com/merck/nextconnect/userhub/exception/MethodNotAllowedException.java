package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

public class MethodNotAllowedException extends CustomException {

  private static final long serialVersionUID = 1L;

  public MethodNotAllowedException(String msg) {
    super(msg);
  }

  public MethodNotAllowedException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes);
  }

  public MethodNotAllowedException(CustomErrorCodes customErrorCodes, List<String> params) {
    super(customErrorCodes, params);
  }
}
