package com.merck.nextconnect.userhub.model.privilege;

import java.util.List;

public class DeviceGroupPrivilege {

  private long privilegeId;
  private List<Location> locations;

  public long getPrivilegeId() {
    return privilegeId;
  }

  public void setPrivilegeId(long privilegeId) {
    this.privilegeId = privilegeId;
  }

  public List<Location> getLocations() {
    return locations;
  }

  public void setLocations(List<Location> location) {
    this.locations = location;
  }
}
