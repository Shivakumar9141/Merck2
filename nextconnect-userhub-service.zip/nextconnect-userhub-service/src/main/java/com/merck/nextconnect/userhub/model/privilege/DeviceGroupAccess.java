package com.merck.nextconnect.userhub.model.privilege;

public class DeviceGroupAccess {

  private long resourceId;
  private long privilegeId;
  private long locationId;
  private long deviceGroupId;

  public long getResourceId() {
    return resourceId;
  }

  public void setResourceId(long resourceId) {
    this.resourceId = resourceId;
  }

  public long getPrivilegeId() {
    return privilegeId;
  }

  public void setPrivilegeId(long privilegeId) {
    this.privilegeId = privilegeId;
  }

  public long getLocationId() {
    return locationId;
  }

  public void setLocationId(long locationId) {
    this.locationId = locationId;
  }

  public long getDeviceGroupId() {
    return deviceGroupId;
  }

  public void setDeviceGroupId(long deviceGroupId) {
    this.deviceGroupId = deviceGroupId;
  }
}
