package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Device;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long> {

  /**
   * change for NCIOT-10694, NCIOT-10688 -- sending mail and sms notification on device assignment
   * -- fetching device details.
   */
  @Query("select d from Device d where d.deviceId = :deviceId and d.deleted = false")
  Optional<Device> findDeviceByDeviceId(@Param("deviceId") long deviceId);

  /**
   * Changes made as per NCIOT-11630.
   *
   * @param email
   * @return List<Device>
   */
  List<Device> findDeviceIdByEmailIdAndSoldToAndBillToAndDeletedAndStatus(
      String email, String soldTo, String billTo, boolean isDeleted, boolean status);

  List<Device> findByDeviceIdInAndDeletedAndStatus(
      List<Long> deviceIds, boolean isDeleted, boolean status);

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param serialNumber
   * @param status
   * @param isDeleted
   * @return Device
   */
  Device findBySerialnoAndStatusAndDeleted(String serialNumber, boolean status, boolean isDeleted);

  /**
   * @param deviceId
   * @param status
   * @param isDeleted
   * @return Device
   */
  Device findByDeviceIdAndStatusAndDeleted(long deviceId, boolean status, boolean isDeleted);
}
