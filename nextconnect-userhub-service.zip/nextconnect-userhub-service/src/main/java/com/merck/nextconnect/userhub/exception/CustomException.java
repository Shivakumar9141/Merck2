package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

public class CustomException extends Exception {

  private static final long serialVersionUID = 1L;

  private String errorCode;

  public CustomException(String msg) {
    super(msg);
  }

  public CustomException(CustomErrorCodes customErrorCode) {
    super(customErrorCode.getDescription());
    this.errorCode = customErrorCode.getErrorCode();
  }

  public CustomException(CustomErrorCodes customErrorCode, List<String> params) {
    super(CustomErrorCodes.getFormattedMessage(customErrorCode, params));
    this.errorCode = customErrorCode.getErrorCode();
  }

  public String getErrorCode() {
    return errorCode;
  }
}
