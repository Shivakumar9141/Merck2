package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Privilege;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * interface talks with Privilege table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal</a>
 */
@Component
public interface PrivilegeRepository extends JpaRepository<Privilege, Long> {

  @Query("from Privilege p where " + "p.resourceType = :filterBy")
  List<Privilege> getByFilter(@Param("filterBy") String filterBy);
}
