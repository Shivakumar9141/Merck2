package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "nc_user_subscription")
public class UserSubscription implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "user_subscription_id")
  private Long userSubscriptionId;

  @OneToOne
  @JoinColumn(name = "user_id")
  private UserProfile userProfile;

  @OneToOne
  @JoinColumn(name = "subscription_catagory_id")
  private SubscriptionCategory subscriptionCategory;

  @ManyToOne
  @JoinColumn(name = "subscription_type_id")
  private SubscriptionType subscriptionType;

  @Column(name = "isd_code")
  private String isdCode;

  @Column(name = "phone")
  private String phone;

  @Column(name = "email_address")
  private String email;

  @Column(name = "status")
  private boolean status;

  @Column(name = "number_of_days_advance")
  private int numberOfDaysAdvance;

  @Column(name = "custom_message")
  private String customMessage;

  @Column(name = "created_ts")
  private Timestamp createdTimestamp;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "last_updated_by")
  private String lastUpdatedBy;

  @Column(name = "last_updated_ts")
  private Timestamp lastUpdatedTimestamp;

  private boolean deleted;
  private String deletedBy;
}
