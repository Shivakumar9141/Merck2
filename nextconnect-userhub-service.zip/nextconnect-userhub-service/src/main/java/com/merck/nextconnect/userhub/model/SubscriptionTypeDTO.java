package com.merck.nextconnect.userhub.model;

import java.io.Serializable;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubscriptionTypeDTO implements Serializable {

  private static final long serialVersionUID = 1L;

  private Long subscriptionTypeId;

  private String subscriptionTypeName;

  private String isdCode;

  private String phones;

  private Set<SubscriptionCategoryDTO> subscriptionCategories;

  @Override
  public String toString() {
    return "SubscriptionTypeDTO [subscriptionTypeId="
        + subscriptionTypeId
        + ", subscriptionTypeName="
        + subscriptionTypeName
        + ", isdCode="
        + isdCode
        + ", phones="
        + phones
        + ", subscriptionCategories="
        + subscriptionCategories
        + "]";
  }
}
