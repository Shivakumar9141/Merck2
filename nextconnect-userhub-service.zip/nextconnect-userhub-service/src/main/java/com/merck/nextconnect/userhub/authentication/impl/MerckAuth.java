package com.merck.nextconnect.userhub.authentication.impl;

import com.merck.nextconnect.userhub.authentication.IAuthRepository;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.util.Constants;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MerckAuth implements IAuthRepository {

  static final Logger logger = LoggerFactory.getLogger(MerckAuth.class);

  @Value("${merck.globalLdap.url}")
  private String globalAuthUrl;

  @Value("${merck.DNAPLdap.url}")
  private String dnapAuthUrl;

  @Value("${merck.DNEULdap.url}")
  private String dneuAuthUrl;

  @Value("${merck.DNLALdap.url}")
  private String dnlaAuthUrl;

  @Value("${merck.DNNALdap.url}")
  private String dnnaAuthUrl;

  @Override
  public boolean authenticate(Login login) {
    String loginName = login.getUserdomain() + "\\" + login.getUsername();
    LdapContext ctx = null;
    try {
      Hashtable<String, String> env = new Hashtable<String, String>();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
      env.put(Context.SECURITY_AUTHENTICATION, "Simple");
      env.put(Context.SECURITY_PRINCIPAL, loginName);
      env.put(Context.SECURITY_CREDENTIALS, login.getPassword());
      env.put(Context.PROVIDER_URL, getProviderUrl(login.getUserdomain()));
      ctx = new InitialLdapContext(env, null);
      logger.info("Connection Successful.");
      return true;
    } catch (NamingException nex) {
      logger.error("connection failed" + nex.getMessage());
      return false;
    } catch (Exception e) {
      logger.error("failed to authenticate" + e.getMessage());
      return false;
    }
  }

  private String getProviderUrl(String domain) {
    switch (domain) {
      case Constants.MERCK_GLOBAL:
        return globalAuthUrl;

      case Constants.MERCK_DNAP:
        return dnapAuthUrl;

      case Constants.MERCK_DNEU:
        return dneuAuthUrl;

      case Constants.MERCK_DNLA:
        return dnlaAuthUrl;

      case Constants.MERCK_DNNA:
        return dnnaAuthUrl;
      default:
        return null;
    }
  }
}
