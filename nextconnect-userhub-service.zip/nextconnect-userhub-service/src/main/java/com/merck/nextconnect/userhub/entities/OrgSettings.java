package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "NC_ORG_SETTINGS")
public class OrgSettings {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  @OneToOne
  @JoinColumn(name = "ORG_ID")
  private Organization org;

  private String logo;

  private String theme;

  private String appName;

  private Long historicalDataSubscription;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public Organization getOrg() {
    return org;
  }

  public void setOrg(Organization org) {
    this.org = org;
  }

  public String getLogo() {
    return logo;
  }

  public void setLogo(String logo) {
    this.logo = logo;
  }

  public String getTheme() {
    return theme;
  }

  public void setTheme(String theme) {
    this.theme = theme;
  }

  public String getAppName() {
    return appName;
  }

  public void setAppName(String appName) {
    this.appName = appName;
  }

  public void setHistoricalDataSubscription(Long historicalDataSubscription) {
    this.historicalDataSubscription = historicalDataSubscription;
  }

  public Long getHistoricalDataSubscription() {
    return historicalDataSubscription;
  }
}
