package com.merck.nextconnect.userhub.util;

import java.text.MessageFormat;
import java.util.List;

public enum CustomErrorCodes {
  ROLE_NAME_CONFLICT("ROLE_NAME_CONFLICT", "Conflict in role name"),
  USER_LOGIN_NAME_CONFLICT("USER_NAME_CONFLICT", "{0} is already existing in the application"),
  USER_EMAIL_CONFLICT("USER_EMAIL_CONFLICT", "{0} is already existing in the application"),
  USER_NOT_FOUND("USER_NOT_FOUND", "user not found"),
  INVALID_DOMAIN("INVALID_DOMAIN", "incorrect domain"),
  USER_NAME_INVALID("USER_NAME_INVALID", "Invalid user name"), // NCIOT-13711
  EMAIL_SENDING_ERROR("EMAIL_SENDING_ERROR", "failed to send email"),
  INVALID_ROLE_SPECIFIED("INVALID_ROLE_SPECIFIED", "role specified is not valid"),
  USER_FIRSTNAME_INVALID("USER_FIRSTNAME_INVALID", "invalid first name"),
  USER_LASTNAME_INVALID("USER_LASTNAME_INVALID", "invalid last name"),
  DUPLICATE_ROLE("DUPLICATE_ROLE", "{0} is already existing in the application"),
  ROLE_NOT_FOUND("ROLE_NOT_FOUND", "role not found"),
  ROLE_VALIDATION_ERROR("ROLE_VALIDATION_ERROR", "invalid role name"),
  EMAIL_SUBSCRIPTION_ERROR(
      "EMAIL_SUBSCRIPTION_ERROR", " error in creating or retrieving email/phone subscription data"),
  DUPLICATE_ORG("DUPLICATE_ORG", "{0} is already existing in the application"),
  ORG_NOT_FOUND("ORG_NOT_FOUND", "Org not found"),
  EMPTY_ORG_NAME("EMPTY_ORG_NAME", "Org name cannot be empty"),
  LAST_USER_IN_SYSTEM_DEFINED_ROLE(
      "LAST_USER_IN_SYSTEM_DEFINED_ROLE",
      "Currently you are the only user, please assign another user to this role and then unsubscribe from the platform"),
  ORG_NAME_VALIDATION_ERROR("ORG_NAME_VALIDATION_ERROR", "validation failed for org name"),
  ORG_DESC_VALIDATION_ERROR("ORG_DESC_VALIDATION_ERROR", "validation failed for org desc"),
  INTERNAL_SERVER_ERROR(
      "INTERNAL_SERVER_ERROR",
      "The server encountered an unexpected condition that prevented it from fulfilling the request."),
  INVALID_DAYS("INVALID_NUMBER_OF_DAYS", "Invalid number of days entered"),
  INVALID_MOBILE("INVALID_MOBILE", "Invalid mobile number"),
  INVALID_COUNTRY("INVALID_COUNTRY", "Invalid country"),
  INVALID_NUMBER_FORMAT(
      "INVALID_NUMBER_FORMAT",
      "The mobile number entered is not valid, please correct and try again"),
  INVALID_NUMBER_LENGTH(
      "INVALID_NUMBER_LENGTH",
      "The number of characters in the mobile number should be more than 10 and less than 31"),
  PHONE_NUMBER_ALREADY_VALIDATED(
      "PHONE_NUMBER_ALREADY_VALIDATED", "The phone number entered is already validated"),
  INVALID_OTP("INVALID_OTP", "Invalid Otp Entered"),
  PHONE_NUMBER_NOT_EXIST("PHONE_NUMBER_NOT_EXIST", "The phone number entered doesn't exists"),
  OTP_EXPIRED("OTP_EXPIRED", "OTP is expired. Send the OTP again"),
  PHONE_NUMBER_NOT_VALIDATED("PHONE_NUMBER_NOT_VALIDATED", "Phone number entered is not validated"),
  CANNOT_SEND_SMS("CANNOT_SEND_SMS", "SMS cannot be sent, please contact the administrator"),
  USERS_EXIST_IN_ORG(
      "USERS_EXIST_IN_ORG",
      "The selected organization already have users who having Active/Pending/Inactive/In-Progress status. Please delete the users and try again"),
  CHILDERN_EXIST_FOR_ORG(
      "CHILDERN_EXISTS_FOR_ORG",
      "The selected organization have child orgs. Please delete child orgs and try again"),
  SESSION_EXPIRED("SESSION_EXPIRED", "User session has expired."),
  LEGAL_POLICY_NOT_FOUND("NOT_FOUND", "Legal policy not found."),
  BUSINESS_UNIT_NOT_FOUND("BUSINESS_UNIT_NOT_FOUND", "Business unit not found"),
  INVALID_COUNTRY_CODE("INVALID_COUNTRY_CODE", "Country code not found"),
  INVALID_POLICY_TYPE("INVALID_POLICY_TYPE", "Invalid policy type"),
  ORG_ID_SHOULD_NOT_BE_NULL("ORG_ID_SHOULD_NOT_BE_NULL", "Org ID cannot be null"),
  LEGAL_POLICY_NOT_FOUND_FOR_BUSINESS_UNIT(
      "LEGAL_POLICY_NOT_FOUND_FOR_BUSINESS_UNIT", "No legal policy for the business unit"),
  PASSWORD_EXPIRED("PASSWORD_EXPIRED", "User's account got expired."),
  USER_ACCOUNT_LOCKED(
      "USER_ACCOUNT_LOCKED", "Your account is locked.please reset the password to login."),
  PASSWORD_EXISTS("PASSWORD_EXISTS", "Cannot choose already existing password."),
  INVALID_HISTORICAL_DATA_SUBSCRIPTION_VALUE(
      "INVALID_HISTORICAL_DATA_SUBSCRIPTION_VALUE",
      "historical data subscription cannot be null or less than -1 for customer org"),
  USER_NOT_AUTO_CREATED("USER_NOT_AUTO_CREATED", "User is not auto created"),
  USER_STATUS_NOT_EXPIRED("USER_STATUS_NOT_EXPIRED", "User profile status is not expired"),
  USER_FEED_BACK_NOT_FOUND(
      "USER_FEED_BACK_NOT_FOUND", "Please provide the Feedback for better experience"),
  CUSTOMERS_FEED_BACK_EMPTY("CUSTOMERS_FEED_BACK_EMPTY", "Zero FeedBack"),
  CUSTOMER_ALREADY_GIVEN_FEEDBACK("CUSTOMER_ALREADY_GIVEN_FEEDBACK", "FeedBack already submitted"),
  INVALID_PARTNER_TYPE("INVALID_PARTNER_TYPE", "partner type not found"),
  INVALID_BRAND("INVALID_BRAND", "brand not found"),
  PARTNER_TYPE_FOR_BRAND_NOT_EXIST(
      "PARTNER_TYPE_FOR_BRAND_NOT_EXIST",
      "The specified partner type list is not associated with brand"),
  ORG_BRAND_NOT_EXIST(
      "ORG_BRAND_NOT_EXIST", "The specified organization is not associated with brand"),
  PARTNER_TYPE_CANNOT_BE_EMPTY(
      "PARTNER_TYPE_CANNOT_BE_EMPTY",
      "Please select at least one partner type associated with brand"),
  INVALID_BRAND_FOR_DEVICE_FAMILIES(
      "INVALID_BRAND_FOR_DEVICE_FAMILIES",
      "Invalid partner peripheral supplier specified for device family of the logged user"),
  ACCESS_DENIED_ORG_DEACTIVATED(
      "ACCESS_DENIED_ORG_DEACTIVATED",
      "Your Organization has been temporarily been deactivated. Please contact your MyMilli-Q™ Administrator"),
  ACCESS_DENIED_SELECTED_ORG_DEACTIVATED(
      "ACCESS_DENIED_SELECTED_ORG_DEACTIVATED",
      "The new user invites for the selected organization is temporarily been suspended. Please try after some time"),
  ACCESS_DENIED_SELECTED_USER_ORG_DEACTIVATED(
      "ACCESS_DENIED_SELECTED_USER_ORG_DEACTIVATED",
      "Selected user organization has been temporarily been deactivated"),
  ACCESS_DENIED_RESET_PASSWORD(
      "ACCESS_DENIED_RESET_PASSWORD", "Access is denied to reset the password"),
  ACCESS_DENIED_CANNOT_RESET_PASSWORD(
      "ACCESS_DENIED_CANNOT_RESET_PASSWORD", "cannot reset password"),
  ACCESS_DENIED_NOT_ACCEPTED_TERMS_AND_POLICY(
      "ACCESS_DENIED_NOT_ACCEPTED_TERMS_AND_POLICY",
      "User has to accept terms and policy by registering profile"),
  ACCESS_DENIED_ACCOUNT_BLOCKED(
      "ACCESS_DENIED_ACCOUNT_BLOCKED",
      "The account is temporarily blocked, please contact admin to unlock the account"),
  DEVICE_NOT_FOUND("DEVICE_NOT_FOUND", "This device doesn't exist in MyMilli-Q™"),
  INVALID_MENU_SEQUENCE("INVALID_MENU_SEQUENCE", "More than one menu item has same sequence "),
  ONLY_CUSTOMER_ADMIN_USER(
      "ONLY_CUSTOMER_ADMIN_USER",
      "A record cannot be deleted as the selected user is the only Customer Admin available in this Organization."),
  ONLY_PARTNER_ADMIN_USER(
      "ONLY_PARTNER_ADMIN_USER",
      "A record cannot be deleted as the selected user is the only Partner Admin available in this Organization."),
  ONLY_DISTRIBUTOR_ADMIN_USER(
      "ONLY_DISTRIBUTOR_ADMIN_USER",
      "A record cannot be deleted as the selected user is the only Distributor Admin available in this Organization."),
  DEVICES_ASSIGNED_TO_USER(
      "DEVICES_ASSIGNED_TO_USER",
      "A record cannot be deleted as the selected user has a device(s) assigned to it."),
  FORGOT_PASSWORD_FAILUE(
      "FORGOT_PASSWORD_FAILUE",
      "Password Reset link will be sent by email to the registered email address. In case you did not receive it, please check the entered email address or contact your Administrator."),
  ACCESS_DENIED_FOR_ORG_TYPE(
      "ACCESS_DENIED_FOR_ORG_TYPE", "User does not have access to delete the organization type"),
  ORG_PARENT_IS_DIFFERENT(
      "ORG_PARENT_IS_DIFFERENT", "Cannot delete this org since the parent org is different"),
  ACCESS_DENIED_FOR_AUTO_CREATED_ORG(
      "ACCESS_DENIED_FOR_AUTO_CREATED_ORG",
      "User does not have access to delete the auto created organization"),
  ACCESS_DENIED_TO_DELETE_ORG(
      "ACCESS_DENIED_TO_DELETE_ORG", "User does not have access to delete the organization"),
  APPLICATION_DOMAIN_IS_REQUIRED(
      "APPLICATION_DOMAIN_IS_REQUIRED ", "Application Domain is required"),
  USER_PROFILE_IMAGE_NOT_FOUND("USER_PROFILE_IMAGE_NOT_FOUND", "User profile image is not found"),
  USER_PROFILE_IMAGE_IS_REQUIRED(
      "USER_PROFILE_IMAGE_IS_REQUIRED", "User profile image is required"),
  UNAUTHORIZED_ACCESS("UNAUTHORIZED_ACCESS", "Unauthorized access"),
  ACCESS_DENIED_TO_DELETE_USER(
      "ACCESS_DENIED_TO_DELETE_USER", "User don’t have privilege to delete the user"),
  ACCESS_DENIED_TO_UPDATE_USER(
      "ACCESS_DENIED_TO_DELETE_USER", "User don’t have privilege to update the user"),
  EMAIL_OR_PHONE_NUMBER_CANNOT_BE_NULL(
      "EMAIL_OR_PHONE_NUMBER_CANNOT_BE_NULL", "Email or Phone number cannot be empty"),
  ACCESS_DENIED_TO_UPDATE_ORG(
      "ACCESS_DENIED_TO_UPDATE_ORG", "User does not have permission to update the organization");

  private final String errorCode;
  private final String description;

  CustomErrorCodes(String errorCode, String description) {
    this.errorCode = errorCode;
    this.description = description;
  }

  public String getErrorCode() {
    return this.errorCode;
  }

  public String getDescription() {
    return this.description;
  }

  public static String getFormattedMessage(CustomErrorCodes customErrorCode, List<String> params) {
    Object[] objArray = new Object[params.size()];
    for (int i = 0; i < params.size(); i++) {
      objArray[i] = params.get(i);
    }
    String message = MessageFormat.format(customErrorCode.getDescription(), objArray);
    return message;
  }
}
