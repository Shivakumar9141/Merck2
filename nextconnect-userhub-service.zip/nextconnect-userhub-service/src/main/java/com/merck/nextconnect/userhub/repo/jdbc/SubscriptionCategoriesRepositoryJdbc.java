package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.SubscriptionType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author msingh2
 *     <p>This class is for JDBC Template implementation to use native sql
 */
@Repository
public class SubscriptionCategoriesRepositoryJdbc {

  static final Logger LOGGER = LoggerFactory.getLogger(SubscriptionCategoriesRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  String SQL_SELECT_SUBSCRIPTION_CATEGORIES_MAPPING =
      "SELECT type.subscription_type_id, type.subscription_type_name, GROUP_CONCAT(CONCAT(category.category_name, ' - ', category.subscription_category_id)) AS category FROM  nc_role_subscription_categories_mapping AS map INNER JOIN nc_subscription_category AS category ON map.subscription_category_id = category.subscription_category_id INNER JOIN nc_subscription_type AS type ON category.subscription_type_id = type.subscription_type_id WHERE map.role_name = :roleName and map.org_created_by = :orgCreatedBy GROUP BY type.subscription_type_id , type.subscription_type_name ORDER BY category.subscription_type_id ASC";

  public List<SubscriptionType> getSubscriptionCategoriesMapping(
      String roleName, String orgCreatedBy) {
    List<SubscriptionType> subscriptionTypeDTOList = new ArrayList<SubscriptionType>();

    try {
      MapSqlParameterSource parameters = new MapSqlParameterSource();
      parameters.addValue("roleName", roleName);
      parameters.addValue("orgCreatedBy", orgCreatedBy);
      subscriptionTypeDTOList =
          namedParameterJdbcTemplate.query(
              SQL_SELECT_SUBSCRIPTION_CATEGORIES_MAPPING,
              parameters,
              (rs, rowNum) ->
                  SubscriptionType.builder()
                      .subscriptionTypeId(rs.getLong("type.subscription_type_id"))
                      .subscriptionTypeName(rs.getString("type.subscription_type_name"))
                      .subscriptionCategories(
                          createSubcriptionCategoryList(rs.getString("category")))
                      .build());
    } catch (Exception e) {
      LOGGER.error("Exception occured in SubscriptionCategoriesMapping while calling DB", e);
    }

    return subscriptionTypeDTOList;
  }

  /**
   * @param category
   * @return
   */
  private Set<SubscriptionCategory> createSubcriptionCategoryList(String category) {
    LOGGER.info("--> category value : " + category);
    Set<SubscriptionCategory> categoryDTO = new HashSet<>();
    if (StringUtils.isEmpty(category)) {
      return categoryDTO;
    }
    // first split based on ','
    List<String> result = Arrays.asList(category.split("\\s*,\\s*"));
    LOGGER.info("result value :" + result);

    // split based on ' - '
    for (String str : result) {
      SubscriptionCategory dto = new SubscriptionCategory();
      String[] splitByDash = str.split(" - ");

      dto.setCategoryName(splitByDash[0]);
      dto.setSubscriptionCategoryId(Long.parseLong(splitByDash[1]));
      categoryDTO.add(dto);
    }

    return categoryDTO;
  }
}
