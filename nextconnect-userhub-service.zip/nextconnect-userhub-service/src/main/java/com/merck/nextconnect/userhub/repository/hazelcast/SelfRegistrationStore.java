package com.merck.nextconnect.userhub.repository.hazelcast;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class will be a Object store to check with sessionId for self registration process.
 *
 * @author M290834
 */
@Component
public class SelfRegistrationStore {

  @Autowired private HazelcastInstance hazelcastInstance;
  public static final String SELF_REGISTRATION_MAP = "selfRegistrationMap";

  public void addSelfRegistrationMap(String sessionId, SelfRegistrationDTO selfRegistrationDTO) {
    IMap<String, SelfRegistrationDTO> selfRegistrationMap =
        hazelcastInstance.getMap(SELF_REGISTRATION_MAP);
    selfRegistrationMap.put(sessionId, selfRegistrationDTO);
  }

  public SelfRegistrationDTO getSelfRegistrationMap(String sessionId) {
    IMap<String, SelfRegistrationDTO> selfRegistrationMap =
        hazelcastInstance.getMap(SELF_REGISTRATION_MAP);
    return selfRegistrationMap.get(sessionId);
  }

  public void removeSelfRegistrationMap(String sessionId) {
    IMap<String, SelfRegistrationDTO> selfRegistrationMap =
        hazelcastInstance.getMap(SELF_REGISTRATION_MAP);
    selfRegistrationMap.remove(sessionId);
  }
}
