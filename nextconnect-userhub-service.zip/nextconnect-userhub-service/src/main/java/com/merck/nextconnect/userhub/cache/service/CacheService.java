package com.merck.nextconnect.userhub.cache.service;

import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public interface CacheService {

  String getMapValues(String mapName, Object resourceId);

  Map<String, String> getAllDistributedCacheValues();

  String clearCacheValues(String mapName, Object resourceId);

  Map<String, String> getConfigurationProperties();

  Map<String, String> getListOfMaps();

  void updateApplicationConfig(String key, String type, String value);
}
