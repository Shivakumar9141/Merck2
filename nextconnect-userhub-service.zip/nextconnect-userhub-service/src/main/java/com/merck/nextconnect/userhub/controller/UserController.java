package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.util.EntityPrivileges;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UsersListingFacets;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.model.HotlineUserType;
import com.merck.nextconnect.userhub.model.UserProfileImageDTO;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.user.Credentials;
import com.merck.nextconnect.userhub.model.user.ResetCredential;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.model.user.UserEmail;
import com.merck.nextconnect.userhub.model.user.UserList;
import com.merck.nextconnect.userhub.model.user.UserPatch;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.response.UserListResponseEntity;
import com.merck.nextconnect.userhub.response.UserProfileResponseEntity;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriTemplate;

@Component
@RestController
@RequestMapping("/api/users")
public class UserController {

  static final Logger logger = LoggerFactory.getLogger(UserController.class);

  @Autowired private IUser iuser;

  @Operation(description = "Fetch all users", tags = "Users")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET)
  @PreAuthorize(EntityPrivileges.READ_USER)
  public ResponseEntity<List<UserListResponseEntity>> getAllUsers(
      @Parameter(
              name = "sortBy",
              description = "Sort on a user attribute",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "sortBy", required = false)
          String sortBy,
      @Parameter(
              name = "orderBy",
              description = "Order by ascending/descending asc/desc",
              schema = @Schema(defaultValue = "asc"))
          @RequestParam(value = "orderBy", required = false)
          String orderBy,
      @Parameter(
              name = "filterBy",
              description = "List of filters",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          List<String> filterBy,
      @Parameter(
              name = "searchBy",
              description = "search category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy,
      @Parameter(name = "page", description = "page number", schema = @Schema(defaultValue = "1"))
          @RequestParam(value = "page", required = false)
          Integer page,
      @Parameter(
              name = "pageLimit",
              description = "per page limit",
              schema = @Schema(defaultValue = "20"))
          @RequestParam(value = "pageLimit", required = false)
          Integer pageLimit) {
    if (page == null) {
      page = 1;
    }
    if (pageLimit == null) {
      pageLimit = 20;
    }
    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    UserList userList = iuser.getAll(fetchCriteria);
    HttpHeaders headers = new HttpHeaders();
    headers.set("x-pagination-count", userList.getTotalPages());
    headers.set("x-record-count", String.valueOf(userList.getRecordCount()));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.GET, null));
    return new ResponseEntity<List<UserListResponseEntity>>(
        userList.getUsers(), headers, HttpStatus.OK);
  }

  @Operation(
      summary = "Get all users facets",
      tags = "Users",
      description = "This API is used to get users listing facets")
  @Parameter(
      name = "Authorization",
      description = "Authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/facets")
  @PreAuthorize(EntityPrivileges.READ_USER)
  public ResponseEntity<UsersListingFacets> getUsersFacets() throws Exception {
    UsersListingFacets usersListingFacets = iuser.getUserListingFacets();
    return new ResponseEntity<UsersListingFacets>(usersListingFacets, HttpStatus.OK);
  }

  @CrossOrigin
  @Operation(
      summary = "add a User",
      tags = "Users",
      description = "This API is used to create a new user")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST)
  @PreAuthorize(EntityPrivileges.CREATE_USER)
  public ResponseEntity<UserProfile> addUser(
      @Parameter(name = "user", description = "user details", schema = @Schema(defaultValue = ""))
          @RequestBody
          UserDetails userDetails)
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          AccessDeniedException {
    UserProfile user = iuser.add(userDetails);
    long userId = user.getUserId();
    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(new UriTemplate("/users/{userId}").expand(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.POST, null));
    return new ResponseEntity<>(user, headers, HttpStatus.CREATED);
  }

  @Operation(
      summary = "delete a User",
      tags = "Users",
      description = "This API is used to delete a User")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}")
  @PreAuthorize(EntityPrivileges.DELETE_USER)
  public ResponseEntity<?> deleteUser(
      @Parameter(name = "id", description = "user id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId)
      throws ResourceNotFoundException, CustomException {
    iuser.delete(userId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.DELETE, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @CrossOrigin
  @Operation(
      summary = "update a User",
      tags = "Users",
      description = "This API is used to update the current User")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.PUT, value = "/{id}")
  public ResponseEntity<?> updateUser(
      @Parameter(name = "id", description = "user id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId,
      @Parameter(name = "user", description = "user details", schema = @Schema(defaultValue = ""))
          @RequestBody
          UserDetails userDetails)
      throws DataValidationException,
          CustomException,
          com.merck.nextconnect.utils.file.handler.exception.CustomException {

    iuser.update(userId, userDetails);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.PUT, properties));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "Fetch a user",
      tags = "Users",
      description = "This API is used to fetch a user")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/{id}")
  public ResponseEntity<UserProfileResponseEntity> getUser(
      @Parameter(name = "id", description = "user id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId) {
    UserProfileResponseEntity user = iuser.fetchOneUser(userId);
    if (user == null) {
      return new ResponseEntity<UserProfileResponseEntity>(HttpStatus.NOT_FOUND);
    }
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.GET, properties));
    return new ResponseEntity<UserProfileResponseEntity>(user, HttpStatus.OK);
  }

  @Operation(
      summary = "reset password",
      tags = "Users",
      description = "This API is used to reset the users password")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST, value = "/password")
  public ResponseEntity<?> resetUserCredentials(
      @Parameter(
              name = "credentials",
              description = "user credentials",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          ResetCredential resetCredentials)
      throws NumberFormatException, DataValidationException, ResourceNotFoundException {
    logger.info("resetUserCredentials method starts");
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if (!authUser.getRole().equals(Constants.PASSWORDUPDATE)) {
      iuser.validatePassword(resetCredentials, Long.parseLong(authUser.getId()));
    }
    Credentials credentials =
        new Credentials(resetCredentials.getNewPassword(), resetCredentials.getConfirmPassword());
    iuser.resetCredentials(credentials, Long.parseLong(authUser.getId()));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PASSWORDUPDATE, Constants.POST, null));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "trigger password reset email",
      tags = "Users",
      description = "This API is used to trigger email for resetting password")
  @RequestMapping(method = RequestMethod.PUT, value = "/passwordreset")
  public ResponseEntity<String> triggerPasswordReset(
      @Parameter(name = "email", description = "email", schema = @Schema(defaultValue = ""))
          @RequestBody
          UserEmail userEmail)
      throws AddressException, MessagingException, CustomException {
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userEmail.getEmail()));
    AuditLogger.getInstance()
        .auditLog(
            AuditLoggerUtil.formatLogWithoutUser(
                Constants.RESET_PASSWORD, Constants.PUT, properties));
    iuser.triggerPasswordReset(userEmail.getEmail());
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @CrossOrigin
  @Operation(
      summary = "Activate/deactivate or update role",
      tags = "Users",
      description = "This API is used to Activate/deactivate or update role for a user")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize("hasAnyAuthority('create_user','update_user')")
  @RequestMapping(method = RequestMethod.PATCH, value = "/{id}")
  public ResponseEntity<?> setStatus(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId,
      @Parameter(
              name = "status and role",
              description = "status and role",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          UserPatch userPatch)
      throws ResourceNotFoundException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    iuser.updateStatusAndRole(userId, userPatch);

    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.PATCH, properties));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "password to be reset by admin",
      tags = "Users",
      description =
          "This API is used to reset the users password by admin who has privilege to reset password")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.PUT, value = "/{id}/password")
  @PreAuthorize("hasAnyAuthority('create_user','update_user')")
  public ResponseEntity<?> resetCredentialsByAdmin(
      @Parameter(
              name = "credentials",
              description = "user credentials",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          Credentials credentials,
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId)
      throws DataValidationException, ResourceNotFoundException {
    iuser.resetCredentials(credentials, userId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.PUT, properties));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "invite user",
      tags = "Users",
      description =
          "This API is used to invite a user to the application by sending email invite"
              + "<br><table>"
              + "<tr><td>Attribute Name</td>   <td>Mandatory/Optional</td>   <td>Description</td></tr>"
              + "<tr><td>userId</td> <td>Mandatory</td> <td> Id of the user </td></tr>"
              + "</table>")
  @RequestMapping(method = RequestMethod.PUT, value = "/{id}/invite")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize("hasAnyAuthority('create_user','update_user')")
  public ResponseEntity<String> inviteUser(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId)
      throws AddressException, MessagingException, CustomException {
    iuser.inviteUser(userId);
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.PUT, null));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "Get all previleges of the User",
      tags = "Users",
      description = "This API is used get all previleges of a User")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/{id}/privileges")
  public ResponseEntity<List<Privileges>> getPrivileges(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId,
      @Parameter(name = "filterBy", description = "filter category", required = true)
          @RequestParam(value = "filterBy", required = true)
          String filterBy)
      throws ResourceNotFoundException {
    List<Privileges> privileges = iuser.getPrivileges(userId, filterBy);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.GET, properties));
    return new ResponseEntity<List<Privileges>>(privileges, HttpStatus.OK);
  }

  @Operation(
      summary = "add privileges to a User",
      tags = "Users",
      description = "This API is used to add privileges to a User")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST, value = "/{id}/privileges")
  public ResponseEntity<?> addPrivileges(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId,
      @Parameter(
              name = "list of privileges",
              description = "list of privileges",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          List<ResourcePrivilege> resourcePrivilege)
      throws ResourceNotFoundException {
    iuser.addPrivileges(userId, resourcePrivilege);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.POST, properties));
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  @Operation(
      summary = "delete privileges of a User",
      tags = "Users",
      description = "This API is used delete privileges of a User")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}/privileges")
  public ResponseEntity<?> deletePrivileges(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId,
      @Parameter(
              name = "list of privileges",
              description = "list of privileges",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          List<ResourcePrivilege> resourcePrivilege)
      throws ResourceNotFoundException {
    iuser.deletePrivileges(userId, resourcePrivilege);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.DELETE, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Operation(
      summary = "invite user from SerivceMAx",
      tags = "Users",
      description =
          "This API is used to invite a user to the application by sending email invite from ServiceMax")
  @PutMapping("/re-invite")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  public ResponseEntity<String> inviteUserFromServiceMax(
      @Parameter(
              name = "emailId",
              description = "email ID of the user",
              schema = @Schema(defaultValue = ""))
          @RequestParam
          String emailId)
      throws MessagingException, CustomException {
    iuser.inviteUserFromServiceMax(emailId);
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.PUT, null));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  // NCIOT-4064
  @Operation(
      summary = "Get user image",
      tags = "Users",
      description = "This API is used to get user image")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/{id}/image")
  public ResponseEntity<UserProfileImageDTO> getUserImage(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId)
      throws CustomException {
    logger.info("Entered getUserImage Controller");
    return new ResponseEntity<>(iuser.fetchImage(userId), HttpStatus.OK);
  }

  // NCIOT-4064
  @Operation(
      summary = "delete user image",
      tags = "Users",
      description = "This API is used to delete user image")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @DeleteMapping("/{id}/image")
  public ResponseEntity<?> deleteUserImage(
      @Parameter(name = "id", description = "id of the user", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long userId)
      throws CustomException {
    logger.info("Entered deleteUserImage Controller");
    iuser.deleteImage(userId);
    logger.info("Exited deleteUserImage Controller");
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  /**
   * This method will return the userType. *
   *
   * @param roleName
   * @param serialno
   * @return String
   * @throws CustomException
   */
  @Operation(
      summary = "get Device Contact Hotline Popup",
      tags = "Users",
      description = "This API is used to get popup page of Device Contact Hotline")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = com.merck.nextconnect.utils.common.Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = com.merck.nextconnect.utils.common.Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = com.merck.nextconnect.utils.common.Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @GetMapping("/hotlineuser")
  public ResponseEntity<HotlineUserType> getContactHotlineUserType() throws CustomException {

    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    HttpHeaders headers = new HttpHeaders();
    String userType = null;
    if (Optional.ofNullable(authUser).isPresent()) {
      userType = iuser.fetchUserType(Integer.valueOf(authUser.getId()));
    }
    if (Optional.ofNullable(userType).isPresent()) {
      HotlineUserType hotlineUserType = new HotlineUserType();
      hotlineUserType.setUserType(userType);
      return new ResponseEntity<>(hotlineUserType, headers, HttpStatus.OK);
    } else {
      logger.info("Contact hotline userType not found {}", userType);
      throw new CustomException(CustomErrorCodes.USER_NOT_FOUND);
    }
  }

  @Operation(
      summary = "invite user from SerivceMAx",
      tags = "Users",
      description =
          "This API is used to invite a user to the application by sending email invite from ServiceMax")
  @PutMapping("/user-re-invite")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  public ResponseEntity<String> inviteUserFromServiceMaxbody(
      @Parameter(
              name = "userEmail",
              description = "email ID of the user",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          UserEmail userEmail)
      throws MessagingException, CustomException {
    if (userEmail.getEmail() != null && !userEmail.getEmail().isEmpty()) {
      iuser.inviteUserFromServiceMax(userEmail.getEmail());
    } else {
      logger.error("Please provide correct Email ID");
      throw new CustomException(CustomErrorCodes.USER_NAME_INVALID);
    }

    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.PUT, null));
    return new ResponseEntity<>(HttpStatus.OK);
  }
}
