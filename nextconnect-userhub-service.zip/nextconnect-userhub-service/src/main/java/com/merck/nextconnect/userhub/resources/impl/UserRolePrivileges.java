package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.entities.AuthUser;
import com.merck.nextconnect.authfilter.entities.UserTerritory;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.DeviceTypeOperation;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.MeasureEventGroupsPrivilegeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.RolesOrgPrivilegeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.UserTerritoryRepository;
import com.merck.nextconnect.authfilter.resources.IprivilegeBuilder;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.userhub.entities.Card;
import com.merck.nextconnect.userhub.entities.Customer;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.DeviceLocation;
import com.merck.nextconnect.userhub.entities.DeviceType;
import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.RoleCardPrivilege;
import com.merck.nextconnect.userhub.entities.RoleDeviceGroupPrivilege;
import com.merck.nextconnect.userhub.entities.RoleDeviceTypePrivilege;
import com.merck.nextconnect.userhub.entities.RoleEntityPrivilege;
import com.merck.nextconnect.userhub.entities.UserDeviceAssignmentTrack;
import com.merck.nextconnect.userhub.entities.UserDevicePrivilege;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.mail.MailTemplate;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroup;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupAccess;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.Location;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleDeviceGroup;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.repository.jpa.CardRepository;
import com.merck.nextconnect.userhub.repository.jpa.CustomerRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceLocationRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceTypeRepository;
import com.merck.nextconnect.userhub.repository.jpa.EntityRepository;
import com.merck.nextconnect.userhub.repository.jpa.PrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleCardPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleDeviceGroupPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleDeviceTypePrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleEntityPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDeviceAssignmentTrackRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.SmsServiceValidation;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.TemplateName;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 * class to perform user - role related privilege operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public class UserRolePrivileges {

  static final Logger logger = LoggerFactory.getLogger(UserRolePrivileges.class);

  @Autowired RoleEntityPrivilegesRepository roleEntityPrivilegesRepo;

  @Autowired RoleDeviceGroupPrivilegesRepository roleDeviceGroupPrivilegesRepo;

  @Autowired RoleDeviceTypePrivilegesRepository roleDeviceTypePrivilegesRepo;

  @Autowired EntityRepository entityRepo;

  @Autowired DeviceTypeRepository deviceTypeRepo;

  @Autowired CustomerRepository customerRepo;

  @Autowired DeviceLocationRepository deviceLocationRepo;

  @Autowired PrivilegeRepository privilegeRepo;

  @Autowired IprivilegeBuilder privilegeBuilder;

  @Autowired IprivilegeProvider privilegeProvider;

  @Autowired UserDevicePrivilegeRepository userDevicePrivilegeRepo;

  @Autowired DeviceRepository deviceRepo;

  @Autowired UserOrgPrivileges userOrgPrivileges;

  @Autowired RoleCardPrivilegesRepository roleCardPrivilegesRepo;

  @Autowired CardRepository cardRepo;

  @Autowired MeasureEventGroupsPrivilegeRepository measureEventGroupPrivilegeRepo;

  @Autowired RolesOrgPrivilegeRepository rolesOrgPrivilegeRepository;

  @Autowired private CountryRepository countryRepo;

  @Autowired UserTerritoryRepository userTerritoryRepo;

  @Autowired private RoleDeviceTypePrivilegesRepository roleDeviceTypePrivilegesRepository;

  @Autowired private UserRepository userRepository;

  @Autowired private MailTemplate mailTemplate;

  @Autowired private SmsServiceValidation smsService;

  @Autowired RoleRepository roleRepo;

  @Autowired private UserDeviceAssignmentTrackRepository userDeviceAssignmentTrackRepository;

  /**
   * adding privileges to a role
   *
   * @param resourcePrivileges - list of privileges and resources
   * @param role - role
   */
  public void addPrivilegeToRole(List<ResourcePrivilege> resourcePrivileges, Role role) {
    validateActionForSystemDefinedRole(role);
    List<RoleEntityPrivilege> roleEntityPrivileges = new ArrayList<>();
    List<RoleDeviceTypePrivilege> roleDeviceTypePrivileges = new ArrayList<>();
    List<RoleCardPrivilege> roleCardPrivileges = new ArrayList<>();
    resourcePrivileges.stream()
        .forEach(
            resourcePrivilege -> {
              Privilege privilege =
                  privilegeRepo.findById(resourcePrivilege.getPrivilegeid()).get();
              Optional.ofNullable(privilege)
                  .filter(p -> Constants.DEVICETYPE.equals(p.getResourceType()))
                  .ifPresent(
                      p -> {
                        if (Constants.ACCESS_ALL.equals(p.getOperation())) {
                          checkAllDeviceAccessPermission();
                        }
                        RoleDeviceTypePrivilege roleDeviceTypePrivilege =
                            new RoleDeviceTypePrivilege();
                        DeviceType deviceType =
                            deviceTypeRepo.findById(resourcePrivilege.getResourceid()).get();
                        roleDeviceTypePrivilege.setDeviceType(deviceType);
                        roleDeviceTypePrivilege.setPrivilege(privilege);
                        roleDeviceTypePrivilege.setRole(role);
                        roleDeviceTypePrivileges.add(roleDeviceTypePrivilege);
                      });
              Optional.ofNullable(privilege)
                  .filter(p -> Constants.ENTITY.equals(p.getResourceType()))
                  .ifPresent(
                      p -> {
                        RoleEntityPrivilege roleEntityPrivilege = new RoleEntityPrivilege();
                        Entities entities =
                            entityRepo.findById(resourcePrivilege.getResourceid()).get();
                        //				NCIOT-16412
                        if (Constants.VIEW_RATING_FEEDBACK_PRVLG.equals(privilege.getOperation())) {
                          List<Role> roles = roleRepo.getCustomerTypeRolesByName(role.getName());
                          if (Optional.ofNullable(roles).isPresent()) {
                            roles.forEach(
                                r -> {
                                  RoleEntityPrivilege roleEntityPriv = new RoleEntityPrivilege();
                                  roleEntityPriv.setEntities(entities);
                                  roleEntityPriv.setPrivilege(privilege);
                                  roleEntityPriv.setRole(r);
                                  roleEntityPrivileges.add(roleEntityPriv);
                                });
                          }
                        } else {
                          roleEntityPrivilege.setEntities(entities);
                          roleEntityPrivilege.setPrivilege(privilege);
                          roleEntityPrivilege.setRole(role);
                          roleEntityPrivileges.add(roleEntityPrivilege);
                        }
                      });

              Optional.ofNullable(privilege)
                  .filter(p -> Constants.CARD.equals(p.getResourceType()))
                  .ifPresent(
                      p -> {
                        RoleCardPrivilege roleCardPrivilege = new RoleCardPrivilege();
                        Card card = cardRepo.findById(resourcePrivilege.getResourceid()).get();
                        Optional.ofNullable(card)
                            .filter(c -> userOrgPrivileges.hasCardAccess(c.getId()))
                            .ifPresent(
                                c -> {
                                  roleCardPrivilege.setCard(card);
                                  roleCardPrivilege.setPrivilege(privilege);
                                  roleCardPrivilege.setRole(role);
                                  roleCardPrivileges.add(roleCardPrivilege);
                                });
                      });
            });
    Optional.ofNullable(roleEntityPrivileges)
        .filter(r -> !r.isEmpty())
        .ifPresent(
            r -> {
              roleEntityPrivilegesRepo.saveAll(roleEntityPrivileges);
              logger.info("successfully added entity level privileges");
              privilegeBuilder.removeEntityPrivileges(role.getRoleId());
              logger.info("successfully removed all the entity privileges from cache");
            });
    Optional.ofNullable(roleDeviceTypePrivileges)
        .filter(r -> !r.isEmpty())
        .ifPresent(
            r -> {
              roleDeviceTypePrivilegesRepo.saveAll(roleDeviceTypePrivileges);
              logger.info("successfully added device type privileges");
              privilegeBuilder.removeDeviceTypePrivileges(role.getRoleId());
              logger.info("successfully removed all the device type privileges from cache");
            });

    Optional.ofNullable(roleCardPrivileges)
        .filter(r -> !r.isEmpty())
        .ifPresent(
            r -> {
              roleCardPrivilegesRepo.saveAll(roleCardPrivileges);
              logger.info("successfully added cards privileges");
              privilegeBuilder.removeCardPrivileges(role.getRoleId());
              logger.info("successfully removed cards privileges from cache");
            });
  }

  /**
   * deleting privileges to a role
   *
   * @param resourcePrivileges - list of privileges and resources
   * @param role - role
   */
  public void deletePrivilegeToRole(List<ResourcePrivilege> resourcePrivileges, Role role) {
    validateActionForSystemDefinedRole(role);
    resourcePrivileges.stream()
        .forEach(
            resourcePrivilege -> {
              Privilege privilege =
                  privilegeRepo.findById(resourcePrivilege.getPrivilegeid()).get();
              Optional.ofNullable(privilege)
                  .filter(p -> Constants.DEVICETYPE.equals(p.getResourceType()))
                  .ifPresent(
                      p -> {
                        if (Constants.ACCESS_ALL.equals(p.getOperation())) {
                          checkAllDeviceAccessPermission();
                        }
                        DeviceType deviceType =
                            deviceTypeRepo.findById(resourcePrivilege.getResourceid()).get();
                        roleDeviceTypePrivilegesRepo.deleteByRoleAndPrivilegeAndDeviceType(
                            role, privilege, deviceType);

                        Optional.ofNullable(
                                privilegeProvider.getDeviceTypePrivileges(role.getRoleId()))
                            .ifPresent(
                                dp -> {
                                  privilegeBuilder.removeDeviceTypePrivileges(role.getRoleId());
                                });
                      });
              Optional.ofNullable(privilege)
                  .filter(p -> Constants.ENTITY.equals(p.getResourceType()))
                  .ifPresent(
                      p -> {
                        Optional.ofNullable(role)
                            .filter(r -> r.isSystemDefined())
                            .ifPresent(
                                rId -> {
                                  if (Constants.LW_SUPER_ADMIN.equalsIgnoreCase(rId.getName())
                                      && Constants.MANAGE_DEVICE_TYPE_PRIVILEGE.equalsIgnoreCase(
                                          p.getOperation())) {
                                    throw new AccessDeniedException(
                                        "Cannot remove device type management privilege for Super Admin");
                                  }
                                  Optional.ofNullable(resourcePrivilege)
                                      .filter(
                                          r -> !(r.getResourceid() == 1 || r.getResourceid() == 2))
                                      .orElseThrow(
                                          () ->
                                              new AccessDeniedException(
                                                  "cannot remove user management privilege for super admin"));
                                });
                        Entities entities =
                            entityRepo.findById(resourcePrivilege.getResourceid()).get();
                        if (Constants.VIEW_RATING_FEEDBACK_PRVLG.equals(privilege.getOperation())) {
                          List<Long> roleIds =
                              roleRepo.getCustomerTypeRolesByName(role.getName()).stream()
                                  .map(Role::getRoleId)
                                  .collect(Collectors.toList());
                          if (Optional.ofNullable(roleIds).isPresent()) {
                            roleEntityPrivilegesRepo.deleteCustomerRoleEntityPrivilege(
                                roleIds, privilege.getprivilegeId(), entities.getEntityId());
                            roleIds.forEach(
                                r -> {
                                  Optional.ofNullable(privilegeProvider.getEntityPrivileges(r))
                                      .ifPresent(
                                          dp -> {
                                            privilegeBuilder.removeEntityPrivileges(r);
                                          });
                                });
                          }
                        } else {
                          roleEntityPrivilegesRepo.deleteByRoleAndPrivilegeAndEntities(
                              role, privilege, entities);
                          Optional.ofNullable(
                                  privilegeProvider.getEntityPrivileges(role.getRoleId()))
                              .ifPresent(
                                  dp -> {
                                    privilegeBuilder.removeEntityPrivileges(role.getRoleId());
                                  });
                        }
                      });

              Optional.ofNullable(privilege)
                  .filter(p -> Constants.CARD.equals(p.getResourceType()))
                  .ifPresent(
                      p -> {
                        Card card = cardRepo.findById(resourcePrivilege.getResourceid()).get();
                        Optional.ofNullable(card)
                            .filter(c -> userOrgPrivileges.hasCardAccess(c.getId()))
                            .ifPresent(
                                c -> {
                                  roleCardPrivilegesRepo.deleteByRoleAndPrivilegeAndCard(
                                      role, privilege, card);
                                  Optional.ofNullable(
                                          privilegeProvider.getEntityPrivileges(role.getRoleId()))
                                      .ifPresent(
                                          dp -> {
                                            privilegeBuilder.removeCardPrivileges(role.getRoleId());
                                          });
                                });
                      });
              logger.info("successfully removed all the privileges");
            });
  }

  /**
   * get device level privileges
   *
   * @param roleId - roleId
   * @param deviceTypeId - deviceTypeId
   * @param resource - resource
   * @return privileges
   */
  public DeviceGroupPrivilege getDeviceGroupPrivileges(
      long roleId, long deviceTypeId, String resource) {
    DeviceGroupPrivilege privileges = new DeviceGroupPrivilege();
    Map<Long, Integer> locationMap = new HashMap<>();
    int locationIndex = 0;
    if (resource.equals(Constants.ROLE)) {
      List<RoleDeviceGroup> deviceGroupPrivileges =
          roleDeviceGroupPrivilegesRepo.getPrivileges(roleId, deviceTypeId);
      privileges.setPrivilegeId(
          privilegeRepo.getByFilter(Constants.DEVICEGROUP).get(0).getprivilegeId());
      for (RoleDeviceGroup deviceGroupPrivilege : deviceGroupPrivileges) {
        Location deviceLocation = new Location();
        DeviceGroup deviceGroup = new DeviceGroup();
        if (!locationMap.containsKey(deviceGroupPrivilege.getLocationId())) {
          locationMap.put(deviceGroupPrivilege.getLocationId(), locationIndex);
          locationIndex++;
          deviceLocation.setId(deviceGroupPrivilege.getLocationId());
          deviceLocation.setName(deviceGroupPrivilege.getLocationName());
          deviceGroup.setId(deviceGroupPrivilege.getDeviceGruopId());
          deviceGroup.setName(deviceGroupPrivilege.getDeviceGroupName());
          if (privileges.getLocations() == null) {
            privileges.setLocations(new ArrayList<>(Arrays.asList(deviceLocation)));
          } else {
            privileges.getLocations().add(deviceLocation);
          }
          deviceLocation.setDeviceGroups(new ArrayList<>(Arrays.asList(deviceGroup)));
        } else {
          deviceGroup.setId(deviceGroupPrivilege.getDeviceGruopId());
          deviceGroup.setName(deviceGroupPrivilege.getDeviceGroupName());
          privileges
              .getLocations()
              .get(locationMap.get(deviceGroupPrivilege.getLocationId()))
              .getDeviceGroups()
              .add(deviceGroup);
        }
      }
    }
    return privileges;
  }

  /**
   * get DeviceType level privileges
   *
   * @param id - resource id (user,role)
   * @param resource - resource
   */
  public List<RolePrivilege> getDeviceTypePrivileges(long id, String resource) {
    List<RolePrivilege> privileges = new ArrayList<RolePrivilege>();
    if (resource.equals(Constants.ROLE)) {
      privileges = roleDeviceTypePrivilegesRepo.getPrivileges(id);
    }
    return privileges;
  }

  /**
   * get Entity level privileges
   *
   * @param id - resource id (user,role)
   * @param resource - resource
   */
  public List<RolePrivilege> getEntityPrivileges(long id, String resource) {
    List<RolePrivilege> privileges = new ArrayList<RolePrivilege>();
    if (resource.equals(Constants.ROLE)) {
      privileges = roleEntityPrivilegesRepo.getPrivileges(id);
    }
    return privileges;
  }

  /**
   * delete privilege
   *
   * @param privilegeId - privilege
   */
  public void deletePrivilege(long privilegeId) {
    Privilege privilege = privilegeRepo.findById(privilegeId).get();
    roleEntityPrivilegesRepo.deleteByPrivilege(privilege);
    roleDeviceTypePrivilegesRepo.deleteByPrivilege(privilege);
  }

  /**
   * get Entity level privilege list
   *
   * @param id - resource id (user,role)
   * @param resource - resource
   */
  public List<String> getEntityPrivilegeList(long id) {
    List<String> privileges = new ArrayList<String>();
    privileges = privilegeProvider.getEntityPrivileges(id);
    return privileges;
  }

  /**
   * get device group level privilege list
   *
   * @param id - resource id (user,role)
   * @param resource - resource
   */
  public List<Long> getDeviceGroupPrivilegeList(long id) {
    List<Long> privileges = new ArrayList<Long>();
    privileges = privilegeProvider.getDeviceGroupPrivileges(id);
    return privileges;
  }

  public Map<Long, Map<DeviceTypeOperation, List<String>>> getDeviceTypePrivilegeMap(long id) {
    Map<Long, Map<DeviceTypeOperation, List<String>>> privileges =
        new HashMap<Long, Map<DeviceTypeOperation, List<String>>>();
    privileges = privilegeProvider.getDeviceTypePrivileges(id);
    return privileges;
  }

  /**
   * adding deviceGroup privileges to a role
   *
   * @param deviceGroupAccess - list of privileges and resources
   * @param role - role
   */
  public void addDeviceGroupPrivilegeToRole(List<DeviceGroupAccess> deviceGroupAccess, Role role) {
    validateActionForSystemDefinedRole(role);
    List<RoleDeviceGroupPrivilege> roleDeviceGroupPrivileges = new ArrayList<>();
    deviceGroupAccess.stream()
        .forEach(
            aDeviceGroupAccess -> {
              Privilege privilege =
                  privilegeRepo.findById(aDeviceGroupAccess.getPrivilegeId()).get();
              RoleDeviceGroupPrivilege roleDeviceGroupPrivilege = new RoleDeviceGroupPrivilege();
              Customer customer =
                  customerRepo.findById(aDeviceGroupAccess.getDeviceGroupId()).get();
              roleDeviceGroupPrivilege.setCustomer(customer);
              roleDeviceGroupPrivilege.setPrivilege(privilege);
              roleDeviceGroupPrivilege.setRole(role);
              roleDeviceGroupPrivilege.setDeviceTypeId(aDeviceGroupAccess.getResourceId());
              DeviceLocation deviceLocation =
                  deviceLocationRepo.findById(aDeviceGroupAccess.getLocationId()).get();
              roleDeviceGroupPrivilege.setDeviceLocation(deviceLocation);
              roleDeviceGroupPrivileges.add(roleDeviceGroupPrivilege);
            });
    if (!roleDeviceGroupPrivileges.isEmpty()) {
      roleDeviceGroupPrivilegesRepo.saveAll(roleDeviceGroupPrivileges);
      logger.info("successfully added deviceGroup level privileges");
      privilegeBuilder.removeDeviceGroupPrivileges(role.getRoleId());
      logger.info("successfully removed all the device group privileges from cache");
    }
  }

  /**
   * deleting deviceGroup privileges to a role
   *
   * @param deviceGroupAccess - list of privileges and resources
   * @param role - role
   */
  public void deleteDeviceGroupPrivilegeToRole(
      List<DeviceGroupAccess> deviceGroupAccess, Role role) {
    validateActionForSystemDefinedRole(role);
    deviceGroupAccess.stream()
        .forEach(
            aDeviceGroupAccess -> {
              Privilege privilege =
                  privilegeRepo.findById(aDeviceGroupAccess.getPrivilegeId()).get();
              Customer customer =
                  customerRepo.findById(aDeviceGroupAccess.getDeviceGroupId()).get();
              DeviceLocation deviceLocation =
                  deviceLocationRepo.findById(aDeviceGroupAccess.getLocationId()).get();
              roleDeviceGroupPrivilegesRepo
                  .deleteByRoleAndPrivilegeAndCustomerAndDeviceLocationAndDeviceTypeId(
                      role,
                      privilege,
                      customer,
                      deviceLocation,
                      aDeviceGroupAccess.getResourceId());
            });
    if (!deviceGroupAccess.isEmpty()) {
      if (privilegeProvider.getDeviceGroupPrivileges(role.getRoleId()) != null) {
        privilegeBuilder.removeDeviceGroupPrivileges(role.getRoleId());
      }
    }
  }

  /**
   * validates operations for privileges with system defined roles
   *
   * @param role - role
   */
  private void validateActionForSystemDefinedRole(Role role) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Optional.ofNullable(role)
        .filter(r -> r.isSystemDefined())
        .ifPresent(
            r -> {
              Optional.ofNullable(authUser)
                  .filter(a -> a.isSystemDefinedRole())
                  .orElseThrow(() -> new AccessDeniedException("unauthorized to edit privileges"));
              Optional.ofNullable(authUser)
                  .filter(a -> a.isSystemDefinedRole())
                  .ifPresent(
                      a -> {
                        Optional.ofNullable(authUser.getRoleId())
                            .filter(authRole -> authRole == r.getRoleId())
                            .orElseThrow(
                                () -> new AccessDeniedException("unauthorized to edit privileges"));
                      });
            });
  }

  private void checkAllDeviceAccessPermission() {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Optional.ofNullable(authUser)
        .filter(a -> a.isSystemDefinedRole())
        .orElseThrow(() -> new AccessDeniedException("unauthorized to edit all access privileges"));
  }

  public List<Privileges> getUserDevicePrivileges(long userId) {
    List<Privileges> privileges = userDevicePrivilegeRepo.getPrivileges(userId);
    return privileges;
  }

  public void addUserDevicePrivileges(
      UserProfile user, List<ResourcePrivilege> resourcePrivileges) {
    List<UserDevicePrivilege> userDevicePrivileges = new ArrayList<>();
    List<UserDeviceAssignmentTrack> userDeviceAssignmentTracks = new ArrayList<>();

    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();

    List<Long> devices = new ArrayList<>();
    resourcePrivileges.stream()
        .forEach(
            resourcePrivilege -> {
              Privilege privilege =
                  privilegeRepo.findById(resourcePrivilege.getPrivilegeid()).get();
              Device device = deviceRepo.findById(resourcePrivilege.getResourceid()).get();

              UserDevicePrivilege devicePrivilege = new UserDevicePrivilege();
              devicePrivilege.setUser(user);
              devicePrivilege.setPrivilege(privilege);
              devicePrivilege.setDevices(device);
              Optional.ofNullable(device)
                  .filter(
                      d ->
                          userOrgPrivileges.hasPermission(device.getDeviceType().getDeviceTypeId()))
                  .ifPresent(
                      d -> {
                        Optional.ofNullable(device.getUuid())
                            .filter(
                                du ->
                                    privilegeProvider.hasDeviceAccess(
                                        du, device.getDeviceType().getDeviceTypeId()))
                            .ifPresent(
                                du -> {
                                  userDevicePrivileges.add(devicePrivilege);
                                  if (privilege.getOperation().equals(Constants.ASSIGN_DEVICE)) {
                                    userDeviceAssignmentTracks.add(
                                        UserDeviceAssignmentTrack.builder()
                                            .user(user)
                                            .device(device)
                                            .assignedTimestamp(Timestamp.from(Instant.now()))
                                            .assignedBy(authUser.getId())
                                            .isEmailTriggered(false)
                                            .build());
                                  }
                                  devices.add(resourcePrivilege.getResourceid());
                                });
                      });
            });
    Optional.ofNullable(userDevicePrivileges)
        .filter(u -> !u.isEmpty())
        .ifPresent(
            u -> {
              userDevicePrivilegeRepo.saveAll(userDevicePrivileges);
              userOrgPrivileges.addDevicesToOrg(user.getOrg().getId(), devices);

              Optional.ofNullable(userDeviceAssignmentTracks)
                  .filter(i -> !i.isEmpty())
                  .ifPresent(
                      j -> {
                        userDeviceAssignmentTrackRepository.saveAll(userDeviceAssignmentTracks);
                      });
              logger.info("successfully added device to users");
            });
  }

  public void deleteUserDevicePrivileges(
      UserProfile user, List<ResourcePrivilege> resourcePrivileges) {

    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();

    resourcePrivileges.stream()
        .forEach(
            resourcePrivilege -> {
              Privilege privilege =
                  privilegeRepo.findById(resourcePrivilege.getPrivilegeid()).get();
              Device device = deviceRepo.findById(resourcePrivilege.getResourceid()).get();
              Optional.ofNullable(device)
                  .filter(
                      d ->
                          userOrgPrivileges.hasPermission(device.getDeviceType().getDeviceTypeId()))
                  .ifPresent(
                      d -> {
                        Optional.ofNullable(device.getUuid())
                            .filter(
                                du ->
                                    privilegeProvider.hasDeviceAccess(
                                        du, device.getDeviceType().getDeviceTypeId()))
                            .ifPresent(
                                du -> {
                                  userDevicePrivilegeRepo.deleteByUserAndPrivilegeAndDevice(
                                      user, privilege, device);
                                  if (privilege.getOperation().equals(Constants.ASSIGN_DEVICE)) {
                                    UserDeviceAssignmentTrack userDeviceAssignmentTrack =
                                        userDeviceAssignmentTrackRepository
                                            .findByUserAndDeviceAndAssignedTimestampNotNullAndUnassignedTimestampNull(
                                                user, device);
                                    if (userDeviceAssignmentTrack != null) {
                                      userDeviceAssignmentTrack.setUnassignedTimestamp(
                                          Timestamp.from(Instant.now()));
                                      userDeviceAssignmentTrack.setUnassignedBy(authUser.getId());
                                      userDeviceAssignmentTrackRepository.save(
                                          userDeviceAssignmentTrack);
                                    }
                                  }
                                });
                      });
              logger.info("successfully deleted device to users");
            });
  }

  public List<RolePrivilege> getCardPrivileges(long id) {
    List<RolePrivilege> privileges = new ArrayList<RolePrivilege>();
    privileges = roleCardPrivilegesRepo.getPrivileges(id);
    return privileges;
  }

  public void deleteMeasureEventGroupsByRoleId(long roleId) {
    measureEventGroupPrivilegeRepo.deleteGroupMappingsByRoleId(roleId);
  }

  public void deleteOrgPrivilegesByRoleId(long roleId) {
    rolesOrgPrivilegeRepository.deleteByRoleId(roleId);
  }

  public void addTerritories(long userId, List<ResourcePrivilege> resourcePrivileges) {
    List<UserTerritory> userTerritories = new ArrayList<>();
    removeAssignedTerritories(userId, resourcePrivileges).stream()
        .forEach(
            resourcePrivilege -> {
              UserTerritory userTerritory = new UserTerritory();
              Country country = countryRepo.findById((int) resourcePrivilege.getResourceid());
              userTerritory.setCountry(country);
              userTerritory.setUser(new AuthUser(userId));
              userTerritories.add(userTerritory);
            });
    Optional.ofNullable(userTerritories)
        .filter(u -> !u.isEmpty())
        .ifPresent(
            u -> {
              userTerritoryRepo.saveAll(userTerritories);
              logger.info("successfully added territories to users");
            });
  }
  ;

  private List<ResourcePrivilege> removeAssignedTerritories(
      long userId, List<ResourcePrivilege> resourcePrivileges) {
    List<Integer> territories = userTerritoryRepo.getUserTerritories(userId);
    return resourcePrivileges.stream()
        .filter(r -> !territories.contains((int) r.getResourceid()))
        .collect(Collectors.toList());
  }

  public void removeTerritories(long userId, List<ResourcePrivilege> resourcePrivileges) {
    resourcePrivileges.stream()
        .forEach(
            resourcePrivilege -> {
              Country country = countryRepo.findById((int) resourcePrivilege.getResourceid());
              userTerritoryRepo.deleteByUserAndCountry(new AuthUser(userId), country);
              logger.info("successfully deleted territories to users");
            });
  }

  public List<Privileges> getUserTerritories(long userId) {
    List<Integer> territories = userTerritoryRepo.getUserTerritories(userId);
    List<Privileges> userTerritoryPrivileges =
        territories.stream()
            .map(
                t ->
                    new Privileges(
                        OrgPrivileges.has_territories.getPrivilegeId(),
                        OrgPrivileges.has_territories.name(),
                        t,
                        Constants.ENTITY))
            .collect(Collectors.toList());
    return userTerritoryPrivileges;
  }
  ;

  public void removeAllTerritories(long userId) {
    userTerritoryRepo.deleteByUser(new AuthUser(userId));
  }

  /**
   * Changes made as per NCIOT-11630. Assigning the device privileges to user.
   *
   * @param user
   * @param resourcePrivileges
   */
  public void autoAddUserDevicePrivileges(
      UserProfile user, List<ResourcePrivilege> resourcePrivileges) {
    logger.info("Starting of autoAddUserDevicePrivileges {}", user.getUserId());
    List<UserDevicePrivilege> userDevicePrivileges = new ArrayList<>();
    List<UserDeviceAssignmentTrack> userDeviceAssignmentTracks = new ArrayList<>();
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    List<Long> devices = new ArrayList<>();
    resourcePrivileges.stream()
        .forEach(
            resourcePrivilege -> {
              Privilege privilege =
                  privilegeRepo.findById(resourcePrivilege.getPrivilegeid()).get();
              Device device = deviceRepo.findById(resourcePrivilege.getResourceid()).get();
              List<RoleDeviceTypePrivilege> roleDeviceTypePrivilege =
                  roleDeviceTypePrivilegesRepository.findByDeviceTypeIdAndRoleId(
                      device.getDeviceType().getDeviceTypeId(), user.getRole().getRoleId());
              if (Optional.ofNullable(roleDeviceTypePrivilege).isPresent()
                  && !roleDeviceTypePrivilege.isEmpty()) {
                UserDevicePrivilege devicePrivilege = new UserDevicePrivilege();
                devicePrivilege.setUser(user);
                devicePrivilege.setPrivilege(privilege);
                devicePrivilege.setDevices(device);
                userDevicePrivileges.add(devicePrivilege);
                devices.add(resourcePrivilege.getResourceid());

                if (privilege.getOperation().equals(Constants.ASSIGN_DEVICE)) {
                  userDeviceAssignmentTracks.add(
                      UserDeviceAssignmentTrack.builder()
                          .user(user)
                          .device(device)
                          .assignedTimestamp(Timestamp.from(Instant.now()))
                          .assignedBy(authUser.getId())
                          .isEmailTriggered(false)
                          .build());
                }
              }
            });
    Optional.ofNullable(userDevicePrivileges)
        .filter(u -> !u.isEmpty())
        .ifPresent(
            u -> {
              userDevicePrivilegeRepo.saveAll(userDevicePrivileges);
              userOrgPrivileges.addDevicesToOrg(user.getOrg().getId(), devices);
              for (UserDevicePrivilege userDevicePrivilege : userDevicePrivileges) {
                try {
                  if (validateFirstAccountCreationOrNot(user) == 0) {
                    mailTemplate.sendDeviceAssignmentChangeMail(
                        user,
                        userDevicePrivilege.getDevices(),
                        TemplateName.DEVICE_ASSIGNMENT_MAIL.getValue(),
                        TemplateName.DEVICE_ASSIGNMENT_MAIL.getValue(),
                        Constants.ACTIVE.toUpperCase());

                    smsService.validateAndSendSMS(
                        Constants.DEVICE_ASSIGNMENT_SMS,
                        Constants.DEVICE_ASSIGNMENT_SMS,
                        user,
                        userDevicePrivilege.getDevices());
                    // updating tracker table
                    UserDeviceAssignmentTrack deviceAssignmentTrack =
                        userDeviceAssignmentTrackRepository
                            .findByUserAndDeviceAndAssignedTimestampNotNullAndUnassignedTimestampNull(
                                user, userDevicePrivilege.getDevices());
                    if (deviceAssignmentTrack != null) {
                      deviceAssignmentTrack.setIsEmailTriggered(true);
                      userDeviceAssignmentTrackRepository.save(deviceAssignmentTrack);
                    }
                  }
                } catch (CustomException e) {
                  logger.error(
                      "Error occurred while sending mail to user : {} for device : {} with exception{}",
                      user,
                      userDevicePrivilege.getDevices(),
                      e);
                } catch (JSONException e) {
                  logger.error(
                      "Error occurred while sending sms to user : {} for device : {} with exception{}",
                      user,
                      userDevicePrivilege.getDevices(),
                      e);
                }
              }
              Optional.ofNullable(userDeviceAssignmentTracks)
                  .filter(i -> !i.isEmpty())
                  .ifPresent(
                      j -> {
                        userDeviceAssignmentTrackRepository.saveAll(userDeviceAssignmentTracks);
                      });
              logger.info("successfully added device to users to {}", user.getUserId());
            });
    logger.info("End of autoAddUserDevicePrivileges {}", user.getUserId());
  }

  private int validateFirstAccountCreationOrNot(UserProfile userProfile) {
    List<UserDeviceAssignmentTrack> userDeviceAssignmentTrack =
        userDeviceAssignmentTrackRepository.findByUser(userProfile);
    if (userDeviceAssignmentTrack.isEmpty() && userDeviceAssignmentTrack.size() == 0) {
      return 0;
    }
    return 1;
  }
}
