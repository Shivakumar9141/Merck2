package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.UIOutputDisplay;
import java.util.List;

public interface IUIOutputDisplay {

  List<UIOutputDisplay> getAll();
}
