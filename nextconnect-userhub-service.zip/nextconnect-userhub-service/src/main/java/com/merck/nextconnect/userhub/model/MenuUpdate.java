package com.merck.nextconnect.userhub.model;

import lombok.Data;

/**
 * @author clukose
 */
@Data
public class MenuUpdate {

  private int menuId;
  private int sequence;
  private boolean isVisible;
}
