package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class FeedBackDTO {

  private double avgRating;
  private double noOfUserFeedBacks;
}
