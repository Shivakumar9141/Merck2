package com.merck.nextconnect.userhub.model;

import java.util.Map;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserFeedBackRatingDTO {

  private double avgRating;
  private double totalUsers;
  private Map<Integer, Integer> ratings;
  private double feedBackPercentage;
}
