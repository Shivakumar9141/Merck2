package com.merck.nextconnect.userhub.model;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@lombok.Builder
@ToString
public class OrgFilter {
  private Set<String> type;
  private Set<Boolean> status;
}
