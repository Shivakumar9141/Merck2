package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.model.DataModel;
import com.merck.nextconnect.userhub.model.FeedBackTrendDTO;
import com.merck.nextconnect.userhub.model.UserAvgRatingCount;
import com.merck.nextconnect.userhub.model.UserFeedBackDateDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingsDTO;
import com.merck.nextconnect.userhub.model.UserFeedbackTrend;
import com.merck.nextconnect.userhub.model.UserRatingTrend;
import com.merck.nextconnect.userhub.model.UserRatingsDTO;
import com.merck.nextconnect.userhub.repo.jdbc.UserFeedBackRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserFeedBackRepository;
import com.merck.nextconnect.userhub.resources.UserFeedBackChartService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserFeedBackUtil;
import com.merck.nextconnect.utils.common.DateTimeUtil;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * @author clukose
 */
@Slf4j
@Service
public class UserFeedBackChartServiceImpl implements UserFeedBackChartService {

  public static final int interval = 15;

  @Autowired private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;
  @Autowired private UserFeedBackRepository userFeedBackRepository;

  @Autowired private UserOrgPrivileges userOrgPrivileges;

  @Override
  public UserFeedbackTrend getUserFeedBackTrend(long duration) {
    log.debug("getUserFeedBackTrend() started");
    UserFeedbackTrend userFeedbackTrend = new UserFeedbackTrend();
    AuthenticatedUser user =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<UserFeedBackDateDTO> infoList = null;

    log.debug("get feedback date intervals based on duration");
    if (Constants.FEEDBACK_DURATION_THREE_MONTHS == duration) {
      infoList =
          UserFeedBackUtil.getFeedbackDateIntervals(duration, Constants.FEEDBACK_INTERVAL_IN_DAYS);
    } else {
      infoList = UserFeedBackUtil.getFeedBackMonthIntervals(duration);
    }

    // set duration parameter which contains feedback date intervals
    List<DataModel> durationdetails = getDateDetail(infoList);
    if (durationdetails != null && !durationdetails.isEmpty()) {
      userFeedbackTrend.setDuration(durationdetails);
    }

    Map<String, Long> userDataMap = new HashMap<>();
    log.debug("get number of users created count based on divided intervals");
    getUserCount(user, infoList);
    Map<String, Long> userCountMap = new HashMap<>();
    // map the chart date with number of users count
    userCountMap = getUserCountMap(infoList);

    log.debug(
        "get mapping of chart date and count of user feedbacks given between divided intervals");
    if (Constants.FEEDBACK_DURATION_THREE_MONTHS == duration) {
      userDataMap = getCountOfFeedBacksByUser(infoList, user, Constants.FEEDBACK_INTERVAL_IN_DAYS);
    } else {
      userDataMap = getCountOfFeedBacksByUser(infoList, user, null);
    }
    List<FeedBackTrendDTO> feedTrendList = new ArrayList<>();

    if (!userDataMap.isEmpty() && !infoList.isEmpty()) {
      processFeedBackTrend(feedTrendList, userDataMap, infoList, userCountMap);
    } else if (!infoList.isEmpty() && userDataMap.isEmpty()) {
      processDefaultFeedBackTrend(feedTrendList, infoList, userCountMap);
    }

    // set total users anf feedback users
    if (feedTrendList != null && !feedTrendList.isEmpty()) {
      userFeedbackTrend.setTotalUsers(getTotalUsersFeedBack(feedTrendList));
      userFeedbackTrend.setFeedbackUsers(getFeedBackUsers(feedTrendList));
    }
    log.debug("getUserFeedBackTrend() completed");
    return userFeedbackTrend;
  }

  @Override
  public UserRatingTrend getUserRatingTrend(long duration) {
    UserRatingTrend userRatingTrend = new UserRatingTrend();
    AuthenticatedUser user =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<UserFeedBackDateDTO> infoList = null;
    if (Constants.FEEDBACK_DURATION_THREE_MONTHS == duration) {
      infoList =
          UserFeedBackUtil.getFeedbackDateIntervals(duration, Constants.FEEDBACK_INTERVAL_IN_DAYS);
    } else {
      infoList = UserFeedBackUtil.getFeedBackMonthIntervals(duration);
    }
    List<DataModel> durationdetails = getDateDetail(infoList);
    if (durationdetails != null && !durationdetails.isEmpty()) {
      userRatingTrend.setDuration(durationdetails);
    }

    Map<String, UserAvgRatingCount> userDataMap = new HashMap<>();
    getUserCount(user, infoList);
    Map<String, Long> userCountMap = new HashMap<>();
    userCountMap = getUserCountMap(infoList);

    if (Constants.FEEDBACK_DURATION_THREE_MONTHS == duration) {
      userDataMap =
          getAvgRatingOfFeedBacksByUser(infoList, user, Constants.FEEDBACK_INTERVAL_IN_DAYS);
    } else {
      userDataMap = getAvgRatingOfFeedBacksByUser(infoList, user, null);
    }

    List<UserRatingsDTO> userRatings = new ArrayList<>();
    if (!userDataMap.isEmpty() && !infoList.isEmpty()) {
      processUserRating(userRatings, userDataMap, infoList, userCountMap);
    } else if (!infoList.isEmpty() && userDataMap.isEmpty()) {
      processDefaultUserRating(userRatings, infoList, userCountMap);
    }

    if (userRatings != null && !userRatings.isEmpty()) {
      userRatingTrend.setRatings(getUserAvgRatingModel(userRatings));
      userRatingTrend.setUsers(getUserModelForRating(userRatings));
      userRatingTrend.setTotalUsers(getTotalUserModelForRating(userRatings));
    }

    return userRatingTrend;
  }

  /**
   * @param feedTrendList
   * @param infoList
   * @param userCountMap
   */
  private void processDefaultFeedBackTrend(
      List<FeedBackTrendDTO> feedTrendList,
      List<UserFeedBackDateDTO> infoList,
      Map<String, Long> userCountMap) {
    for (UserFeedBackDateDTO info : infoList) {
      FeedBackTrendDTO feedBackDTO = new FeedBackTrendDTO();
      feedBackDTO.setCreatedDate(info.getChartDate());
      feedBackDTO.setTotalUserCount(userCountMap.get(info.getChartDate()));
      feedTrendList.add(feedBackDTO);
    }
  }

  /**
   * @param feedTrendList
   * @param userDataMap
   * @param infoList
   * @param userCountMap
   */
  private void processFeedBackTrend(
      List<FeedBackTrendDTO> feedTrendList,
      Map<String, Long> userDataMap,
      List<UserFeedBackDateDTO> infoList,
      Map<String, Long> userCountMap) {
    for (UserFeedBackDateDTO info : infoList) {
      FeedBackTrendDTO feedBackDTO = new FeedBackTrendDTO();
      feedBackDTO.setCreatedDate(info.getChartDate());
      feedBackDTO.setTotalUserCount(userCountMap.get(info.getChartDate()));
      if (userDataMap.containsKey(info.getChartDate())) {
        feedBackDTO.setFeedbackUserCount(
            userDataMap.get(info.getChartDate()) != null
                ? userDataMap.get(info.getChartDate())
                : 0);
      }
      feedTrendList.add(feedBackDTO);
    }
  }

  /**
   * @param user
   * @return
   */
  private void getUserCount(AuthenticatedUser user, List<UserFeedBackDateDTO> dateInfoList) {
    List<Integer> orgs = new ArrayList<>();
    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .filter(o -> o.getOrgId() != user.getOrgId())
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));
    for (UserFeedBackDateDTO dateInfo : dateInfoList) {

      String userRole = user.getRole();

      switch (userRole) {
        case Constants.LW_FSE:
          dateInfo.setCount(
              userFeedBackRepository.getTotalFSEUsersWithDate(
                  Long.valueOf(user.getId()),
                  Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                  DateTimeUtil.getPlusDays(dateInfo.getDate(), 1)));

          break;

        case Constants.DISTRIBUTOR_ADMIN:
          orgs =
              userFeedBackRepository.getDistributorAdminOrgs(
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")), user.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
          List<UserFeedBackRatingsDTO> val = new ArrayList<>();

          if (accessibleOrgs.size() > 0) {

            dateInfo.setCount(
                userFeedBackRepository.getTotalUsersDistributorAdminWithDate(
                    Arrays.asList(getAvailabeRoleForFeedBackForDistributor().split(",")),
                    DateTimeUtil.getPlusDays(dateInfo.getDate(), 1),
                    accessibleOrgs));
          }
          break;
        case Constants.DISTRIBUTOR_FSE:
          orgs =
              userFeedBackRepository.getDistributorFSEOrgs(
                  Long.valueOf(user.getId()),
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
                  user.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
          if (accessibleOrgs.size() > 0) {
            dateInfo.setCount(
                userFeedBackRepository.getTotalDistributorFSEUsersWithDate(
                    Long.valueOf(user.getId()),
                    Arrays.asList(getAvailabeRoleForFeedBackForDistributor().split(",")),
                    DateTimeUtil.getPlusDays(dateInfo.getDate(), 1),
                    accessibleOrgs));
          }
          break;
        default:
          dateInfo.setCount(
              userFeedBackRepository.getTotalUsersWithDate(
                  Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                  DateTimeUtil.getPlusDays(dateInfo.getDate(), 1)));

          break;
      }
    }
  }

  /**
   * @param userRatings
   * @param infoList
   * @param userCountMap
   */
  private void processDefaultUserRating(
      List<UserRatingsDTO> userRatings,
      List<UserFeedBackDateDTO> infoList,
      Map<String, Long> userCountMap) {

    for (UserFeedBackDateDTO info : infoList) {
      UserRatingsDTO ratingDTO = new UserRatingsDTO();
      ratingDTO.setCreatedDate(info.getChartDate());
      ratingDTO.setTotalUsers(userCountMap.get(info.getChartDate()));
      userRatings.add(ratingDTO);
    }
  }

  /**
   * @param userRatingDTO
   * @param userDataMap
   * @param infoList
   * @param userCountMap
   */
  private void processUserRating(
      List<UserRatingsDTO> userRatings,
      Map<String, UserAvgRatingCount> userDataMap,
      List<UserFeedBackDateDTO> infoList,
      Map<String, Long> userCountMap) {
    for (UserFeedBackDateDTO info : infoList) {
      UserRatingsDTO ratingDTO = new UserRatingsDTO();
      ratingDTO.setCreatedDate(info.getChartDate());
      ratingDTO.setTotalUsers(userCountMap.get(info.getChartDate()));
      if (userDataMap.containsKey(info.getChartDate())) {
        ratingDTO.setCount(
            userDataMap.get(info.getChartDate()) != null
                ? userDataMap.get(info.getChartDate()).getUserRatingCount()
                : 0);
        ratingDTO.setAverageRating(
            (float)
                (Math.round(
                        (userDataMap.get(info.getChartDate()) != null
                                ? userDataMap.get(info.getChartDate()).getRating()
                                : 0)
                            * 100)
                    / 100.0));
      }
      userRatings.add(ratingDTO);
    }
  }

  /**
   * @param feedbackDuration
   * @return
   */
  private List<DataModel> getDateDetail(List<UserFeedBackDateDTO> feedbackDuration) {
    List<DataModel> details = new ArrayList<>();
    details.add(getDataModel(feedbackDuration));
    return details;
  }

  /**
   * @param dateDuration
   * @return
   */
  private DataModel getDataModel(List<UserFeedBackDateDTO> dateDurations) {

    DataModel dateModel = new DataModel();
    dateModel.setName("date");
    dateModel.setLabel("Date");
    dateModel.setValueType("DATE");
    dateModel.setValues(
        dateDurations.stream()
            .filter(Objects::nonNull)
            .map(UserFeedBackDateDTO::getChartDate)
            .collect(Collectors.toList())
            .toArray());
    return dateModel;
  }

  /**
   * @param feedTrendList
   * @return
   */
  List<DataModel> getFeedBackUsers(List<FeedBackTrendDTO> feedTrendList) {
    List<DataModel> details = new ArrayList<>();
    DataModel dateModel = new DataModel();
    dateModel.setName("userFeedback");
    dateModel.setLabel("userFeedback");
    dateModel.setValueType("NUMERIC");
    dateModel.setValues(
        feedTrendList.stream()
            .filter(Objects::nonNull)
            .map(FeedBackTrendDTO::getFeedbackUserCount)
            .collect(Collectors.toList())
            .toArray());
    dateModel.setUnits(getUnits(feedTrendList.size()));
    details.add(dateModel);
    return details;
  }

  /**
   * @param feedTrendList
   * @return
   */
  List<DataModel> getTotalUsersFeedBack(List<FeedBackTrendDTO> feedTrendList) {
    List<DataModel> details = new ArrayList<>();
    DataModel dateModel = new DataModel();
    dateModel.setName("users");
    dateModel.setLabel("users");
    dateModel.setValueType("NUMERIC");
    dateModel.setValues(
        feedTrendList.stream()
            .filter(Objects::nonNull)
            .map(FeedBackTrendDTO::getTotalUserCount)
            .collect(Collectors.toList())
            .toArray());
    dateModel.setUnits(getUnits(feedTrendList.size()));
    details.add(dateModel);
    return details;
  }

  /**
   * @param userRatingDTO
   * @return
   */
  private List<DataModel> getUserAvgRatingModel(List<UserRatingsDTO> userRatings) {
    List<DataModel> details = new ArrayList<>();
    DataModel dateModel = new DataModel();
    dateModel.setName("rating");
    dateModel.setLabel("Average Rating");
    dateModel.setValueType("NUMERIC");
    dateModel.setValues(
        userRatings.stream()
            .filter(Objects::nonNull)
            .map(UserRatingsDTO::getAverageRating)
            .collect(Collectors.toList())
            .toArray());
    dateModel.setUnits(getUnits(userRatings.size()));
    details.add(dateModel);
    return details;
  }

  /**
   * @param userRatingDTO
   * @return
   */
  private List<DataModel> getUserModelForRating(List<UserRatingsDTO> userRatings) {
    List<DataModel> details = new ArrayList<>();
    DataModel dateModel = new DataModel();
    dateModel.setName("user");
    dateModel.setLabel("User Feedback Count");
    dateModel.setValueType("NUMERIC");
    dateModel.setValues(
        userRatings.stream()
            .filter(Objects::nonNull)
            .map(UserRatingsDTO::getCount)
            .collect(Collectors.toList())
            .toArray());
    dateModel.setUnits(getUnits(userRatings.size()));
    details.add(dateModel);
    return details;
  }

  /**
   * NCIOT-12522
   *
   * @param userRatingDTO
   * @return
   */
  private List<DataModel> getTotalUserModelForRating(List<UserRatingsDTO> userRatings) {
    List<DataModel> details = new ArrayList<>();
    DataModel dateModel = new DataModel();
    dateModel.setName("totalUsers");
    dateModel.setLabel("Total Users");
    dateModel.setValueType("NUMERIC");
    dateModel.setValues(
        userRatings.stream()
            .filter(Objects::nonNull)
            .map(UserRatingsDTO::getTotalUsers)
            .collect(Collectors.toList())
            .toArray());
    dateModel.setUnits(getUnits(userRatings.size()));
    details.add(dateModel);
    return details;
  }

  /**
   * @param Size
   * @return
   */
  private String[] getUnits(int size) {
    String[] units = new String[size];

    Arrays.fill(units, "");
    return units;
  }

  /**
   * @return
   */
  String getAvailabeRoleForFeedBack() {
    return "Technical User,Quality Manager,Customer Admin,Partner Admin,Partner Hotline,External Customer Tech";
  }

  /**
   * @return
   */
  String getAvailabeRoleForFeedBackForDistributor() {
    return "Technical User,Quality Manager,Customer Admin";
  }

  /**
   * NCIOT-12688
   *
   * @param input
   * @return
   */
  private double getFormattedOutPut(double input) {
    DecimalFormat df = new DecimalFormat("#.#");
    df.setRoundingMode(RoundingMode.DOWN);
    return Double.valueOf((df.format(input)));
  }

  /**
   * @param infoList
   * @return
   */
  private Map<String, Long> getUserCountMap(List<UserFeedBackDateDTO> infoList) {

    return infoList.stream()
        .collect(
            Collectors.toMap(UserFeedBackDateDTO::getChartDate, UserFeedBackDateDTO::getCount));
  }

  /**
   * @param infoList
   * @param user
   * @param feedback interval in days
   * @return map with chart date as key and feedback count as value
   */
  private Map<String, Long> getCountOfFeedBacksByUser(
      List<UserFeedBackDateDTO> infoList, AuthenticatedUser user, Integer feedBackIntervalInDays) {
    Map<String, Long> userDataMap = new HashMap<>();
    String userRole = user.getRole();
    List<Integer> orgs = new ArrayList<>();
    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .filter(o -> o.getOrgId() != user.getOrgId())
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));
    for (UserFeedBackDateDTO dateInfo : infoList) {
      Long userFeedBackCount = null;
      switch (userRole) {
        case Constants.LW_FSE:
          userFeedBackCount =
              userFeedBackRepositoryJdbc.getUserFeedBackCountForFSE(
                  user.getId(),
                  Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                  getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                  DateTimeUtil.getPlusDays(dateInfo.getDate(), 1));
          break;

        case Constants.DISTRIBUTOR_ADMIN:
          orgs =
              userFeedBackRepository.getDistributorAdminOrgs(
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")), user.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }

          List<UserFeedBackRatingsDTO> val = new ArrayList<>();

          if (accessibleOrgs.size() > 0) {
            userFeedBackCount =
                userFeedBackRepositoryJdbc.getUserFeedBackCountForDistributorAdmin(
                    Arrays.asList(getAvailabeRoleForFeedBackForDistributor().split(",")),
                    getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                    DateTimeUtil.getPlusDays(dateInfo.getDate(), 1),
                    accessibleOrgs);
          }
          break;

        case Constants.DISTRIBUTOR_FSE:
          orgs =
              userFeedBackRepository.getDistributorFSEOrgs(
                  Long.valueOf(user.getId()),
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
                  user.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
          if (accessibleOrgs.size() > 0) {
            userFeedBackCount =
                userFeedBackRepositoryJdbc.getUserFeedBackCountForDistributorFSE(
                    String.valueOf(user.getId()),
                    Arrays.asList(getAvailabeRoleForFeedBackForDistributor().split(",")),
                    getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                    DateTimeUtil.getPlusDays(dateInfo.getDate(), 1),
                    accessibleOrgs);
          }
          break;
        default:
          userFeedBackCount =
              userFeedBackRepositoryJdbc.getAllUsersFeedBackCount(
                  Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                  getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                  DateTimeUtil.getPlusDays(dateInfo.getDate(), 1));
          break;
      }
      if (userDataMap.containsKey(dateInfo.getChartDate())) {
        userFeedBackCount = userDataMap.get(dateInfo.getChartDate()) + userFeedBackCount;
      }
      userDataMap.put(dateInfo.getChartDate(), userFeedBackCount);
    }
    return userDataMap;
  }

  /**
   * @param dateToFormat-initial date to get required start date
   * @param feedback interval in days
   * @return start date string
   */
  private String getStartDate(Integer feedBackIntervalInDays, LocalDate dateToFormat) {
    String startDate = null;
    if (Objects.nonNull(feedBackIntervalInDays)) {
      startDate =
          dateToFormat
              .minusDays(feedBackIntervalInDays)
              .format(DateTimeFormatter.ofPattern(Constants.FEED_TREND_DATE_FORMAT));
    } else {
      startDate =
          dateToFormat
              .withDayOfMonth(Constants.DEFAULT_DATE_FORMAT)
              .format(DateTimeFormatter.ofPattern(Constants.FEED_TREND_DATE_FORMAT));
    }
    return startDate;
  }

  private Map<String, UserAvgRatingCount> getAvgRatingOfFeedBacksByUser(
      List<UserFeedBackDateDTO> infoList, AuthenticatedUser user, Integer feedBackIntervalInDays) {
    Map<String, UserAvgRatingCount> userDataMap = new HashMap<>();
    String userRole = user.getRole();
    List<Integer> orgs = new ArrayList<>();
    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .filter(o -> o.getOrgId() != user.getOrgId())
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));
    for (UserFeedBackDateDTO dateInfo : infoList) {
      UserAvgRatingCount userFeedBackCount = null;
      switch (userRole) {
        case Constants.LW_FSE:
          userFeedBackCount =
              userFeedBackRepositoryJdbc.getUserFeedBackAvgRatingForFSE(
                  user.getId(),
                  Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                  getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                  DateTimeUtil.getPlusDays(dateInfo.getDate(), 1));
          break;

        case Constants.DISTRIBUTOR_ADMIN:
          orgs =
              userFeedBackRepository.getDistributorAdminOrgs(
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")), user.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }

          List<UserFeedBackRatingsDTO> val = new ArrayList<>();

          if (accessibleOrgs.size() > 0) {
            userFeedBackCount =
                userFeedBackRepositoryJdbc.getUserFeedBackAvgRatingForDistributorAdmin(
                    Arrays.asList(getAvailabeRoleForFeedBackForDistributor().split(",")),
                    getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                    DateTimeUtil.getPlusDays(dateInfo.getDate(), 1),
                    accessibleOrgs);
          }
          break;

        case Constants.DISTRIBUTOR_FSE:
          orgs =
              userFeedBackRepository.getDistributorFSEOrgs(
                  Long.valueOf(user.getId()),
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
                  user.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
          if (accessibleOrgs.size() > 0) {
            userFeedBackCount =
                userFeedBackRepositoryJdbc.getUserFeedBackAvgRatingForDistributorFSE(
                    String.valueOf(user.getId()),
                    Arrays.asList(getAvailabeRoleForFeedBackForDistributor().split(",")),
                    getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                    DateTimeUtil.getPlusDays(dateInfo.getDate(), 1),
                    accessibleOrgs);
          }
          break;

        default:
          userFeedBackCount =
              userFeedBackRepositoryJdbc.getAllUsersFeedBackAvgRating(
                  Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                  getStartDate(feedBackIntervalInDays, dateInfo.getDate()),
                  DateTimeUtil.getPlusDays(dateInfo.getDate(), 1));
          break;
      }
      /*
       * if (userDataMap.containsKey(dateInfo.getChartDate())) { userFeedBackCount =
       * userDataMap.get(dateInfo.getChartDate()) + userFeedBackCount; }
       */
      userDataMap.put(dateInfo.getChartDate(), userFeedBackCount);
    }
    return userDataMap;
  }
}
