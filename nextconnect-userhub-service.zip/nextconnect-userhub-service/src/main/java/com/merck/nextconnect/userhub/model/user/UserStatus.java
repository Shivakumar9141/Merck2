package com.merck.nextconnect.userhub.model.user;

public enum UserStatus {
  PENDING("Pending"),
  ACTIVE("Active"),
  INACTIVE("Inactive"),
  IN_PROGRESS("In Progress"),
  EXPIRED("Expired"); // Changes made as per NCIOT-11630.

  private final String value;

  public String value() {
    return this.value;
  }

  UserStatus(String value) {
    this.value = value;
  }
}
