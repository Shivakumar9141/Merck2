package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MenuGroupResponse {

  private int menuGroupId;
  private String menuGroupName;
  private int minCount;
  private int maxCount;
}
