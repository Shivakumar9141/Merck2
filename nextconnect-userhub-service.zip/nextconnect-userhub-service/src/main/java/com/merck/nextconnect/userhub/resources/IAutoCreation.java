package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import com.merck.nextconnect.utils.model.OrgAndUserDetailResponse;
import jakarta.mail.MessagingException;

/**
 * @author tah
 *     <p>Interface for AutoCreation
 */
public interface IAutoCreation {

  /**
   * Create org and user and assign device
   *
   * <p>This API is called from data synch scheduler Asynchronously.
   *
   * <p>This API is accessed by multiple thread at the same time and we have to check for existence
   * of data before creating new record.It may create duplication. So to avoid that ,the private
   * methods called inside this method are synchronized accordingly.
   *
   * @param orgAndUserDetail
   * @return
   * @throws DataValidationException
   * @throws DuplicateResourceException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   * @throws MessagingException
   * @throws ResourceNotFoundException
   * @throws CustomException
   */
  OrgAndUserDetailResponse create(OrgAndUserDetail orgAndUserDetail)
      throws DataValidationException,
          DuplicateResourceException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          MessagingException,
          ResourceNotFoundException,
          CustomException;
}
