package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.PhoneNumberOtp;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface PhoneNumberOtpRepository extends JpaRepository<PhoneNumberOtp, Long> {

  public PhoneNumberOtp findFirstByPhoneNumberAndUserProfileUserId(String phoneNumber, long userId);

  public List<PhoneNumberOtp> findByUserProfileUserIdAndOtpNot(long userId, String otp);

  @Transactional
  @Modifying
  @Query(value = "delete from PhoneNumberOtp where userProfile.userId=:user_id")
  public void deleteUserRecord(@Param("user_id") Long userId);
}
