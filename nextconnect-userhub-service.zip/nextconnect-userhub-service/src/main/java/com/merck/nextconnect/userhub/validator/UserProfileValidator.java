package com.merck.nextconnect.userhub.validator;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author SHATHWAR Interface for validating the user profile. Changes made as per NCIOT-11630.
 */
public interface UserProfileValidator {
  public void validateUserProfile(UserProfile userProfile) throws CustomException;

  public void UserProfileImageValidator(MultipartFile image) throws DataValidationException;
}
