/** */
package com.merck.nextconnect.userhub.validator;

import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import org.springframework.stereotype.Service;

/**
 * @author SHATHWAR
 */
@Service
public interface UserhubValidator {

  public void validateOrgStatus(Boolean status) throws DataValidationException;

  void validateForNull(OrgAndUserDetail orgAndUserDetail) throws DataValidationException;

  boolean isValidOrgDetailsPresent(OrgAndUserDetail orgAndUserDetail);

  boolean isValidUserInviteDetailsPresent(OrgAndUserDetail orgAndUserDetail);
}
