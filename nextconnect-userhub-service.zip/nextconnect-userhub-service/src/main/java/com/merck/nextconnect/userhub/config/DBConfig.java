package com.merck.nextconnect.userhub.config;

import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.autoconfigure.DataSourceProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Configuration
public class DBConfig {

  @Primary
  @Bean
  @ConfigurationProperties("spring.datasource.ncapp")
  public DataSourceProperties ncAppDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Primary
  @Bean(name = "profileDataSource")
  @ConfigurationProperties(prefix = "spring.datasource.ncapp.config")
  public HikariDataSource ncAppDataSource() {
    return (HikariDataSource)
        ncAppDataSourceProperties()
            .initializeDataSourceBuilder()
            .type(HikariDataSource.class)
            .build();
  }

  @Bean(name = "namedParameterJdbcTemplate")
  public NamedParameterJdbcTemplate namedParameterJdbcTemplate(
      @Qualifier("profileDataSource") DataSource dataSource) {
    return new NamedParameterJdbcTemplate(dataSource);
  }

  @Bean(name = "deviceNamedParameterJdbcTemplate")
  public NamedParameterJdbcTemplate jdbcTemplateLogs(DataSource dataSource) {
    return new NamedParameterJdbcTemplate(dataSource);
  }
}
