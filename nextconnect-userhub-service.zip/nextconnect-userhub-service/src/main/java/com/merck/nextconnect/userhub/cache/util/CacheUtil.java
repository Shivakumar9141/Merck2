package com.merck.nextconnect.userhub.cache.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class CacheUtil {

  public static final Map<String, String> HazelcastMapInfo =
      Collections.unmodifiableMap(
          new HashMap<String, String>() {
            private static final long serialVersionUID = 1L;

            {
              put("EntityPrivilegeMap", "Used for holding Entity Privileges");
              put("DeviceGroupPrivilegeMap", "Stores device group Privileges");
              put("DeviceTypePrivilegeMap", "Stores Privileges for DeviceType");
              put("DevicePrivilegeMap", "Stores the privileges for all the devices");
              put("cardPrivilegeMap", "Stores cards based on DeviceType");
              put("tokenMap", "Stores the Accesstoken information");
              put("certificateMap", "Stores the certificate id when certificate is created");
              put(
                  "deviceIdSessionIdMap",
                  "Stores the deviceId and the sessionid to get the status of the notification");
              put("deviceInformationMap", "Stores the notification information");
              put("userLastAccessTimeMap", "Stores the Last Access time of each user");
              put(
                  "userDeviceRemoteTokenMap",
                  "Stores the information for connection of remote device and also Stores User token ");
              put("topicid", "Store the topicid and deviceid");
              put("conditionInformationMap", "Stores NEM events config conditions");
              put("nemInformationMap", "Stores NEM events related measures");
              put(
                  "masterConfigInformationMap",
                  "This map stores device_measure_master_config table data");
            }
          });
}
