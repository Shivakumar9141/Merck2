package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.utils.common.entities.Language;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public interface ILanguage {

  List<Language> getAll();
}
