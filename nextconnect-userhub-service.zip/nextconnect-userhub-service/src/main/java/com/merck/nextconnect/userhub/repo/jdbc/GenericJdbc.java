package com.merck.nextconnect.userhub.repo.jdbc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class GenericJdbc {
  static final Logger LOGGER = LoggerFactory.getLogger(GenericJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  /**
   * update table nc_device_access_request and mark the device as approved
   *
   * @param deviceId
   * @param userId
   */
  public void updateDeviceAccessRequestStatusApproved(Long deviceId, Long userId) {

    LOGGER.debug("Updating status as approved for deviceId :{}  and userId {}", deviceId, userId);
    String sql =
        "Update nc_device_access_request set status_id = (select status_id from nc_device_access_request_status where status_name='APPROVED') where device_id=:deviceId and requested_by =:userId";
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("deviceId", deviceId);
    parameters.addValue("userId", userId);
    namedParameterJdbcTemplate.update(sql, parameters);
  }

  /**
   * deleting the device request entry which is in approved status from the user
   *
   * @param deviceId
   * @param userId
   */
  public void deleteRequestDeviceForDeviceFromUser(long deviceId, long userId) {
    LOGGER.debug("deleting the entry for deviceId :{}  and userId {}", deviceId, userId);
    String sql =
        "delete from nc_device_access_request where status_id = (select status_id from nc_device_access_request_status where status_name='APPROVED') and device_id=:deviceId and requested_by =:userId";
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("deviceId", deviceId);
    parameters.addValue("userId", userId);
    namedParameterJdbcTemplate.update(sql, parameters);
  }
}
