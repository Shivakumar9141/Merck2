package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * interface to perform privileges operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface Iprivileges {

  /**
   * add a privilege
   *
   * @param privilegeInfo - privilege info
   */
  long add(PrivilegeInfo privilegeInfo);

  /**
   * delete a privilege
   *
   * @param privilegeId - id of the privilege
   */
  void delete(long privilegeId);

  /**
   * get all privileges
   *
   * @param filterBy - filter by criteria
   * @return list of privileges
   */
  List<Privilege> getAll(String filterBy);

  /**
   * get all entities
   *
   * @return list of entities
   */
  List<Entities> getAllEntities();
}
