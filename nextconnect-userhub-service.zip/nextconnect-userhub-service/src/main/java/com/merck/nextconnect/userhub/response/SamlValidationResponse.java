package com.merck.nextconnect.userhub.response;

import lombok.Getter;
import lombok.Setter;
import org.joda.time.DateTime;
import org.opensaml.xml.signature.Signature;
import org.springframework.stereotype.Component;

@Component
public class SamlValidationResponse {

  @Setter @Getter private boolean validationStatus;

  @Setter @Getter private Signature signature;

  @Setter @Getter private DateTime notBefore;

  @Setter @Getter private DateTime notOnOrAfter;

  @Setter @Getter private String emailAdress;
}
