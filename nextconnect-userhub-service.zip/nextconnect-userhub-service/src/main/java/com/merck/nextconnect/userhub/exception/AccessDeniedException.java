package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

/**
 * Exception class to throw access denied exception based on access
 *
 * @author <a href="mailto:thippeswamy.a-h@merckgroup.com">Thippeswamy A H </a>
 */
public class AccessDeniedException extends CustomException {

  private static final long serialVersionUID = 1L;

  public AccessDeniedException(String msg) {
    super(msg);
  }

  public AccessDeniedException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes);
  }

  public AccessDeniedException(CustomErrorCodes customErrorCodes, List<String> params) {
    super(customErrorCodes, params);
  }
}
