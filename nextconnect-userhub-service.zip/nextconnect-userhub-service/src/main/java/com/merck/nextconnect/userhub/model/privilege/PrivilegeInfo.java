package com.merck.nextconnect.userhub.model.privilege;

public class PrivilegeInfo {

  private String resourceType;
  private String operation;

  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public String getResourceType() {
    return resourceType;
  }

  public void setResourceType(String resourceType) {
    this.resourceType = resourceType;
  }
}
