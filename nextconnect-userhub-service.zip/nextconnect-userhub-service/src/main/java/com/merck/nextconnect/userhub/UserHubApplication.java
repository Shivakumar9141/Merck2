package com.merck.nextconnect.userhub;

import com.merck.nextconnect.storage.exception.FileStorageException;
import com.merck.nextconnect.storage.service.FileStorageServiceFactory;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import org.apache.hc.client5.http.ConnectionKeepAliveStrategy;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.TrustSelfSignedStrategy;
import org.apache.hc.core5.http.HttpHeaders;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.apache.hc.core5.util.TimeValue;
import org.apache.hc.core5.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.boot.web.server.servlet.context.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableAsync
@EnableAutoConfiguration
@EnableTransactionManagement
@EnableCaching
@ServletComponentScan
@EntityScan(basePackages = {"com.merck.nextconnect.*"})
@EnableJpaRepositories(basePackages = {"com.merck.nextconnect.*"})
@ComponentScan("com.merck.*")
@PropertySource("classpath:auth.properties")
@PropertySource("classpath:db.properties")
@PropertySource("classpath:ldap.properties")
@PropertySource("classpath:mailconfig.properties")
public class UserHubApplication {

  private static final Logger LOGGER = LoggerFactory.getLogger(UserHubApplication.class);

  public static void main(String[] args) {
    SpringApplication.run(UserHubApplication.class, args);
  }

  // Determines the timeout in milliseconds until a connection is established.
  private static final Timeout CONNECT_TIMEOUT = Timeout.ofMilliseconds(30000);

  // The timeout when requesting a connection from the connection manager.
  private static final Timeout REQUEST_TIMEOUT = Timeout.ofMilliseconds(30000);

  // The timeout for waiting for data
  private static final Timeout SOCKET_TIMEOUT = Timeout.ofMilliseconds(60000);

  private static final int MAX_TOTAL_CONNECTIONS = 200;
  private static final int MAX_TOTAL_CONNECTIONS_PER_ROUTE = 100;
  private static final long DEFAULT_KEEP_ALIVE_TIME_MILLIS = 20 * 1000;
  private static final TimeValue CLOSE_IDLE_CONNECTION_WAIT_TIME_SECS =
      Timeout.ofMilliseconds(30000);

  @Autowired private CloseableHttpClient closeableHttpClient;

  @Bean(name = "restTemplate")
  public RestTemplate getPubPostbackRestTemplate() {
    HttpComponentsClientHttpRequestFactory clientHttpRequestFactory =
        new HttpComponentsClientHttpRequestFactory();
    clientHttpRequestFactory.setHttpClient(closeableHttpClient);
    return new RestTemplate(clientHttpRequestFactory);
  }

  @Bean
  public CloseableHttpClient httpClient() {

    RequestConfig requestConfig =
        RequestConfig.custom()
            .setConnectionRequestTimeout(REQUEST_TIMEOUT)
            .setConnectTimeout(CONNECT_TIMEOUT)
            .setResponseTimeout(SOCKET_TIMEOUT)
            .build();

    return HttpClients.custom()
        .setDefaultRequestConfig(requestConfig)
        .setConnectionManager(poolingConnectionManager())
        .setKeepAliveStrategy(connectionKeepAliveStrategy())
        .build();
  }

  @Bean
  public PoolingHttpClientConnectionManager poolingConnectionManager() {
    SSLContextBuilder builder = new SSLContextBuilder();
    try {
      builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
    } catch (NoSuchAlgorithmException | KeyStoreException e) {
      LOGGER.error(
          "Pooling Connection Manager Initialisation failure because of " + e.getMessage(), e);
    }

    SSLConnectionSocketFactory sslsf = null;
    try {
      sslsf = new SSLConnectionSocketFactory(builder.build());
    } catch (KeyManagementException | NoSuchAlgorithmException e) {
      LOGGER.error(
          "Pooling Connection Manager Initialisation failure because of " + e.getMessage(), e);
    }

    Registry<ConnectionSocketFactory> socketFactoryRegistry =
        RegistryBuilder.<ConnectionSocketFactory>create()
            .register("https", sslsf)
            .register("http", new PlainConnectionSocketFactory())
            .build();

    PoolingHttpClientConnectionManager poolingConnectionManager =
        new PoolingHttpClientConnectionManager(socketFactoryRegistry);
    poolingConnectionManager.setMaxTotal(MAX_TOTAL_CONNECTIONS);
    poolingConnectionManager.setDefaultMaxPerRoute(MAX_TOTAL_CONNECTIONS_PER_ROUTE);
    return poolingConnectionManager;
  }

  @Bean
  public ConnectionKeepAliveStrategy connectionKeepAliveStrategy() {
    return (response, context) -> {
      LOGGER.info("Rest response::" + response);
      // Get the Keep-Alive header
      String keepAlive = null;
      if (response.getFirstHeader(HttpHeaders.CONNECTION) != null) {
        keepAlive = response.getFirstHeader(HttpHeaders.CONNECTION).getValue();
      }
      if ("keep-alive".equalsIgnoreCase(keepAlive)) {
        // Parse the Keep-Alive timeout
        String timeoutValue = null;
        if (response.getFirstHeader(HttpHeaders.KEEP_ALIVE) != null) {
          timeoutValue = response.getFirstHeader(HttpHeaders.KEEP_ALIVE).getValue();
          if (timeoutValue != null) {
            String[] params = timeoutValue.split(",");
            for (String param : params) {
              String[] keyValue = param.split("=");
              if (keyValue.length == 2 && "timeout".equalsIgnoreCase(keyValue[0].trim())) {
                long timeoutInSeconds = Long.parseLong(keyValue[1].trim());
                return TimeValue.ofSeconds(timeoutInSeconds); // Convert seconds to TimeValue
              }
            }
          }
        }
      }
      // Default keep-alive time if no "timeout" parameter is found
      return TimeValue.ofMilliseconds(DEFAULT_KEEP_ALIVE_TIME_MILLIS);
    };
  }

  @Bean
  public Runnable idleConnectionMonitor(
      final PoolingHttpClientConnectionManager connectionManager) {
    return new Runnable() {
      @Override
      @Scheduled(fixedDelay = 10000)
      public void run() {
        try {
          if (connectionManager != null) {
            LOGGER.trace("run IdleConnectionMonitor - Closing expired and idle connections...");
            connectionManager.closeExpired();
            connectionManager.closeIdle(CLOSE_IDLE_CONNECTION_WAIT_TIME_SECS);
          } else {
            LOGGER.trace(
                "run IdleConnectionMonitor - Http Client Connection manager is not initialised");
          }
        } catch (Exception e) {
          LOGGER.error(
              "run IdleConnectionMonitor - Exception occurred. msg={}, e={}", e.getMessage(), e);
        }
      }
    };
  }

  @Bean
  public OpenAPI openApi() {
    return new OpenAPI()
        .components(
            new Components()
                .addSecuritySchemes(
                    "bearerToken",
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .in(SecurityScheme.In.HEADER)
                        .bearerFormat("JWT")
                        .scheme("bearer")))
        .addSecurityItem(new SecurityRequirement().addList("bearerToken"))
        .info(
            new Info()
                .title("NextConnect Platform API")
                .description(
                    "The NextConnect Platform API exposes APIs which can expose information about devices provisioned ,"
                        + "users registered and can expose analytics data regarding the device maintainance and usage.")
                .version("0.1")
                .license(
                    new License()
                        .name("Merck License")
                        .url("http://www.merck.com/licensing/home.html")));
  }

  /**
   * @param key
   * @return
   * @throws FileStorageException
   */
  @Bean
  public FileStorageServiceFactory getFileStorageServiceFactoryBean(
      @Value("${nextconnect.filestorage.servicetype.key}") String key) throws FileStorageException {
    return new FileStorageServiceFactory(key);
  }
}
