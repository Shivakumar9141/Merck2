package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.model.CoveredProductDTO;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author tah
 *     <p>This class is for JDBC Template implementation to use native sql
 */
@Repository
public class CoveredProductRepositoryJdbc {

  static final Logger LOGGER = LoggerFactory.getLogger(CoveredProductRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  private static final String SQL_SELECT_SM_COVERED_PRODUCT_ID =
      "select distinct cp.sm_covered_product_id from nc_sm_service_contract sc join nc_sm_covered_product cp on sc.service_contract_id=cp.service_contract_id inner join nc_contract_type ct on cp.service_level=ct.contract_name where ct.contract_type='M' and sc.service_contract_status in (:status) AND DATE(sc.service_contract_start_date) <= DATE(now()) and DATE(sc.service_contract_end_date) >= DATE(now())  and cp.device_id = :deviceId";

  private static final String SQL_SELECT_DEVICE_ID =
      "SELECT distinct cp.device_id FROM nc_sm_covered_product cp INNER JOIN nc_contract_type ct on cp.service_level=ct.contract_name WHERE ct.contract_type='M' AND cp.service_contract_id IN (SELECT service_contract_id from nc_sm_service_contract WHERE service_contract_status IN (:status) AND sm_service_contract_id = :smServiceContractId)";

  public List<CoveredProductDTO> getSmCoveredProductId(Long deviceId) {
    List<CoveredProductDTO> coveredProductDTOList = new ArrayList<CoveredProductDTO>();

    if (deviceId == null) {
      return coveredProductDTOList;
    }

    try {
      MapSqlParameterSource parameters = new MapSqlParameterSource();
      parameters.addValue("deviceId", deviceId);
      parameters.addValue(
          "status",
          com.merck.nextconnect.utils.common.Constants.ACTIVE_SERVICE_CONTRACT_STATUS_LIST);
      coveredProductDTOList =
          namedParameterJdbcTemplate.query(
              SQL_SELECT_SM_COVERED_PRODUCT_ID,
              parameters,
              (rs, rowNum) ->
                  CoveredProductDTO.builder()
                      .smCoveredProductId(rs.getString("cp.sm_covered_product_id"))
                      .build());
    } catch (Exception e) {
      LOGGER.error("Exception occured in getSmCoveredProductId while calling DB", e);
    }

    return coveredProductDTOList;
  }

  /**
   * Gets the covered products(devices) for the provided sm service contract ID
   *
   * @param smServiceContractId
   * @return
   */
  public List<Long> getcoveredDevicesUnderSmServiceContract(String smServiceContractId) {
    List<Long> deviceIdList = new ArrayList<Long>();

    if (StringUtils.isBlank(smServiceContractId)) {
      return deviceIdList;
    }

    try {
      MapSqlParameterSource parameters = new MapSqlParameterSource();
      parameters.addValue("smServiceContractId", smServiceContractId);
      parameters.addValue(
          "status",
          com.merck.nextconnect.utils.common.Constants.ACTIVE_SERVICE_CONTRACT_STATUS_LIST);
      deviceIdList =
          namedParameterJdbcTemplate.queryForList(SQL_SELECT_DEVICE_ID, parameters, Long.class);
    } catch (Exception e) {
      LOGGER.error(
          "Exception occured in getcoveredDevicesUnderSmServiceContract while calling DB", e);
    }
    LOGGER.debug("deviceIdList : {} ", deviceIdList);
    return deviceIdList;
  }
}
