package com.merck.nextconnect.userhub.model.org;

public class OrgSettingsDto {

  private String logo;

  private String theme;

  private String appName;

  public OrgSettingsDto() {}

  public OrgSettingsDto(String logo, String theme, String appName) {
    this.logo = logo;
    this.theme = theme;
    this.appName = appName;
  }

  public String getLogo() {
    return logo;
  }

  public void setLogo(String logo) {
    this.logo = logo;
  }

  public String getTheme() {
    return theme;
  }

  public void setTheme(String theme) {
    this.theme = theme;
  }

  public String getAppName() {
    return appName;
  }

  public void setAppName(String appName) {
    this.appName = appName;
  }
}
