/**
 * RoleResponseEntity.java
 *
 * @author Prateek Pande
 *     <p>Copyright © 2021 Merck. All rights reserved.
 */
package com.merck.nextconnect.userhub.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class RoleResponseEntity {

  private long roleId;

  private String name;
}
