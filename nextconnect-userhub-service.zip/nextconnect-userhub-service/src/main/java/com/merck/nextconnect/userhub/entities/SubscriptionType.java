package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "nc_subscription_type")
public class SubscriptionType implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "subscription_type_id")
  private Long subscriptionTypeId;

  @Column(name = "subscription_type_name")
  private String subscriptionTypeName;

  @OneToMany(mappedBy = "subscriptionType", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  private Set<SubscriptionCategory> subscriptionCategories;
}
