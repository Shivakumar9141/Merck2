package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * this is used to the relation between
 *
 * @author clukose
 */
@Entity
@Table(name = "nc_user_menu")
@Getter
@Setter
public class UserMenu implements Serializable {

  /** */
  private static final long serialVersionUID = 7508084706540098050L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long userMenuId;

  @Column(name = "sequence")
  private int sequence;

  @Column(name = "is_visible")
  private boolean isVisible;

  @ManyToOne
  @JoinColumn(name = "menu_id")
  private Menu menu;

  @ManyToOne
  @JoinColumn(name = "user_id")
  private UserProfile userProfile;
}
