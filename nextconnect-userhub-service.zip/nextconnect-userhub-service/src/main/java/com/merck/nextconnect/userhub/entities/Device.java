package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "NC_DEVICES")
public class Device {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long deviceId;

  @Column(columnDefinition = "boolean default false")
  private Boolean connectivity;

  @Column(columnDefinition = "boolean default false")
  private boolean status;

  @Column private String uuid;

  @Pattern(regexp = ".*\\S.*")
  private String devicename;

  @Pattern(regexp = ".*\\S.*")
  private String serialno;

  @Pattern(regexp = ".*\\S.*")
  private String securitykey;

  @OneToOne
  @JoinColumn(name = "DEVICE_TYPE_ID")
  private DeviceType deviceType;

  @Column private Timestamp installedDate; // Made changes as per NCIOT-12313.

  @Column private Timestamp shippedDate;

  @Column private boolean isDealer;

  @Column(name = "sm_email")
  private String emailId;

  @Column private String productCatalogNo;

  @Column(columnDefinition = "boolean default false")
  private boolean deleted;

  @Column private String soldTo;

  @Column private String billTo;

  @Column private String smFirstName;

  @Column private String smLastName;

  @Column private String smDeviceId;

  public Device() {}

  public Device(String devicename, String serialno, String securitykey) {
    this.devicename = devicename;
    this.serialno = serialno;
    this.securitykey = securitykey;
  }
}
