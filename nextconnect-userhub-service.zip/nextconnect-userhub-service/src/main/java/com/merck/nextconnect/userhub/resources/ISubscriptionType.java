package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public interface ISubscriptionType {

  public List<SubscriptionTypeDTO> getAllSubscription();
}
