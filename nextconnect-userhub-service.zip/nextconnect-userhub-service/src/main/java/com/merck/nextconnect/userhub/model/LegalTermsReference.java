package com.merck.nextconnect.userhub.model;

/**
 * @author SHATHWAR
 */
public enum LegalTermsReference {
  NOFILTER("no_filter"),
  ORGTYPE("org_type");

  private final String value;

  public String value() {
    return this.value;
  }

  private LegalTermsReference(String value) {
    this.value = value;
  }
}
