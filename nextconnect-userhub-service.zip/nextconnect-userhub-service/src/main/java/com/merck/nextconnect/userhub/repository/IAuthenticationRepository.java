package com.merck.nextconnect.userhub.repository;

import org.springframework.stereotype.Component;

/** interface to do authentication */
/**
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal</a>
 */
@Component
public interface IAuthenticationRepository {

  /**
   * Authenticate with LDAP
   *
   * @param username - user name
   * @param password - user password
   * @return authed
   */
  boolean authenticateByEmail(String username, String password);

  /**
   * Authenticate with LDAP
   *
   * @param username - user name
   * @param password - user password
   * @return authed
   */
  boolean authenticateByUsername(String username, String password);
}
