/**
 * OrganizationResponseEntity.java
 *
 * @author Prateek Pande
 *     <p>Copyright © 2021 Merck. All rights reserved.
 */
package com.merck.nextconnect.userhub.response;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class OrganizationResponseEntity {

  private int id;

  private String name;

  private String type;

  private Boolean status;
}
