package com.merck.nextconnect.userhub.model;

import lombok.Data;

/**
 * @author clukose
 */
@Data
public class MenuGroupRequest {
  private long roleId;
  private long userId;
  private int orgId;
}
