package com.merck.nextconnect.userhub.model.user;

import java.util.List;

public class UserLoginInfo {

  private String userName;
  private List<String> authenticationTypes;

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public List<String> getAuthenticationTypes() {
    return authenticationTypes;
  }

  public void setAuthenticationTypes(List<String> authenticationTypes) {
    this.authenticationTypes = authenticationTypes;
  }
}
