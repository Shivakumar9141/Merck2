package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.FeedBackDTO;
import com.merck.nextconnect.userhub.model.FeedBackStatus;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.UserDefaulterFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackPageDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingDTO;
import com.merck.nextconnect.userhub.model.user.UserDataList;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.util.List;

public interface IUserFeedBackService {

  public UserDataDTO createFeedBack(UserFeedBackDTO feedBackDTO, String userId)
      throws CustomException;

  public FeedBackDTO getAllUsersFeedBack(AuthenticatedUser user) throws CustomException;

  public FeedBackStatus getFeedBack(Long userId) throws CustomException;

  public FeedBackDTO getAllFeedBack(Long userId) throws CustomException;

  public UserFeedBackFacets getUserFeedBackFacets() throws CustomException;

  public UserFeedBackPageDTO getAllFeedBacks(FetchCriteria fetchCriteria);

  public UserFeedBackRatingDTO getRatingDetails(
      Long userId, AuthenticatedUser authUser, List<String> filterBy) throws CustomException;

  public UserDefaulterFacets getFeedBackDefaultersFacets() throws CustomException;

  public UserDataList getFeedBackDefaulters(FetchCriteria fetchCriteria) throws CustomException;

  public String getNoFeedBackSortByEntries(List<String> filterBy, String sortBy);
}
