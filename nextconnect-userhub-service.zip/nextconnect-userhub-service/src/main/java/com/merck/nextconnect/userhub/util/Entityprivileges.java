package com.merck.nextconnect.userhub.util;

public class Entityprivileges {
  public static final String EMAIL_NOTIFICATION_SUBSCRIPTION =
      "hasAuthority('subscribe_notifications')";

  public static final String DELETE_PARTNER_ORG_TYPE_PRIVILEGE = "delete_partnerorgtype";
  public static final String DELETE_ALL_ORG_TYPE_PRIVILEGE = "delete_allorgtypes";
  public static final String DELETE_CUSTOMER_ORG_TYPE_PRIVILEGE = "delete_customerorgtype";
}
