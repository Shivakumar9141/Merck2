package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.CountryDTO;
import com.merck.nextconnect.userhub.model.CountryTimezoneDTO;
import com.merck.nextconnect.userhub.resources.ICountry;
import com.merck.nextconnect.userhub.resources.IRegion;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Country;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
@RequestMapping("/api/countries")
public class CountryController {

  @Autowired private ICountry iCountry;

  @Autowired private IRegion iRegion;

  @Operation(description = "user Location", tags = "Users")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET)
  public ResponseEntity<List<Country>> getCountries(
      @Parameter(
              name = "searchBy",
              description = "search category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy) {
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.COUNTRY, Constants.GET, null));
    if (searchBy == null) {
      searchBy = Constants.EMPTY_STRING;
    }
    return new ResponseEntity<>(iCountry.getCountries(searchBy), HttpStatus.OK);
  }

  @Operation(description = "List of Countries by Region", tags = "Users")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/region/{regionId}")
  public ResponseEntity<List<CountryDTO>> getCountryByRegionId(
      @Parameter(
              name = "regionId",
              description = "Region Id",
              schema = @Schema(defaultValue = ""),
              required = true)
          @PathVariable(value = "regionId", required = true)
          List<Integer> regionId) {
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.Region, Constants.GET, null));
    return new ResponseEntity<>(iRegion.getCountryByRegionId(regionId), HttpStatus.OK);
  }

  @Operation(description = "List user Timezone", tags = "Users")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/timezone")
  public ResponseEntity<List<CountryTimezoneDTO>> getCountriesTimezone(
      @Parameter(
              name = "countryId",
              description = "Country Id",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "countryId", required = false)
          Integer countryId) {

    List<CountryTimezoneDTO> countryTimezones = iCountry.getCountriesTimezone(countryId);
    if (Optional.ofNullable(countryTimezones).isPresent())
      return new ResponseEntity<List<CountryTimezoneDTO>>(countryTimezones, HttpStatus.OK);
    return new ResponseEntity<List<CountryTimezoneDTO>>(new ArrayList<>(), HttpStatus.NOT_FOUND);
  }
}
