package com.merck.nextconnect.userhub.config;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class MailConfig {

  @Autowired private JavaMailSender javaMailSender;

  @Value("${nextconnect.email.headerName}")
  private String headerName;

  @Value("${nextconnect.email.headerValue}")
  private String headerValue;

  @Value("${nextconnect.email.fromemail}")
  private String email;

  public void send(String to, String subject, String body, String environment)
      throws MessagingException, AddressException {

    MimeMessage message = javaMailSender.createMimeMessage();
    message.setFrom(new InternetAddress(email));
    Base64.Encoder encoder = Base64.getEncoder();
    String Value = encoder.encodeToString(headerValue.getBytes());
    message.setHeader(headerName, Value);
    MimeMessageHelper helper;
    helper = new MimeMessageHelper(message, true); // true indicates
    if (!environment.equalsIgnoreCase("PROD")) {
      subject = environment + "-" + subject;
    }
    helper.setSubject(subject);
    helper.setTo(to);
    helper.setText(body, true); // true indicates html
    // continue using helper object for more functionalities like adding
    // attachments, etc.

    javaMailSender.send(message);
  }
}
