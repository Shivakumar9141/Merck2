package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserProfileSettingsDTO {

  private Integer displayPerPage;
  private boolean subscribeUserFeedBackReport;
}
