package com.merck.nextconnect.userhub.model.user;

public class UserPatch {

  private Boolean status;
  private Long roleId;
  private Integer countryId;
  private Integer timeZoneId;
  private String phoneNumber;
  private Integer languageId;
  private Integer dateformatId;
  private String firstName;
  private String lastName;
  private String isdCode;
  private int businessDomainId;

  public Boolean getStatus() {
    return status;
  }

  public void setStatus(Boolean status) {
    this.status = status;
  }

  public Long getRoleId() {
    return roleId;
  }

  public void setRoleId(Long roleId) {
    this.roleId = roleId;
  }

  public Integer getCountryId() {
    return countryId;
  }

  public void setCountryId(Integer countryId) {
    this.countryId = countryId;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public Integer getTimeZoneId() {
    return timeZoneId;
  }

  public void setTimeZoneId(Integer timeZoneId) {
    this.timeZoneId = timeZoneId;
  }

  public Integer getLanguageId() {
    return languageId;
  }

  public void setLanguageId(Integer languageId) {
    this.languageId = languageId;
  }

  public Integer getDateFormatId() {
    return dateformatId;
  }

  public void setDateFormatId(Integer dateformatId) {
    this.dateformatId = dateformatId;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getIsdCode() {
    return isdCode;
  }

  public void setIsdCode(String isdCode) {
    this.isdCode = isdCode;
  }

  public int getBusinessDomainId() {
    return businessDomainId;
  }

  public void setBusinessDomainId(int businessDomainId) {
    this.businessDomainId = businessDomainId;
  }
}
