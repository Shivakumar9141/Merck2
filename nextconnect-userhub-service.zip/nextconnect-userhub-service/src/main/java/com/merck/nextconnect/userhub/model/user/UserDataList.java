package com.merck.nextconnect.userhub.model.user;

import com.merck.nextconnect.userhub.model.UserDataDTO;
import java.util.List;
import lombok.Data;

@Data
public class UserDataList {

  private List<UserDataDTO> users;
  private long totalPages;
  private long recordCount;
}
