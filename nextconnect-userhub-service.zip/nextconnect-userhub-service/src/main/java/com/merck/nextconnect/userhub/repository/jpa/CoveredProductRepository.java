package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.CoveredProduct;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CoveredProductRepository extends JpaRepository<CoveredProduct, Long> {

  @Query(
      "select cp.serviceContractId from CoveredProduct cp where cp.deviceId = :deviceId and cp.serviceLevel in :serviceLevel")
  Set<Long> findServiceContractIdByDeviceIdAndServiceLevel(
      @Param("deviceId") long deviceId, @Param("serviceLevel") List<String> serviceLevel);

  @Query(
      "select distinct cp.deviceId from CoveredProduct cp where cp.serviceContractId in :serviceContractIds")
  List<Long> getDeviceIdsFromServiceContractId(
      @Param("serviceContractIds") List<String> serviceContractIds);
}
