package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import org.springframework.security.core.AuthenticationException;

/** Thrown when login credentials are wrong */
public class LoginAuthenticationException extends AuthenticationException {

  /** */
  private static final long serialVersionUID = 1L;

  private String errorCode;

  public LoginAuthenticationException(String msg) {
    super(msg);
  }

  public LoginAuthenticationException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes.getDescription());
    this.errorCode = customErrorCodes.getErrorCode();
  }

  public LoginAuthenticationException(CustomErrorCodes customErrorCodes, String msg) {
    super(msg);
    this.errorCode = customErrorCodes.getErrorCode();
  }

  public String getErrorCode() {
    return errorCode;
  }
}
