package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.AuthPartnerPeripheralSupplierRepository;
import com.merck.nextconnect.authfilter.repository.jpa.PartnerTypeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.RolesOrgPrivilegeRepository;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.resources.IOrgPrivilegeProvider;
import com.merck.nextconnect.authfilter.resources.impl.OrgEntitesFactory;
import com.merck.nextconnect.authfilter.resources.org.IOrgBuilderFacade;
import com.merck.nextconnect.authfilter.resources.org.IOrgCreator;
import com.merck.nextconnect.authfilter.resources.org.impl.OrgFactory;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.model.org.OrgSettingsDto;
import com.merck.nextconnect.userhub.model.privilege.OrgPrivilege;
import com.merck.nextconnect.userhub.repository.jpa.OrgDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrgPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrgSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class UserOrgPrivileges {

  static final Logger logger = LoggerFactory.getLogger(UserOrgPrivileges.class);

  @Autowired OrgPrivilegesRepository orgPrivilegesRepo;

  @Autowired OrgSettingsRepository orgSettingsRepo;

  @Autowired IOrgPermissions orgPermissions;

  @Autowired OrgEntitesFactory orgEntitesFactory;

  @Autowired IOrgPrivilegeProvider orgPrivilegeProvider;

  @Autowired OrganizationRepository orgRepo;

  @Autowired IOrgCreator orgCreator;

  @Autowired IOrgBuilderFacade orgBuilderFacade;

  @Autowired RolesOrgPrivilegeRepository rolesOrgPrivilegeRepo;

  @Autowired OrgFactory orgFactory;

  @Autowired PartnerTypeRepository partnerTypeRepo;

  @Autowired AuthPartnerPeripheralSupplierRepository authPartnerPeripheralSupplierRepo;

  @Autowired private OrgDevicePrivilegeRepository orgDevicePrivilegeRepository;

  private static final String DEVICE = "device";

  private static final String CARD = "card";

  public List<OrgPrivilege> getOrgPrivileges() {
    List<OrgPrivilege> privileges = new ArrayList<OrgPrivilege>();
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    privileges = orgPrivilegesRepo.getPrivileges(authUser.getOrgId());
    return privileges;
  }

  public OrgSettingsDto getOrgSpecificSettings() {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    OrgSettingsDto orgSettings = orgSettingsRepo.getOrgSettings(authUser.getOrgId());
    return orgSettings;
  }

  public boolean hasPermission(long deviceTypeId) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return orgPermissions.hasPermission(authUser.getOrgId(), deviceTypeId);
  }

  public void addDevicesToOrg(int orgId, List<Long> deviceIds) {
    List<Long> orgDevices = orgEntitesFactory.getOrgEntities(DEVICE).getAll(orgId);
    deviceIds.stream()
        .filter(d -> !orgDevices.contains(d.longValue()))
        .forEach(
            d -> {
              orgEntitesFactory.getOrgEntities(DEVICE).addToOrg(orgId, d, false);
            });
  }

  public boolean hasCardAccess(long cardId) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return orgEntitesFactory.getOrgEntities(CARD).hasAccess(authUser.getOrgId(), cardId);
  }

  public List<OrgDto> getOrgs(OrgPrivileges orgPrivileges, String searchBy, String type) {
    AuthenticatedUser authenticatedUser = UserhubUtils.getAuthenticatedUser();
    List<OrgDto> orgs = new ArrayList<>();
    if (searchBy != null) {
      orgs.addAll(
          orgPrivilegeProvider
              .getOrgsByRolePrivilege(authenticatedUser.getRoleId(), orgPrivileges, type)
              .stream()
              .filter(o -> o.getName().toLowerCase().contains(searchBy.toLowerCase()))
              .map(
                  o ->
                      new OrgDto(
                          o.getId(),
                          o.getName(),
                          o.getType(),
                          o.getDescription(),
                          o.getStatus(),
                          o.isDeleted()))
              .collect(Collectors.toList()));
      orgs.stream()
          .filter(o -> o.getOrgId() != authenticatedUser.getOrgId())
          .findAny()
          .ifPresent(
              o -> {
                Organization org = orgRepo.findById(authenticatedUser.getOrgId()).get();
                Optional.ofNullable(org)
                    .filter(og -> og.getName().toLowerCase().contains(searchBy.toLowerCase()))
                    .ifPresent(
                        og -> {
                          if (type == null || type.equalsIgnoreCase(org.getType())) {
                            orgs.add(
                                new OrgDto(
                                    org.getId(),
                                    org.getName(),
                                    org.getType(),
                                    o.getDescription(),
                                    o.getStatus(),
                                    o.isDeleted()));
                          }
                        });
              });
      Optional.ofNullable(orgs)
          .filter(o -> orgs.isEmpty())
          .ifPresent(
              o -> {
                Organization org = orgRepo.findById(authenticatedUser.getOrgId()).get();
                Optional.ofNullable(org)
                    .filter(og -> og.getName().toLowerCase().contains(searchBy.toLowerCase()))
                    .ifPresent(
                        og -> {
                          if (type == null || type.equalsIgnoreCase(org.getType())) {
                            orgs.add(
                                new OrgDto(
                                    org.getId(),
                                    org.getName(),
                                    org.getType(),
                                    org.getDescription(),
                                    org.getStatus(),
                                    org.isDeleted()));
                          }
                        });
              });
    } else {
      orgs.addAll(
          orgPrivilegeProvider
              .getOrgsByRolePrivilege(authenticatedUser.getRoleId(), orgPrivileges, type)
              .stream()
              .map(
                  o ->
                      new OrgDto(
                          o.getId(),
                          o.getName(),
                          o.getType(),
                          o.getDescription(),
                          o.getStatus(),
                          o.isDeleted()))
              .collect(Collectors.toList()));
      orgs.stream()
          .filter(o -> o.getOrgId() != authenticatedUser.getOrgId())
          .findAny()
          .ifPresent(
              o -> {
                Organization org = orgRepo.findById(authenticatedUser.getOrgId()).get();
                if (org != null && (type == null || type.equalsIgnoreCase(org.getType()))) {
                  orgs.add(
                      new OrgDto(
                          org.getId(),
                          org.getName(),
                          org.getType(),
                          org.getDescription(),
                          org.getStatus(),
                          org.isDeleted()));
                }
              });
      Optional.ofNullable(orgs)
          .filter(o -> orgs.isEmpty())
          .ifPresent(
              o -> {
                Organization org = orgRepo.findById(authenticatedUser.getOrgId()).get();
                if (org != null && (type == null || type.equalsIgnoreCase(org.getType()))) {
                  orgs.add(
                      new OrgDto(
                          org.getId(),
                          org.getName(),
                          org.getType(),
                          org.getDescription(),
                          org.getStatus(),
                          org.isDeleted()));
                }
              });
    }
    orgs.sort((OrgDto o1, OrgDto o2) -> o1.getName().compareToIgnoreCase(o2.getName()));
    return orgs;
  }

  public int createOrg(OrgInfo orgInfo) throws DuplicateResourceException, DataValidationException {
    Optional.ofNullable(orgInfo.getName())
        .filter(o -> !o.trim().isEmpty())
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.EMPTY_ORG_NAME));

    Optional.ofNullable(orgInfo.getName())
        .filter(o -> !orgCreator.hasOrgByName(o.trim()))
        .orElseThrow(
            () ->
                new DuplicateResourceException(
                    CustomErrorCodes.DUPLICATE_ORG, Arrays.asList(orgInfo.getName())));

    return orgBuilderFacade.buildOrg(orgInfo);
  }

  public void isolateOrg(int orgId) {
    rolesOrgPrivilegeRepo.deleteByOrgId(orgId);
    orgDevicePrivilegeRepository.deleteByOrgId(orgId);
  }

  public List<OrgDto> addCustomProperties(List<OrgDto> orgs) {
    List<String> orgTypes =
        orgs.stream().map(o -> o.getType()).distinct().collect(Collectors.toList());
    Map<Integer, Map<String, Object>> orgCustomProperties = new HashMap<>();
    Map<Integer, List<PartnerTypeEntity>> orgPartnerTypes = new HashMap<>();
    if (orgTypes.contains(Constants.PARTNER)) {
      List<Integer> partnerOrgIds =
          orgs.stream()
              .filter(o -> o.getType().contains(Constants.PARTNER))
              .map(o -> o.getOrgId())
              .distinct()
              .collect(Collectors.toList());
      orgCustomProperties.putAll(
          orgFactory.getOrgCustomProperties(Constants.PARTNER).getCustomProperties(partnerOrgIds));

      orgPartnerTypes =
          orgFactory.getOrgCustomProperties(Constants.PARTNER).getPartnerTypesForOrg(partnerOrgIds);
    }
    orgs.stream()
        .filter(o -> orgCustomProperties.containsKey(o.getOrgId()))
        .forEach(
            o -> {
              o.setCustomProperties(orgCustomProperties.get(o.getOrgId()));
            });

    for (OrgDto org : orgs) {
      if (orgPartnerTypes.containsKey(org.getOrgId())) {
        org.setPartnerTypes(orgPartnerTypes.get(org.getOrgId()));
      }
    }

    return orgs;
  }
}
