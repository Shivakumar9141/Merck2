package com.merck.nextconnect.userhub.model.privilege;

import java.util.List;

public class Location {

  private long id;
  private String name;
  private List<DeviceGroup> DeviceGroups;

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<DeviceGroup> getDeviceGroups() {
    return DeviceGroups;
  }

  public void setDeviceGroups(List<DeviceGroup> deviceGroups) {
    DeviceGroups = deviceGroups;
  }
}
