package com.merck.nextconnect.userhub.model.user;

import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;

public class UserDetails {
  private String loginText;
  private String firstName;
  private String lastName;
  private String email;
  private String isdCode;
  private String phone;
  private int businessDomainId;
  private int countryId;
  private String countryCode;
  private long domainId;
  private long roleId;
  private int dateFormatId;
  private int languageId;
  private boolean consentStatus;
  private int orgId;
  private UserSubscriptionDTO userSubscriptionDTO;
  private boolean privacyPolicyStatus;
  private Integer timeZoneId;
  private UserProfileSettingsDTO userProfileSettings;
  private String invitedVia;
  private boolean isAutoCreated;
  private boolean registrationFlow;
  private boolean platformSubscription;

  public UserSubscriptionDTO getUserSubscriptionDTO() {
    return userSubscriptionDTO;
  }

  public void setUserSubscriptionDTO(UserSubscriptionDTO userSubscriptionDTO) {
    this.userSubscriptionDTO = userSubscriptionDTO;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getIsdCode() {
    return isdCode;
  }

  public void setIsdCode(String isdCode) {
    this.isdCode = isdCode;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public int getBusinessDomainId() {
    return businessDomainId;
  }

  public void setBusinessDomainId(int businessDomainId) {
    this.businessDomainId = businessDomainId;
  }

  public long getRoleId() {
    return roleId;
  }

  public void setRoleId(long roleId) {
    this.roleId = roleId;
  }

  public int getCountryId() {
    return countryId;
  }

  public void setCountryId(int countryId) {
    this.countryId = countryId;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getLoginText() {
    return loginText;
  }

  public void setLoginText(String loginText) {
    this.loginText = loginText;
  }

  public long getDomainId() {
    return domainId;
  }

  public void setDomainId(long domainId) {
    this.domainId = domainId;
  }

  public int getDateFormatId() {
    return dateFormatId;
  }

  public void setDateFormatId(int dateFormatId) {
    this.dateFormatId = dateFormatId;
  }

  public int getLanguageId() {
    return languageId;
  }

  public void setLanguageId(int languageId) {
    this.languageId = languageId;
  }

  public boolean isConsentStatus() {
    return consentStatus;
  }

  public void setConsentStatus(boolean consentStatus) {
    this.consentStatus = consentStatus;
  }

  public int getOrgId() {
    return orgId;
  }

  public void setOrgId(int orgId) {
    this.orgId = orgId;
  }

  public boolean isPrivacyPolicyStatus() {
    return privacyPolicyStatus;
  }

  public void setPrivacyPolicyStatus(boolean privacyPolicyStatus) {
    this.privacyPolicyStatus = privacyPolicyStatus;
  }

  public Integer getTimeZoneId() {
    return timeZoneId;
  }

  public void setTimeZoneId(Integer timeZoneId) {
    this.timeZoneId = timeZoneId;
  }

  public UserProfileSettingsDTO getUserProfileSettings() {
    return userProfileSettings;
  }

  public void setUserProfileSettings(UserProfileSettingsDTO userProfileSettings) {
    this.userProfileSettings = userProfileSettings;
  }

  public boolean isAutoCreated() {
    return isAutoCreated;
  }

  public void setAutoCreated(boolean isAutoCreated) {
    this.isAutoCreated = isAutoCreated;
  }

  public String getInvitedVia() {
    return invitedVia;
  }

  public void setInvitedVia(String invitedVia) {
    this.invitedVia = invitedVia;
  }

  public boolean isRegistrationFlow() {
    return registrationFlow;
  }

  public void setRegistrationFlow(boolean registrationFlow) {
    this.registrationFlow = registrationFlow;
  }

  public boolean isPlatformSubscription() {
    return platformSubscription;
  }

  public void setPlatformSubscription(boolean platformSubscription) {
    this.platformSubscription = platformSubscription;
  }
}
