package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.repository.jpa.SubscriptionCategoryRepository;
import com.merck.nextconnect.userhub.resources.ISubscriptionCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionCategoryImpl implements ISubscriptionCategory {

  @Autowired private SubscriptionCategoryRepository subscriptionCategoryRepository;

  @Override
  public SubscriptionCategory findOneByCategoryId(Long categoryId) {
    return subscriptionCategoryRepository.findById(categoryId).get();
  }
}
