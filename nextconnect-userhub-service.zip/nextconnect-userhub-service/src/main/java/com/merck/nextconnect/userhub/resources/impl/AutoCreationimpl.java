package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.model.user.UserPatch;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repo.jdbc.CoveredProductRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.GenericJdbc;
import com.merck.nextconnect.userhub.repository.jpa.CoveredProductRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.ServiceContractRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IAutoCreation;
import com.merck.nextconnect.userhub.resources.IOrganization;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserHubAsyncService;
import com.merck.nextconnect.userhub.validator.UserhubValidator;
import com.merck.nextconnect.utils.common.DateTimeUtil;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.common.repository.jpa.LanguageRepository;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.file.util.CustomErrorCodes;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import com.merck.nextconnect.utils.model.OrgAndUserDetailResponse;
import jakarta.mail.MessagingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * @author tah
 *     <p>Impl class for creation of org and user
 */
@Service
public class AutoCreationimpl implements IAutoCreation {

  static final Logger LOGGER = LoggerFactory.getLogger(AutoCreationimpl.class);

  @Autowired private UserhubValidator userhubValidator;

  @Autowired IOrganization organization;

  @Autowired @Lazy private IUser iuser;

  @Autowired RoleRepository roleRepo;

  @Autowired UserRepository userRepo;

  @Autowired private IprivilegeProvider privilegeProvider;

  @Autowired private ServiceContractRepository serviceContractRepository;

  @Autowired private CoveredProductRepository coveredProductRepository;

  @Autowired CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;

  @Autowired UserHubAsyncService userHubAsyncService;

  @Autowired GenericJdbc genericJdbc;

  @Autowired LanguageRepository languageRepo;

  @Override
  public OrgAndUserDetailResponse create(OrgAndUserDetail orgAndUserDetail)
      throws DuplicateResourceException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          MessagingException,
          ResourceNotFoundException,
          CustomException {

    OrgAndUserDetailResponse response = new OrgAndUserDetailResponse();
    int orgId = 0;

    boolean isValidOrgDetailsPresent = userhubValidator.isValidOrgDetailsPresent(orgAndUserDetail);
    LOGGER.info("isValidOrgDetailsPresent : {} ", isValidOrgDetailsPresent);

    boolean isValidUserInviteDetailsPresent =
        userhubValidator.isValidUserInviteDetailsPresent(orgAndUserDetail);
    LOGGER.info("isValidUserInviteDetailsPresent : {} ", isValidUserInviteDetailsPresent);

    // Step1 : create org if not exist
    if (isValidOrgDetailsPresent) {
      Organization org = organization.getOrgByName(getOrgName(orgAndUserDetail));
      if (Optional.ofNullable(org).isPresent()) {
        LOGGER.debug("Org already exists, orgId : {}, orgName : {} ", org.getId(), org.getName());
        orgId = org.getId();
      } else {
        if (UserInvitedVia.SERVIE_CONTRACT
            .value()
            .equalsIgnoreCase(orgAndUserDetail.getInvitedVia())) {
          // service contract level , we create the org type as customer
          orgId = createOrg(orgAndUserDetail);
        } else if (isValidUserInviteDetailsPresent) {
          orgId = createOrg(orgAndUserDetail);
        } else {
          LOGGER.info(
              "Customer/Distributor Admin details were not provided, so we are not sure which organization type to create at IP level");
          throw new DataValidationException(CustomErrorCodes.INVALID_REQUEST);
        }
      }
    } else {
      LOGGER.info(
          "All mandatory fields are not provided to create new org or to check for existing.");
      throw new DataValidationException(CustomErrorCodes.INVALID_REQUEST);
    }

    if (orgId == 0) {
      LOGGER.info("As we dont have org details, user cannot be created and invited");
      throw new CustomException(CustomErrorCodes.APPLICATION_ERROR);
    }

    // Step2 : create user and invite if not exist
    if (isValidUserInviteDetailsPresent) {
      UserProfile userProfile = userRepo.getUserByEmail(orgAndUserDetail.getEmail());
      if (userProfile != null) {
        LOGGER.debug(
            "user already exist : userId : {} , status : {} , orgId : {} ",
            userProfile.getUserId(),
            userProfile.getStatus(),
            userProfile.getOrg().getId());
        checkAndAssignDevice(userProfile, orgAndUserDetail, orgId, response);
      } else {
        createUser(orgAndUserDetail, orgId, response);
      }
    } else {
      LOGGER.info(
          "All mandatory fields are not provided to create new user and invite or to check for existing.");
      throw new DataValidationException(CustomErrorCodes.INVALID_REQUEST);
    }
    return response;
  }

  /**
   * Create org
   *
   * @param orgAndUserDetail
   * @param orgId
   * @throws DuplicateResourceException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   * @throws DataValidationException
   */
  private synchronized Integer createOrg(OrgAndUserDetail orgAndUserDetail)
      throws DuplicateResourceException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          DataValidationException {
    int orgId = 0;
    OrgInfo orgInfo = new OrgInfo();
    Organization org = organization.getOrgByName(getOrgName(orgAndUserDetail));
    if (Optional.ofNullable(org).isPresent()) {
      LOGGER.debug("Org already exists, orgId : {}, orgName : {} ", org.getId(), org.getName());
      orgId = org.getId();
    } else {
      populateOrgInfo(orgAndUserDetail, orgInfo);
      orgId = organization.create(orgInfo);
      organization.updateOrgSetting(orgId, orgInfo.getHistoricalDataSubscription());
      LOGGER.debug("newly created orgId : {}", orgId);
    }
    return orgId;
  }

  /**
   * create User and invite
   *
   * @param orgAndUserDetail
   * @param orgId
   * @param response
   * @throws ResourceNotFoundException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   * @throws DataValidationException
   * @throws DuplicateResourceException
   * @throws MessagingException
   */
  private synchronized void createUser(
      OrgAndUserDetail orgAndUserDetail, int orgId, OrgAndUserDetailResponse response)
      throws ResourceNotFoundException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          DataValidationException,
          DuplicateResourceException,
          MessagingException {

    UserProfile userProfile = userRepo.getUserByEmail(orgAndUserDetail.getEmail());
    if (userProfile != null) {
      LOGGER.debug(
          "user already exist : userId : {} , status : {} , orgId : {} ",
          userProfile.getUserId(),
          userProfile.getStatus(),
          userProfile.getOrg().getId());
      checkAndAssignDevice(userProfile, orgAndUserDetail, orgId, response);
    } else {
      Organization orgz = organization.getOrgByName(getOrgName(orgAndUserDetail));
      if (orgz.getStatus().equals(false)) {
        LOGGER.info("Provided org is deactivated, new user will not invited");
        response.setOrgDeactivated(true);
        response.setOrgId(Long.valueOf(orgz.getId()));
      } else {
        LOGGER.info("user was not found. creating new user");
        UserDetails userDetails = new UserDetails();
        populateUserDetails(orgId, orgAndUserDetail, userDetails);
        UserProfile user;
        try {
          user = iuser.add(userDetails);
          LOGGER.debug("newly created userId : {}", user.getUserId());
        } catch (AccessDeniedException e) {
          LOGGER.info("Access Denied : {}", e.getErrorCode());
          response.setOrgDeactivated(true);
          response.setOrgId(Long.valueOf(orgz.getId()));
        }
      }
    }
  }

  /**
   * Check and assign device
   *
   * @param userProfile
   * @param orgAndUserDetail
   * @param orgId
   * @param response
   * @throws ResourceNotFoundException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   * @throws DataValidationException
   */
  private void checkAndAssignDevice(
      UserProfile userProfile,
      OrgAndUserDetail orgAndUserDetail,
      int orgId,
      OrgAndUserDetailResponse response)
      throws ResourceNotFoundException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          DataValidationException {
    int existingUserOrgId = userProfile.getOrg().getId();
    if (orgId == existingUserOrgId) {
      assignDeviceToUser(orgAndUserDetail, userProfile);

    } else {
      LOGGER.info("Provided user org is different");
      response.setUserBelongToDifferentOrg(true);
      response.setUserOrgName(userProfile.getOrg().getName());
      response.setDateOfFirstInvitation(
          DateTimeUtil.formatDate(userProfile.getCreatedOn(), DateTimeUtil.PATTERN_B));
    }
  }

  /**
   * NCIOT-12956
   *
   * <p>Assign device to user if the user is INACTIVE we should make him active and send a mail AND
   * tick MymilliqActivated check box
   *
   * @param orgAndUserDetail
   * @param userProfile
   * @throws ResourceNotFoundException
   * @throws DataValidationException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   */
  private void assignDeviceToUser(OrgAndUserDetail orgAndUserDetail, UserProfile userProfile)
      throws ResourceNotFoundException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          DataValidationException {

    Long deviceId = orgAndUserDetail.getDeviceId();

    if (deviceId != null) {
      if (UserStatus.ACTIVE.value().equalsIgnoreCase(userProfile.getStatus())
          || UserStatus.INACTIVE.value().equalsIgnoreCase(userProfile.getStatus())) {
        activateUser(userProfile);
        assignDevice(deviceId, userProfile);
        updateMymilliqActivtedCheckbox(deviceId);
      }
    } else if (StringUtils.isNotBlank(orgAndUserDetail.getSmServiceContractId())) {
      List<Long> deviceIdList =
          coveredProductRepositoryJdbc.getcoveredDevicesUnderSmServiceContract(
              orgAndUserDetail.getSmServiceContractId());
      for (Long device : deviceIdList) {
        if (UserStatus.ACTIVE.value().equalsIgnoreCase(userProfile.getStatus())
            || UserStatus.INACTIVE.value().equalsIgnoreCase(userProfile.getStatus())) {
          activateUser(userProfile);
          assignDevice(device, userProfile);
          updateMymilliqActivtedCheckbox(device);
        }
      }
    }
  }

  /**
   * Changes the user status from Inactive to Active
   *
   * @param userProfile
   * @throws ResourceNotFoundException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   * @throws DataValidationException
   */
  private void activateUser(UserProfile userProfile)
      throws ResourceNotFoundException,
          com.merck.nextconnect.userhub.exception.DataValidationException,
          DataValidationException {
    if (UserStatus.INACTIVE.value().equalsIgnoreCase(userProfile.getStatus())) {
      UserPatch userPatch = new UserPatch();
      userPatch.setStatus(true);
      iuser.updateStatusAndRole(userProfile.getUserId(), userPatch);
    }
  }

  /**
   * Assigns user with device
   *
   * @param deviceId
   * @param userProfile
   * @throws ResourceNotFoundException
   */
  private synchronized void assignDevice(Long deviceId, UserProfile userProfile)
      throws ResourceNotFoundException {

    List<Long> userDeviceIds = privilegeProvider.getAuthUserDevices(userProfile.getUserId());
    LOGGER.debug("userDeviceIds : {}", userDeviceIds);

    if (!userDeviceIds.contains(deviceId)) {
      List<ResourcePrivilege> resourcePrivileges = new ArrayList<ResourcePrivilege>();
      ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
      resourcePrivilege.setPrivilegeid(OrgPrivileges.assign_device.getPrivilegeId());
      resourcePrivilege.setResourceid(deviceId);
      resourcePrivileges.add(resourcePrivilege);
      iuser.addPrivileges(userProfile.getUserId(), resourcePrivileges);
      LOGGER.debug("assigned the device {} to user {}", deviceId, userProfile.getUserId());
      genericJdbc.updateDeviceAccessRequestStatusApproved(deviceId, userProfile.getUserId());
    }
  }

  /**
   * MymilliqActivated check box needs to be ticked at IP AND CP level
   *
   * @param deviceId
   */
  private void updateMymilliqActivtedCheckbox(Long deviceId) {
    userHubAsyncService.updateMymilliqActivtedCheckboxForDeviceAutoAssignment(deviceId);
  }

  /**
   * populate Org Info
   *
   * @param orgAndUserDetail
   * @param orgInfo
   */
  private void populateOrgInfo(OrgAndUserDetail orgAndUserDetail, OrgInfo orgInfo) {
    LOGGER.info("populateOrgInfo..");
    if (orgAndUserDetail.isDealer()) {
      orgInfo.setType(Constants.DISTRIBUTOR);
      orgInfo.setTemplate(Constants.LABWATER_DISTRIBUTOR_TEMPLATE);
    } else {
      orgInfo.setType(Constants.CUSTOMER);
      orgInfo.setTemplate(Constants.LABWATER_CUSTOMER_TEMPLATE);
    }
    orgInfo.setName(getOrgName(orgAndUserDetail));
    orgInfo.setDesc(
        StringUtils.isBlank(orgAndUserDetail.getCustomerName())
            ? "Account/Customer name was not provided"
            : orgAndUserDetail.getCustomerName());
    orgInfo.setHistoricalDataSubscription(24L);
    orgInfo.setStatus(true);
    orgInfo.setAutoCreated(true);
    orgInfo.setCreatedVia(orgAndUserDetail.getInvitedVia());
  }

  /**
   * populate UserDetails
   *
   * @param orgId
   * @param orgAndUserDetail
   * @param userDetails
   * @throws DataValidationException
   */
  private void populateUserDetails(
      int orgId, OrgAndUserDetail orgAndUserDetail, UserDetails userDetails)
      throws DataValidationException {
    LOGGER.info("populateUserDetails..");
    List<UserDomain> userDomain = organization.getDomains(orgId);
    userDetails.setDomainId(userDomain.get(0).getDomainId());
    if (orgAndUserDetail.isDealer()) {
      Role role = roleRepo.getRoleByName(Constants.DISTRIBUTOR_ADMIN, orgId);
      if (Objects.nonNull(role)) {
        userDetails.setRoleId(role.getRoleId());
      } else {
        LOGGER.error("The provided org is not a distribuor org {}", orgId);
        throw new DataValidationException(CustomErrorCodes.INVALID_DISTRIBUTOR_ORG);
      }
    } else {
      Role role = roleRepo.getRoleByName(Constants.CUSTOMER_ADMIN, orgId);
      if (Objects.nonNull(role)) {
        userDetails.setRoleId(role.getRoleId());
      } else {
        LOGGER.error("The provided org is not a customer org {}", orgId);
        throw new DataValidationException(CustomErrorCodes.INVALID_CUSTOMER_ORG);
      }
    }
    userDetails.setOrgId(orgId);
    userDetails.setFirstName(orgAndUserDetail.getFirstName());
    userDetails.setLastName(orgAndUserDetail.getLastName());
    userDetails.setEmail(orgAndUserDetail.getEmail());
    userDetails.setLoginText(orgAndUserDetail.getEmail());
    userDetails.setInvitedVia(orgAndUserDetail.getInvitedVia());
    userDetails.setAutoCreated(true);
    userDetails.setCountryCode(orgAndUserDetail.getSmAdminCountryCode());
    languageValidator(
        orgAndUserDetail.getLanguage(),
        userDetails); // null check,check string in nc_lang, get language id
  }

  private void languageValidator(String language, UserDetails userDetails) {

    if (StringUtils.isNotBlank(language)) {
      Language lang = languageRepo.findByValue(language);

      if (Optional.ofNullable(lang).isPresent() && lang.getId() > 0) {
        userDetails.setLanguageId(lang.getId());
      }
    }
  }

  /**
   * org name should be like ORG_Soldto_Billto
   *
   * @param orgAndUserDetail
   * @return
   */
  private String getOrgName(OrgAndUserDetail orgAndUserDetail) {
    return Constants.ORG_CAPITAL
        + Constants.UNDERSCORE
        + orgAndUserDetail.getSoldTo()
        + Constants.UNDERSCORE
        + orgAndUserDetail.getBillTo();
  }
}
