package com.merck.nextconnect.userhub.cache.controller;

import com.merck.nextconnect.authfilter.util.EntityPrivileges;
import com.merck.nextconnect.userhub.cache.service.CacheService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
@RequestMapping("/api/v1/cache")
public class CacheController {

  static final Logger logger = LoggerFactory.getLogger(CacheController.class);

  @Autowired CacheService cacheService;

  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @Operation(description = "Fetch all the map names ", tags = "Cache")
  @RequestMapping(value = "/maps", method = RequestMethod.GET)
  public ResponseEntity<Map<String, String>> getListOfMaps() {
    return new ResponseEntity<Map<String, String>>(cacheService.getListOfMaps(), HttpStatus.OK);
  }

  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @Operation(description = "Fetch all values based on map name ", tags = "Cache")
  @RequestMapping(value = "/{mapName}", method = RequestMethod.GET)
  @PreAuthorize(EntityPrivileges.PLATFORM_ADMIN)
  public ResponseEntity<String> getMapValues(
      @Parameter(name = "mapName", description = "name of the map", required = true)
          @PathVariable(value = "mapName", required = true)
          String mapName,
      @Parameter(
              name = "resourceId",
              description = "resource id",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "resourceId", required = false)
          Object resourceId)
      throws JSONException {

    JSONObject valueObject = new JSONObject();
    String values = cacheService.getMapValues(mapName, resourceId);
    valueObject.put("result ", values);
    return new ResponseEntity<String>(valueObject.toString(), HttpStatus.OK);
  }

  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @Operation(description = "To fetch all the values of populated maps ", tags = "Cache")
  @RequestMapping(method = RequestMethod.GET)
  @PreAuthorize(EntityPrivileges.PLATFORM_ADMIN)
  public ResponseEntity<Map<String, String>> getAllDistributedCacheValues() {

    Map<String, String> values = cacheService.getAllDistributedCacheValues();
    return new ResponseEntity<Map<String, String>>(values, HttpStatus.OK);
  }

  @Operation(description = "Get cache configuration", tags = "Cache")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(value = "/properties", method = RequestMethod.GET)
  @PreAuthorize(EntityPrivileges.PLATFORM_ADMIN)
  public ResponseEntity<?> getCacheConfigurations() {
    return new ResponseEntity<Map<String, String>>(
        cacheService.getConfigurationProperties(), HttpStatus.OK);
  }

  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @Operation(description = "Clear the values in cache", tags = "Cache")
  @RequestMapping(method = RequestMethod.PUT)
  @PreAuthorize(EntityPrivileges.PLATFORM_ADMIN)
  public ResponseEntity<String> clearCacheValues(
      @Parameter(
              name = "mapName",
              description = "name of the map",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "mapName", required = false)
          String mapName,
      @Parameter(
              name = "resourceId",
              description = "resourceId",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "resourceId", required = false)
          Object resourceId)
      throws JSONException {
    JSONObject valueObject = new JSONObject();
    String values = cacheService.clearCacheValues(mapName, resourceId);
    valueObject.put("result ", values);
    return new ResponseEntity<String>(String.valueOf(valueObject), HttpStatus.OK);
  }

  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER,
      schema = @Schema(implementation = String.class),
      content = @Content(schema = @Schema(implementation = String.class)))
  @Operation(description = "configure application properties", tags = "Cache")
  @RequestMapping(value = "/application-config", method = RequestMethod.PUT)
  @PreAuthorize(EntityPrivileges.PLATFORM_ADMIN)
  public ResponseEntity<?> configureApplicationConfig(
      @Parameter(name = "key", description = "key", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "key", required = true)
          String key,
      @Parameter(name = "type", description = "type", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "type", required = false)
          String type,
      @Parameter(name = "value", description = "value", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "value", required = true)
          String value)
      throws JSONException {
    cacheService.updateApplicationConfig(key, type, value);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }
}
