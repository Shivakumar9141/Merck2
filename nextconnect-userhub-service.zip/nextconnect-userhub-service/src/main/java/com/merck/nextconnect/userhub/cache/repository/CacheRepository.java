package com.merck.nextconnect.userhub.cache.repository;

import com.hazelcast.core.DistributedObject;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.hazelcast.nio.serialization.HazelcastSerializationException;
import com.merck.nextconnect.userhub.cache.util.CacheUtil;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CacheRepository {

  static final Logger logger = LoggerFactory.getLogger(CacheRepository.class);

  @Autowired private HazelcastInstance hazelcastInstance;

  private static final String APPLICATION_CONFIG = "applicationConfig";

  public String getMapValues(String mapName, Object resourceId) {

    String values = null;
    IMap<Object, Object> map = hazelcastInstance.getMap(mapName);
    if (resourceId != null && (map.isEmpty()) != true) {

      Object key = getKeyValue(map);
      logger.info(":::: value of key is -{}", key);
      if ((key) instanceof Long) {
        Long longValue = Long.parseLong(resourceId.toString());
        Object valueToConvert = map.get(longValue);
        values = checkForNull(valueToConvert);

      } else if ((key) instanceof String) {
        String stringValue = resourceId.toString();
        Object valueToConvert = map.get(stringValue);
        values = checkForNull(valueToConvert);
      }

    } else {
      if ((map.isEmpty()) != true) {
        values = getMapContent(map);
      } else {
        values = "Map is Empty";
      }
    }
    return values;
  }

  private Object getKeyValue(IMap<Object, Object> map) {
    Entry<Object, Object> entry = map.entrySet().iterator().next();
    Object key = entry.getKey();
    return key;
  }

  private String getMapContent(IMap<Object, Object> map) {
    Map<Object, Object> resultantMap =
        map.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    logger.info(":::: Keyset of resultantMap is -{}", resultantMap.keySet());
    logger.info(":::: Values of resultantMap is -{}", resultantMap.values());
    return resultantMap.toString();
  }

  private String checkForNull(Object valueToConvert) {
    String values;
    if (valueToConvert != null) {
      logger.info(":::: valueToConvert is having values -{}", valueToConvert);
      values = valueToConvert.toString();
    } else {
      logger.info(":::: valueToConvert is null ::::: -{} ", valueToConvert);
      values = "No Entry is present for this resourceId ";
    }
    return values;
  }

  private String checkForEntry(Object resourceId, IMap<Object, Object> map) {

    String values;
    if (map.containsKey(resourceId)) {
      logger.info(":::: resourceId is having values -{}", resourceId);
      values = "Entry will be cleared for this resourceId";

    } else {
      logger.info(":::: resourceId is :::::- {}", resourceId);
      values = "No Entry is present for this resourceId to clear";
    }
    return values;
  }

  public String clearCacheValues(String mapName, Object resourceId) {
    String values = null;

    if (mapName != null) {
      values = clearEntriesByMapName(mapName, resourceId);
    } else {
      clearAllMaps();
      values = "All maps are cleared";
    }

    return values;
  }

  private String clearEntriesByMapName(String mapName, Object resourceId) {
    String values = null;
    IMap<Object, Object> map = hazelcastInstance.getMap(mapName);
    if (resourceId != null && (map.isEmpty()) != true) {
      Object key = getKeyValue(map);
      logger.info(":::: value of key is -{}", key);
      if ((key) instanceof Long) {
        Long longValue = Long.parseLong(resourceId.toString());
        values = checkForEntry(longValue, map);
        map.remove(longValue);
      } else if ((key) instanceof String) {
        String stringValue = resourceId.toString();
        values = checkForEntry(stringValue, map);
        map.remove(stringValue);
      }

    } else {

      if ((map.isEmpty()) != true) {
        map.clear();
        values = "Entire map is cleared";
      } else {
        values = "Map is empty";
      }
    }
    return values;
  }

  private void clearAllMaps() {
    Map<String, String> listofmaps = CacheUtil.HazelcastMapInfo;
    listofmaps
        .keySet()
        .forEach(
            m -> {
              hazelcastInstance.getMap(m).clear();
            });
  }

  public String getMembers() {

    String members = hazelcastInstance.getCluster().getMembers().toString();
    return members;
  }

  public Map<String, String> getAllDistributedCacheValues() {
    Map<String, String> resultantMap = new HashMap<String, String>();
    Collection<DistributedObject> distributedObjects = hazelcastInstance.getDistributedObjects();
    logger.info(":::: distributedObjects of cache is -{}", distributedObjects);
    try {
      List<DistributedObject> mapList =
          distributedObjects.stream().filter(s -> s instanceof Map).collect(Collectors.toList());
      mapList.forEach(
          l -> {
            logger.info(":::: Name of the map is -{}", l.getName());
            String valueList = getMapContent(hazelcastInstance.getMap(l.getName()));
            resultantMap.put(l.getName(), valueList);
          });
    } catch (HazelcastSerializationException e) {
      logger.error(
          "Failed to serialize the object to display key and value pairs " + e.getMessage());
    }
    return resultantMap;
  }

  public IMap<String, Object> getApplicationConfigMap() {
    return hazelcastInstance.getMap(APPLICATION_CONFIG);
  }
}
