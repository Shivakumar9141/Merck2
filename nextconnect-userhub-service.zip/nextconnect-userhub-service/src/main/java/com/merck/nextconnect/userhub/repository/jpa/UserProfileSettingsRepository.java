package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserProfileSettings;
import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserProfileSettingsRepository extends JpaRepository<UserProfileSettings, Long> {

  @Query("from UserProfileSettings ups where ups.userProfile.userId = ?1")
  UserProfileSettings fetchUserProfileSettingByUserId(long userId);

  @Query(
      "select new com.merck.nextconnect.userhub.model.UserProfileSettingsDTO(ups.displayPerPage,ups.subscribeUserFeedBackReport)"
          + " from UserProfileSettings ups  where ups.userProfile.userId = :userId")
  UserProfileSettingsDTO fetchUserProfileSettings(@Param("userId") long userId);
}
