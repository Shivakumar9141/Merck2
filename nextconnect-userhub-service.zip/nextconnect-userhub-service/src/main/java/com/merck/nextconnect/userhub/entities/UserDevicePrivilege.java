package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "NC_USERS_DEVICE_PRIVILEGES")
public class UserDevicePrivilege {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @ManyToOne
  @JoinColumn(name = "USER_ID")
  private UserProfile user;

  @ManyToOne
  @JoinColumn(name = "PRIVILEGE_ID")
  private Privilege privilege;

  @ManyToOne
  @JoinColumn(name = "DEVICE_ID")
  private Device device;

  public UserDevicePrivilege() {}

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public UserProfile getUser() {
    return user;
  }

  public void setUser(UserProfile user) {
    this.user = user;
  }

  public Privilege getPrivilege() {
    return privilege;
  }

  public void setPrivilege(Privilege privilege) {
    this.privilege = privilege;
  }

  public Device getDevices() {
    return device;
  }

  public void setDevices(Device devices) {
    this.device = devices;
  }
}
