package com.merck.nextconnect.userhub.authentication.impl;

import com.merck.nextconnect.userhub.authentication.IAuthRepository;
import com.merck.nextconnect.userhub.entities.UserCredentials;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.user.AccountStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserCredentialsRepository;
import com.merck.nextconnect.userhub.resources.IAccountPolicy;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;

@Component
public class NextConnectAuth implements IAuthRepository {

  @Autowired UserCredentialsRepository userCredentialsRepository;

  @Autowired IAccountPolicy accountPolicy;

  @Autowired private ApplicationConfigRepository applicationConfigRepository;

  @Override
  public boolean authenticate(Login login) {
    UserCredentials userCredentials =
        userCredentialsRepository.getUserCredentials(
            login.getUsername(), Constants.NEXTCONNECT_AUTH);
    Optional.ofNullable(userCredentials)
        .orElseThrow(() -> new LoginAuthenticationException("Username or password is incorrect"));
    if (BCrypt.checkpw(login.getPassword(), userCredentials.getPasswordHash())) {
      if (!userCredentials.getUserProfile().getRole().isServiceRole())
        validateExpiry(userCredentials.getCreatedTime());
      if (userCredentials.getStatus().equals(AccountStatus.LOCKED.value())) {
        throw new LoginAuthenticationException(CustomErrorCodes.USER_ACCOUNT_LOCKED);
      }
      accountPolicy.resetLockOut(userCredentials.getUserProfile().getUserId());
      return true;
    } else {
      accountPolicy.failedLoginAttempt(userCredentials);
    }
    return false;
  }

  private void validateExpiry(Timestamp createdTime) {
    int validityDays =
        Integer.valueOf(
            applicationConfigRepository
                .findByCategoryAndKey(Constants.PASSWORD_POLICY, Constants.VALIDITY_DAYS)
                .getValue());
    double timeDifferenceInMillis =
        new Timestamp(new Date().getTime()).getTime() - createdTime.getTime();
    double timeDifference = Math.ceil(timeDifferenceInMillis / (60 * 60 * 24 * 1000));
    if (timeDifference > validityDays) {
      throw new LoginAuthenticationException(CustomErrorCodes.PASSWORD_EXPIRED);
    }
  }
}
