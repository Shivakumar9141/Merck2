package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author M290834 This model will be used to find the UserType.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HotlineUserType {
  private String userType;
}
