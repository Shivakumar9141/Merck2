package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.OrganizationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author asharma5
 */
@Repository
public interface OrganizationTypeRepository extends JpaRepository<OrganizationType, Integer> {

  OrganizationType findByOrgTypeName(String string);
}
