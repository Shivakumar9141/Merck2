package com.merck.nextconnect.userhub.model;

import java.util.List;
import lombok.Data;

@Data
public class UserFeedBackPageDTO {

  private List<UserDataDTO> users;
  private long totalPages;
  private long recordCount;
}
