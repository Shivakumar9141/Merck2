package com.merck.nextconnect.userhub.model;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author clukose
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserFeedBackDateDTO {

  private String chartDate;

  private LocalDate date;

  private long count;
}
