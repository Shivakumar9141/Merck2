package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "NC_ORG")
public class Organization {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  private String name;

  private String type;

  private String description;

  private Boolean status;

  private Date lastUpdatedDate;

  private String lastUpdatedBy;

  private Date createdDate;

  private String createdBy;

  @Column(columnDefinition = "boolean default false", nullable = false)
  private boolean deleted;

  @ManyToOne
  @JoinColumn(name = "PARENT")
  private Organization parent;

  @Column(columnDefinition = "boolean default false", nullable = false)
  private boolean isAutoCreated;

  @Column(name = "created_via")
  private String createdVia;

  public Organization(int id) {
    this.id = id;
  }
}
