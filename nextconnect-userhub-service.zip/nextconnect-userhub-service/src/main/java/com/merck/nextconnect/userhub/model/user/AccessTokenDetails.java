package com.merck.nextconnect.userhub.model.user;

public class AccessTokenDetails {}
