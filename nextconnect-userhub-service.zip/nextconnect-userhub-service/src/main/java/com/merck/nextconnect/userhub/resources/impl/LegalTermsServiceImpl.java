package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.entities.LegalTermsMapping;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.PolicyTypeEntity;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.LegalTermsReference;
import com.merck.nextconnect.userhub.repository.jpa.LegalTermsRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.resources.ILegalTermsService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.validator.LegalTermsValidator;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author SHATHWAR This is to provide the HTML template for privacy policy and terms and
 *     conditions.
 */
@Service
public class LegalTermsServiceImpl implements ILegalTermsService {

  private static final Logger logger = LoggerFactory.getLogger(LegalTermsServiceImpl.class);

  @Autowired private LegalTermsRepository legalTermsRepository;

  @Autowired private LegalTermsValidator legalTermsValidator;

  @Autowired private CountryRepository countryRepository;

  @Autowired private OrganizationRepository organizationRepository;

  /**
   * @param countryCode
   * @param languageCode
   * @param orgId
   * @param type
   * @return PolicyTypeEntity
   */
  public PolicyTypeEntity getPolicyOrTerms(
      String languageCode, String type, String countryCode, int orgId)
      throws DataValidationException,
          ResourceNotFoundException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {

    logger.info(
        "Start of getPolicyOrTerms --> language code --> {}, type --> {}, country code --> {}, org id --> {}",
        languageCode,
        type,
        countryCode,
        orgId);

    legalTermsValidator.validateForNull(languageCode, countryCode, type);
    if (orgId == 0) throw new DataValidationException(CustomErrorCodes.ORG_ID_SHOULD_NOT_BE_NULL);

    Organization org =
        organizationRepository
            .findOrgById(orgId)
            .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ORG_NOT_FOUND));

    int id = organizationRepository.findIdByName(Constants.LABWATER);

    if (org.getParent() == null || org.getParent().getId() == 0)
      throw new ResourceNotFoundException(CustomErrorCodes.BUSINESS_UNIT_NOT_FOUND);

    if (org.getParent().getId() == id
        || orgId == id
        || (org.getParent().getType().equalsIgnoreCase(Constants.ORG_TYPE_DISTRIBUTOR)
            && org.getParent().getParent().getId() == id)) {

      Optional.ofNullable(countryRepository.findByCountryCode(countryCode))
          .orElseThrow(() -> new DataValidationException(CustomErrorCodes.INVALID_COUNTRY_CODE));

      LegalTermsMapping legalTermsMapping;

      if (!(countryCode.equalsIgnoreCase(Constants.USA_COUNTRY_CODE)
          || countryCode.equalsIgnoreCase(Constants.CANADA_COUNTRY_CODE)))
        countryCode = Constants.OTHER;

      //			MMI-FS-ESERV-3516 changes
      if (org.getType().equalsIgnoreCase(Constants.ORG_TYPE_DISTRIBUTOR)) {

        legalTermsMapping =
            legalTermsRepository
                .findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
                    countryCode,
                    languageCode,
                    id,
                    type,
                    LegalTermsReference.ORGTYPE.value(),
                    Constants.ORG_TYPE_DISTRIBUTOR)
                .orElseThrow(
                    () -> new ResourceNotFoundException(CustomErrorCodes.LEGAL_POLICY_NOT_FOUND));
      } else {

        legalTermsMapping =
            legalTermsRepository
                .findByCountryCodeAndLanguageCodeAndBusinessUnitIdAndPolicyTypeEntityPolicyTypeAndLegalTermsReferenceReferenceNameAndReferenceValue(
                    countryCode,
                    languageCode,
                    id,
                    type,
                    LegalTermsReference.NOFILTER.value(),
                    Constants.NO_FILTER)
                .orElseThrow(
                    () -> new ResourceNotFoundException(CustomErrorCodes.LEGAL_POLICY_NOT_FOUND));
      }

      logger.info(
          "End of getPolicyOrTerms --> language code --> {}, type --> {}, country code --> {}, org id --> {}",
          languageCode,
          type,
          countryCode,
          orgId);

      return legalTermsMapping.getPolicyTypeEntity();

    } else {
      logger.info("getPolicyOrTerms --> legal policy not found for org --> {}", org.getId());
      throw new ResourceNotFoundException(
          CustomErrorCodes.LEGAL_POLICY_NOT_FOUND_FOR_BUSINESS_UNIT);
    }
  }
}
