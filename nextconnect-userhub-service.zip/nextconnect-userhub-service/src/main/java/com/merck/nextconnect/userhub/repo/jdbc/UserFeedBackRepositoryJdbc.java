package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.model.UserAvgRatingCount;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingsDTO;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserFeedBackRepositoryJdbc {

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Value("#{'${users.roles.ignore}'.split(',')}")
  private List<String> rolesList;

  private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

  public List<UserDataDTO> getAllFeedBacks(String userId) {
    String sql =
        "SELECT up.user_id,up.first_name,up.last_name,org.name,nl.value,uef.created_date,uef.rating,uef.feed_back FROM nc_user_profile  up join nc_user_exp_feedback uef on up.user_id=uef.user_id join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) and up.deleted=0 and up.role_id not in(select role_id from nc_roles where name in(:roles))and up.status='Active' ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", rolesList);
    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("up.first_name"))
                .userId(Long.valueOf(rs.getString("up.user_id")))
                .lastName(rs.getString("up.last_name"))
                .createdDate(rs.getTimestamp("uef.created_date"))
                .customerOrgName(rs.getString("org.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("uef.feed_back"))
                .rating(rs.getInt("uef.rating"))
                .build());
  }

  public List<UserDataDTO> getAllUsersFeedBacks() {

    String sql =
        "SELECT up.user_id,up.first_name,up.last_name,org.name,nl.value,uef.created_date,uef.rating,uef.feed_back FROM nc_user_profile  up join nc_user_exp_feedback uef on up.user_id=uef.user_id join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id where up.deleted=0 and up.role_id not in(select role_id from nc_roles where name in(:roles))and up.status='Active' ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", rolesList);

    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("up.first_name"))
                .userId(Long.valueOf(rs.getString("up.user_id")))
                .lastName(rs.getString("up.last_name"))
                .createdDate(rs.getTimestamp("uef.created_date"))
                .customerOrgName(rs.getString("org.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("uef.feed_back"))
                .rating(rs.getInt("uef.rating"))
                .build());
  }

  private String getDate() {

    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.YEAR, -1);
    return format.format(cal.getTime());
  }

  public List<UserFeedBackRatingsDTO> getAllRatings(Long userId, String filteredQuery) {
    // NCIOT-10774 - Getting the rating counts of the users who falls under the FSE terriotory
    String baseSql =
        "SELECT feedback.rating, COUNT(feedback.rating) AS total FROM nc_user_profile profile"
            + " inner join nc_user_territories territories on profile.country_id=territories.territory_id"
            + " inner JOIN  nc_user_exp_feedback feedback ON profile.user_id = feedback.user_id "
            + " join nc_org o on profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " WHERE profile.deleted = 0 and territories.user_id=:userId "
            + "AND profile.status = 'Active' ";
    String orderBy = " group by feedback.rating order by feedback.rating desc";
    String finalQuery = baseSql + filteredQuery + orderBy;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (RowMapper<UserFeedBackRatingsDTO>)
            (rs, rowNum) ->
                UserFeedBackRatingsDTO.builder()
                    .ratings(rs.getInt("feedback.rating"))
                    .count(rs.getInt("total"))
                    .build());
  }

  public List<UserFeedBackRatingsDTO> getAllUsersRatings(Long userId, String filteredQuery) {
    // NCIOT-10774 - Getting All the users rating count
    String baseSql =
        "SELECT feedback.rating, count(feedback.rating) as total FROM nc_user_profile profile join nc_user_exp_feedback feedback on"
            + " profile.user_id=feedback.user_id join nc_org o on profile.org_id = o.id join nc_country c on profile.country_id = c.id "
            + " join nc_roles r on r.role_id = profile.role_id where profile.deleted=0 and profile.status='Active' ";
    String orderBy = " group by feedback.rating order by feedback.rating desc";
    String finalQuery = baseSql + filteredQuery + orderBy;
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (RowMapper<UserFeedBackRatingsDTO>)
            (rs, rowNum) ->
                UserFeedBackRatingsDTO.builder()
                    .ratings(rs.getInt("feedback.rating"))
                    .count(rs.getInt("total"))
                    .build());
  }

  public List<UserDataDTO> getAllUserFSE(String userId) {

    String sql =
        "SELECT up.user_id,up.first_name,up.last_name,up.created_on,org.name,nl.value, nc.country_code FROM nc_user_profile  up  join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id join nc_country nc on up.country_id = nc.id where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) and up.deleted=0 and up.role_id not in(select role_id from nc_roles where name in(:roles))and up.status='Active' ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", rolesList);
    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (RowMapper<UserDataDTO>)
            (rs, rowNum) ->
                UserDataDTO.builder()
                    .firstName(rs.getString("up.first_name"))
                    .userId(Long.valueOf(rs.getString("up.user_id")))
                    .lastName(rs.getString("up.last_name"))
                    .createdDate(rs.getTimestamp("up.created_on"))
                    .customerOrgName(rs.getString("org.name"))
                    .countryCode(rs.getString("nc.country_code"))
                    .language(rs.getString("nl.value"))
                    .build());
  }

  public List<UserDataDTO> getAllUsers() {

    String sql =
        "SELECT up.user_id,up.first_name,up.last_name,up.created_on,org.name,nl.value, nc.country_code FROM nc_user_profile  up  join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id join nc_country nc on up.country_id = nc.id where up.deleted=0 and up.role_id not in(select role_id from nc_roles where name in(:roles))and up.status='Active' ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", rolesList);

    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("up.first_name"))
                .userId(Long.valueOf(rs.getString("up.user_id")))
                .lastName(rs.getString("up.last_name"))
                .createdDate(rs.getTimestamp("up.created_on"))
                .customerOrgName(rs.getString("org.name"))
                .countryCode(rs.getString("nc.country_code"))
                .language(rs.getString("nl.value"))
                .build());
  }

  /**
   * NCIOT-11742
   *
   * @param userId
   * @param filteredQuery
   * @return
   */
  public List<UserFeedBackRatingsDTO> getAllRatingsForDistributorFSE(
      Long userId, List<Integer> accessibleOrgs, List<String> roleList, String filteredQuery) {

    String baseSql =
        "SELECT feedback.rating, COUNT(feedback.rating) AS total FROM nc_user_profile profile "
            + " inner join nc_user_territories territories on profile.country_id=territories.territory_id "
            + " inner Join  nc_user_exp_feedback feedback ON profile.user_id = feedback.user_id "
            + " join nc_org o on profile.org_id=o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " WHERE profile.deleted = 0 and territories.user_id=:userId "
            + " AND profile.status = 'Active' "
            + " and profile.role_id in (select role_id from nc_roles where name in (:roleList)) and profile.org_id in (:accessibleOrgs)";

    String orderBy = " group by feedback.rating order by feedback.rating desc";
    String finalQuery = baseSql + filteredQuery + orderBy;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roleList", roleList);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (RowMapper<UserFeedBackRatingsDTO>)
            (rs, rowNum) ->
                UserFeedBackRatingsDTO.builder()
                    .ratings(rs.getInt("feedback.rating"))
                    .count(rs.getInt("total"))
                    .build());
  }

  /**
   * NCIOT-11742
   *
   * @param userId
   * @param roles
   * @param accessibleOrgs
   * @return
   */
  public List<UserDataDTO> getAllFeedBacksForDistributorFSE(
      String userId, List<String> roles, List<Integer> accessibleOrgs) {

    String sql =
        "SELECT up.user_id,up.first_name,up.last_name,org.name,nl.value,uef.created_date,uef.rating,uef.feed_back "
            + " FROM nc_user_profile up "
            + " join nc_user_exp_feedback uef on up.user_id=uef.user_id "
            + " join nc_org org on up.org_id=org.id "
            + " join nc_languages nl on up.language_id=nl.id "
            + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) "
            + " and up.deleted=0 and up.role_id  in(select role_id from nc_roles where name in(:roles)) and "
            + " up.status='Active' and up.org_id in (:accessibleOrgs) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", roles);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("up.first_name"))
                .userId(Long.valueOf(rs.getString("up.user_id")))
                .lastName(rs.getString("up.last_name"))
                .createdDate(rs.getTimestamp("uef.created_date"))
                .customerOrgName(rs.getString("org.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("uef.feed_back"))
                .rating(rs.getInt("uef.rating"))
                .build());
  }

  /**
   * NCIOT-11742
   *
   * @param userId
   * @param accessibleOrgs
   * @param filteredQuery
   * @return
   */
  public List<UserFeedBackRatingsDTO> getAllUsersRatingsForDistributorAdmin(
      Long userId, List<Integer> accessibleOrgs, List<String> roleList, String filteredQuery) {
    String baseSql =
        "SELECT feedback.rating, count(feedback.rating) as total FROM nc_user_profile profile "
            + " join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id "
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + "  where profile.deleted=0 and profile.status='Active' and "
            + " profile.role_id in (select role_id from nc_roles where name in (:roles)) and profile.org_id in (:accessibleOrgs) ";

    String orderBy = " group by feedback.rating order by feedback.rating desc";
    String finalQuery = baseSql + filteredQuery + orderBy;
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", roleList);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (RowMapper<UserFeedBackRatingsDTO>)
            (rs, rowNum) ->
                UserFeedBackRatingsDTO.builder()
                    .ratings(rs.getInt("feedback.rating"))
                    .count(rs.getInt("total"))
                    .build());
  }

  /**
   * NCIOT-11742
   *
   * @param roles
   * @param accessibleOrgs
   * @return
   */
  public List<UserDataDTO> getAllUsersFeedBacksForDistributorAdmin(
      List<String> roles, List<Integer> accessibleOrgs) {
    String sql =
        "SELECT up.user_id,up.first_name,up.last_name,org.name,nl.value,uef.created_date,uef.rating,uef.feed_back FROM nc_user_profile  up "
            + " join nc_user_exp_feedback uef on up.user_id=uef.user_id "
            + " join nc_org org on up.org_id=org.id "
            + " join nc_languages nl on up.language_id=nl.id "
            + " where up.deleted=0 and up.role_id  in(select role_id from nc_roles where name in(:roles)) and up.status='Active' "
            + " and up.org_id in (:accessibleOrgs)";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", roles);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("up.first_name"))
                .userId(Long.valueOf(rs.getString("up.user_id")))
                .lastName(rs.getString("up.last_name"))
                .createdDate(rs.getTimestamp("uef.created_date"))
                .customerOrgName(rs.getString("org.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("uef.feed_back"))
                .rating(rs.getInt("uef.rating"))
                .build());
  }

  public List<String> getUserTerritories(String userId) {
    String GET_TERRITORIES =
        "select ncCountry.country_code from nc_country ncCountry join nc_user_territories ncTerritories on ncCountry.id=ncTerritories.territory_id  where user_id=:userId";
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    return namedParameterJdbcTemplate.queryForList(GET_TERRITORIES, parameters, String.class);
  }

  /**
   * MCOSAT-2105
   *
   * @param roles
   * @param start date
   * @param end date
   * @param logged in user id
   * @return count of users feedback of required roles for LW FSE
   */
  public Long getUserFeedBackCountForFSE(
      String userId, List<String> fseRolesList, String startDate, String endDate) {

    String sql =
        "SELECT count(uef.id) FROM nc_user_profile  up join nc_user_exp_feedback uef on up.user_id=uef.user_id join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) and up.deleted=0 and up.role_id in(select role_id from nc_roles where name in(:roles))and up.status='Active' and uef.created_date BETWEEN (:startDate) AND (:endDate) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", fseRolesList);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    return namedParameterJdbcTemplate.queryForObject(sql, parameters, Long.class);
  }

  /**
   * MCOSAT-2105
   *
   * @param roles
   * @param start date
   * @param end date
   * @return count of users feedback of required roles for Distributor Admin
   */
  public Long getUserFeedBackCountForDistributorAdmin(
      List<String> distAdminRolesList,
      String startDate,
      String endDate,
      List<Integer> accessibleOrgs) {
    String sql =
        "SELECT count(uef.id) FROM nc_user_profile  up "
            + " join nc_user_exp_feedback uef on up.user_id=uef.user_id "
            + " join nc_org org on up.org_id=org.id "
            + " join nc_languages nl on up.language_id=nl.id "
            + " where up.deleted=0 and up.role_id  in(select role_id from nc_roles where name in(:roles)) and up.status='Active' "
            + " and uef.created_date BETWEEN (:startDate) and (:endDate) and up.org_id in (:accessibleOrgs) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", distAdminRolesList);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.queryForObject(sql, parameters, Long.class);
  }

  /**
   * MCOSAT-2105
   *
   * @param roles
   * @param start date
   * @param end date
   * @param logged in user id
   * @return count of users feedback of required roles for Distributor FSE
   */
  public Long getUserFeedBackCountForDistributorFSE(
      String userId,
      List<String> roles,
      String startDate,
      String endDate,
      List<Integer> accessibleOrgs) {

    String sql =
        "SELECT count(uef.id) "
            + " FROM nc_user_profile up "
            + " join nc_user_exp_feedback uef on up.user_id=uef.user_id "
            + " join nc_org org on up.org_id=org.id "
            + " join nc_languages nl on up.language_id=nl.id "
            + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) "
            + " and up.deleted=0 and up.role_id  in(select role_id from nc_roles where name in(:roles)) and "
            + " up.status='Active' "
            + " and uef.created_date BETWEEN (:startDate) and (:endDate) and up.org_id in (:accessibleOrgs) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", roles);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.queryForObject(sql, parameters, Long.class);
  }

  /**
   * MCOSAT-2105
   *
   * @param roles
   * @param start date
   * @param end date
   * @return count of users feedback of required roles
   */
  public Long getAllUsersFeedBackCount(List<String> roles, String startDate, String endDate) {

    String sql =
        "SELECT count(uef.id) FROM nc_user_profile  up join nc_user_exp_feedback uef on up.user_id=uef.user_id join nc_org org on up.org_id=org.id  join nc_languages nl on up.language_id=nl.id where up.deleted=0 and up.role_id in(select role_id from nc_roles where name in(:roles))and up.status='Active' and uef.created_date BETWEEN (:startDate) AND (:endDate) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", roles);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    return namedParameterJdbcTemplate.queryForObject(sql, parameters, Long.class);
  }

  public UserAvgRatingCount getUserFeedBackAvgRatingForFSE(
      String userId, List<String> fseRolesList, String startDate, String endDate) {

    String sql =
        "SELECT avg(uef.rating) as rating, count(uef.user_id) as user FROM nc_user_profile  up join nc_user_exp_feedback uef "
            + "on up.user_id=uef.user_id join nc_org org on up.org_id=org.id  join nc_languages nl "
            + "on up.language_id=nl.id where up.country_id in(select territory_id from nc_user_territories ut "
            + "where ut.user_id=:userId) and up.deleted=0 and up.role_id in(select role_id from nc_roles where name in(:roles)) "
            + "and up.status='Active' and uef.created_date BETWEEN (:startDate) AND (:endDate) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", fseRolesList);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    return namedParameterJdbcTemplate.queryForObject(
        sql,
        parameters,
        (RowMapper<UserAvgRatingCount>)
            (rs, rowNum) ->
                UserAvgRatingCount.builder()
                    .rating(rs.getFloat("rating"))
                    .userRatingCount(rs.getLong("user"))
                    .build());
  }

  public UserAvgRatingCount getUserFeedBackAvgRatingForDistributorAdmin(
      List<String> distAdminRolesList,
      String startDate,
      String endDate,
      List<Integer> accessibleOrgs) {
    String sql =
        "SELECT avg(uef.rating) as rating, count(uef.user_id) as user FROM nc_user_profile  up "
            + " join nc_user_exp_feedback uef on up.user_id=uef.user_id "
            + " join nc_org org on up.org_id=org.id "
            + " join nc_languages nl on up.language_id=nl.id "
            + " where up.deleted=0 and up.role_id  in(select role_id from nc_roles where name in(:roles)) and up.status='Active' "
            + " and uef.created_date BETWEEN (:startDate) and (:endDate) and up.org_id in (:accessibleOrgs) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", distAdminRolesList);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.queryForObject(
        sql,
        parameters,
        (RowMapper<UserAvgRatingCount>)
            (rs, rowNum) ->
                UserAvgRatingCount.builder()
                    .rating(rs.getFloat("rating"))
                    .userRatingCount(rs.getLong("user"))
                    .build());
  }

  public UserAvgRatingCount getUserFeedBackAvgRatingForDistributorFSE(
      String userId,
      List<String> roles,
      String startDate,
      String endDate,
      List<Integer> accessibleOrgs) {

    String sql =
        "SELECT avg(uef.rating) as rating, count(uef.user_id) as user FROM nc_user_profile up "
            + " join nc_user_exp_feedback uef on up.user_id=uef.user_id "
            + " join nc_org org on up.org_id=org.id "
            + " join nc_languages nl on up.language_id=nl.id "
            + " where up.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) "
            + " and up.deleted=0 and up.role_id  in(select role_id from nc_roles where name in(:roles)) and "
            + " up.status='Active' "
            + " and uef.created_date BETWEEN (:startDate) and (:endDate) and up.org_id in (:accessibleOrgs) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", roles);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.queryForObject(
        sql,
        parameters,
        (RowMapper<UserAvgRatingCount>)
            (rs, rowNum) ->
                UserAvgRatingCount.builder()
                    .rating(rs.getFloat("rating"))
                    .userRatingCount(rs.getLong("user"))
                    .build());
  }

  public UserAvgRatingCount getAllUsersFeedBackAvgRating(
      List<String> roles, String startDate, String endDate) {

    String sql =
        "SELECT avg(uef.rating) as rating, count(uef.user_id) as user FROM nc_user_profile  up join nc_user_exp_feedback uef "
            + "on up.user_id=uef.user_id join nc_org org on up.org_id=org.id  join nc_languages nl on "
            + "up.language_id=nl.id where up.deleted=0 and up.role_id in(select role_id from nc_roles where name in(:roles)) "
            + "and up.status='Active' and uef.created_date BETWEEN (:startDate) AND (:endDate) ";

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", roles);
    parameters.addValue("startDate", startDate);
    parameters.addValue("endDate", endDate);
    return namedParameterJdbcTemplate.queryForObject(
        sql,
        parameters,
        (RowMapper<UserAvgRatingCount>)
            (rs, rowNum) ->
                UserAvgRatingCount.builder()
                    .rating(rs.getFloat("rating"))
                    .userRatingCount(rs.getLong("user"))
                    .build());
  }

  public List<UserDataDTO> getAllFeedBacksWithFilters(String userId, String filteredQuery) {

    String baseSql =
        "SELECT profile.user_id,profile.first_name,profile.last_name,o.name,nl.value,feedback.created_date,feedback.rating,feedback.feed_back FROM "
            + " nc_user_profile  profile join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id "
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " join nc_languages nl on profile.language_id=nl.id where profile.country_id in(select territory_id from nc_user_territories ut "
            + " where ut.user_id=:userId) and profile.deleted=0 and profile.role_id not in(select role_id from nc_roles where name in(:roles)) "
            + " and profile.status='Active' ";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", rolesList);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("profile.first_name"))
                .userId(Long.valueOf(rs.getString("profile.user_id")))
                .lastName(rs.getString("profile.last_name"))
                .createdDate(rs.getTimestamp("feedback.created_date"))
                .customerOrgName(rs.getString("o.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("feedback.feed_back"))
                .rating(rs.getInt("feedback.rating"))
                .build());
  }

  public List<UserDataDTO> getAllFeedBacksForDistributorFSEWithFilters(
      String userId, List<String> roles, List<Integer> accessibleOrgs, String filteredQuery) {

    String baseSql =
        "SELECT profile.user_id,profile.first_name,profile.last_name,o.name,nl.value,feedback.created_date,feedback.rating,feedback.feed_back "
            + " FROM nc_user_profile profile "
            + " join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id "
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " join nc_languages nl on profile.language_id=nl.id "
            + " where profile.country_id in(select territory_id from nc_user_territories ut where ut.user_id=:userId) "
            + " and profile.deleted=0 and profile.role_id  in(select role_id from nc_roles where name in(:roles)) and "
            + " profile.status='Active' and profile.org_id in (:accessibleOrgs) ";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("roles", roles);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("profile.first_name"))
                .userId(Long.valueOf(rs.getString("profile.user_id")))
                .lastName(rs.getString("profile.last_name"))
                .createdDate(rs.getTimestamp("feedback.created_date"))
                .customerOrgName(rs.getString("o.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("feedback.feed_back"))
                .rating(rs.getInt("feedback.rating"))
                .build());
  }

  public List<UserDataDTO> getAllUsersFeedBacksForDistributorAdminWithFilters(
      List<String> roles, List<Integer> accessibleOrgs, String filteredQuery) {
    String baseSql =
        "SELECT profile.user_id,profile.first_name,profile.last_name,o.name,nl.value,feedback.created_date,feedback.rating,feedback.feed_back FROM nc_user_profile  profile "
            + " join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id "
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " join nc_languages nl on profile.language_id=nl.id "
            + " where profile.deleted=0 and profile.role_id  in(select role_id from nc_roles where name in(:roles)) and profile.status='Active' "
            + " and profile.org_id in (:accessibleOrgs)";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", roles);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("profile.first_name"))
                .userId(Long.valueOf(rs.getString("profile.user_id")))
                .lastName(rs.getString("profile.last_name"))
                .createdDate(rs.getTimestamp("feedback.created_date"))
                .customerOrgName(rs.getString("o.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("feedback.feed_back"))
                .rating(rs.getInt("feedback.rating"))
                .build());
  }

  public List<UserDataDTO> getAllUsersFeedBacksWithFilters(String filteredQuery) {

    String baseSql =
        "SELECT profile.user_id,profile.first_name,profile.last_name,o.name,nl.value,feedback.created_date,feedback.rating,feedback.feed_back FROM nc_user_profile "
            + " profile join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id "
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " join nc_languages nl on profile.language_id=nl.id where profile.deleted=0 and profile.role_id not in "
            + " (select role_id from nc_roles where name in(:roles)) and profile.status='Active' ";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("roles", rolesList);
    return namedParameterJdbcTemplate.query(
        finalQuery,
        parameters,
        (rs, rowNum) ->
            UserDataDTO.builder()
                .firstName(rs.getString("profile.first_name"))
                .userId(Long.valueOf(rs.getString("profile.user_id")))
                .lastName(rs.getString("profile.last_name"))
                .createdDate(rs.getTimestamp("feedback.created_date"))
                .customerOrgName(rs.getString("o.name"))
                .language(rs.getString("nl.value"))
                .feedback(rs.getString("feedback.feed_back"))
                .rating(rs.getInt("feedback.rating"))
                .build());
  }

  public Long getTotalFSEUsers(Long userId, List<String> rolesList, String filteredQuery) {

    String baseSql =
        "SELECT count(*) as Total_Users FROM nc_user_profile  profile join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id"
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " where profile.country_id in (select territory_id from nc_user_territories ut where ut.user_id=:userId and profile.deleted=0 and profile.status='Active') "
            + " and profile.role_id not in (select role_id from nc_roles where name in(:rolesList))";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("rolesList", rolesList);
    return namedParameterJdbcTemplate.queryForObject(finalQuery, parameters, Long.class);
  }

  public Long getTotalDistributorFSEUsers(
      Long userId, List<String> rolesList, List<Integer> accessibleOrgs, String filteredQuery) {

    String baseSql =
        "SELECT count(*) as Total_Users FROM nc_user_profile  profile join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id"
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " where profile.country_id in (select territory_id from nc_user_territories ut where ut.user_id=:userId and profile.deleted=0 and profile.status='Active') "
            + " and profile.role_id  in (select role_id from nc_roles where name in(:rolesList)) and profile.org_id in (:accessibleOrgs)";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    parameters.addValue("rolesList", rolesList);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.queryForObject(finalQuery, parameters, Long.class);
  }

  public Long getTotalUsersDistributorAdmin(
      List<String> rolesList, List<Integer> accessibleOrgs, String filteredQuery) {

    String baseSql =
        "SELECT count(*) as Total_Users FROM nc_user_profile profile join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id"
            + " inner join nc_roles r on profile.role_id=r.role_id inner join nc_org o on profile.org_id=o.id join nc_country c on profile.country_id = c.id"
            + " where profile.deleted=0 and profile.status='Active' "
            + " and r.name  in (:rolesList) and profile.org_id in (:accessibleOrgs)";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("rolesList", rolesList);
    parameters.addValue("accessibleOrgs", accessibleOrgs);
    return namedParameterJdbcTemplate.queryForObject(finalQuery, parameters, Long.class);
  }

  public Long getTotalUsers(List<String> rolesList, String filteredQuery) {

    String baseSql =
        "SELECT count(1) as Total_Users FROM nc_user_profile profile join nc_user_exp_feedback feedback on profile.user_id=feedback.user_id"
            + " join nc_org o ON  profile.org_id = o.id join nc_country c on profile.country_id = c.id join nc_roles r on r.role_id = profile.role_id "
            + " where profile.role_id in (select role_id from  nc_roles where name not in (:rolesList)) and profile.deleted=0 and profile.status='Active'";

    String finalQuery = baseSql + filteredQuery;

    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("rolesList", rolesList);
    return namedParameterJdbcTemplate.queryForObject(finalQuery, parameters, Long.class);
  }
}
