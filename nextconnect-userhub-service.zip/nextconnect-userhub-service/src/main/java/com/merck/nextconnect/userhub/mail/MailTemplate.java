package com.merck.nextconnect.userhub.mail;

import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import org.springframework.stereotype.Component;

@Component
public interface MailTemplate {

  void sendCountryUpdateAlertMail(String toMail) throws CustomException;

  void sendDeviceAssignmentChangeMail(
      UserProfile userProfile,
      Device device,
      String templateName,
      String categoryName,
      String status)
      throws CustomException;
}
