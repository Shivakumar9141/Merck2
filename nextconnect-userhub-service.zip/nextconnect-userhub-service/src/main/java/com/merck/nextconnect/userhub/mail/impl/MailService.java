package com.merck.nextconnect.userhub.mail.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.config.MailConfig;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.mail.IMailService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.email.entities.EmailAttribute;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/** service class to do mail operations */
/**
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal</a>
 */
@Component
public class MailService implements IMailService {

  @Autowired private MailConfig mailConfig;

  @Value("${nextconnect.login.url}")
  private String loginUrl;

  @Value("${nextconnect.resetpassword.url}")
  private String resetPasswordUrl;

  @Value("${nextconnect.registration.url}")
  private String registrationUrl;

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${nextconnect.environment}")
  private String nextconnectEnvironment;

  @Autowired private EmailTemplateService emailTemplateService;

  @Autowired private EmailService emailService;

  Properties prop = new Properties();
  InputStream input = getClass().getClassLoader().getResourceAsStream("mailtemplate.properties");

  static final Logger logger = LoggerFactory.getLogger(MailService.class);

  /**
   * sending mail
   *
   * @param userProfile - user profile
   * @param action - action (invite user , password update)
   * @param token - jwt token
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  @Override
  public void send(UserProfile userProfile, String action, String jti, String environment)
      throws AddressException, MessagingException, CustomException {
    try {
      prop.load(input);
    } catch (IOException e) {
      logger.info("failed to load mail template");
    }
    String url = registrationUrl + "?token=" + jti;
    String body;
    if (Constants.NEXTCONNECT_AUTH.equals(
        userProfile.getUserDomain().getAuthenticationProvider())) {
      if (Constants.INVITE_USER.equals(action)) {
        if (isLabwaterOrg(userProfile)) {
          /*Made changes as per NCIOT-12313.*/
          AuthenticatedUser authUser =
              UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userProfile.getInvitedVia())
                  ? null
                  : (AuthenticatedUser)
                      SecurityContextHolder.getContext().getAuthentication().getPrincipal();
          EmailTemplate emailTemplate = null;

          if (userProfile.isAutoCreated()
              || UserInvitedVia.SELF_REGISTRATION
                  .value()
                  .equalsIgnoreCase(userProfile.getInvitedVia())) {
            emailTemplate =
                emailTemplateService.findByCategoryAndLanguageId(
                    Constants.INVITE_USER_AUTO_ORG_SELF_REG, userProfile.getLanguage().getId());
          } else if (Constants.LABWATER.equalsIgnoreCase(userProfile.getOrg().getName())) {
            emailTemplate =
                emailTemplateService.findByCategoryAndLanguageId(
                    Constants.INVITE_USER_LABWATER_ROLE_MANUAL, userProfile.getLanguage().getId());
          } else {
            emailTemplate =
                emailTemplateService.findByCategoryAndLanguageId(
                    Constants.INVITE_USER_NON_LABWATER_ROLE_MANUAL,
                    userProfile.getLanguage().getId());
          }
          EmailMessage emailMessageCustomer =
              EmailMessage.builder()
                  .emailTemplate(emailTemplate)
                  .emailFrom(fromEmail)
                  .emailTo(userProfile.getEmail())
                  .subject(Constants.MILLIQ_CONNECT_INVITATION)
                  .status(Constants.EMAIL_SUCCESS_STATUS)
                  .createdBy(
                      UserInvitedVia.SELF_REGISTRATION
                              .value()
                              .equalsIgnoreCase(userProfile.getInvitedVia())
                          ? UserInvitedVia.SELF_REGISTRATION.value()
                          : authUser.getId())
                  .createdTimestamp(Timestamp.from(Instant.now()))
                  .lastUpdatedBy(
                      UserInvitedVia.SELF_REGISTRATION
                              .value()
                              .equalsIgnoreCase(userProfile.getInvitedVia())
                          ? UserInvitedVia.SELF_REGISTRATION.value()
                          : authUser.getId())
                  .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
                  .charset(Constants.EMAIL_CHAR_SET)
                  .contentType(Constants.EMAIL_CONTENT_TYPE)
                  .build();
          Set<EmailAttribute> emailAttributeSet = new HashSet<>();

          if (userProfile.isAutoCreated()
              || UserInvitedVia.SELF_REGISTRATION
                  .value()
                  .equalsIgnoreCase(userProfile.getInvitedVia())) {
            emailAttributeSet.add(
                EmailAttribute.builder()
                    .attributeName(Constants.FIRST_NAME)
                    .attributeValue(userProfile.getFirstName())
                    .emailMessage(emailMessageCustomer)
                    .build());
            emailAttributeSet.add(
                EmailAttribute.builder()
                    .attributeName(Constants.LAST_NAME)
                    .attributeValue(userProfile.getLastName())
                    .emailMessage(emailMessageCustomer)
                    .build());
          }
          emailAttributeSet.add(
              EmailAttribute.builder()
                  .attributeName(Constants.REGISTRATION_LINK)
                  .attributeValue(url)
                  .emailMessage(emailMessageCustomer)
                  .build());
          emailAttributeSet.add(
              EmailAttribute.builder()
                  .attributeName(Constants.NEXTCONNECT_ENV)
                  .attributeValue(nextconnectEnvironment)
                  .emailMessage(emailMessageCustomer)
                  .build());
          emailAttributeSet.add(
              EmailAttribute.builder()
                  .attributeName(Constants.LOGIN_NAME)
                  .attributeValue(userProfile.getLoginName())
                  .emailMessage(emailMessageCustomer)
                  .build());
          emailMessageCustomer.setEmailAttributes(emailAttributeSet);
          try {
            emailService.sendMail(emailMessageCustomer, environment);
          } catch (Exception e) {
            logger.info("Error while sending invite email to --> {}", userProfile.getEmail(), e);
            throw new CustomException(CustomErrorCodes.EMAIL_SENDING_ERROR);
          }
        } else {
          body =
              prop.getProperty("mailtemplate.userinvite.nextconnect.content1")
                  + userProfile.getLoginName()
                  + prop.getProperty("mailtemplate.userinvite.content2")
                  + url
                  + prop.getProperty("mailtemplate.userinvite.button")
                  + prop.getProperty("mailtemplate.footer");
          sendMail(userProfile.getEmail(), Constants.NEXTCONNECT_INVITATION, body, environment);
        }

      } else {
        url = resetPasswordUrl + "?token=" + jti;
        if (isLabwaterOrg(userProfile)) {

          EmailTemplate emailTemplate =
              emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
                  Constants.PASSWORD_FORGOT, userProfile.getLanguage().getId(), Constants.ACTIVE);

          EmailMessage emailMessageCustomer =
              EmailMessage.builder()
                  .emailTemplate(emailTemplate)
                  .emailFrom(fromEmail)
                  .emailTo(userProfile.getEmail())
                  .subject(Constants.MILLIQ_CONNECT_PASSWORD_UPDATE)
                  .status(Constants.EMAIL_SUCCESS_STATUS)
                  .createdBy(Constants.PASSWORD_FORGOT)
                  .createdTimestamp(Timestamp.from(Instant.now()))
                  .lastUpdatedBy(Constants.PASSWORD_FORGOT)
                  .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
                  .charset(Constants.EMAIL_CHAR_SET)
                  .contentType(Constants.EMAIL_CONTENT_TYPE)
                  .build();
          Set<EmailAttribute> emailAttributeSet = new HashSet<>();
          emailAttributeSet.add(
              EmailAttribute.builder()
                  .attributeName(Constants.RESET_URL)
                  .attributeValue(url)
                  .emailMessage(emailMessageCustomer)
                  .build());
          emailMessageCustomer.setEmailAttributes(emailAttributeSet);
          try {
            emailService.sendMail(emailMessageCustomer, environment);
          } catch (Exception e) {
            logger.info(
                "Error while sending password reset email to --> {}", userProfile.getEmail(), e);
            throw new CustomException(CustomErrorCodes.EMAIL_SENDING_ERROR);
          }
        } else {
          body =
              prop.getProperty("mailtemplate.password.content")
                  + url
                  + prop.getProperty("mailtemplate.password.button")
                  + prop.getProperty("mailtemplate.footer");
          sendMail(
              userProfile.getEmail(), Constants.NEXTCONNECT_PASSWORD_UPDATE, body, environment);
        }
      }
    } else if (Constants.MERCK_AUTH.equals(
        userProfile.getUserDomain().getAuthenticationProvider())) {
      if (isLabwaterOrg(userProfile)) {
        AuthenticatedUser authUser =
            (AuthenticatedUser)
                SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        EmailTemplate emailTemplate =
            emailTemplateService.findByCategoryAndLanguageId(
                Constants.INVITE_USER_LABWATER_ROLE_MANUAL, userProfile.getLanguage().getId());
        EmailMessage emailMessageCustomer =
            EmailMessage.builder()
                .emailTemplate(emailTemplate)
                .emailFrom(fromEmail)
                .emailTo(userProfile.getEmail())
                .subject(Constants.MILLIQ_CONNECT_INVITATION)
                .status(Constants.EMAIL_SUCCESS_STATUS)
                .createdBy(authUser.getId())
                .createdTimestamp(Timestamp.from(Instant.now()))
                .lastUpdatedBy(authUser.getId())
                .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
                .charset(Constants.EMAIL_CHAR_SET)
                .contentType(Constants.EMAIL_CONTENT_TYPE)
                .build();
        Set<EmailAttribute> emailAttributeSet = new HashSet<>();
        emailAttributeSet.add(
            EmailAttribute.builder()
                .attributeName(Constants.REGISTRATION_LINK)
                .attributeValue(url)
                .emailMessage(emailMessageCustomer)
                .build());
        emailAttributeSet.add(
            EmailAttribute.builder()
                .attributeName(Constants.NEXTCONNECT_ENV)
                .attributeValue(nextconnectEnvironment)
                .emailMessage(emailMessageCustomer)
                .build());
        emailAttributeSet.add(
            EmailAttribute.builder()
                .attributeName(Constants.LOGIN_NAME)
                .attributeValue(userProfile.getLoginName())
                .emailMessage(emailMessageCustomer)
                .build());
        emailMessageCustomer.setEmailAttributes(emailAttributeSet);
        try {
          emailService.sendMail(emailMessageCustomer, environment);
        } catch (Exception e) {
          logger.info("Error while sending invite email to --> {}", userProfile.getEmail(), e);
          throw new CustomException(CustomErrorCodes.EMAIL_SENDING_ERROR);
        }
      } else {
        body =
            prop.getProperty("mailtemplate.userinvite.merck.content1")
                + "Your Domain Name\\"
                + userProfile.getLoginName()
                + prop.getProperty("mailtemplate.userinvite.merck.note")
                + prop.getProperty("mailtemplate.userinvite.content2")
                + url
                + prop.getProperty("mailtemplate.userinvite.button")
                + prop.getProperty("mailtemplate.footer");

        sendMail(userProfile.getEmail(), Constants.NEXTCONNECT_INVITATION, body, environment);
      }

    } else {
      if (isLabwaterOrg(userProfile)) {
        AuthenticatedUser authUser =
            (AuthenticatedUser)
                SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        EmailTemplate emailTemplate =
            emailTemplateService.findByCategoryAndLanguageId(
                Constants.INVITE_USER_LABWATER_ROLE_MANUAL, userProfile.getLanguage().getId());
        EmailMessage emailMessageCustomer =
            EmailMessage.builder()
                .emailTemplate(emailTemplate)
                .emailFrom(fromEmail)
                .emailTo(userProfile.getEmail())
                .subject(Constants.MILLIQ_CONNECT_INVITATION)
                .status(Constants.EMAIL_SUCCESS_STATUS)
                .createdBy(authUser.getId())
                .createdTimestamp(Timestamp.from(Instant.now()))
                .lastUpdatedBy(authUser.getId())
                .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
                .charset(Constants.EMAIL_CHAR_SET)
                .contentType(Constants.EMAIL_CONTENT_TYPE)
                .build();
        Set<EmailAttribute> emailAttributeSet = new HashSet<>();
        emailAttributeSet.add(
            EmailAttribute.builder()
                .attributeName(Constants.REGISTRATION_LINK)
                .attributeValue(url)
                .emailMessage(emailMessageCustomer)
                .build());
        emailAttributeSet.add(
            EmailAttribute.builder()
                .attributeName(Constants.NEXTCONNECT_ENV)
                .attributeValue(nextconnectEnvironment)
                .emailMessage(emailMessageCustomer)
                .build());
        emailAttributeSet.add(
            EmailAttribute.builder()
                .attributeName(Constants.LOGIN_NAME)
                .attributeValue(userProfile.getLoginName())
                .emailMessage(emailMessageCustomer)
                .build());
        emailMessageCustomer.setEmailAttributes(emailAttributeSet);
        try {
          emailService.sendMail(emailMessageCustomer, environment);
        } catch (Exception e) {
          logger.info("Error while sending invite email to --> {}", userProfile.getEmail(), e);
          throw new CustomException(CustomErrorCodes.EMAIL_SENDING_ERROR);
        }
      } else {
        body =
            prop.getProperty("mailtemplate.userinvite.sial.content1")
                + userProfile.getLoginName()
                + prop.getProperty("mailtemplate.userinvite.content2")
                + url
                + prop.getProperty("mailtemplate.userinvite.button")
                + prop.getProperty("mailtemplate.footer");

        sendMail(userProfile.getEmail(), Constants.NEXTCONNECT_INVITATION, body, environment);
      }
    }
  }

  /**
   * sending mail
   *
   * @param to - email
   * @param subject - subject
   * @param body - content
   * @throws MessagingException
   * @throws AddressException
   */
  @Override
  public void sendMail(String to, String subject, String body, String environment)
      throws AddressException, MessagingException {
    mailConfig.send(to, subject, body, environment);
    logger.info("mail sent successfully");
  }

  private boolean isLabwaterOrg(UserProfile userProfile) {
    if (userProfile.getOrg().getName().equalsIgnoreCase(Constants.LABWATER)) {
      return true;
    } else if (userProfile.getOrg().getParent() != null
        && (userProfile.getOrg().getParent().getName().equalsIgnoreCase(Constants.LABWATER)
            || userProfile
                .getOrg()
                .getParent()
                .getParent()
                .getName()
                .equalsIgnoreCase(Constants.LABWATER))) {
      return true;
    } else {
      return false;
    }
  }
}
