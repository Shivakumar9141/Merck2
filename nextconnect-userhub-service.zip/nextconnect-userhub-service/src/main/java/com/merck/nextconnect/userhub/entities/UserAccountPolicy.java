package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "NC_USER_ACCOUNT_POLICY")
public class UserAccountPolicy {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @Column(columnDefinition = "int default 0", nullable = false)
  private int failedAttempts;

  private Date lastFailed;

  @OneToOne
  @JoinColumn(name = "USER_ID")
  private UserProfile userProfile;

  public UserAccountPolicy() {}

  public UserAccountPolicy(UserProfile userProfile, int failedAttempts, Date lastFailed) {
    this.userProfile = userProfile;
    this.failedAttempts = failedAttempts;
    this.lastFailed = lastFailed;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public int getFailedAttempts() {
    return failedAttempts;
  }

  public void setFailedAttempts(int failedAttempts) {
    this.failedAttempts = failedAttempts;
  }

  public Date getLastFailed() {
    return lastFailed;
  }

  public void setLastFailed(Date lastFailed) {
    this.lastFailed = lastFailed;
  }

  public UserProfile getUserProfile() {
    return userProfile;
  }

  public void setUserProfile(UserProfile userProfile) {
    this.userProfile = userProfile;
  }
}
