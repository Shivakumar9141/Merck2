package com.merck.nextconnect.userhub.util;

import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.utils.sms.resources.SmsService;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

// change for NCIOT-10694, NCIOT-10688
/**
 * @author pkumar12 07-08-2020
 */
@Service
public class SmsServiceValidation {

  @Value("${nextconnect.sms.url}")
  private String smsHost;

  @Value("${nextconnect.sms.username}")
  private String smsUsername;

  @Value("${nextconnect.sms.password}")
  private String smsPassword;

  @Autowired private SmsService smsService;

  static final Logger logger = LoggerFactory.getLogger(SmsServiceValidation.class);

  // change for NCIOT-10694
  /**
   * This method is used to validate data before sending SMS
   *
   * @param templateName,categoryName,userProfile,device
   * @throws JSONException
   * @return void
   */
  public void validateAndSendSMS(
      String templateName, String categoryName, UserProfile userProfile, Device device)
      throws JSONException {
    try {
      logger.info(
          "Template Name : {} ,Category Name : {}, UserProfile : {}, Device details : {}",
          templateName,
          categoryName,
          String.valueOf(userProfile),
          String.valueOf(device));
      String phoneNumber = "";
      String username = "";
      String systemName = "";
      boolean flag = false;
      if (!StringUtils.isBlank(userProfile.getIsdCode())
          && !StringUtils.isBlank(userProfile.getPhone())) {
        flag = true;
      }
      phoneNumber =
          (StringUtils.isBlank(userProfile.getIsdCode()) ? "" : userProfile.getIsdCode())
              + (StringUtils.isBlank(userProfile.getPhone()) ? "" : userProfile.getPhone());
      username =
          (StringUtils.isBlank(userProfile.getFirstName()) ? "" : userProfile.getFirstName())
              + " "
              + (StringUtils.isBlank(userProfile.getLastName()) ? "" : userProfile.getLastName());
      systemName = StringUtils.isBlank(device.getDevicename()) ? "" : device.getDevicename();
      if (flag == true) {
        smsService.sendSMSAsPerTemplate(
            phoneNumber,
            templateName,
            categoryName,
            username,
            systemName,
            smsHost,
            smsUsername,
            smsPassword,
            userProfile.getLanguage().getId());
      } else {
        logger.error("ISD code or Phone number is empty for user {}", String.valueOf(userProfile));
      }
    } catch (Exception e) {
      logger.error("Exception occured while sending SMS with exception : {}", e);
    }
  }
}
