package com.merck.nextconnect.userhub.validator.impl;

import static com.merck.nextconnect.utils.validations.helper.FileValidationHelpers.inExtensionString;
import static com.merck.nextconnect.utils.validations.helper.FileValidationHelpers.sizeMoreThan;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.validator.UserProfileValidator;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author SHATHWAR Interface implementation for validating the user profile. Changes made as per
 *     NCIOT-11630.
 */
@Service
public class UserProfileValidatorImpl implements UserProfileValidator {

  private List<String> validImageExtensionList = Arrays.asList("jpeg", "jpg", "png");
  private static final long MAX_FILE_SIZE = 4194304L;

  static final Logger logger = LoggerFactory.getLogger(UserProfileValidatorImpl.class);

  /**
   * Changes made as per NCIOT-11630. Validating the user profile to check whether the user profile
   * status is expired or not Validating the user profile is auto-created or not.
   *
   * @param UserProfile
   */
  @Override
  public void validateUserProfile(UserProfile userProfile) throws CustomException {
    if (!userProfile.getStatus().equalsIgnoreCase("expired")) {
      logger.info("User profile status is not expired emailID -> {}", userProfile.getEmail());
      throw new CustomException(CustomErrorCodes.USER_STATUS_NOT_EXPIRED);
    }

    if (!userProfile.isAutoCreated()) {
      logger.info("User is not auto created, emailID -> {}", userProfile.getEmail());
      throw new CustomException(CustomErrorCodes.USER_NOT_AUTO_CREATED);
    }
  }

  @Override
  public void UserProfileImageValidator(MultipartFile image) throws DataValidationException {
    if (image != null) {
      inExtensionString(validImageExtensionList)
          .test(image)
          .throwIfInvalid("image", validImageExtensionList.toString());
      sizeMoreThan(MAX_FILE_SIZE).test(image).throwIfInvalid("image", "4MB");
    }
  }
}
