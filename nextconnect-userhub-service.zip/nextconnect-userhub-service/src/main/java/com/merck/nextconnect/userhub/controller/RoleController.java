package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.util.EntityPrivileges;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.MethodNotAllowedException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupAccess;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleInfo;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.resources.IRoles;
import com.merck.nextconnect.userhub.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriTemplate;

@Component
@RestController
@RequestMapping("/api/roles")
public class RoleController {

  static final Logger logger = LoggerFactory.getLogger(RoleController.class);

  @Autowired IRoles iroles;

  /**
   * add a role
   *
   * @param roleInfo - roleInfo (name,desc)
   * @throws DuplicateResourceException - duplicate resource exception
   * @throws DataValidationException
   */
  @Operation(
      summary = "Add a role",
      tags = "Roles",
      description = "This API is used to create a new role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST)
  @PreAuthorize(EntityPrivileges.CREATE_ROLE)
  public ResponseEntity<?> addRole(
      @Parameter(name = "role", description = "role details", schema = @Schema(defaultValue = ""))
          @RequestBody
          RoleInfo roleInfo)
      throws DuplicateResourceException, DataValidationException {
    long roleId = iroles.add(roleInfo);
    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(new UriTemplate("/roles/{roleId}").expand(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ROLE, Constants.POST, null));
    return new ResponseEntity<>(headers, HttpStatus.CREATED);
  }

  /**
   * List all roles
   *
   * @return roles
   */
  @Operation(description = "List all roles", tags = "Roles")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET)
  @PreAuthorize(EntityPrivileges.CREATE_USER) // Pentest
  public ResponseEntity<List<Role>> getRoles(
      @Parameter(name = "orgId", description = "orgId", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "orgId", required = false)
          Integer orgId)
      throws ResourceNotFoundException {
    List<Role> roles = new ArrayList<Role>();
    roles = iroles.getAll(orgId);
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ROLE, Constants.GET, null));
    return new ResponseEntity<List<Role>>(roles, HttpStatus.OK);
  }

  /**
   * delete a role
   *
   * @param roleId - id of the role
   * @throws MethodNotAllowedException - method not allowed
   */
  @Operation(
      summary = "Delete a role",
      tags = "Roles",
      description = "This API is used to deleete a role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}")
  @PreAuthorize(EntityPrivileges.DELETE_ROLE)
  public ResponseEntity<String> deleteRole(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId)
      throws DataValidationException {
    iroles.delete(roleId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ROLE, Constants.DELETE, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  /**
   * get a role
   *
   * @param roleId - id of the role
   * @return role
   */
  @Operation(
      summary = "get a role",
      tags = "Roles",
      description = "This API is used get a single Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/{id}")
  @PreAuthorize(EntityPrivileges.READ_ROLE)
  public ResponseEntity<Role> getRole(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId) {
    Role role = iroles.fetchOne(roleId);
    if (role == null) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ROLE, Constants.GET, properties));
    return new ResponseEntity<Role>(role, HttpStatus.OK);
  }

  @Operation(
      summary = "Get all previleges of the Role",
      tags = "Roles",
      description = "This API is used get all previleges of a Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize(EntityPrivileges.READ_ROLE)
  @RequestMapping(method = RequestMethod.GET, value = "/{id}/privileges")
  public ResponseEntity<List<RolePrivilege>> getPrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(
              name = "filterBy",
              description = "filter category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          String filterBy)
      throws InterruptedException, ExecutionException, ResourceNotFoundException {
    List<RolePrivilege> privileges = iroles.getPrivileges(roleId, filterBy);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.GET, properties));
    return new ResponseEntity<List<RolePrivilege>>(privileges, HttpStatus.OK);
  }

  @Operation(
      summary = "add privileges to a Role",
      tags = "Roles",
      description = "This API is used to add privileges to a Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST, value = "/{id}/privileges")
  @PreAuthorize("hasAnyAuthority('create_role','update_role')")
  public ResponseEntity<?> addPrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(
              name = "list of privileges",
              description = "list of privileges",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          List<ResourcePrivilege> resourcePrivilege) {
    iroles.addPrivileges(roleId, resourcePrivilege);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.POST, properties));
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  @Operation(
      summary = "delete privileges of a Role",
      tags = "Roles",
      description = "This API is used delete privileges of a Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize("hasAnyAuthority('create_role','update_role')")
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}/privileges")
  public ResponseEntity<?> deletePrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(
              name = "list of privileges",
              description = "list of privileges",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          List<ResourcePrivilege> resourcePrivilege) {
    iroles.deletePrivileges(roleId, resourcePrivilege);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.DELETE, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Operation(
      summary = "Get all devicegroup previleges of the Role",
      tags = "Roles",
      description = "This API is used to get all devicegroup previleges of the Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize(EntityPrivileges.READ_ROLE)
  @RequestMapping(method = RequestMethod.GET, value = "/{id}/devicegroups")
  public ResponseEntity<DeviceGroupPrivilege> getDeviceGroupPrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(
              name = "devicetype",
              description = "id of devicetype",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "devicetype")
          long devicetype)
      throws ResourceNotFoundException {
    DeviceGroupPrivilege privileges = iroles.getDeviceGroupPrivileges(roleId, devicetype);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.GET, properties));
    return new ResponseEntity<DeviceGroupPrivilege>(privileges, HttpStatus.OK);
  }

  @Operation(
      summary = "add devicegroup privileges to a Role",
      tags = "Roles",
      description = "This API is used to add devicegroup privileges to a Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize("hasAnyAuthority('create_role','update_role')")
  @RequestMapping(method = RequestMethod.POST, value = "/{id}/devicegroups")
  public ResponseEntity<?> addDeviceGroupPrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(
              name = "list of privileges",
              description = "list of privileges",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          List<DeviceGroupAccess> deviceGroupAccess) {
    iroles.addDeviceGroupPrivileges(roleId, deviceGroupAccess);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.POST, properties));
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  @Operation(
      summary = "delete devicegroup privileges of a Role",
      tags = "Roles",
      description = "This API is used to delete devicegroup privileges of a Role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize("hasAnyAuthority('create_role','update_role')")
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}/devicegroups")
  public ResponseEntity<?> deleteDeviceGroupPrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(
              name = "list of privileges",
              description = "list of privileges",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          List<DeviceGroupAccess> deviceGroupAccess) {
    iroles.deleteDeviceGroupPrivileges(roleId, deviceGroupAccess);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.DELETE, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Operation(
      summary = "update a Role",
      tags = "Roles",
      description = "This API is used to update an existing role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.PUT, value = "/{id}")
  @PreAuthorize("hasAnyAuthority('create_role','update_role')")
  public ResponseEntity<?> updateRole(
      @Parameter(name = "id", description = "role id", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId,
      @Parameter(name = "role", description = "role details", schema = @Schema(defaultValue = ""))
          @RequestBody
          RoleInfo roleInfo)
      throws DataValidationException, DuplicateResourceException, ResourceNotFoundException {
    iroles.update(roleInfo, roleId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.ROLE, Constants.PUT, properties));
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "Get all previleges of the Role for Manage role",
      tags = "Roles",
      description = "This API is used get all previleges of a Role  for Manage role")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PreAuthorize(EntityPrivileges.READ_ROLE)
  @RequestMapping(method = RequestMethod.GET, value = "manage/{id}/privileges")
  public ResponseEntity<List<RolePrivilege>> getPrivileges(
      @Parameter(name = "id", description = "id of the role", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long roleId)
      throws InterruptedException, ExecutionException, ResourceNotFoundException {
    List<RolePrivilege> privileges = iroles.getPrivileges(roleId);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(roleId));
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.GET, properties));
    return new ResponseEntity<List<RolePrivilege>>(privileges, HttpStatus.OK);
  }
}
