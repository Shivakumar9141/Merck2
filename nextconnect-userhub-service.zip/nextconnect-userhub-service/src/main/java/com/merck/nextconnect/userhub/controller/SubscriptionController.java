package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.EmailSubscriptionValidationDTO;
import com.merck.nextconnect.userhub.model.InvalidEmailsDTO;
import com.merck.nextconnect.userhub.model.PhoneNumberDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.ISubscriptionType;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.resources.IUserSubscription;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.Entityprivileges;
import com.merck.nextconnect.utils.exception.EmailException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
@RequestMapping("/api/v1")
public class SubscriptionController {

  static final Logger logger = LoggerFactory.getLogger(SubscriptionController.class);

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Autowired private ISubscriptionType subscriptionTypeService;
  @Autowired private IUserSubscription userSubscriptionService;
  @Autowired IUser iuser;
  @Autowired UserRepository userRepository;

  @PreAuthorize(Entityprivileges.EMAIL_NOTIFICATION_SUBSCRIPTION)
  @Operation(description = "Fetch all subscription Types", tags = "Subscriptions")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/subscription")
  // @PreAuthorize(EntityPrivileges.READ_USER)
  public ResponseEntity<List<SubscriptionTypeDTO>> getAllUsers() {
    List<SubscriptionTypeDTO> subscriptionTypes = subscriptionTypeService.getAllSubscription();
    return new ResponseEntity<List<SubscriptionTypeDTO>>(subscriptionTypes, HttpStatus.OK);
  }

  @PreAuthorize(Entityprivileges.EMAIL_NOTIFICATION_SUBSCRIPTION)
  @Operation(
      summary = "get user Subscription Categories and email subscriptions",
      tags = "Subscriptions",
      description =
          "This API is used to get user subscription categories and the emails subscribed")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/subscription/{userId}")
  // @PreAuthorize(EntityPrivileges.CREATE_USER)
  public ResponseEntity<UserSubscriptionDTO> getSubscription(
      @Parameter(
              name = "userId",
              description = "id of the user",
              schema = @Schema(defaultValue = ""))
          @PathVariable(value = "userId")
          long userId)
      throws CustomException {

    UserSubscriptionDTO userSubscriptionDTO =
        userSubscriptionService.fetchAllUserSubscriptionByUser(userId);
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.USER, Constants.GET, null));
    return new ResponseEntity<>(userSubscriptionDTO, HttpStatus.OK);
  }

  @PreAuthorize(Entityprivileges.EMAIL_NOTIFICATION_SUBSCRIPTION)
  @Operation(
      summary = "Search mail Ids based on the input",
      tags = "Subscriptions",
      description = "This API is used to list the mail Ids of the users")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/subscription/{mailId}/search")
  public ResponseEntity<?> searchMailId(
      @Parameter(
              name = "mailId",
              description = "id of the user",
              schema = @Schema(defaultValue = ""))
          @PathVariable(value = "mailId")
          String mailId) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<String> mailSearches =
        mailId.trim().isEmpty()
            ? new ArrayList<>()
            : userRepository.findEmailsByOrgIdAndStatusAndDeleted(
                mailId, authUser.getOrgId(), UserStatus.ACTIVE.value(), false);
    return new ResponseEntity<List<String>>(mailSearches, HttpStatus.OK);
  }

  @PreAuthorize(Entityprivileges.EMAIL_NOTIFICATION_SUBSCRIPTION)
  @Operation(
      summary = "Validate the mail Id",
      tags = "Subscriptions",
      description = "This API is used to validate a user mail Id based on email subscriptions")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(
      method = RequestMethod.POST,
      produces = {MediaType.APPLICATION_JSON_VALUE},
      value = "/subscription")
  public ResponseEntity<InvalidEmailsDTO> validateMailId(
      @Parameter(
              name = "emailSubscriptionValidationDTO",
              description = "emailSubscriptionValidationDTO",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          EmailSubscriptionValidationDTO emailSubscriptionValidationDTO)
      throws CustomException {
    InvalidEmailsDTO invalidEmails =
        userSubscriptionService.validateEmails(emailSubscriptionValidationDTO);
    return new ResponseEntity<InvalidEmailsDTO>(invalidEmails, HttpStatus.OK);
  }

  @Operation(
      summary = "Unsubscribe user from platform",
      tags = "Users",
      description = "This API is used to unsubscribe a user from platform")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.DELETE, value = "/user-unsubscribe")
  public ResponseEntity<?> unsubscribeUser()
      throws DataValidationException, EmailException, CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    long userId = Long.parseLong(authUser.getId());
    iuser.unSubscribe(userId, authUser.getOrgId(), authUser.getRoleId(), environment);
    Map<String, String> properties = new HashMap<>();
    properties.put("resourceId", String.valueOf(userId));
    AuditLogger.getInstance()
        .auditLog(
            AuditLoggerUtil.formatLog(Constants.USER, Constants.UNSUBSCRIBE_USER, properties));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Operation(
      summary = "Send the OTP to the phonenumber",
      tags = "Subscriptions",
      description = "This API is used to send the OTP to the mobile number entered by the user")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PostMapping("/subscription/otp")
  public ResponseEntity<?> sendOTP(
      @Parameter(
              name = "phoneNumber",
              description = "Mobile number of the user",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          PhoneNumberDTO phoneNumberDTO)
      throws CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    userSubscriptionService.sendOTP(
        Long.parseLong(authUser.getId()),
        phoneNumberDTO.getIsdCode(),
        phoneNumberDTO.getPhoneNumber());
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Operation(
      summary = "Validate the OTP to the phonenumber",
      tags = "Subscriptions",
      description = "This API is used to validate the OTP")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/subscription/otp")
  public ResponseEntity<?> validateOTP(
      @Parameter(
              name = "isdCode",
              description = "ISD Code of the user",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "isdCode", required = false)
          String isdCode,
      @Parameter(
              name = "phoneNumber",
              description = "Mobile number of the user",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "phoneNumber", required = false)
          String phoneNumber,
      @Parameter(
              name = "otp",
              description = "OTP received on the phone of the user",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "otp", required = false)
          String otp)
      throws CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    userSubscriptionService.validateOTP(
        Long.parseLong(authUser.getId()), isdCode, phoneNumber, otp);
    return new ResponseEntity<>(HttpStatus.OK);
  }
}
