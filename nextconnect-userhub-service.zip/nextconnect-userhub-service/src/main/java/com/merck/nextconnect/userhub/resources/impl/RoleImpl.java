package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.util.RoleConstants;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupAccess;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleInfo;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleCardPrivilegesRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IRoles;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

/**
 * service class to perform role operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public class RoleImpl implements IRoles {

  static final Logger logger = LoggerFactory.getLogger(RoleImpl.class);

  @Autowired RoleRepository roleRepo;

  @Autowired UserRolePrivileges userRolePrivileges;

  @Autowired UserRepository userRepo;

  @Autowired OrganizationRepository orgRepo;

  @Autowired IOrgPermissions orgPermissions;

  @Autowired RoleCardPrivilegesRepository roleCardPrivilegesRepo;

  private String roleNamePattern = "^[a-zA-Z][a-zA-Z0-9 .-]{1,15}$";

  /**
   * add a role
   *
   * @param role - role (roleName,roleDesc)
   * @return roleId
   * @throws DuplicateResourceException
   * @throws DataValidationException
   */
  public long add(RoleInfo roleInfo) throws DuplicateResourceException, DataValidationException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    if (!UserhubUtils.validatePattern(roleNamePattern, roleInfo.getName())) {
      throw new DataValidationException(CustomErrorCodes.ROLE_VALIDATION_ERROR);
    }
    if (roleRepo.getRoleByName(roleInfo.getName(), authUser.getOrgId()) != null) {
      throw new DuplicateResourceException(CustomErrorCodes.ROLE_NAME_CONFLICT);
    }
    Role role = new Role(roleInfo);
    Organization org = orgRepo.findById(authUser.getOrgId()).get();
    role.setOrg(org);
    long roleId = roleRepo.save(role).getRoleId();
    return roleId;
  }

  /**
   * delete a role
   *
   * @param roleId - id of the role
   * @throws DataValidationException
   */
  public void delete(long roleId) throws DataValidationException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Role role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    Optional.ofNullable(role)
        .filter(r -> !r.isSystemDefined())
        .orElseThrow(() -> new DataValidationException("cannot delete system defined role"));
    Optional.ofNullable(roleId)
        .filter(r -> userRepo.getUsersByRole(roleId, authUser.getOrgId()).isEmpty())
        .orElseThrow(
            () ->
                new DataValidationException(
                    "cannot delete role that is having at least 1 user assigned"));
    Optional.ofNullable(roleId)
        .filter(r -> userRepo.getUsersByRole(roleId, authUser.getOrgId()).isEmpty())
        .ifPresent(
            r -> {
              userRepo.removeDeletedUsersRole(roleId, authUser.getOrgId());
              userRolePrivileges.roleEntityPrivilegesRepo.deleteByRoleId(roleId);
              userRolePrivileges.roleDeviceTypePrivilegesRepo.deleteByRoleId(roleId);
              userRolePrivileges.roleDeviceGroupPrivilegesRepo.deleteByRoleId(roleId);
              userRolePrivileges.deleteMeasureEventGroupsByRoleId(roleId);
              userRolePrivileges.deleteOrgPrivilegesByRoleId(roleId);
              roleCardPrivilegesRepo.deleteByRoleId(roleId);
              roleRepo.deleteByOrgId(roleId, authUser.getOrgId());
            });
  }

  /**
   * get all roles
   *
   * @return List<role>
   * @throws ResourceNotFoundException
   */
  public List<Role> getAll(Integer orgId) throws ResourceNotFoundException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    List<Role> roles;
    if (orgId == null || orgId == authUser.getOrgId()) {
      roles =
          authUser.isSystemDefinedRole()
              ? roleRepo
                  .getAllForSystemDefinedRolesWithCustomer(
                      authUser.getRoleId(), authUser.getOrgId())
                  .stream()
                  .filter(distinctByKey(Role::getName))
                  .collect(Collectors.toList())
              : roleRepo.getUserDefinedRoles(authUser.getOrgId());
    } else {
      Optional.ofNullable(orgId)
          .filter(uD -> orgPermissions.hasRoleAccess(orgId, OrgPrivileges.manage_accounts))
          .orElseThrow(() -> new AccessDeniedException("User doesnt have access to the given org"));
      roles = roleRepo.getRoles(orgId);
    }
    // NCIOT-12118,12122,12120
    filterRoles(orgId, authUser.getRole(), roles);
    UserProfile profile = userRepo.findById(Long.valueOf(authUser.getId())).get();
    Optional<List<Organization>> orgs = orgRepo.findByType(Constants.DISTRIBUTOR);
    if (orgs.isPresent()) {
      List<Integer> orgIds =
          orgs.get().stream().map(Organization::getId).collect(Collectors.toList());
      if (profile.getRole().getName().equals(Constants.CUSTOMER_ADMIN)
          && orgIds.contains(profile.getOrg().getParent().getId())) {
        logger.info(
            "User Name is {} and the parent Organization {} ",
            profile.getLoginName(),
            profile.getOrg().getParent());
        roles.removeIf(r -> r.getName().equalsIgnoreCase(RoleConstants.EXTERNAL_CUSTOMER_TECH));
      }
    }
    return roles;
  }

  // NCIOT-16412
  private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
    Set<Object> seen = ConcurrentHashMap.newKeySet();
    return t -> seen.add(keyExtractor.apply(t));
  }

  /**
   * //NCIOT-12118,12122,12120 Filter roles based on the logged user and the organization type
   * selected
   *
   * @param orgId
   * @param role
   * @param roles
   * @throws ResourceNotFoundException
   */
  private void filterRoles(Integer orgId, String role, List<Role> roles)
      throws ResourceNotFoundException {
    if (Optional.ofNullable(orgId).isPresent()) {
      Organization org =
          orgRepo
              .findOrgById(orgId)
              .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ORG_NOT_FOUND));
      String orgType = org.getType();
      if (!roles.isEmpty()
          && (role.equalsIgnoreCase(Constants.SERVICE_ADMIN)
              || role.equalsIgnoreCase(Constants.LW_BUSINESS_MANAGER)
              || role.equalsIgnoreCase(Constants.DISTRIBUTOR_ADMIN)
              || role.equalsIgnoreCase(Constants.LW_MCS)
              || role.equalsIgnoreCase(Constants.LW_SERVICE_COORDINATOR)
              || role.equalsIgnoreCase(Constants.LW_SUPER_ADMIN))) {
        switch (orgType) {
          case Constants.CUSTOMER:
            if (role.equalsIgnoreCase(Constants.LW_BUSINESS_MANAGER)
                || role.equalsIgnoreCase(Constants.DISTRIBUTOR_ADMIN)
                || role.equalsIgnoreCase(Constants.LW_MCS)
                || role.equalsIgnoreCase(Constants.LW_SERVICE_COORDINATOR)
                || role.equalsIgnoreCase(Constants.SERVICE_ADMIN)) {
              roles.removeIf(
                  r -> r.getName().equalsIgnoreCase(RoleConstants.EXTERNAL_CUSTOMER_TECH));
            }
            break;
          case Constants.BUSINESS_UNIT:
            if (role.equalsIgnoreCase(Constants.SERVICE_ADMIN)) {
              roles.removeIf(r -> r.getName().equalsIgnoreCase(Constants.LW_BUSINESS_MANAGER));
            } else if (role.equalsIgnoreCase(Constants.LW_MCS)
                || role.equalsIgnoreCase(Constants.LW_SERVICE_COORDINATOR)) {
              roles.removeIf(r -> !Constants.BUSINESS_UNIT_ROLES_MCS_ICS.contains(r.getName()));
            } else if (role.equalsIgnoreCase(Constants.LW_SUPER_ADMIN)) {
              roles.removeIf(r -> !Constants.BUSINESS_UNIT_ROLES.contains(r.getName()));
            }
            break;
          case Constants.DISTRIBUTOR:
            if (role.equalsIgnoreCase(Constants.LW_SERVICE_COORDINATOR)
                || role.equalsIgnoreCase(Constants.SERVICE_ADMIN)) {
              roles.removeIf(r -> r.getName().equalsIgnoreCase(Constants.DISTRIBUTOR_FSE));
            }
            break;
          case Constants.PARTNER:
            if (role.equalsIgnoreCase(Constants.SERVICE_ADMIN)) {
              roles.removeIf(r -> r.getName().equalsIgnoreCase(Constants.PARTNER_HOTLINE));
            }
            break;
        }
      }
    }
  }

  /**
   * update a role
   *
   * @param roleInfo
   * @param roleId
   * @throws DataValidationException
   * @throws DuplicateResourceException
   * @throws ResourceNotFoundException
   */
  public void update(RoleInfo roleInfo, long roleId)
      throws DataValidationException, DuplicateResourceException, ResourceNotFoundException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Role role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    Optional.ofNullable(role)
        .filter(r -> !r.isSystemDefined())
        .orElseThrow(() -> new DataValidationException("cannot edit system defined role"));
    Optional.ofNullable(roleInfo)
        .filter(r -> UserhubUtils.validatePattern(roleNamePattern, roleInfo.getName()))
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.ROLE_VALIDATION_ERROR));
    if (roleRepo.getRoleByName(roleInfo.getName(), authUser.getOrgId()) != null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.DUPLICATE_ROLE, Arrays.asList(roleInfo.getName()));
    }
    int result = roleRepo.update(roleInfo.getName(), roleId, authUser.getOrgId());
    Optional.ofNullable(result)
        .filter(r -> result == 1)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ROLE_NOT_FOUND));
  }

  /**
   * get a role
   *
   * @return role
   */
  public Role fetchOne(long roleId) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    return roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
  }

  /**
   * get all privileges of role
   *
   * @param roleId - roleId
   * @param filterBy - filter criteria(entity,devicetype,devicegroup)
   * @return rolePrivileges - privileges of the role
   * @throws ResourceNotFoundException
   */
  @Override
  public List<RolePrivilege> getPrivileges(long roleId, String filterBy)
      throws ResourceNotFoundException {
    List<RolePrivilege> rolePrivileges = new ArrayList<RolePrivilege>();
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    //		Role role = roleRepo.getRoleByOrg(roleId,authUser.getOrgId());
    Role role = roleRepo.findById(roleId).get(); // NCIOT-16412
    Optional.ofNullable(role)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ROLE_NOT_FOUND));
    if (filterBy != null) {
      switch (filterBy) {
        case Constants.DEVICETYPE:
          rolePrivileges = userRolePrivileges.getDeviceTypePrivileges(roleId, Constants.ROLE);
          break;
        case Constants.ENTITY:
          rolePrivileges = userRolePrivileges.getEntityPrivileges(roleId, Constants.ROLE);
          break;
        case Constants.CARD:
          rolePrivileges = userRolePrivileges.getCardPrivileges(roleId);
          break;
      }
    } else {
      rolePrivileges = getAllPrivileges(roleId);
    }
    logger.info("succesfully fetch rolePrivileges");
    return rolePrivileges;
  }

  /**
   * adding privileges to a role
   *
   * @param roleId - roleId
   * @param resourcePrivileges - privileges and resources
   */
  @Override
  public void addPrivileges(long roleId, List<ResourcePrivilege> resourcePrivileges) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    //		Role role = roleRepo.getRoleByOrg(roleId,authUser.getOrgId());
    Role role = roleRepo.findById(roleId).get(); // NCIOT-16412
    userRolePrivileges.addPrivilegeToRole(resourcePrivileges, role);
    logger.info("added privileges ");
  }

  /**
   * delete privileges to a role
   *
   * @param roleId - roleId
   * @param resourcePrivileges - privileges and resources
   */
  @Override
  public void deletePrivileges(long roleId, List<ResourcePrivilege> resourcePrivileges) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    //		Role role = roleRepo.getRoleByOrg(roleId,authUser.getOrgId());
    Role role = roleRepo.findById(roleId).get(); // NCIOT-16412
    userRolePrivileges.deletePrivilegeToRole(resourcePrivileges, role);
  }

  /**
   * get all privileges
   *
   * @param roleId - roleId
   * @return rolePrivileges - privileges of the role
   */
  private List<RolePrivilege> getAllPrivileges(long roleId) {
    logger.info("fetching privileges of role");
    List<RolePrivilege> rolePrivileges = new ArrayList<RolePrivilege>();
    List<RolePrivilege> getRoleDeviceTypePrivilege =
        userRolePrivileges.getDeviceTypePrivileges(roleId, Constants.ROLE);
    List<RolePrivilege> getRoleEntityPrivilege =
        userRolePrivileges.getEntityPrivileges(roleId, Constants.ROLE);
    List<RolePrivilege> getCardPrivilege = userRolePrivileges.getCardPrivileges(roleId);
    rolePrivileges.addAll(getRoleDeviceTypePrivilege);
    rolePrivileges.addAll(getRoleEntityPrivilege);
    rolePrivileges.addAll(getCardPrivilege);
    logger.info("successfully fetch privileges of role");
    return rolePrivileges;
  }

  /**
   * get all devicegroup privileges of role
   *
   * @param roleId - roleId
   * @param deviceTypeId - deviceTypeId
   * @return DeviceGroupPrivilege - privileges of the devicegroup
   * @throws ResourceNotFoundException
   */
  @Override
  public DeviceGroupPrivilege getDeviceGroupPrivileges(long roleId, long deviceTypeId)
      throws ResourceNotFoundException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    DeviceGroupPrivilege privileges = new DeviceGroupPrivilege();
    Role role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    Optional.ofNullable(role)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ROLE_NOT_FOUND));
    privileges = userRolePrivileges.getDeviceGroupPrivileges(roleId, deviceTypeId, Constants.ROLE);
    return privileges;
  }

  /**
   * adding devicegroup privileges to a role
   *
   * @param roleId - roleId
   * @param resourcePrivileges - deviceGroup privileges and resources
   */
  @Override
  public void addDeviceGroupPrivileges(long roleId, List<DeviceGroupAccess> deviceGroupAccess) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Role role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    userRolePrivileges.addDeviceGroupPrivilegeToRole(deviceGroupAccess, role);
    logger.info("added privileges ");
  }

  /**
   * delete devicegroup privileges to a role
   *
   * @param roleId - roleId
   * @param deviceGroupAccess - deviceGroup privileges and resources
   */
  @Override
  public void deleteDeviceGroupPrivileges(long roleId, List<DeviceGroupAccess> deviceGroupAccess) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Role role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    userRolePrivileges.deleteDeviceGroupPrivilegeToRole(deviceGroupAccess, role);
    logger.info("deleted privileges ");
  }

  /** NCIOT-16412 */
  @Override
  public List<RolePrivilege> getPrivileges(long roleId) throws ResourceNotFoundException {
    new ArrayList<RolePrivilege>();
    Role role = roleRepo.findById(roleId).get(); // NCIOT-16412
    Optional.ofNullable(role)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ROLE_NOT_FOUND));
    List<RolePrivilege> rolePrivileges = getAllPrivileges(roleId);
    logger.info("succesfully fetch rolePrivileges for specified roleId");
    return rolePrivileges;
  }
}
