package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface SubscriptionCategoryRepository extends JpaRepository<SubscriptionCategory, Long> {

  // public SubscriptionCategory findByCategoryName(String categoryName);
}
