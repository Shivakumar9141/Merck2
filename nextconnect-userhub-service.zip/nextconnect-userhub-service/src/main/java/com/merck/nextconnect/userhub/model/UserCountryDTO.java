package com.merck.nextconnect.userhub.model;

import com.merck.nextconnect.utils.common.entities.Region;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserCountryDTO {
  private int id;
  private String countryCode;
  private String countryName;
  private Region region;
}
