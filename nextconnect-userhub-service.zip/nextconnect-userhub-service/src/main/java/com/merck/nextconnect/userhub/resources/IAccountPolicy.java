package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.UserCredentials;
import org.springframework.stereotype.Component;

@Component
public interface IAccountPolicy {

  /**
   * reset lockout
   *
   * @param userId - userId
   */
  void resetLockOut(long userId);

  /**
   * lock user account
   *
   * @param userId - userId
   */
  void lockUserAccount(long userId, long activeCredentialId);

  /**
   * failed login attempt
   *
   * @param userId - userId
   */
  void failedLoginAttempt(UserCredentials userCredential);
}
