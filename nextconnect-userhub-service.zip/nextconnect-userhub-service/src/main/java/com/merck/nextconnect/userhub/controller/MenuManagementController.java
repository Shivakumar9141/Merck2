package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.MenuGroupRequest;
import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuManagementRequest;
import com.merck.nextconnect.userhub.model.MenuManagementResponse;
import com.merck.nextconnect.userhub.model.MenuUpdateRequest;
import com.merck.nextconnect.userhub.model.MenuUpdateRequestDTO;
import com.merck.nextconnect.userhub.resources.MenuService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * this is used for menu managemnt Introduces as a part of NCIOT-12252
 *
 * @author clukose
 */
@RestController
@RequestMapping("/api")
public class MenuManagementController {

  @Autowired private MenuService menuservice;

  @Operation(description = "Fetc all menu groups", tags = "menu management")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/menugroups")
  @PreAuthorize("hasAuthority('menu_management')")
  public ResponseEntity<List<MenuGroupResponse>> get() {
    MenuGroupRequest request = new MenuGroupRequest();

    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    request.setOrgId(authUser.getOrgId());
    request.setUserId(Long.valueOf(authUser.getId()));
    request.setRoleId(authUser.getRoleId());
    List<MenuGroupResponse> menuGroupResponse = menuservice.getMenuGroups(request);
    return new ResponseEntity<List<MenuGroupResponse>>(menuGroupResponse, HttpStatus.OK);
  }

  @Operation(
      description = "Fetch all menu correspoding to a menu  groups",
      tags = "menu management")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/usermenu/{menuGroupName}")
  @PreAuthorize("hasAuthority('menu_management')")
  public ResponseEntity<List<MenuManagementResponse>> getUserMenuResponse(
      @Parameter(
              name = "menuGroupName",
              description = "name of the menu group",
              schema = @Schema(defaultValue = ""))
          @PathVariable(value = "menuGroupName")
          String menuGroupName)
      throws CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    MenuManagementRequest request = new MenuManagementRequest();
    request.setMenuGroupName(menuGroupName);
    request.setOrgId(authUser.getOrgId());
    request.setUserId(Long.valueOf(authUser.getId()));
    request.setRoleId(authUser.getRoleId());
    List<MenuManagementResponse> menuMangeResponses = menuservice.getMenuInfo(request);
    return new ResponseEntity<List<MenuManagementResponse>>(menuMangeResponses, HttpStatus.OK);
  }

  @Operation(
      summary = "Update menu sequence for  menu  groups",
      tags = "menu management",
      description = "This API is used to update the menu  sequence and visibility for each user  ")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.PUT, value = "/usermenu/mangement")
  @PreAuthorize("hasAuthority('menu_management')")
  public ResponseEntity<List<MenuManagementResponse>> updateMenuSequence(
      @Parameter(
              name = "menuUpdateDetails",
              description = "menuUpdate Details",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          MenuUpdateRequest menuUpdateDetails)
      throws CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    MenuUpdateRequestDTO request = new MenuUpdateRequestDTO();
    request.setOrgId(authUser.getOrgId());
    request.setUserId(Long.valueOf(authUser.getId()));
    request.setRoleId(authUser.getRoleId());
    request.setMenuUpdateRequest(menuUpdateDetails);
    List<MenuManagementResponse> menuMangeResponses = menuservice.updateUserMenu(request);
    return new ResponseEntity<List<MenuManagementResponse>>(menuMangeResponses, HttpStatus.OK);
  }
}
