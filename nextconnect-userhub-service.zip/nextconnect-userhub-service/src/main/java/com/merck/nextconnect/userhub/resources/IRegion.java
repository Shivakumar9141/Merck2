package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.model.CountryDTO;
import com.merck.nextconnect.utils.common.entities.Region;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public interface IRegion {

  List<Region> getRegions(String searchBy);

  List<CountryDTO> getCountryByRegionId(List<Integer> regionId);
}
