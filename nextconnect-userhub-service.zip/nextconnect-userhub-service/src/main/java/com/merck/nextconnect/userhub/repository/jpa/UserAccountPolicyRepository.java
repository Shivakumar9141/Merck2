package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserAccountPolicy;
import jakarta.transaction.Transactional;
import java.util.Date;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * interface talks with UserAccountPolicy table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface UserAccountPolicyRepository extends JpaRepository<UserAccountPolicy, Long> {

  @Transactional
  @Modifying
  @Query(
      "UPDATE UserAccountPolicy u SET u.failedAttempts = :failedAttempts , u.lastFailed = :lastFailed  where "
          + "u.userProfile.userId = :id")
  int updateUserLoginAttempt(
      @Param("id") long id,
      @Param("failedAttempts") int failedAttempts,
      @Param("lastFailed") Date lastFailed);

  @Query("from UserAccountPolicy u where " + "u.userProfile.userId = :id ")
  UserAccountPolicy getByUserId(@Param("id") long id);

  @Modifying
  @Transactional
  @Query("delete from UserAccountPolicy u where u.userProfile.userId = :userId")
  void deleteByUserId(@Param("userId") long userId);
}
