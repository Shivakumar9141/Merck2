package com.merck.nextconnect.userhub.entities;

import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "NC_PRIVILEGES")
public class Privilege {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long privilegeId;

  @Pattern(regexp = ".*\\S.*")
  private String resourceType;

  @Pattern(regexp = ".*\\S.*")
  private String operation;

  public Privilege() {}

  public Privilege(PrivilegeInfo privilegeInfo) {
    this.resourceType = privilegeInfo.getResourceType();
    this.operation = privilegeInfo.getOperation();
  }

  public Privilege(long privilegeId, String resource, String operation) {
    this.privilegeId = privilegeId;
    this.resourceType = resource;
    this.operation = operation;
  }

  public long getprivilegeId() {
    return privilegeId;
  }

  public void setprivilegeId(long privilegeId) {
    this.privilegeId = privilegeId;
  }

  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public String getResourceType() {
    return resourceType;
  }

  public void setResourceType(String resourceType) {
    this.resourceType = resourceType;
  }
}
