package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.entities.PolicyTypeEntity;
import com.merck.nextconnect.userhub.resources.ILegalTermsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/legalpolicy")
public class LegalTermsController {
  @Autowired private ILegalTermsService iLegalTermsService;

  @Operation(
      summary = "Get the privacy policy and terms and cocndition",
      tags = "Legal Terms",
      description =
          "This API is used to get the privacy policy and terms and conditions depending on the language and country.")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @GetMapping
  public ResponseEntity<PolicyTypeEntity> legalTerms(
      @Parameter(
              name = "languageCode",
              description = "languageCode",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "languageCode", required = false)
          String languageCode,
      @Parameter(name = "type", description = "type", schema = @Schema(defaultValue = ""))
          @RequestParam(value = "type", required = false)
          String type,
      @Parameter(
              name = "countryCode",
              description = "Code of the country",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "countryCode", required = false)
          String countryCode,
      @Parameter(
              name = "orgId",
              description = "Organization ID of the user",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "orgId", required = false)
          int orgId)
      throws Exception {
    return new ResponseEntity<>(
        iLegalTermsService.getPolicyOrTerms(languageCode, type, countryCode, orgId), HttpStatus.OK);
  }
}
