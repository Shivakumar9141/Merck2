package com.merck.nextconnect.userhub.entities;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.merck.nextconnect.userhub.util.JsonDateSerializer;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@Table(name = "nc_user_exp_feedback")
@AllArgsConstructor
@NoArgsConstructor
public class UserFeedBackEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private long id;

  @ManyToOne(targetEntity = UserProfile.class)
  @JoinColumn(name = "user_id")
  private UserProfile user;

  @Column(name = "rating")
  private Integer rating;

  @Column(name = "feed_back")
  private String feedBack;

  @JsonSerialize(using = JsonDateSerializer.class)
  @Column(name = "created_date")
  private Timestamp createdDate;
}
