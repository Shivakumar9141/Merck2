package com.merck.nextconnect.userhub.cache.service;

import com.merck.nextconnect.userhub.cache.repository.CacheRepository;
import com.merck.nextconnect.userhub.cache.util.CacheUtil;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

@Component
public class CacheServiceImpl implements CacheService {

  static final Logger logger = LoggerFactory.getLogger(CacheServiceImpl.class);

  @Autowired CacheRepository cacheRepository;

  @Autowired ConversionService conversionService;

  @Override
  public String getMapValues(String mapName, Object resourceId) {

    String values = cacheRepository.getMapValues(mapName, resourceId);
    logger.info(":::: values :::: -> " + values);
    return values;
  }

  @Override
  public String clearCacheValues(String mapName, Object resourceId) {
    String values = cacheRepository.clearCacheValues(mapName, resourceId);
    return values;
  }

  @Override
  public Map<String, String> getConfigurationProperties() {

    Map<String, String> properties = new HashMap<>();
    properties.put("members", cacheRepository.getMembers());
    return properties;
  }

  @Override
  public Map<String, String> getListOfMaps() {
    Map<String, String> listofmaps = CacheUtil.HazelcastMapInfo;
    return listofmaps;
  }

  @Override
  public Map<String, String> getAllDistributedCacheValues() {

    Map<String, String> values = cacheRepository.getAllDistributedCacheValues();
    return values;
  }

  @Override
  public void updateApplicationConfig(String key, String type, String value) {
    cacheRepository.getApplicationConfigMap().put(key, convert(type, value));
    logger.info(String.format("PUT application config property: (%s, %s)", key, value));
  }

  private Object convert(String type, String value) {
    if (type == null) {
      return value;
    }
    if (!type.startsWith("java.lang.")) {
      throw new IllegalArgumentException("Unsupported target type: " + type);
    }
    Class<?> targetClass;
    try {
      targetClass = Class.forName(type);
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Unknown target type: " + type, e);
    }
    if (!conversionService.canConvert(String.class, targetClass)) {
      throw new IllegalArgumentException("Conversion not defined for target type: " + type);
    }
    return conversionService.convert(value, targetClass);
  }
}
