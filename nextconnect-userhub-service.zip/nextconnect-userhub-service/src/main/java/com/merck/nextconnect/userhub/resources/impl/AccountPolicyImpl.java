package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.entities.UserAccountPolicy;
import com.merck.nextconnect.userhub.entities.UserCredentials;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserAccountPolicyRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserCredentialsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IAccountPolicy;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AccountPolicyImpl implements IAccountPolicy {

  @Autowired UserAccountPolicyRepository userAccountPolicyRepo;

  @Autowired UserRepository userRepo;

  @Autowired JwtTokenGenerator jwtTokenGenerator;

  @Autowired private UserCredentialsRepository userCredentialsRepository;

  @Value("${account.lockout.threshold}")
  private int threshold;

  @Value("${account.lockout.timeThreshold}")
  private long timeThreshold;

  @Override
  public void resetLockOut(long userId) {
    userAccountPolicyRepo.deleteByUserId(userId);
  }

  @Override
  public void lockUserAccount(long userId, long activeCredentialId) {
    userCredentialsRepository.lockUserAccount(activeCredentialId);
    jwtTokenGenerator.removeTokenRecords(userId);
    throw new LoginAuthenticationException(CustomErrorCodes.USER_ACCOUNT_LOCKED);
  }

  @Override
  public void failedLoginAttempt(UserCredentials userCredential) {
    UserProfile userProfile = userCredential.getUserProfile();
    Date currentTime = new Date();
    UserAccountPolicy userAccountPolicyEntity =
        userAccountPolicyRepo.getByUserId(userProfile.getUserId());
    Optional.ofNullable(userProfile)
        .filter(
            u ->
                (!(u.getRole().isSystemDefined()
                    || u.getStatus().equals(UserStatus.PENDING.value()))))
        .ifPresent(
            u -> {
              UserAccountPolicy userAccountPolicy =
                  userAccountPolicyEntity != null
                      ? userAccountPolicyEntity
                      : userAccountPolicyRepo.save(new UserAccountPolicy(userProfile, 0, null));

              Optional.ofNullable(userAccountPolicy.getLastFailed())
                  .filter(
                      c ->
                          ((currentTime.getTime() - userAccountPolicy.getLastFailed().getTime())
                              > timeThreshold))
                  .ifPresent(
                      c -> {
                        userAccountPolicy.setFailedAttempts(0);
                      });

              userAccountPolicy.setFailedAttempts(userAccountPolicy.getFailedAttempts() + 1);
              userAccountPolicy.setLastFailed(new Date());
              userAccountPolicyRepo.updateUserLoginAttempt(
                  userAccountPolicy.getUserProfile().getUserId(),
                  userAccountPolicy.getFailedAttempts(),
                  userAccountPolicy.getLastFailed());

              Optional.ofNullable(userAccountPolicy.getLastFailed())
                  .filter(
                      c ->
                          ((currentTime.getTime() - userAccountPolicy.getLastFailed().getTime())
                              < timeThreshold))
                  .ifPresent(
                      c -> {
                        if (userAccountPolicy.getFailedAttempts() > threshold) {
                          resetLockOut(userAccountPolicy.getUserProfile().getUserId());
                          lockUserAccount(
                              userAccountPolicy.getUserProfile().getUserId(),
                              userCredential.getCredentialId());
                        }
                      });
            });
  }
}
