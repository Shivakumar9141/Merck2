package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuInfoDTO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * NCIOT -11855
 *
 * @author clukose
 */
@Repository
public class MenuManagementRepositoryJdbc {

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  public List<MenuGroupResponse> getMenuGroup(MapSqlParameterSource parameters, String sql) {
    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            MenuGroupResponse.builder()
                .menuGroupId(rs.getInt("mg.menugroup_id"))
                .maxCount(rs.getInt("mg.max_count"))
                .minCount(rs.getInt("mg.min_count"))
                .menuGroupName(rs.getString("mg.name"))
                .build());
  }

  public Integer getUserMenuCount(MapSqlParameterSource parameters, String sql) {
    return namedParameterJdbcTemplate.queryForObject(sql, parameters, Integer.class);
  }

  public int insertMenuInfo(MapSqlParameterSource parameters, String sql) {

    return namedParameterJdbcTemplate.update(sql, parameters);
  }

  /**
   * @param parameters
   * @param sql
   * @return
   */
  public List<MenuInfoDTO> getMenuInfo(MapSqlParameterSource parameters, String sql) {

    return namedParameterJdbcTemplate.query(
        sql,
        parameters,
        (rs, rowNum) ->
            MenuInfoDTO.builder()
                .menuSequence(rs.getInt(("um.sequence")))
                .isVisible(rs.getBoolean("um.is_visible"))
                .menuId(rs.getInt("um.menu_id"))
                .menuKey(rs.getString("menu.menu_key"))
                .toolTip(rs.getString("menu.tool_tip"))
                .tag(rs.getString("menu.tag"))
                .isMandatory(rs.getBoolean("menu.is_mandatory"))
                .iconUriImage(rs.getString("menu.icon_relative_uri_image"))
                .menuGroupId(rs.getInt("mg.menugroup_id"))
                .maxCount(rs.getInt("grp.max_count"))
                .minCount(rs.getInt("grp.min_count"))
                .menuGroupName(rs.getString("grp.name"))
                .build());
  }

  /**
   * @param paramList
   * @param sql
   */
  public void batchUpdate(List<MapSqlParameterSource> paramList, String sql) {

    namedParameterJdbcTemplate.batchUpdate(
        sql, paramList.toArray(new MapSqlParameterSource[paramList.size()]));
  }
}
