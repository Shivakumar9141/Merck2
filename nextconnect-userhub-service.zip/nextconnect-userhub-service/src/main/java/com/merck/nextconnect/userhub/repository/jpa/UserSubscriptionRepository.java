package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserSubscription;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public interface UserSubscriptionRepository extends JpaRepository<UserSubscription, Long> {

  // @Query("select UserSubscription from UserSubscription us where email=?1 and
  // subscriptionCategory.categoryId=?2 and status=?3 and createdBy!= ?3")
  public UserSubscription
      findByEmailAndSubscriptionCategorySubscriptionCategoryIdAndStatusAndCreatedByNotAndDeletedAndUserProfileDeleted(
          String email,
          Long subscriptionCategoryId,
          boolean status,
          String createdBy,
          boolean deleted,
          boolean userStatus);

  public List<UserSubscription> findByCreatedByAndStatusAndDeletedAndUserProfileDeleted(
      String email, boolean status, boolean deleted, boolean userStatus);

  public List<UserSubscription> findByEmailAndStatusAndDeletedAndCreatedByNotAndUserProfileDeleted(
      String email, boolean status, boolean deleted, String createdBy, boolean userStatus);

  public List<UserSubscription>
      findByEmailAndSubscriptionCategorySubscriptionCategoryIdAndSubscriptionTypeSubscriptionTypeIdAndCreatedByAndDeletedAndUserProfileDeleted(
          String email,
          Long subscriptionCategory,
          Long subscriptionTypeId,
          String creatdeBy,
          boolean deleted,
          boolean userStatus);

  public List<UserSubscription>
      findBySubscriptionCategorySubscriptionCategoryIdAndSubscriptionTypeSubscriptionTypeIdAndStatusAndEmailInAndDeletedAndUserProfileDeleted(
          Long subscriptionCategory,
          Long subscriptionTypeId,
          boolean status,
          List<String> createdBy,
          boolean deleted,
          boolean userStatus);

  public List<UserSubscription>
      findByEmailAndSubscriptionCategorySubscriptionCategoryIdAndStatusAndCreatedByNotAndDeletedAndUserProfileDeletedOrderByLastUpdatedTimestampDesc(
          String email,
          Long subscriptionCategoryId,
          boolean status,
          String createdBy,
          boolean deleted,
          boolean userStatus);

  public List<UserSubscription> findByEmailAndDeletedAndUserProfileDeleted(
      String mailId, boolean deleted, boolean userStatus);

  @Transactional
  @Modifying
  @Query("update UserSubscription us set us.customMessage = ?1 where us.createdBy = ?2")
  void setCustomMessageForUserSubscription(String customMessage, String createdBy);

  public UserSubscription
      findFirstByEmailAndSubscriptionCategorySubscriptionCategoryIdAndSubscriptionTypeSubscriptionTypeIdAndDeletedAndUserProfileDeleted(
          String email,
          long subscriptionCategoryId,
          Long subscriptionTypeId,
          boolean deleted,
          boolean userStatus);

  public List<UserSubscription>
      findByEmailInAndStatusAndDeletedAndSubscriptionTypeSubscriptionTypeNameAndSubscriptionCategoryCategoryNameAndUserProfileDeleted(
          List<String> existingEmails,
          boolean status,
          boolean b,
          String subscriptionTypeName,
          String categoryName,
          boolean userStatus);

  @Query("from UserSubscription us where (email=:email OR createdBy=:createdBy) AND deleted=false")
  public List<UserSubscription> findByEmailOrCreatedByAndDeleted(
      @Param("email") String email, @Param("createdBy") String createdBy);
}
