package com.merck.nextconnect.userhub.util;

import com.merck.nextconnect.userhub.model.UserFeedBackDateDTO;
import com.merck.nextconnect.utils.common.DateTimeUtil;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * @author clukose
 */
public class UserFeedBackUtil {

  public static String GENERAL_DATE_FORMAT = "yyyy-MM-dd";

  public static List<UserFeedBackDateDTO> getDateIntervals(Long duration, int dateInterval) {
    LocalDate currentdate = LocalDate.now();
    LocalDate startDate = currentdate.minusMonths(duration);
    List<UserFeedBackDateDTO> dateDetails = new ArrayList<>();
    getDates(dateDetails, startDate, currentdate, dateInterval);

    return dateDetails;
  }

  /**
   * @param dateIntervals
   * @param startDate
   * @param currentdate
   */
  private static void getDates(
      List<UserFeedBackDateDTO> dateDetails,
      LocalDate startDate,
      LocalDate currentdate,
      int dateInterval) {
    LocalDate interDate = startDate;
    while (interDate.isBefore(currentdate)) {
      populate(dateDetails, interDate);
      interDate = interDate.plusDays(dateInterval);
    }
    populate(dateDetails, currentdate);
  }

  /**
   * @param dateDetails
   * @param interDate
   */
  private static void populate(List<UserFeedBackDateDTO> dateDetails, LocalDate interDate) {
    UserFeedBackDateDTO dateInfo = new UserFeedBackDateDTO();
    dateInfo.setDate(interDate);
    dateInfo.setChartDate(interDate.format(DateTimeUtil.getDateTimeFormat()));
    dateDetails.add(dateInfo);
  }

  /**
   * @param date
   * @param days
   * @return
   */
  public static String getPlusDays(LocalDate date, int days) {

    return date.plusDays(days).format(DateTimeFormatter.ofPattern(GENERAL_DATE_FORMAT));
  }

  /**
   * @param duration of feedback in months(3,6,9,12)
   * @return List of Date Details MCOSAT-2105-This method split the total duration to per month
   *     interval dates
   */
  public static List<UserFeedBackDateDTO> getFeedBackMonthIntervals(long duration) {
    LocalDate currentDate = LocalDate.now();
    LocalDate startDate = currentDate.minusMonths(duration);
    LocalDate interDate = startDate;
    List<UserFeedBackDateDTO> dateDetails = new ArrayList<>();
    while (interDate.isBefore(currentDate)) {
      LocalDate endDatePerMonth = interDate.withDayOfMonth(interDate.lengthOfMonth());
      setDateInfo(dateDetails, endDatePerMonth, interDate, duration);
      interDate = interDate.plusMonths(Constants.DEFAULT_LONG_NUMBER_ONE);
    }
    LocalDate endDatePerMonth = interDate.withDayOfMonth(interDate.lengthOfMonth());
    setDateInfo(dateDetails, endDatePerMonth, interDate, duration);
    return dateDetails;
  }

  /**
   * @param duration of feedback in months(3,6,9,12)
   * @param intervals in days to divide the duration
   * @return List of Date Details MCOSAT-2105-This method split the total duration to requested
   *     interval dates in days
   */
  public static List<UserFeedBackDateDTO> getFeedbackDateIntervals(
      Long duration, Integer feedbackIntervalInDays) {
    LocalDate currentDate = LocalDate.now();
    LocalDate startDate = currentDate.minusMonths(duration);
    LocalDate interDate = startDate;
    List<UserFeedBackDateDTO> dateDetails = new ArrayList<>();
    while (interDate.isBefore(currentDate)) {
      LocalDate endDatePerInterval = interDate.plusDays(feedbackIntervalInDays);
      if (endDatePerInterval.isAfter(currentDate)) {
        setDateInfo(dateDetails, currentDate, interDate, duration);
      } else {
        setDateInfo(dateDetails, endDatePerInterval, interDate, duration);
      }
      interDate = endDatePerInterval.plusDays(Constants.DEFAULT_LONG_NUMBER_ONE);
    }
    return dateDetails;
  }

  /**
   * @param List of Date Details Object
   * @param duration of feedback in months(3,6,9,12)
   * @param start date to set date variable
   * @param end date to set date variable
   * @return List of Date Details MCOSAT-2105-This method set the Date Info Object
   */
  private static List<UserFeedBackDateDTO> setDateInfo(
      List<UserFeedBackDateDTO> dateDetails,
      LocalDate endDate,
      LocalDate startDate,
      Long duration) {
    UserFeedBackDateDTO dateInfo =
        UserFeedBackDateDTO.builder()
            .date(endDate)
            .chartDate(getChartDateByInterval(duration, endDate, startDate))
            .build();
    dateDetails.add(dateInfo);
    return dateDetails;
  }

  /**
   * @param duration of feedback in months(3,6,9,12)
   * @param start date to set chart date variable
   * @param end date to set chart date variable
   * @return String representation of Chart Date MCOSAT-2105-This method set the Chart Date to
   *     required format based on duration
   */
  private static String getChartDateByInterval(
      Long duration, LocalDate endDate, LocalDate startDate) {
    if (Constants.FEEDBACK_DURATION_THREE_MONTHS == duration) {
      return startDate.format(
              DateTimeFormatter.ofPattern(Constants.FEED_BACK_DATE_FORMAT_FOR_THREE_MONTHS))
          + Constants.HYPHEN
          + endDate.format(
              DateTimeFormatter.ofPattern(Constants.FEED_BACK_DATE_FORMAT_FOR_THREE_MONTHS));
    } else {
      return String.valueOf(endDate.getMonthValue()) + Constants.SLASH_STRING + endDate.getYear();
    }
  }
}
