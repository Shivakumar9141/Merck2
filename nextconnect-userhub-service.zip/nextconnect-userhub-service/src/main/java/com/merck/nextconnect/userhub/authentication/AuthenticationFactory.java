package com.merck.nextconnect.userhub.authentication;

import com.merck.nextconnect.authfilter.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.authentication.impl.MerckAuth;
import com.merck.nextconnect.userhub.authentication.impl.NextConnectAuth;
import com.merck.nextconnect.userhub.authentication.impl.SialAuth;
import com.merck.nextconnect.userhub.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationFactory {

  static final Logger logger = LoggerFactory.getLogger(AuthenticationFactory.class);

  @Autowired private MerckAuth merckAuth;

  @Autowired private SialAuth sialAuth;

  @Autowired private NextConnectAuth nextConnectAuth;

  public IAuthRepository getAuthProvider(String domain) {
    switch (domain) {
      case Constants.NEXTCONNECT:
        return nextConnectAuth;
      case Constants.SIAL:
        return sialAuth;
      case Constants.MERCK_GLOBAL:
        return merckAuth;
      case Constants.MERCK_DNAP:
        return merckAuth;
      case Constants.MERCK_DNEU:
        return merckAuth;
      case Constants.MERCK_DNLA:
        return merckAuth;
      case Constants.MERCK_DNNA:
        return merckAuth;
      default:
        logger.info("Invalid Domain");
        throw new LoginAuthenticationException("invalid domian");
    }
  }
}
