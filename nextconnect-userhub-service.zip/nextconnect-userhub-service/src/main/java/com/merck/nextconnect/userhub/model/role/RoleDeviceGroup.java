package com.merck.nextconnect.userhub.model.role;

public class RoleDeviceGroup {

  private long privilegeId;
  private long locationId;
  private String locationName;
  private long deviceGruopId;
  private String deviceGroupName;

  public RoleDeviceGroup() {}

  public RoleDeviceGroup(
      long privilegeId,
      long locationId,
      String locationName,
      long deviceGruopId,
      String deviceGroupName) {
    this.privilegeId = privilegeId;
    this.locationId = locationId;
    this.locationName = locationName;
    this.deviceGruopId = deviceGruopId;
    this.deviceGroupName = deviceGroupName;
  }

  public long getPrivilegeId() {
    return privilegeId;
  }

  public void setPrivilegeId(long privilegeId) {
    this.privilegeId = privilegeId;
  }

  public long getLocationId() {
    return locationId;
  }

  public void setLocationId(long locationId) {
    this.locationId = locationId;
  }

  public String getLocationName() {
    return locationName;
  }

  public void setLocationName(String locationName) {
    this.locationName = locationName;
  }

  public long getDeviceGruopId() {
    return deviceGruopId;
  }

  public void setDeviceGruopId(long deviceGruopId) {
    this.deviceGruopId = deviceGruopId;
  }

  public String getDeviceGroupName() {
    return deviceGroupName;
  }

  public void setDeviceGroupName(String deviceGroupName) {
    this.deviceGroupName = deviceGroupName;
  }
}
