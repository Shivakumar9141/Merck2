package com.merck.nextconnect.userhub.model.role;

import com.merck.nextconnect.userhub.model.privilege.Privileges;
import java.io.Serializable;

public class RolePrivilege extends Privileges implements Serializable {

  /** */
  private static final long serialVersionUID = 1L;

  private long privilegeId;

  private String operation;

  private long resourceId;

  private String resourceType;

  public RolePrivilege() {}

  public RolePrivilege(long privilegeId, String operation, long resourceId, String resourceType) {
    this.privilegeId = privilegeId;
    this.operation = operation;
    this.resourceId = resourceId;
    this.resourceType = resourceType;
  }

  public long getPrivilegeId() {
    return privilegeId;
  }

  public void setPrivilegeId(long privilegeId) {
    this.privilegeId = privilegeId;
  }

  public long getResourceId() {
    return resourceId;
  }

  public void setResourceId(long resourceId) {
    this.resourceId = resourceId;
  }

  public String getResourceType() {
    return resourceType;
  }

  public void setResourceType(String resourceType) {
    this.resourceType = resourceType;
  }

  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }
}
