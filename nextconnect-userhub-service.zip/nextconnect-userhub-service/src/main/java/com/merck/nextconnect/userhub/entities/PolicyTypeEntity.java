package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder(toBuilder = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "nc_legal_terms")
public class PolicyTypeEntity {
  @Id private int policyId;

  private String policyContent;

  private String policyType;

  private String languageCode;

  private String createdBy;

  private Timestamp createdDate;

  private String updatedBy;

  private Timestamp updatedDate;

  private String contentLanguage;
}
