package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

public class DuplicateResourceException extends CustomException {

  private static final long serialVersionUID = 1L;

  public DuplicateResourceException(String msg) {
    super(msg);
  }

  public DuplicateResourceException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes);
  }

  public DuplicateResourceException(CustomErrorCodes customErrorCodes, List<String> params) {
    super(customErrorCodes, params);
  }
}
