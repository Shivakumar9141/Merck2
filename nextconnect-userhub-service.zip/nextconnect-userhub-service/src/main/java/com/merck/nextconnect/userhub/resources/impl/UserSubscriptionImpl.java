package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.controller.SubscriptionController;
import com.merck.nextconnect.userhub.entities.PhoneNumberOtp;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.SubscriptionCategory;
import com.merck.nextconnect.userhub.entities.SubscriptionType;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.entities.UserSubscription;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.FailedDependencyException;
import com.merck.nextconnect.userhub.model.EmailSubscriptionValidationDTO;
import com.merck.nextconnect.userhub.model.InvalidEmails;
import com.merck.nextconnect.userhub.model.InvalidEmailsDTO;
import com.merck.nextconnect.userhub.model.SubscriptionCategoryDTO;
import com.merck.nextconnect.userhub.model.SubscriptionTypeDTO;
import com.merck.nextconnect.userhub.model.UserSubscriptionDTO;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.PhoneNumberOtpRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserSubscriptionRepository;
import com.merck.nextconnect.userhub.resources.ISubscriptionCategory;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.resources.IUserSubscription;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.UserHubAsyncService;
import com.merck.nextconnect.userhub.validator.SubscriptionValidator;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.repository.jpa.NcSmsTemplateRepository;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

@Service
public class UserSubscriptionImpl implements IUserSubscription {

  private static final String OTP_EXPIRY_TIME = "OTP_EXPIRY_TIME";
  private static final String OTP_MESSAGE = "OTP_MESSAGE";
  private static final String SMS_OTP_SUBSCRIPTION = "SMS_OTP_SUBSCRIPTION";
  static final Logger logger = LoggerFactory.getLogger(SubscriptionController.class);
  @Autowired private UserSubscriptionRepository userSubscriptionRepository;
  @Autowired private ISubscriptionCategory subscriptionCategoryService;

  @Autowired private CountryRepository countryRepository;

  @Value("${nextconnect.sms.url}")
  private String smsHost;

  @Value("${nextconnect.sms.username}")
  private String smsUsername;

  @Value("${nextconnect.sms.password}")
  private String smsPassword;

  @Value("${nextconnect.subscription.numberofdaysadvance}")
  private int numberOfDefaultDaysAdvance;

  @Value("${nextconnect.subscription.fss.numberofdaysadvance}")
  private int numberOfDaysAdvanceForFssSubscription;

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Value("${nextconnect.email.fromemail}")
  private String emailFrom;

  @Autowired private RestTemplate restTemplate;

  @Autowired private PhoneNumberOtpRepository phoneNumberOtpRepository;
  @Autowired private IUser userService;
  @Autowired UserRepository userRepository;
  @Autowired RoleRepository roleRepo;
  @Autowired private ApplicationConfigRepository applicationConfigRepository;

  @Autowired private PhoneNumberValidator phoneNumberValidator;

  @Autowired private SubscriptionValidator subscriptionValidator;

  @Autowired private EmailTemplateService emailTemplateService;

  @Autowired private EmailService emailService;

  @Autowired private UserHubAsyncService userHubAsyncService;

  @Autowired private NcSmsTemplateRepository ncSmsTemplateRepository;

  private static final String SELF = "SELF";
  private static final String OTHER = "OTHER";
  private static final String USER_NOT_AVAILABLE = "USER_NOT_AVAILABLE";
  private static final String USER_ALREADY_SUBSCRIBED = "USER_ALREADY_SUBSCRIBED";
  private static final String USER_UNSUBSCRIBED = "USER_UNSUBSCRIBED";

  @Override
  public boolean save(UserSubscriptionDTO userSubscriptionDTO, Long userId) throws CustomException {

    UserProfile loggedinUser = userService.fetchOne(userId);

    // If phone number is not validated, then throw exception
    if (Optional.ofNullable(userSubscriptionDTO)
        .flatMap(x -> Optional.ofNullable(x.getSubscriptionTypeDTOs().stream()))
        .map(
            y ->
                y.filter(z -> z.getSubscriptionTypeId() == 2)
                    .map(SubscriptionTypeDTO::getSubscriptionCategories)
                    .flatMap(Collection::stream)
                    .anyMatch(SubscriptionCategoryDTO::isStatus))
        .get())
      userSubscriptionDTO.getSubscriptionTypeDTOs().stream()
          .filter(
              y ->
                  StringUtils.isNotBlank(y.getPhones())
                      && StringUtils.isNotBlank(y.getIsdCode())
                      && Optional.ofNullable(
                              phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
                                  y.getIsdCode() + y.getPhones(), userId))
                          .filter(x -> x.isValidated())
                          .isPresent())
          .findAny()
          .orElseThrow(
              () -> new DataValidationException(CustomErrorCodes.PHONE_NUMBER_NOT_VALIDATED));

    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    boolean oldData = true;
    try {
      UserSubscriptionDTO existingSubscription = fetchAllUserSubscription(userId);
      if (userSubscriptionDTO != null
          && StringUtils.isBlank(userSubscriptionDTO.getCustomMessage())) {
        userSubscriptionDTO.setCustomMessage("");
      }
      userSubscriptionRepository.setCustomMessageForUserSubscription(
          userSubscriptionDTO.getCustomMessage(), loggedinUser.getEmail());
      if ((existingSubscription == null)
          || (existingSubscription != null
              && CollectionUtils.isEmpty(existingSubscription.getSubscriptionTypeDTOs()))) {
        logger.info(
            "The user with userId: -->{}<-- is not having prior email subscription records, creating new records",
            userId);
        oldData = false;
      }

      for (SubscriptionTypeDTO subscription : userSubscriptionDTO.getSubscriptionTypeDTOs()) {
        List<SubscriptionTypeDTO> existingSubscriptionTypeDTOs =
            oldData
                ? existingSubscription.getSubscriptionTypeDTOs().stream()
                    .filter(x -> x.getSubscriptionTypeId() == subscription.getSubscriptionTypeId())
                    .collect(Collectors.toList())
                : null; // get existing categories for the same user

        if (existingSubscriptionTypeDTOs == null
            || CollectionUtils.isEmpty(
                existingSubscriptionTypeDTOs)) // if there is no type, no need to do further checks
        oldData = false;

        if (subscription.getSubscriptionTypeId() == 2
            && subscription.getSubscriptionCategories().stream().noneMatch(x -> x.isStatus())) {
          phoneNumberOtpRepository.deleteUserRecord(userId);
        }

        for (SubscriptionCategoryDTO category : subscription.getSubscriptionCategories()) {
          long subscriptionCategoryId = category.getSubscriptionCategoryId();

          if (subscription.getSubscriptionTypeId() == 2) {

            logger.info("Adding SMS details for {}", loggedinUser.getEmail());
            UserSubscription userSubscription =
                userSubscriptionRepository
                    .findFirstByEmailAndSubscriptionCategorySubscriptionCategoryIdAndSubscriptionTypeSubscriptionTypeIdAndDeletedAndUserProfileDeleted(
                        loggedinUser.getEmail(),
                        subscriptionCategoryId,
                        subscription.getSubscriptionTypeId(),
                        false,
                        false);

            // Update SMS details if present else insert
            if (Optional.ofNullable(userSubscription).isPresent()) {
              userSubscriptionRepository.save(
                  userSubscription.toBuilder()
                      .status(category.isStatus())
                      .numberOfDaysAdvance(getDefaultNumberOfDaysBasedOnStatusAndRole(category))
                      .isdCode(subscription.getIsdCode())
                      .phone(subscription.getPhones())
                      .customMessage(userSubscriptionDTO.getCustomMessage())
                      .lastUpdatedTimestamp(timestamp)
                      .lastUpdatedBy(loggedinUser.getEmail())
                      .build());
            } else if (category.isStatus()) {
              userSubscriptionRepository.save(
                  UserSubscription.builder()
                      .createdBy(loggedinUser.getEmail())
                      .createdTimestamp(timestamp)
                      .customMessage(userSubscriptionDTO.getCustomMessage())
                      .email(loggedinUser.getEmail())
                      .status(category.isStatus())
                      .isdCode(subscription.getIsdCode())
                      .phone(subscription.getPhones())
                      .numberOfDaysAdvance(category.getNumberOfDaysAdvance()) // CHG***
                      .subscriptionType(
                          SubscriptionType.builder()
                              .subscriptionTypeId(subscription.getSubscriptionTypeId())
                              .subscriptionTypeName(subscription.getSubscriptionTypeName())
                              .build())
                      .subscriptionCategory(
                          subscriptionCategoryService.findOneByCategoryId(subscriptionCategoryId))
                      .userProfile(loggedinUser)
                      .lastUpdatedTimestamp(timestamp)
                      .lastUpdatedBy(loggedinUser.getEmail())
                      .build());
            }
          } else if (subscription.getSubscriptionTypeId() == 1) {

            if (category.isStatus()) {
              List<String> existingEmails = null, emailsToAdd = null, emailsToDelete = null;

              if (oldData)
                existingEmails =
                    Optional.ofNullable(
                            existingSubscriptionTypeDTOs.get(0).getSubscriptionCategories().stream()
                                .filter(
                                    x -> x.getSubscriptionCategoryId() == subscriptionCategoryId)
                                .collect(Collectors.toList()))
                        .orElse(Collections.emptyList())
                        .stream()
                        .flatMap(x -> x.getEmails().stream())
                        .collect(Collectors.toList());

              if (!CollectionUtils.isEmpty(existingEmails)) {
                List<String> test = existingEmails;
                emailsToAdd =
                    category.getEmails().stream() // This is basically a subtract operation
                        .filter(item -> !test.contains(item))
                        .collect(Collectors.toList());
                emailsToDelete =
                    existingEmails.stream()
                        .filter(item -> !category.getEmails().contains(item))
                        .collect(Collectors.toList());

                // Updating existing email's number of days advance
                userSubscriptionRepository.saveAll(
                    userSubscriptionRepository
                        .findByEmailInAndStatusAndDeletedAndSubscriptionTypeSubscriptionTypeNameAndSubscriptionCategoryCategoryNameAndUserProfileDeleted(
                            existingEmails,
                            category.isStatus(),
                            false,
                            subscription.getSubscriptionTypeName(),
                            category.getCategoryName(),
                            false)
                        .stream()
                        .map(
                            userSubscription ->
                                userSubscription.toBuilder()
                                    .numberOfDaysAdvance(
                                        category.getNumberOfDaysAdvance()) // CHG***
                                    .lastUpdatedTimestamp(timestamp)
                                    .lastUpdatedBy(loggedinUser.getEmail())
                                    .customMessage(userSubscriptionDTO.getCustomMessage())
                                    .build())
                        .collect(Collectors.toList()));
              }

              // Adding emails
              ((emailsToAdd == null) ? category.getEmails() : emailsToAdd)
                  .stream()
                      .filter(x -> !x.isEmpty() && !"string".equals(x))
                      .forEach(
                          email -> {
                            logger.info(
                                "Adding new email subscription for the category : -->{}<-- and email_id :-->{}<-- added by user : -->{}<--",
                                category.getCategoryName(),
                                email,
                                loggedinUser.getEmail());
                            userSubscriptionRepository.save(
                                UserSubscription.builder()
                                    .createdBy(loggedinUser.getEmail())
                                    .createdTimestamp(timestamp)
                                    .customMessage(userSubscriptionDTO.getCustomMessage())
                                    .email(email)
                                    .status(category.isStatus())
                                    .numberOfDaysAdvance(
                                        category.getNumberOfDaysAdvance()) // CHG***
                                    .subscriptionType(
                                        SubscriptionType.builder()
                                            .subscriptionTypeId(
                                                subscription.getSubscriptionTypeId())
                                            .subscriptionTypeName(
                                                subscription.getSubscriptionTypeName())
                                            .build())
                                    .subscriptionCategory(
                                        subscriptionCategoryService.findOneByCategoryId(
                                            subscriptionCategoryId))
                                    .userProfile(loggedinUser)
                                    .lastUpdatedTimestamp(timestamp)
                                    .lastUpdatedBy(loggedinUser.getEmail())
                                    .build());
                            // triggering subscription assignment email to users
                            userHubAsyncService.sendEmailToUserForAssignedUnassignedSubscriptions(
                                emailFrom, email, Constants.SUBJECT_ASSIGNED);
                          });

              // Removing emails
              Optional.ofNullable(emailsToDelete)
                  .ifPresent(
                      emailsToDeleteList ->
                          emailsToDeleteList.forEach(
                              email ->
                                  userSubscriptionRepository
                                      .findByEmailAndSubscriptionCategorySubscriptionCategoryIdAndSubscriptionTypeSubscriptionTypeIdAndCreatedByAndDeletedAndUserProfileDeleted(
                                          email,
                                          subscriptionCategoryId,
                                          subscription.getSubscriptionTypeId(),
                                          loggedinUser.getEmail(),
                                          false,
                                          false)
                                      .forEach(
                                          userToDelete -> {
                                            logger.info(
                                                "removing the following record from the Db as the record is deleted : {}",
                                                userToDelete);
                                            userSubscriptionRepository.save(
                                                userToDelete.toBuilder()
                                                    .status(false)
                                                    .deleted(true)
                                                    .lastUpdatedBy(loggedinUser.getEmail())
                                                    .lastUpdatedTimestamp(timestamp)
                                                    .deletedBy(
                                                        loggedinUser
                                                                .getEmail()
                                                                .equals(userToDelete.getEmail())
                                                            ? SELF
                                                            : OTHER)
                                                    .build());
                                            // triggering subscription unassignment email to users
                                            userHubAsyncService
                                                .sendEmailToUserForAssignedUnassignedSubscriptions(
                                                    emailFrom,
                                                    userToDelete.getEmail(),
                                                    Constants.SUBJECT_UNASSIGNED);
                                          })));
            } else {
              List<String> emailsList =
                  subscription.getSubscriptionCategories().stream()
                      .filter(y -> y.getSubscriptionCategoryId() == subscriptionCategoryId)
                      .filter(x -> x.getEmails() != null)
                      .flatMap(x -> x.getEmails().stream())
                      .collect(Collectors.toList());
              if (!emailsList.isEmpty()) {
                logger.info(
                    "Removing email subscription for the category :-->{}<-- removed by user : -->{}<-- for the users present: -->{}<--",
                    category.getCategoryName(),
                    loggedinUser.getEmail(),
                    emailsList);
                userSubscriptionRepository
                    .findBySubscriptionCategorySubscriptionCategoryIdAndSubscriptionTypeSubscriptionTypeIdAndStatusAndEmailInAndDeletedAndUserProfileDeleted(
                        subscriptionCategoryId,
                        subscription.getSubscriptionTypeId(),
                        true,
                        emailsList,
                        false,
                        false)
                    .forEach(
                        user ->
                            userSubscriptionRepository.save(
                                user.toBuilder()
                                    .status(false)
                                    .deleted(true)
                                    .lastUpdatedBy(loggedinUser.getEmail())
                                    .lastUpdatedTimestamp(timestamp)
                                    .deletedBy(
                                        loggedinUser.getEmail().equals(user.getEmail())
                                            ? SELF
                                            : OTHER)
                                    .numberOfDaysAdvance(
                                        getDefaultNumberOfDaysBasedOnStatusAndRole(category))
                                    .build()));
              }
            }
          }
        }
      }
      return true;
    } catch (Exception ex) {
      logger.error(
          "Exception occured when logging email subscription data for the user --> {}",
          loggedinUser,
          ex);
      throw new CustomException(CustomErrorCodes.EMAIL_SUBSCRIPTION_ERROR);
    }
  }

  public Integer getDefaultNumberOfDaysBasedOnStatusAndRole(SubscriptionCategoryDTO category) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Role role = roleRepo.findById(authUser.getRoleId()).orElse(null);

    if (category.isStatus()) {
      return category.getNumberOfDaysAdvance();
    } else {
      if (Constants.FSS_ROLES.stream().anyMatch(role.getName()::contains))
        return numberOfDaysAdvanceForFssSubscription;
      else if (Constants.CUSTOMER_ROLES.stream().anyMatch(role.getName()::contains))
        return numberOfDefaultDaysAdvance;
    }

    return numberOfDefaultDaysAdvance;
  }

  @Override
  public InvalidEmailsDTO validateEmails(EmailSubscriptionValidationDTO emails)
      throws CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    int orgId = authUser.getOrgId();
    List<String> badEmails = new ArrayList<>();
    List<String> invalidEmails = new ArrayList<>();
    List<String> cancelledSubscriptionEmails = new ArrayList<>();
    InvalidEmailsDTO finalListEmails = null;
    try {
      for (String email : emails.getEmails()) {
        List<String> emailFromDB =
            userRepository.findEmailByOrgIdAndStatusAndDeleted(
                email, orgId, UserStatus.ACTIVE.value(), false);
        if (emailFromDB != null && !emailFromDB.isEmpty()) {
          UserSubscription userSubscription =
              userSubscriptionRepository
                  .findByEmailAndSubscriptionCategorySubscriptionCategoryIdAndStatusAndCreatedByNotAndDeletedAndUserProfileDeleted(
                      email, emails.getCategoryId(), true, authUser.getUsername(), false, false);
          if (userSubscription != null) badEmails.add(email);
          else {
            List<UserSubscription> deletedUserSubscription =
                userSubscriptionRepository
                    .findByEmailAndSubscriptionCategorySubscriptionCategoryIdAndStatusAndCreatedByNotAndDeletedAndUserProfileDeletedOrderByLastUpdatedTimestampDesc(
                        email, emails.getCategoryId(), false, authUser.getUsername(), true, false);
            if (!deletedUserSubscription.isEmpty()
                && String.valueOf(deletedUserSubscription.get(0).getDeletedBy()).equals(SELF))
              cancelledSubscriptionEmails.add(email);
          }
        } else {
          invalidEmails.add(email);
        }
      }
      InvalidEmails emailsNotInNextconnect =
          InvalidEmails.builder()
              .errorMessage(
                  "These users are not available in nextconnect or not previliged for subscriptions")
              .emails(invalidEmails)
              .errorCode(USER_NOT_AVAILABLE)
              .build();
      InvalidEmails emailsAlreadySubscribed =
          InvalidEmails.builder()
              .errorMessage("These users are already subscribed for emails")
              .emails(badEmails)
              .errorCode(USER_ALREADY_SUBSCRIBED)
              .build();
      InvalidEmails emailsCancelledSubscription =
          InvalidEmails.builder()
              .errorMessage("These users have unsubscribed for email ")
              .emails(cancelledSubscriptionEmails)
              .errorCode(USER_UNSUBSCRIBED)
              .build();
      List<InvalidEmails> fullList = new ArrayList<>();
      fullList.add(emailsNotInNextconnect);
      fullList.add(emailsAlreadySubscribed);
      fullList.add(emailsCancelledSubscription);
      finalListEmails = InvalidEmailsDTO.builder().invalidEmails(fullList).build();
    } catch (Exception ex) {
      logger.error(
          "Exception occured when validating email subscription data for the user: -->{}<--",
          authUser.getUsername(),
          ex);
      throw new CustomException(CustomErrorCodes.EMAIL_SUBSCRIPTION_ERROR);
    }

    return finalListEmails;
  }

  @Override
  public UserSubscriptionDTO fetchAllUserSubscription(Long userId) throws CustomException {

    UserProfile loggedinUser = userService.fetchOne(userId);
    List<SubscriptionTypeDTO> subscriptionTypeDTOs = new ArrayList<>();
    try {
      List<UserSubscription> userSubscriptions =
          userSubscriptionRepository.findByCreatedByAndStatusAndDeletedAndUserProfileDeleted(
              loggedinUser.getEmail(), true, false, false);
      String customMessage = null;
      if (!CollectionUtils.isEmpty(userSubscriptions))
        customMessage = userSubscriptions.get(0).getCustomMessage();
      logger.info(
          "Fetching subscriptions of size: "
              + userSubscriptions.size()
              + " for the request of the user: "
              + loggedinUser.getEmail());
      Map<SubscriptionType, List<UserSubscription>> SubscriptionTypeMap =
          userSubscriptions.stream()
              .collect(Collectors.groupingBy(UserSubscription::getSubscriptionType));
      for (SubscriptionType subscriptionType : SubscriptionTypeMap.keySet()) {
        List<UserSubscription> userListSubscriptiontype = SubscriptionTypeMap.get(subscriptionType);
        List<SubscriptionCategoryDTO> subscriptionCategoryDTOs = new ArrayList<>();
        Map<SubscriptionCategory, List<UserSubscription>> SubscriptionCategoryMap =
            userListSubscriptiontype.stream()
                .collect(Collectors.groupingBy(UserSubscription::getSubscriptionCategory));

        for (SubscriptionCategory subscriptionCategory : SubscriptionCategoryMap.keySet()) {

          List<UserSubscription> userList = SubscriptionCategoryMap.get(subscriptionCategory);
          List<String> emails =
              userList.stream().map(x -> x.getEmail()).collect(Collectors.toList());
          SubscriptionCategoryDTO subscriptionCategoryDTO =
              SubscriptionCategoryDTO.builder()
                  .categoryName(subscriptionCategory.getCategoryName())
                  .emails(emails)
                  .subscriptionCategoryId(subscriptionCategory.getSubscriptionCategoryId())
                  .status(true)
                  .build();
          subscriptionCategoryDTOs.add(subscriptionCategoryDTO);
        }
        SubscriptionTypeDTO subscriptionTypeDTO =
            SubscriptionTypeDTO.builder()
                .subscriptionCategories(new HashSet<>(subscriptionCategoryDTOs))
                .subscriptionTypeId(subscriptionType.getSubscriptionTypeId())
                .subscriptionTypeName(subscriptionType.getSubscriptionTypeName())
                .build();
        subscriptionTypeDTOs.add(subscriptionTypeDTO);
      }
      return UserSubscriptionDTO.builder()
          .subscriptionTypeDTOs(subscriptionTypeDTOs)
          .customMessage(customMessage)
          .build();

    } catch (Exception ex) {
      logger.error(
          "Exception occured when logging email subscription data for the user -->{}<--",
          loggedinUser,
          ex);
      throw new CustomException(CustomErrorCodes.EMAIL_SUBSCRIPTION_ERROR);
    }
  }

  @Override
  public UserSubscriptionDTO fetchAllUserSubscriptionByUser(Long userId) throws CustomException {
    UserProfile loggedinUser = userService.fetchOne(userId);
    List<SubscriptionTypeDTO> subscriptionTypeDTOs = new ArrayList<>();
    int numberOfDaysAdvance = numberOfDefaultDaysAdvance;
    String isdCode = "", phoneNumber = "";

    try {
      List<UserSubscription> userSubscriptions =
          userSubscriptionRepository.findByCreatedByAndStatusAndDeletedAndUserProfileDeleted(
              loggedinUser.getEmail(), true, false, false);
      List<UserSubscription> otherSubscriptions =
          userSubscriptionRepository
              .findByEmailAndStatusAndDeletedAndCreatedByNotAndUserProfileDeleted(
                  loggedinUser.getEmail(), true, false, loggedinUser.getEmail(), false);

      List<UserSubscription> combinedList =
          Stream.of(userSubscriptions, otherSubscriptions)
              .flatMap(Collection::stream)
              .collect(Collectors.toList());
      String customMessage = null;
      if (!CollectionUtils.isEmpty(userSubscriptions))
        customMessage = userSubscriptions.get(0).getCustomMessage();

      logger.info(
          "Fetching subscriptions of size: {} for the request of the user: {}",
          combinedList.size(),
          loggedinUser.getEmail());

      Map<SubscriptionType, List<UserSubscription>> subscriptionTypeMap =
          combinedList.stream()
              .collect(Collectors.groupingBy(UserSubscription::getSubscriptionType));
      for (SubscriptionType subscriptionType : subscriptionTypeMap.keySet()) {
        List<UserSubscription> userListSubscriptiontype = subscriptionTypeMap.get(subscriptionType);
        List<SubscriptionCategoryDTO> subscriptionCategoryDTOs = new ArrayList<>();
        Map<SubscriptionCategory, List<UserSubscription>> subscriptionCategoryMap =
            userListSubscriptiontype.stream()
                .collect(Collectors.groupingBy(UserSubscription::getSubscriptionCategory));

        for (SubscriptionCategory subscriptionCategory : subscriptionCategoryMap.keySet()) {
          List<UserSubscription> userList = subscriptionCategoryMap.get(subscriptionCategory);
          List<String> emails =
              userList.stream().map(UserSubscription::getEmail).collect(Collectors.toList());
          // CHG***
          numberOfDaysAdvance =
              userList.stream()
                  .filter(
                      x ->
                          x.getSubscriptionType().getSubscriptionTypeId()
                              == subscriptionType.getSubscriptionTypeId())
                  .map(UserSubscription::getNumberOfDaysAdvance)
                  .findFirst()
                  .orElse(numberOfDefaultDaysAdvance);

          SubscriptionCategoryDTO subscriptionCategoryDTO =
              SubscriptionCategoryDTO.builder()
                  .categoryName(subscriptionCategory.getCategoryName())
                  .emails(emails)
                  .subscriptionCategoryId(subscriptionCategory.getSubscriptionCategoryId())
                  .status(true)
                  .numberOfDaysAdvance(numberOfDaysAdvance)
                  .build();
          subscriptionCategoryDTOs.add(subscriptionCategoryDTO);

          if (subscriptionType.getSubscriptionTypeId() == 2) {
            SubscriptionTypeDTO subscriptionTypeDTO =
                userList.stream()
                    .filter(x -> x.getSubscriptionType().getSubscriptionTypeId() == 2)
                    .map(
                        x ->
                            SubscriptionTypeDTO.builder()
                                .isdCode(x.getIsdCode())
                                .phones(x.getPhone())
                                .build())
                    .findFirst()
                    .orElse(null);
            if (subscriptionTypeDTO != null) {
              isdCode = subscriptionTypeDTO.getIsdCode();
              phoneNumber = subscriptionTypeDTO.getPhones();
            }
          }
        }

        subscriptionTypeDTOs.add(
            SubscriptionTypeDTO.builder()
                .subscriptionCategories(new HashSet<>(subscriptionCategoryDTOs))
                .subscriptionTypeId(subscriptionType.getSubscriptionTypeId())
                .isdCode(subscriptionType.getSubscriptionTypeId() == 2 ? isdCode : "")
                .phones(subscriptionType.getSubscriptionTypeId() == 2 ? phoneNumber : "")
                .subscriptionTypeName(subscriptionType.getSubscriptionTypeName())
                .build());
      }
      return UserSubscriptionDTO.builder()
          .subscriptionTypeDTOs(subscriptionTypeDTOs)
          .customMessage(customMessage)
          .build();
    } catch (Exception ex) {
      logger.error(
          "Exception occured when logging email subscription data for the user --> {}",
          loggedinUser,
          ex);
      throw new CustomException(CustomErrorCodes.EMAIL_SUBSCRIPTION_ERROR);
    }
  }

  @Override
  public void sendOTP(long userId, String isdCode, String phoneNumber)
      throws DataValidationException,
          CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {

    phoneNumberValidator.validatePhoneNumber(isdCode, phoneNumber);

    // Validate ISD Code for the supporting countries
    subscriptionValidator.validateSmsIsdSupportedCountries(
        countryRepository.findFirstByIsdCode(isdCode));

    phoneNumber = isdCode + phoneNumber;
    String randomNumber = String.format("%05d", new SecureRandom().nextInt(100000));

    PhoneNumberOtp phoneNumberOtp =
        phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(phoneNumber, userId);
    if (Optional.ofNullable(phoneNumberOtp).isPresent() && phoneNumberOtp.isValidated()) {
      logger.error("{} already validated", phoneNumber);
      throw new DataValidationException(CustomErrorCodes.PHONE_NUMBER_ALREADY_VALIDATED);
    } else if (Optional.ofNullable(phoneNumberOtp).isPresent() && !phoneNumberOtp.isValidated()) {
      try {
        sendSMS(phoneNumber, randomNumber, userId);
        phoneNumberOtpRepository.save(
            phoneNumberOtp.toBuilder()
                .otp(randomNumber)
                .timeStamp(Timestamp.from(Instant.now()))
                .build());
      } catch (HttpStatusCodeException e) {
        logger.error("HttpStatusCodeException: UserSubscriptionImpl -> sendOTP -> {}", e);
        throw new FailedDependencyException(CustomErrorCodes.CANNOT_SEND_SMS);
      } catch (Exception e) {
        logger.error("UserSubscriptionImpl -> sendOTP -> {}", e);
        throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
      }

    } else if (!Optional.ofNullable(phoneNumberOtp).isPresent()) {
      try {

        sendSMS(phoneNumber, randomNumber, userId);

        UserProfile userProfile = new UserProfile();
        userProfile.setUserId(userId);
        PhoneNumberOtp phoneNumberOtpObj = new PhoneNumberOtp();
        phoneNumberOtpObj.setUserProfile(userProfile);
        phoneNumberOtpObj.setOtp(randomNumber);
        phoneNumberOtpObj.setPhoneNumber(phoneNumber);
        phoneNumberOtpObj.setTimeStamp(Timestamp.from(Instant.now()));
        phoneNumberOtpObj.setValidated(false);
        phoneNumberOtpRepository.save(phoneNumberOtpObj);
      } catch (HttpStatusCodeException e) {
        logger.error(
            "HttpStatusCodeException: UserSubscriptionImpl -> sendOTP -> Failed sending SMS: {}",
            e);
        throw new FailedDependencyException(CustomErrorCodes.CANNOT_SEND_SMS);
      } catch (DataAccessException e) {
        logger.error(
            "DataAccessException: UserSubscriptionImpl -> sendOTP -> Failed saving data: {}", e);
        throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
      } catch (Exception e) {
        logger.error("UserSubscriptionImpl -> sendOTP -> unknown exception: {}", e);
        throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
      }
    } else {
      logger.error("None of the conditions matched. Unknown exception");
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }

  private void sendSMS(String phoneNumber, String randomNumber, long userId)
      throws CustomException, JSONException {

    Language language = userRepository.getLanguageId(userId);

    String smsMessage =
        ncSmsTemplateRepository.getDataByCategoryAndConfigKeyAndLanguageId(
            SMS_OTP_SUBSCRIPTION, OTP_MESSAGE, language.getId());

    // Send OTP in the SMS
    String creds = new String(Base64.encodeBase64((smsUsername + ":" + smsPassword).getBytes()));
    HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", "Basic " + creds);
    headers.setContentType(MediaType.APPLICATION_JSON);

    JSONObject encoding = new JSONObject();
    encoding.put("invalidCharacters", "TO_UTF16");
    encoding.put("encoding", "utf-16");
    encoding.put("maxParts", "20");
    encoding.put("src", com.merck.nextconnect.utils.common.Constants.SENDER_ID); // NCIOT-5088
    JSONObject text = new JSONObject();
    text.put("text", String.format(smsMessage, randomNumber));

    JSONObject dst = new JSONObject();
    dst.put("dst", phoneNumber);

    JSONArray recipientsArray = new JSONArray();
    recipientsArray.put(dst);
    text.put("recipients", recipientsArray);

    JSONArray messages = new JSONArray();
    messages.put(text);

    JSONObject otpSms = new JSONObject();
    otpSms.put("options", encoding);
    otpSms.put("messages", messages);

    JSONArray smsJson = new JSONArray();
    smsJson.put(otpSms);

    HttpEntity<String> request = new HttpEntity<>(smsJson.get(0).toString(), headers);
    logger.debug("Request Payload for SMS" + request.getBody());
    ResponseEntity<String> response =
        restTemplate.exchange(smsHost, HttpMethod.POST, request, String.class);
    Optional.ofNullable(response)
        .ifPresent(
            resp -> {
              if (resp.getStatusCode().equals(HttpStatus.CREATED)) {
                logger.info(
                    "OTP sent successfully to {} with jobId {}", phoneNumber, resp.getBody());
              }
            });
  }

  @Override
  public void validateOTP(long userId, String isdCode, String phoneNumber, String otp)
      throws CustomException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {

    subscriptionValidator.validateOtp(isdCode, phoneNumber, otp);
    PhoneNumberOtp phoneNumberOtp =
        phoneNumberOtpRepository.findFirstByPhoneNumberAndUserProfileUserId(
            isdCode + phoneNumber, userId);

    // Check if phone number is present & already validated

    if (Optional.ofNullable(phoneNumberOtp).isPresent() && phoneNumberOtp.isValidated()) {
      logger.error(
          "-->{}<-- -->{}<-- already validated for user -->{}<--", isdCode, phoneNumber, userId);
      throw new DataValidationException(CustomErrorCodes.PHONE_NUMBER_ALREADY_VALIDATED);
    } // Check if phone number is present but not validated
    else if (Optional.ofNullable(phoneNumberOtp).isPresent() && !phoneNumberOtp.isValidated()) {

      // Check if OTP is present in the database & is equal to the OTP submitted by the user
      if (Optional.ofNullable(phoneNumberOtp.getOtp()).isPresent()
          && phoneNumberOtp.getOtp().equals(otp)) {
        int otpExpiryTime = 0;

        try {
          otpExpiryTime =
              Integer.parseInt(
                  applicationConfigRepository
                      .findByCategoryAndKey(SMS_OTP_SUBSCRIPTION, OTP_EXPIRY_TIME)
                      .getValue());
        } catch (Exception e) {
          logger.error(
              "UserSubscriptionImpl -> validateOTP -> Exception occurred while retrieving Otp Expiry Time: -->{}<-- -->{}<--, user: -->{}<--",
              isdCode,
              phoneNumber,
              userId,
              e);
          throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
        }

        // Check if the OTP is expired
        if (LocalDateTime.now()
            .isAfter(phoneNumberOtp.getTimeStamp().toLocalDateTime().plusMinutes(otpExpiryTime)))
          throw new DataValidationException(CustomErrorCodes.OTP_EXPIRED);
        try {
          // remove the current validated entry of the current user
          phoneNumberOtpRepository.deleteAll(
              phoneNumberOtpRepository.findByUserProfileUserIdAndOtpNot(userId, otp));
          phoneNumberOtpRepository.save(
              phoneNumberOtp.toBuilder()
                  .timeStamp(Timestamp.from(Instant.now()))
                  .validated(true)
                  .build());
          logger.info(
              "-->{}<-- for -->{}<-- validated & updated in the database", phoneNumber, userId);
        } catch (Exception e) {
          logger.error(
              "UserSubscriptionImpl -> validateOTP -> Error occurred while saving ISD Code -->{}<-- & phone number: -->{}<-- for user -->{}<--",
              isdCode,
              phoneNumber,
              userId,
              e);
          throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
        }
      } else {
        logger.error(
            "Invalid OTP sent for Phone number -->{}<-- with ISD Code -->{}<-- for user -->{}<--",
            phoneNumber,
            isdCode,
            userId);
        throw new DataValidationException(CustomErrorCodes.INVALID_OTP);
      }
    } // Check if phone number exists in the database
    else if (!Optional.ofNullable(phoneNumberOtp).isPresent()) {
      logger.error(
          "Phone number -->{}<-- with ISD Code -->{}<-- doesn't exist for user -->{}<--",
          phoneNumber,
          isdCode,
          userId);
      throw new DataValidationException(CustomErrorCodes.PHONE_NUMBER_NOT_EXIST);
    } // If none of the condition matches then throw unknown exception although chances are rare
    else {
      logger.error(
          "None of the conditions matched. Unknown exception: -->{}<-- -->{}<--, user: -->{}<--",
          isdCode,
          phoneNumber,
          userId);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }

  @Override
  public Pair<String, String> getUserPhoneAndEmail(long userId)
      throws DataValidationException, CustomException {

    UserProfile userProfile = userRepository.getUserById(userId);

    if (!Optional.ofNullable(userProfile).isPresent()) {
      logger.error("Could not find the user profile for userId {}", userId);
      throw new DataValidationException(CustomErrorCodes.USER_NOT_FOUND);
    }
    if (StringUtils.isBlank(userProfile.getPhone())
        || StringUtils.isBlank(userProfile.getIsdCode())
        || StringUtils.isBlank(userProfile.getEmail())) {
      logger.error(
          "Email or phone number cannot be null email {} and phone number and isdCode {}",
          userProfile.getPhone(),
          userProfile.getEmail(),
          userProfile.getIsdCode());
      throw new DataValidationException(CustomErrorCodes.EMAIL_OR_PHONE_NUMBER_CANNOT_BE_NULL);
    }
    return Pair.of(
        String.join("", userProfile.getIsdCode(), userProfile.getPhone()), userProfile.getEmail());
  }
}
