package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.resources.IBusinessDomainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Business Domain
 *
 * @author SSHREEBE
 */
@RestController
@RequestMapping("/api/business-domain")
public class BusinessDomainController {

  @Autowired private IBusinessDomainService businessDomainService;

  @Operation(
      summary = "Find all business domain",
      tags = "Business domain",
      description = "This API is used to fetch list of all business domain excluding generic")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET)
  public ResponseEntity<List<BusinessDomainDTO>> fetchAllBusinessDomain(
      @Parameter(
              name = "includeGeneric",
              description = "Including the Generic",
              schema = @Schema(defaultValue = "false"))
          @RequestParam(value = "includeGeneric", required = false)
          Boolean includeGeneric)
      throws DataValidationException {

    return new ResponseEntity<>(
        businessDomainService.getAllBusinessDomain(includeGeneric), HttpStatus.OK);
  }
}
