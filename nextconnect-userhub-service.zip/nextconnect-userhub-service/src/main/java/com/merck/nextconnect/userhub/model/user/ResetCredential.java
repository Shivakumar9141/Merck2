package com.merck.nextconnect.userhub.model.user;

public class ResetCredential {

  private String currentPassword;
  private String newPassword;
  private String confirmPassword;

  public String getCurrentPassword() {
    return currentPassword;
  }

  public void setCurrentPassword(String CurrentPassword) {
    this.currentPassword = CurrentPassword;
  }

  public String getNewPassword() {
    return newPassword;
  }

  public void setNewPassword(String newPassword) {
    this.newPassword = newPassword;
  }

  public String getConfirmPassword() {
    return confirmPassword;
  }

  public void setConfirmPassword(String confirmPassword) {
    this.confirmPassword = confirmPassword;
  }
}
