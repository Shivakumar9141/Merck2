package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserDeviceAssignmentTrack;
import com.merck.nextconnect.userhub.entities.UserProfile;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDeviceAssignmentTrackRepository
    extends JpaRepository<UserDeviceAssignmentTrack, Long> {

  UserDeviceAssignmentTrack
      findByUserAndDeviceAndAssignedTimestampNotNullAndUnassignedTimestampNull(
          UserProfile userProfile, Device device);

  List<UserDeviceAssignmentTrack> findByUser(UserProfile userProfile);
}
