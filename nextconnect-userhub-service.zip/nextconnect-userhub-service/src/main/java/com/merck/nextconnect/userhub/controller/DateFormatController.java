package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.resources.IDateFormat;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
@RequestMapping("/api")
public class DateFormatController {

  @Autowired IDateFormat dateFormat;

  @Operation(description = "user date format", tags = "Date And Time")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/dateformats")
  public ResponseEntity<List<DateFormat>> getDates() {
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.DATE_FORMAT, Constants.GET, null));
    return new ResponseEntity<>(dateFormat.getDateFormats(), HttpStatus.OK);
  }
}
