package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

public class ResourceNotFoundException extends CustomException {

  private static final long serialVersionUID = 1L;

  public ResourceNotFoundException(String msg) {
    super(msg);
  }

  public ResourceNotFoundException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes);
  }

  public ResourceNotFoundException(CustomErrorCodes customErrorCodes, List<String> params) {
    super(customErrorCodes, params);
  }
}
