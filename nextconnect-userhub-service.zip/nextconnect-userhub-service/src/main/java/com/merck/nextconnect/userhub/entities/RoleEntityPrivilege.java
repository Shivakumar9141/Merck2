package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "NC_ROLES_ENTITY_PRIVILEGES")
public class RoleEntityPrivilege {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long roleEntityId;

  @ManyToOne
  @JoinColumn(name = "ROLE_ID")
  private Role role;

  @ManyToOne
  @JoinColumn(name = "PRIVILEGE_ID")
  private Privilege privilege;

  @ManyToOne
  @JoinColumn(name = "ENTITY_ID")
  private Entities entities;

  public RoleEntityPrivilege() {}

  public long getRoleEntityId() {
    return roleEntityId;
  }

  public void setRoleEntityId(long roleEntityId) {
    this.roleEntityId = roleEntityId;
  }

  public Role getRole() {
    return role;
  }

  public void setRole(Role role) {
    this.role = role;
  }

  public Privilege getPrivilege() {
    return privilege;
  }

  public void setPrivilege(Privilege privilege) {
    this.privilege = privilege;
  }

  public Entities getEntities() {
    return entities;
  }

  public void setEntities(Entities entities) {
    this.entities = entities;
  }
}
