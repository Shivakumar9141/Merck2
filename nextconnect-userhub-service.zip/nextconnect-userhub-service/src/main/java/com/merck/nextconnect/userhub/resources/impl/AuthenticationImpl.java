package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthToken;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.DeviceTypeOperation;
import com.merck.nextconnect.authfilter.repository.hazelcast.TokenStore;
import com.merck.nextconnect.authfilter.resources.IprivilegeBuilder;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.authentication.AuthenticationFactory;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.MenuGroupRequest;
import com.merck.nextconnect.userhub.model.UserInfo;
import com.merck.nextconnect.userhub.model.privilege.Privileges;
import com.merck.nextconnect.userhub.model.user.UserLoginInfo;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repository.jpa.UserProfileSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IAuthentication;
import com.merck.nextconnect.userhub.resources.ICountry;
import com.merck.nextconnect.userhub.resources.IRoles;
import com.merck.nextconnect.userhub.resources.MenuService;
import com.merck.nextconnect.userhub.response.SamlAuthResponse;
import com.merck.nextconnect.userhub.response.SamlValidationResponse;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.LoginUtil;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.util.security.DecryptUtil;
import com.merck.nextconnect.util.security.EncryptUtil;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.security.Keys;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.crypto.SecretKey;
import org.apache.commons.lang3.RandomUtils;
import org.apache.http.HttpStatus;
import org.joda.time.DateTime;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.Response;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureValidator;
import org.opensaml.xml.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * interface to perform user authentication
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Service
public class AuthenticationImpl implements IAuthentication {

  static final Logger logger = LoggerFactory.getLogger(AuthenticationImpl.class);

  @Autowired JwtTokenGenerator jwtTokenGenerator;

  @Autowired UserRepository userRepo;

  @Autowired UserProfileSettingsRepository userProfileSettingsRepository;

  @Autowired UserRolePrivileges userRolePrivileges;

  @Autowired IprivilegeBuilder privilegeBuilder;

  @Autowired IRoles iroles;

  @Autowired AuthenticationFactory authFactory;

  @Autowired IprivilegeProvider privilegeProvider;

  @Autowired UserOrgPrivileges userOrgPrivileges;

  @Value("${saml.idp.entity.id}")
  private String samlValidationIssuer;

  @Value("${saml.token.cache.encrypt.key}")
  private String encryptKeyForLoginToken;

  @Autowired LoginUtil loginUtil;

  @Autowired TokenStore tokenStore;

  @Autowired private MenuService menuManagementService;

  @Autowired private ICountry iCountry;

  /**
   * authenticate the user
   *
   * @param login - user loginame and password
   * @return AuthToken - user tokens
   * @throws com.merck.nextconnect.userhub.exception.AccessDeniedException
   */
  @Override
  public AuthToken login(Login login)
      throws com.merck.nextconnect.userhub.exception.AccessDeniedException {
    AuthToken authToken = new AuthToken();
    String loginName = login.getUsername();
    String authProvider = UserhubUtils.getAuthProvider(login.getUserdomain());
    Optional<UserProfile> userProfile =
        Optional.ofNullable(userRepo.getUserWithOutOrg(loginName, authProvider));
    userProfile.orElseThrow(
        () -> new LoginAuthenticationException("Username or password is incorrect"));
    // NCIOT-11199
    userProfile
        .filter(u -> u.getOrg().getStatus().equals(true))
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.ACCESS_DENIED_ORG_DEACTIVATED));
    userProfile
        .filter(u -> !u.getStatus().equals(UserStatus.INACTIVE.value()))
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.ACCESS_DENIED_ACCOUNT_BLOCKED));
    if (authFactory.getAuthProvider(login.getUserdomain()).authenticate(login)) {
      userProfile
          .filter(
              u ->
                  UserhubUtils.validateConsentStatus(
                      u.isConsentStatus(), u.isPrivacyPolicyStatus()))
          .orElseThrow(
              () ->
                  new LoginAuthenticationException(
                      "User has to accept terms and policy by registering profile"));
      authToken = generateAuthToken(userProfile.get());
      fillPrivileges(userProfile.get().getRole());
      logger.info("added privileges to cache for the user role");
    }
    return authToken;
  }

  /**
   * method to generate auth token
   *
   * @param login - user loginame and password
   * @return AuthToken - user tokens
   */
  private AuthToken generateAuthToken(UserProfile userProfile) {
    AuthToken authToken = new AuthToken();
    String jti = UUID.randomUUID().toString();
    byte[] keyBytes = new byte[64];
    new SecureRandom().nextBytes(keyBytes);
    SecretKey secretKey = Keys.hmacShaKeyFor(keyBytes);
    String accessToken = jwtTokenGenerator.generateAccessToken(secretKey, jti);
    String refreshToken = jwtTokenGenerator.generateRefreshToken(secretKey, jti);
    authToken.setToken(accessToken);
    authToken.setRefreshToken(refreshToken);
    jwtTokenGenerator.saveToken(
        Encoders.BASE64.encode(secretKey.getEncoded()), jti, userProfile.getUserId());
    logger.info("successfully generated and persisted user tokens");
    return authToken;
  }

  /**
   * gets the user info
   *
   * @param loginText - user loginame
   * @return UserLoginInfo - user info
   */
  @Override
  public UserLoginInfo getLoginTypes(String loginText) {
    UserLoginInfo userLoginInfo = new UserLoginInfo();
    List<String> loginTypes = userRepo.getLoginTypes(loginText);
    userLoginInfo.setUserName(loginText);
    userLoginInfo.setAuthenticationTypes(loginTypes);
    return userLoginInfo;
  }

  /**
   * get the information of users
   *
   * @param userId - id of the user
   * @param username - name of the user
   * @return userDetail - users details
   * @throws ResourceNotFoundException
   */
  @Override
  public UserInfo getUserInfo(long userId, String username, int orgId)
      throws ResourceNotFoundException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    UserInfo userDetail = new UserInfo();
    userDetail.setId(userId);
    userDetail.setUsername(username);
    UserProfile userProfile = userRepo.getUserById(userId, orgId, authUser.getRoleId());
    userDetail.setEmail(userProfile.getEmail());
    userDetail.setStatus(userProfile.getStatus());
    userDetail.setDomainName(userProfile.getUserDomain().getDomainName());
    userDetail.setDateFormat(userProfile.getDateFormat().getDateFormat());
    userDetail.setLanguageCode(userProfile.getLanguage().getCode());
    userDetail.setRole(userProfile.getRole().getName());
    userDetail.setRoleId(userProfile.getRole().getRoleId());
    userDetail.setOrgId(userProfile.getOrg().getId());
    userDetail.setOrgName(
        userProfile
            .getOrg()
            .getName()); // NCIOT-9657 Adding Organization Name (Required to Display in Pop-Up
    // screen)
    userDetail.setFirstName(userProfile.getFirstName());
    userDetail.setLastName(userProfile.getLastName());
    userDetail.setDomainVisible(isDomainVisible(userProfile.getRole().getName()));
    Optional.ofNullable(userProfile.getCountry())
        .ifPresent(
            u -> {
              userDetail.setCountryCode(u.getCountryCode());
            });
    Optional.ofNullable(userProfile.getTimeZoneId())
        .ifPresent(
            u -> {
              userDetail.setTimeZone(u);
              userDetail.setCountryTimezoneDTO(iCountry.getCountryTimezone(u));
            });
    userDetail.setAutoCreated(userProfile.isAutoCreated());

    userDetail.setInvitedVia(userProfile.getInvitedVia());
    userDetail.setValidated(userProfile.isValidated());
    List<Privileges> privileges = new ArrayList<Privileges>();
    privileges.addAll(iroles.getPrivileges(userDetail.getRoleId(), Constants.ENTITY));
    privileges.addAll(iroles.getPrivileges(userDetail.getRoleId(), Constants.DEVICETYPE));
    privileges.addAll(userOrgPrivileges.getOrgPrivileges());
    userDetail.setPrivileges(privileges);
    userDetail.setOrgSettings(userOrgPrivileges.getOrgSpecificSettings());
    userDetail.setUserProfileSettings(
        userProfileSettingsRepository.fetchUserProfileSettings(userId));
    // NCIOT-11851
    MenuGroupRequest menuGroupRequest = new MenuGroupRequest();
    menuGroupRequest.setRoleId(userProfile.getRole().getRoleId());
    userDetail.setMenuGroups(menuManagementService.getMenuGroups(menuGroupRequest));
    userDetail.setOrgType(userProfile.getOrg().getType());
    userDetail.setParentType(userProfile.getOrg().getParent().getType());

    return userDetail;
  }

  /**
   * fill entity level privileges to the cache
   *
   * @param role - role object
   */
  private void fillPrivileges(Role role) {
    List<String> entityPrivilegeList = userRolePrivileges.getEntityPrivilegeList(role.getRoleId());
    if (!entityPrivilegeList.isEmpty()) {
      privilegeBuilder.addEntityPrivileges(role.getRoleId(), entityPrivilegeList);
    }

    List<Long> deviceGroupLevelPrivileges =
        userRolePrivileges.getDeviceGroupPrivilegeList(role.getRoleId());
    if (!deviceGroupLevelPrivileges.isEmpty()) {
      privilegeBuilder.addDeviceGroupPrivileges(role.getRoleId(), deviceGroupLevelPrivileges);
    }
    Map<Long, Map<DeviceTypeOperation, List<String>>> deviceTypeLevelPrivileges =
        userRolePrivileges.getDeviceTypePrivilegeMap(role.getRoleId());
    if (!deviceTypeLevelPrivileges.isEmpty()) {
      privilegeBuilder.addDeviceTypePrivileges(role.getRoleId(), deviceTypeLevelPrivileges);
    }
  }

  @Override
  public SamlAuthResponse loginBySaml(String samlResponse) {
    logger.info("loginBySaml called");
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();
    Response smalResponse = loginUtil.validateAndParseSamlResponse(samlResponse);
    String hashTokenCacheKey = "";
    if (null != smalResponse) {
      SamlValidationResponse samlValidationResponse = samlResponseValidation(smalResponse);
      if (samlValidationResponse.isValidationStatus()) {
        samlAuthResponse = getAuthTokenByUserName(samlValidationResponse.getEmailAdress());
        if (samlAuthResponse.getStatusCode() == HttpStatus.SC_OK) {
          hashTokenCacheKey = storeTokenAndGetHash(samlAuthResponse, samlValidationResponse);
          samlAuthResponse.setHashTokenCacheKey(hashTokenCacheKey);
          logger.info("loginBySaml --> samlAuthResponse valid");
        }
      } else {
        samlAuthResponse.setStatusCode(HttpStatus.SC_BAD_REQUEST);
        samlAuthResponse.setStatusMessage("BadRequest");
        logger.info("loginBySaml --> samlAuthResponse invalid");
      }
    } else {
      samlAuthResponse.setStatusCode(HttpStatus.SC_BAD_REQUEST);
      samlAuthResponse.setStatusMessage("BadRequest");
      logger.info("loginBySaml --> samlAuthResponse null");
    }
    return samlAuthResponse;
  }

  @Override
  public String getTokenFromCacheByHash(String hash) throws Exception {
    String encryptedAuthToken = tokenStore.retrieveAuthToken(hash);
    String decryptedToken = DecryptUtil.decrypt(encryptKeyForLoginToken, encryptedAuthToken);
    return decryptedToken;
  }

  // NCIOT-1696
  public boolean isDomainVisible(String roleName) {
    if (Constants.LABWATER_BUSINESS_ROLES.contains(roleName)) {
      return false;
    } else {
      return true;
    }
  }

  private SamlValidationResponse samlResponseValidation(Response smalResponse) {
    SamlValidationResponse samlValidationResponse = new SamlValidationResponse();
    samlValidationResponse.setValidationStatus(false);
    Assertion assertion = smalResponse.getAssertions().get(0);
    String issuer = assertion.getIssuer().getValue();
    Signature signature = assertion.getSignature();
    DateTime notBefore = smalResponse.getAssertions().get(0).getConditions().getNotBefore();
    DateTime notOnOrAfter = smalResponse.getAssertions().get(0).getConditions().getNotOnOrAfter();
    List<AttributeStatement> attributeStatements =
        smalResponse.getAssertions().get(0).getAttributeStatements();
    List<Attribute> attributes = attributeStatements.get(0).getAttributes();
    List<XMLObject> attributeValues = attributes.get(7).getAttributeValues();
    String emailAddress = attributeValues.get(0).getDOM().getTextContent();
    boolean dateTimeValidationStatus = dateTimeValidation(notBefore, notOnOrAfter);
    logger.info("dateTimeValidationStatus == " + dateTimeValidationStatus);
    boolean validateIssuerStatus = validateIssuer(issuer);
    logger.info("validateIssuerStatus == " + validateIssuerStatus);
    // Check for additional injected Assertions
    boolean samlAssertionValidationStatus = samlAssertionValidation(smalResponse);
    logger.info("samlAssertionValidationStatus == {}", samlAssertionValidationStatus);
    boolean validateProfileSignatureStatus = validateProfileSignature(signature);
    logger.info("validateProfileSignatureStatus == {}", validateProfileSignatureStatus);

    BasicX509Credential credential = loginUtil.getCredential();
    if (null != credential
        && dateTimeValidationStatus
        && validateIssuerStatus
        && validateProfileSignatureStatus
        && samlAssertionValidationStatus) {
      boolean validationStatus = validateSignature(signature, credential);
      logger.info("validate certificate with signature status == " + validationStatus);
      samlValidationResponse.setValidationStatus(validationStatus);
      samlValidationResponse.setNotBefore(notBefore);
      samlValidationResponse.setNotOnOrAfter(notOnOrAfter);
      samlValidationResponse.setSignature(signature);
      samlValidationResponse.setEmailAdress(emailAddress);
    }
    return samlValidationResponse;
  }

  private boolean validateSignature(Signature signature, BasicX509Credential credential) {
    boolean validateSignatureStatus = false;
    /* create SignatureValidator */
    SignatureValidator signatureValidator = new SignatureValidator(credential);
    try {
      signatureValidator.validate(signature);
      validateSignatureStatus = true;
      logger.info("validateSignatureStatus == " + validateSignatureStatus);
    } catch (ValidationException ve) {
      logger.error("LoginServiceImpl {} validateSignature" + ve.getMessage());
      validateSignatureStatus = false;
    }
    return validateSignatureStatus;
  }

  private boolean validateIssuer(String issuer) {
    boolean issuerValidateStatus = false;
    if (issuer.equals(samlValidationIssuer)) {
      issuerValidateStatus = true;
    }
    return issuerValidateStatus;
  }

  private boolean dateTimeValidation(DateTime notBefore, DateTime notOnOrAfter) {
    boolean dateValidationStutus = false;
    if (notBefore.isBeforeNow() && notOnOrAfter.isAfterNow()) {
      dateValidationStutus = true;
    }
    return dateValidationStutus;
  }

  private SamlAuthResponse getAuthTokenByUserName(String loginName) {
    AuthToken authToken = new AuthToken();
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();
    UserProfile userProfile = userRepo.getUserByEmail(loginName);
    if (userProfile == null
        || userProfile.getStatus().equals(UserStatus.INACTIVE.value())
        || !UserhubUtils.validateConsentStatus(
            userProfile.isConsentStatus(), userProfile.isPrivacyPolicyStatus())) {
      samlAuthResponse.setStatusCode(HttpStatus.SC_UNAUTHORIZED);
      samlAuthResponse.setStatusMessage("Unauthorized");
    } else {
      authToken = generateAuthToken(userProfile);
      fillPrivileges(userProfile.getRole());
      samlAuthResponse.setAuthToken(authToken);
      samlAuthResponse.setStatusCode(HttpStatus.SC_OK);
      samlAuthResponse.setStatusMessage("Success");
    }
    return samlAuthResponse;
  }

  private String storeTokenAndGetHash(
      SamlAuthResponse samlAuthResponse, SamlValidationResponse samlValidationResponse) {
    // generate hash with some unique params like String+timestamp
    // encrpty the auth token AES key for now store in Properties

    String valuesForHash =
        RandomUtils.nextLong()
            + samlValidationResponse.getEmailAdress()
            + System.currentTimeMillis();
    String hashForThisUser = DecryptUtil.getSha256(valuesForHash);
    String encryptedToken =
        EncryptUtil.encrypt(encryptKeyForLoginToken, samlAuthResponse.getAuthToken().toString());
    tokenStore.saveAuthToken(hashForThisUser, encryptedToken);
    return hashForThisUser;
  }

  /**
   * single assertion is expected and configured to be returned as part of SAML Response. Thus,
   * invalidating any encrypted assertion or more than one assertion Also, prevents XSW3, XSW5 and
   * similar attacks
   *
   * @param response
   * @return
   */
  private boolean samlAssertionValidation(Response response) {
    boolean isStructureValid = true;

    // Encrypted Assertions are not requested/configured
    if (Objects.nonNull(response.getEncryptedAssertions())
        && !response.getEncryptedAssertions().isEmpty()) isStructureValid = false;
    if (isStructureValid) {
      if (Objects.isNull(response.getAssertions()) || (1 != response.getAssertions().size()))
        isStructureValid = false;
    }
    return isStructureValid;
  }

  /**
   * validates the profile signature to rule out invalid Assertion ref_id, URI, child elements, etc.
   *
   * @param signature
   * @return
   */
  private boolean validateProfileSignature(Signature signature) {
    boolean isSignatureProfileValid = false;
    if (Objects.nonNull(signature)) {
      SAMLSignatureProfileValidator profileValidator = new SAMLSignatureProfileValidator();
      try {
        profileValidator.validate(signature);
        isSignatureProfileValid = true;
      } catch (ValidationException ex) {
        logger.error("LoginServiceImpl --> validateProfile: {} ", ex.getMessage());
      }
    }
    return isSignatureProfileValid;
  }
}
