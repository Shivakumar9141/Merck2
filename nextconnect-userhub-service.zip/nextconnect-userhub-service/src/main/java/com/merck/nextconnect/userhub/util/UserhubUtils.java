package com.merck.nextconnect.userhub.util;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.context.SecurityContextHolder;

public class UserhubUtils {

  private static Pattern pattern;

  private static Matcher matcher;

  public static final HashMap<String, String> user_domain_map =
      new HashMap<String, String>() {
        {
          put(Constants.NEXTCONNECT, Constants.NEXTCONNECT_AUTH);
          put(Constants.SIAL, Constants.SIAL_AUTH);
          put(Constants.MERCK_GLOBAL, Constants.MERCK_AUTH);
          put(Constants.MERCK_DNAP, Constants.MERCK_AUTH);
          put(Constants.MERCK_DNEU, Constants.MERCK_AUTH);
          put(Constants.MERCK_DNLA, Constants.MERCK_AUTH);
          put(Constants.MERCK_DNNA, Constants.MERCK_AUTH);
        }
      };

  /**
   * email validation
   *
   * @param email - email
   * @return boolean
   */
  public static boolean isValidEmailAddress(String email) {
    boolean result = true;
    try {
      InternetAddress emailAddr = new InternetAddress(email);
      emailAddr.validate();
    } catch (AddressException ex) {
      result = false;
    }
    return result;
  }

  public static String getAuthProvider(String userDomain) {
    return user_domain_map.get(userDomain);
  }

  /**
   * validates pattern
   *
   * @param rule - regex rule
   * @param input - input to validate
   * @return boolean
   */
  public static boolean validatePattern(String rule, String input) {
    pattern = Pattern.compile(rule, Pattern.DOTALL);
    matcher = pattern.matcher(input);
    return matcher.matches();
  }

  /**
   * get authenticated user
   *
   * @return authUser
   */
  public static AuthenticatedUser getAuthenticatedUser() {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return authUser;
  }

  public static boolean validateConsentStatus(boolean consentTs, boolean privacyPolicyStatus) {
    return (consentTs && privacyPolicyStatus);
  }

  /**
   * escape Underscore with slash for like operator in mysql.
   *
   * <p>https://stackoverflow.com/questions/22167132/mysql-like-query-with-underscore/22167148
   *
   * @param searchBy
   * @return
   */
  public static String escapeUnderscoreSpecialChar(String searchBy) {
    if (StringUtils.isNotBlank(searchBy)) {
      searchBy = searchBy.replaceAll("_", "\\_");
    }
    return searchBy;
  }
}
