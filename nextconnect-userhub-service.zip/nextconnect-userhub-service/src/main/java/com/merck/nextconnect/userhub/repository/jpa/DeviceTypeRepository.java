package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.DeviceType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * interface talks with device type table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal</a>
 */
@Repository
public interface DeviceTypeRepository extends JpaRepository<DeviceType, Long> {}
