package com.merck.nextconnect.userhub.authentication.impl;

import com.merck.nextconnect.userhub.authentication.IAuthRepository;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.stereotype.Component;

@Component
public class SialAuth implements IAuthRepository {

  @Autowired
  @Qualifier("sialLdap")
  private LdapTemplate sialLdap;

  @Override
  public boolean authenticate(Login login) {
    final Filter f = new EqualsFilter("sAMAccountName", login.getUsername());
    final boolean authenticated =
        sialLdap.authenticate(Constants.EMPTY_STRING, f.encode(), login.getPassword());

    return authenticated;
  }
}
