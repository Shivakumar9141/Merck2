package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import com.merck.nextconnect.userhub.repository.jpa.EntityRepository;
import com.merck.nextconnect.userhub.repository.jpa.PrivilegeRepository;
import com.merck.nextconnect.userhub.resources.Iprivileges;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * service class to perform privileges operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public class PrivilegeImpl implements Iprivileges {

  static final Logger logger = LoggerFactory.getLogger(PrivilegeImpl.class);

  @Autowired PrivilegeRepository privilegeRepo;

  @Autowired UserRolePrivileges userRolePrivileges;

  @Autowired EntityRepository entityRepo;

  /**
   * add a privilege
   *
   * @param privilegeInfo - privilege info
   */
  public long add(PrivilegeInfo privilegeInfo) {
    Privilege privilege = new Privilege(privilegeInfo);
    long privilegeId = privilegeRepo.save(privilege).getprivilegeId();
    return privilegeId;
  }

  /**
   * get all privileges
   *
   * @param filterBy - filter by criteria
   * @return list of privileges
   */
  public List<Privilege> getAll(String filterBy) {
    List<Privilege> privileges;
    if (filterBy != null) {
      privileges = privilegeRepo.getByFilter(filterBy);
    } else {
      privileges = privilegeRepo.findAll();
    }
    return privileges;
  }

  /**
   * get all entities
   *
   * @return list of entities
   */
  @Override
  public List<Entities> getAllEntities() {
    return entityRepo.findAll();
  }

  /**
   * delete a privilege
   *
   * @param privilegeId - id of the privilege
   */
  @Override
  public void delete(long privilegeId) {
    userRolePrivileges.deletePrivilege(privilegeId);
    privilegeRepo.deleteById(privilegeId);
  }
}
