package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * menu group mapping table
 *
 * @author clukose
 */
@Entity
@Table(name = "nc_menu_group_mapping")
@Getter
@Setter
public class MenuGroupMapping implements Serializable {
  /** */
  private static final long serialVersionUID = -6553294380864481514L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int menuGroupMappingId;

  @ManyToOne
  @JoinColumn(name = "menugroup_id")
  private MenuGroup menuGroup;

  @ManyToOne
  @JoinColumn(name = "menu_id")
  private Menu menu;
}
