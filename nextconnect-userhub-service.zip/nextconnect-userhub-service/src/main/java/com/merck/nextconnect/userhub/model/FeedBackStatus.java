package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeedBackStatus {
  private double rating;
  private boolean status;
  private String feedback;
  private Long totalFeedbacks;
}
