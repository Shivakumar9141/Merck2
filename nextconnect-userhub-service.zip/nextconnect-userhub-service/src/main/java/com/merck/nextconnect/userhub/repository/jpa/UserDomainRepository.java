package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.utils.common.entities.UserDomain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface UserDomainRepository extends JpaRepository<UserDomain, Long> {

  @Query("from UserDomain u where " + "u.domainName = :name")
  UserDomain getByDomainName(@Param("name") String name);

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param name
   * @return long
   */
  @Query("select d.domainId from UserDomain d where d.domainName = :name")
  long findDomainIdByDomainName(@Param("name") String name);
}
