package com.merck.nextconnect.userhub.mail;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import org.springframework.stereotype.Component;

/** interface to do mail operations */
/**
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal</a>
 */
@Component
public interface IMailService {

  /**
   * sending mail
   *
   * @param userProfile - user profile
   * @param action - action (invite user , password update)
   * @param token - jwt token
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  void send(UserProfile userProfile, String action, String token, String environment)
      throws AddressException, MessagingException, CustomException;

  /**
   * sending email
   *
   * @param to - recipient email
   * @param subject - email subject
   * @param body - email content
   * @param environment - email subject might bbe modified based on environment
   */
  void sendMail(String to, String subject, String body, String environment)
      throws AddressException, MessagingException;
}
