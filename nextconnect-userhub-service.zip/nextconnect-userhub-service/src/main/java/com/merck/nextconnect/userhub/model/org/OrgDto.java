package com.merck.nextconnect.userhub.model.org;

import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrgDto {

  private int orgId;

  private String name;

  private Boolean status;

  private String description;

  private String createdBy;

  private String createdOn;

  private String type;

  private Map<String, Object> customProperties;

  private Long historicalDataSubscription;

  private List<PartnerTypeEntity> partnerTypes;

  private boolean isAutoCreated;

  public static final String PATTERN = "yyyy-MM-dd'T'HH:mm:ssXXX";

  private boolean deleted;

  private boolean enableDeleteIcon;

  /** Add enableToggle as per V6MILIQ-2644 */
  private boolean enableToggle;

  public OrgDto(int orgId, String name, String type, String description, Boolean status) {
    this.orgId = orgId;
    this.name = name;
    this.type = type;
    this.description = description;
    this.status = status;
  }

  public OrgDto(
      int orgId, String name, String type, String description, Boolean status, Boolean deleted) {
    this.orgId = orgId;
    this.name = name;
    this.type = type;
    this.description = description;
    this.status = status;
    this.deleted = deleted;
  }

  public OrgDto(
      int orgId,
      String name,
      String description,
      String createdBy,
      Date createdOn,
      Boolean status,
      String type) {
    this.orgId = orgId;
    this.name = name;
    this.description = description;
    this.createdBy = createdBy;
    this.createdOn =
        Optional.ofNullable(createdOn).isPresent()
            ? new SimpleDateFormat(PATTERN).format(createdOn)
            : null;
    this.status = status;
    this.type = type;
  }

  public OrgDto(
      int orgId,
      String name,
      String description,
      String createdBy,
      Date createdOn,
      Boolean status,
      String type,
      Long historicalDataSubscription,
      boolean isAutoCreated) {
    this.orgId = orgId;
    this.name = name;
    this.description = description;
    this.createdBy = createdBy;
    this.createdOn =
        Optional.ofNullable(createdOn).isPresent()
            ? new SimpleDateFormat(PATTERN).format(createdOn)
            : null;
    this.status = status;
    this.type = type;
    this.historicalDataSubscription = historicalDataSubscription;
    this.isAutoCreated = isAutoCreated;
  }
}
