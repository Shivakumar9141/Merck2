/** */
package com.merck.nextconnect.userhub.validations.helper;

import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.file.handler.exception.ValidationErrorCodes;
import com.merck.nextconnect.utils.validations.SimpleValidation;
import com.merck.nextconnect.utils.validations.Validation;

/**
 * @author Harshit Shrivastava 26-Nov-2018
 */
public class SubscriptionHelper {

  public static Validation<Country> validateCountry =
      SimpleValidation.from(
          (s) -> s != null && s.isSupportEnabled(), ValidationErrorCodes.ISDCODE_NOT_SUPPORTED);
}
