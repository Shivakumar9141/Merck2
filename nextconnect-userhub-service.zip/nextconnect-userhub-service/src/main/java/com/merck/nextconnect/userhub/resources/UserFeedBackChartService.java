package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.model.UserFeedbackTrend;
import com.merck.nextconnect.userhub.model.UserRatingTrend;

/**
 * @author clukose
 */
public interface UserFeedBackChartService {

  UserFeedbackTrend getUserFeedBackTrend(long duration);

  UserRatingTrend getUserRatingTrend(long duration);
}
