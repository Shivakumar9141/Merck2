package com.merck.nextconnect.userhub.model.privilege;

public class ResourcePrivilege {

  private long resourceid;
  private long privilegeid;

  public long getPrivilegeid() {
    return privilegeid;
  }

  public void setPrivilegeid(long privilegeid) {
    this.privilegeid = privilegeid;
  }

  public long getResourceid() {
    return resourceid;
  }

  public void setResourceid(long resourceid) {
    this.resourceid = resourceid;
  }
}
