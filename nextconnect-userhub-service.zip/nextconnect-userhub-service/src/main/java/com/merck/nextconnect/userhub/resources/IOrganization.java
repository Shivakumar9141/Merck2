package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.OrganizationType;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.OrgFilter;
import com.merck.nextconnect.userhub.model.OrgPartnerBrandPartnerTypeDTO;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

@Component
public interface IOrganization {

  List<OrgDto> getAll(String operation, String searchBy, String type, String reference);

  /**
   * get user domains
   *
   * @return UserDomain - user domains
   */
  List<UserDomain> getDomains(Integer orgId);

  int create(OrgInfo orgInfo)
      throws DuplicateResourceException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException;

  void update(OrgInfo orgInfo, int orgId)
      throws DuplicateResourceException,
          DataValidationException,
          ResourceNotFoundException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          CustomException;

  List<String> getFacets(String operation);

  void delete(int orgId) throws ResourceNotFoundException, CustomException, EmailException;

  /** Made changes as per NCIOT-11283. */
  OrgFilter getFilter();

  /**
   * Made changes as per NCIOT-11283.
   *
   * @param fetchCriteria
   * @return Page<Organization>
   * @throws CustomException
   */
  Page<Organization> getAllOrgs(FetchCriteria fetchCriteria) throws CustomException;

  /**
   * Made changes as per NCIOT-11283.
   *
   * @param content
   * @return List<OrgDto>
   */
  List<OrgDto> orgListConvertor(List<Organization> content);

  void updateOrgSetting(int orgId, Long historicalDataSubscription);

  Organization getOrgByName(String orgName);

  List<OrganizationType> getOrganizationType();

  OrgPartnerBrandPartnerTypeDTO getOrgBrandPartnerTypes(Integer orgId); // NCIOT-12122,12118,12123

  /**
   * Updates org status
   *
   * @param orgInfo
   * @param orgId
   * @throws ResourceNotFoundException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws CustomException
   * @throws EmailException
   */
  void updateOrgStatus(OrgInfo orgInfo, int orgId)
      throws ResourceNotFoundException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          CustomException;
}
