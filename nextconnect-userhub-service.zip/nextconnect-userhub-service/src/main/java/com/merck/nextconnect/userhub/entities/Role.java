package com.merck.nextconnect.userhub.entities;

import com.merck.nextconnect.userhub.model.role.RoleInfo;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import java.io.Serializable;
import lombok.ToString;

@ToString
@Entity
@Table(name = "NC_ROLES")
public class Role implements Serializable {

  /** */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long roleId;

  @Pattern(regexp = ".*\\S.*")
  private String name;

  @Column(columnDefinition = "boolean default false")
  private Boolean systemDefined = false;

  @ManyToOne
  @JoinColumn(name = "ORG_ID")
  private Organization org;

  @Column private boolean isServiceRole;

  public Role() {}

  public Role(long roleId) {
    this.roleId = roleId;
  }

  public Role(RoleInfo roleinfo) {
    this.name = roleinfo.getName();
  }

  public long getRoleId() {
    return roleId;
  }

  public void setRoleId(long roleId) {
    this.roleId = roleId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public boolean isSystemDefined() {
    return systemDefined;
  }

  public void setSystemDefined(boolean systemDefined) {
    this.systemDefined = systemDefined;
  }

  public Organization getOrg() {
    return org;
  }

  public void setOrg(Organization org) {
    this.org = org;
  }

  public boolean isServiceRole() {
    return isServiceRole;
  }

  public void setServiceRole(boolean isServiceRole) {
    this.isServiceRole = isServiceRole;
  }
}
