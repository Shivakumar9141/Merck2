package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.MenuDTO;
import com.merck.nextconnect.userhub.model.MenuGroupRequest;
import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuInfoDTO;
import com.merck.nextconnect.userhub.model.MenuManagementRequest;
import com.merck.nextconnect.userhub.model.MenuManagementResponse;
import com.merck.nextconnect.userhub.model.MenuUpdate;
import com.merck.nextconnect.userhub.model.MenuUpdateRequestDTO;
import com.merck.nextconnect.userhub.repo.jdbc.MenuManagementRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserMenuRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.MenuService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * NCIOT-11851
 *
 * @author clukose
 */
@Service
public class MenuServiceImpl implements MenuService {

  @Autowired private UserMenuRepository userMenuRepository;

  @Autowired private MenuManagementRepositoryJdbc menuJdbc;

  @Autowired private UserRepository userRepository;

  @Override
  public List<MenuGroupResponse> getMenuGroups(MenuGroupRequest request) {
    MapSqlParameterSource menuGroupParam = new MapSqlParameterSource();
    menuGroupParam.addValue("roleId", request.getRoleId());
    StringBuilder groupQuery = getMenuGroupQuery();
    return menuJdbc.getMenuGroup(menuGroupParam, String.valueOf(groupQuery));
  }

  @Override
  public List<MenuManagementResponse> getMenuInfo(MenuManagementRequest request)
      throws CustomException {

    List<MenuManagementResponse> menuManResponses = new ArrayList<>();
    MenuManagementResponse response = null;
    boolean isUserMenuExists = isRecordExist(request.getUserId(), request.getMenuGroupName());
    if (!isUserMenuExists) {
      MapSqlParameterSource insertParameters = new MapSqlParameterSource();
      insertParameters.addValue("userId", request.getUserId());
      insertParameters.addValue("roleId", request.getRoleId());
      StringBuilder getCountQuery = getUserMenuCount(request.getMenuGroupName());
      Integer count = menuJdbc.getUserMenuCount(insertParameters, String.valueOf(getCountQuery));
      String visibility = "1";
      if (count > 0) {
        getCountQuery = getMaxCount(request.getMenuGroupName());
        Integer maxCount =
            menuJdbc.getUserMenuCount(insertParameters, String.valueOf(getCountQuery));
        String limit = "limit " + maxCount;
        StringBuilder insertQuery =
            getUserMenuInsertQuery(visibility, limit, request.getMenuGroupName());
        menuJdbc.insertMenuInfo(insertParameters, String.valueOf(insertQuery));

        if ((count - maxCount) > 0) {
          limit = "limit " + count + " offset " + maxCount;
          visibility = "0";
          insertQuery = getUserMenuInsertQuery(visibility, limit, request.getMenuGroupName());
          menuJdbc.insertMenuInfo(insertParameters, String.valueOf(insertQuery));
        }
      }
    }

    // NCIOT-14537-Inserting additional menu's when new privileges are given
    List<Integer> menuIdList =
        userMenuRepository.getDifferMenuId(
            request.getRoleId(), request.getUserId(), request.getMenuGroupName());
    if (menuIdList != null && !menuIdList.isEmpty()) {
      MapSqlParameterSource insertParameters = new MapSqlParameterSource();
      insertParameters.addValue("userId", request.getUserId());
      insertParameters.addValue("roleId", request.getRoleId());
      for (Integer menuId : menuIdList) {
        String visibility = "1";
        StringBuilder getCountQuery =
            getPresentVisibleMenuCount(request.getUserId(), visibility, request.getMenuGroupName());
        Integer presentVisibleMenuCount =
            menuJdbc.getUserMenuCount(insertParameters, String.valueOf(getCountQuery));
        getCountQuery = getMaxCount(request.getMenuGroupName());
        Integer maxCount =
            menuJdbc.getUserMenuCount(insertParameters, String.valueOf(getCountQuery));
        if (!((maxCount - presentVisibleMenuCount) > 0)) {
          visibility = "0";
        }
        insertParameters.addValue("menuId", menuId);
        StringBuilder insertQuery = getUserMenuInsertQuery(visibility);
        menuJdbc.insertMenuInfo(insertParameters, String.valueOf(insertQuery));
      }
    }
    response = getUserMenu(request.getMenuGroupName(), request.getUserId(), request.getRoleId());
    if (response != null) {
      menuManResponses.add(response);
    }

    return menuManResponses;
  }

  /**
   * @param request
   * @return
   */
  private MenuManagementResponse getUserMenu(String menuGroupName, long userId, long roleId) {
    MenuManagementResponse response = new MenuManagementResponse();
    MapSqlParameterSource getParameters = new MapSqlParameterSource();
    getParameters.addValue("grpname", menuGroupName);
    getParameters.addValue("userId", userId);
    getParameters.addValue("roleId", roleId);
    StringBuilder getMenuQuery = getUserMenuInfoQuery();
    List<MenuInfoDTO> menuInfoList =
        menuJdbc.getMenuInfo(getParameters, String.valueOf(getMenuQuery));

    if (menuInfoList != null && !menuInfoList.isEmpty()) {
      menuInfoList = hideSCMButtonForCustOfDistributors(menuInfoList);
      response = mapMenuResponse(menuInfoList);
    }
    return response;
  }

  /**
   * @param menuInfoList
   * @return
   */
  private MenuManagementResponse mapMenuResponse(List<MenuInfoDTO> menuInfoList) {

    Comparator<MenuDTO> sequenceComparator = Comparator.comparing(MenuDTO::getMenuSequence);
    MenuManagementResponse response = new MenuManagementResponse();

    Optional<MenuInfoDTO> menuInfo = menuInfoList.stream().findFirst();
    if (menuInfo.isPresent()) {
      response.setMenuGroupId(menuInfo.get().getMenuGroupId());
      response.setMenuGroupName(menuInfo.get().getMenuGroupName());
      response.setMaxVisibleCount(menuInfo.get().getMaxCount());
      response.setMinVisibleCount(menuInfo.get().getMinCount());
    }
    Set<MenuDTO> menus = processMenus(menuInfoList);
    if (menus != null && !menus.isEmpty()) {
      Map<Boolean, List<MenuDTO>> groupedMenus =
          menus.stream()
              .sorted(sequenceComparator)
              .collect(Collectors.groupingBy(MenuDTO::isVisible));
      Set<MenuDTO> finalList = new HashSet<>();
      if (groupedMenus.containsKey(true)) {
        finalList.addAll(groupedMenus.get(true));
      }
      if (groupedMenus.containsKey(false)) {
        finalList.addAll(groupedMenus.get(false));
      }
      response.setMenus(finalList);
    }

    return response;
  }

  /**
   * @param menuInfoList
   * @return
   */
  private Set<MenuDTO> processMenus(List<MenuInfoDTO> menuInfoList) {
    Set<MenuDTO> menus = new HashSet<>();

    for (MenuInfoDTO menuInfo : menuInfoList) {
      MenuDTO menu = new MenuDTO();
      menu.setMenuId(menuInfo.getMenuId());
      menu.setMenuKey(menuInfo.getMenuKey());
      menu.setMandatory(menuInfo.isMandatory());
      menu.setMenuSequence(menuInfo.getMenuSequence());
      menu.setVisible(menuInfo.isVisible());
      menu.setIconUriImage(menuInfo.getIconUriImage());
      menu.setTag(menuInfo.getTag());
      menu.setToolTip(menuInfo.getToolTip());
      menus.add(menu);
    }

    return menus;
  }

  /**
   * @return
   */
  private StringBuilder getInsertQuery() {

    StringBuilder insertQuery = new StringBuilder();
    insertQuery.append(
        "insert into nc_user_menu(user_id,menu_id,sequence,is_visible) select :userId, ");
    insertQuery.append(
        " menu.menu_id,menu.default_sequence,menu.is_active from nc_role_menu_privilege mrp ");
    insertQuery.append("left join  nc_menu menu ");
    insertQuery.append(" on menu.menu_id=mrp.menu_id ");
    insertQuery.append(" where mrp.role_id=:roleId  ");
    return insertQuery;
  }

  /**
   * @return
   */
  private StringBuilder getUserMenuInsertQuery(
      String visibility, String limit, String menuGroupName) {
    StringBuilder insertQuery = new StringBuilder();
    insertQuery.append("insert ignore into nc_user_menu(user_id,menu_id,sequence,is_visible) ");
    insertQuery.append("select :userId, menu.menu_id, menu.default_sequence, " + visibility + " ");
    insertQuery.append("from nc_role_menu_privilege mrp ");
    insertQuery.append("left join nc_menu menu on menu.menu_id = mrp.menu_id ");
    insertQuery.append("left join nc_menu_group_mapping mgm on menu.menu_id = mgm.menu_id ");
    insertQuery.append("left join nc_menugroup mg on mgm.menugroup_id = mg.menugroup_id ");
    insertQuery
        .append("WHERE mrp.role_id = :roleId AND mg.name = '")
        .append(menuGroupName)
        .append("' ");
    insertQuery.append("AND NOT EXISTS ( ");
    insertQuery.append("    SELECT 1 FROM nc_user_menu um ");
    insertQuery.append("    WHERE um.user_id = :userId ");
    insertQuery.append("    AND um.menu_id = menu.menu_id ");
    insertQuery.append("    AND um.sequence = menu.default_sequence ");
    insertQuery.append(") ");
    insertQuery.append(limit).append(";");

    return insertQuery;
  }

  /**
   * @return
   */
  private StringBuilder getUserMenuCount(String menuGroupName) {
    StringBuilder insertQuery = new StringBuilder();
    insertQuery.append("select count(menu.menu_id) from nc_role_menu_privilege mrp ");
    insertQuery.append("left join  nc_menu menu ");
    insertQuery.append(" on menu.menu_id=mrp.menu_id ");
    insertQuery.append(" left join nc_menu_group_mapping mgm on menu.menu_id=mgm.menu_id ");
    insertQuery.append(" left join nc_menugroup mg on mgm.menugroup_id=mg.menugroup_id ");
    insertQuery.append(" where mrp.role_id=:roleId AND mg.name = '" + menuGroupName + "' ");
    return insertQuery;
  }

  /**
   * @return
   */
  private StringBuilder getMaxCount(String menuGroup) {
    StringBuilder insertQuery = new StringBuilder();
    insertQuery.append("select max_count from nc_menugroup where name = '" + menuGroup + "';");
    return insertQuery;
  }

  /**
   * @return
   */
  private StringBuilder getUserMenuInfoQuery() {
    StringBuilder getUserMenuInfo = new StringBuilder();
    getUserMenuInfo.append(
        " SELECT um.menu_id,um.sequence,um.is_visible,menu.menu_key,menu.tool_tip,menu.tag,menu.is_mandatory,menu.icon_relative_uri_image,mg.menugroup_id,grp.max_count,grp.min_count,grp.name ");
    getUserMenuInfo.append(" FROM nc_user_menu um ");
    getUserMenuInfo.append(" INNER JOIN  nc_menu_group_mapping mg ON um.menu_Id = mg.menu_id ");
    getUserMenuInfo.append(" LEFT JOIN  nc_menu menu ON menu.menu_id = mg.menu_id ");
    getUserMenuInfo.append(" LEFT JOIN nc_menugroup grp ON grp.menugroup_id = mg.menugroup_id ");
    getUserMenuInfo.append("  LEFT JOIN nc_role_menu_privilege rmp ON rmp.menu_id = mg.menu_id ");
    getUserMenuInfo.append(
        " WHERE rmp.role_id =:roleId AND  grp.name=:grpname AND um.user_id=:userId ");
    return getUserMenuInfo;
  }

  /**
   * @param userId
   * @return
   */
  private boolean isRecordExist(long userId, String menuGroupName) {
    boolean isRecordExist = false;
    if (userMenuRepository.getCountFromUserMenu(userId, menuGroupName) > 0) {
      isRecordExist = true;
    }

    return isRecordExist;
  }

  @Override
  public List<MenuManagementResponse> updateUserMenu(MenuUpdateRequestDTO request)
      throws CustomException {

    validateSequence(request.getMenuUpdateRequest().getMenus());
    List<MenuManagementResponse> responses = new ArrayList<>();
    List<MapSqlParameterSource> updateParameterList = new ArrayList<>();

    for (MenuUpdate update : request.getMenuUpdateRequest().getMenus()) {
      MapSqlParameterSource updateParam = new MapSqlParameterSource();
      updateParam.addValue("sequence", update.getSequence());
      updateParam.addValue("visible", update.isVisible());
      updateParam.addValue("userId", request.getUserId());
      updateParam.addValue("menuId", update.getMenuId());
      updateParameterList.add(updateParam);
    }
    StringBuilder updateQuery = getUpdateQuery();
    menuJdbc.batchUpdate(updateParameterList, String.valueOf(updateQuery));

    MenuManagementResponse response =
        getUserMenu(
            request.getMenuUpdateRequest().getMenuGroupName(),
            request.getUserId(),
            request.getRoleId());

    if (response != null) {
      responses.add(response);
    }
    return responses;
  }

  /**
   * if more than one menu has same sequence it will return invalid menu sequence error
   *
   * @param menus
   * @throws CustomException
   */
  private void validateSequence(List<MenuUpdate> menus) throws CustomException {

    Set<Integer> sequenceList =
        menus.stream().map(MenuUpdate::getSequence).collect(Collectors.toSet());

    if (menus.size() != sequenceList.size()) {
      throw new CustomException(CustomErrorCodes.INVALID_MENU_SEQUENCE);
    }
  }

  /**
   * @return
   */
  StringBuilder getUpdateQuery() {
    StringBuilder updateQuery = new StringBuilder();
    updateQuery.append(" update nc_user_menu ");
    updateQuery.append(" set sequence=:sequence,is_visible=:visible ");
    updateQuery.append(" where user_id=:userId AND menu_id=:menuId");
    return updateQuery;
  }

  /**
   * @return
   */
  StringBuilder getMenuGroupQuery() {
    StringBuilder menuGroupQuery = new StringBuilder();
    menuGroupQuery.append(" select mg.menugroup_id,mg.name,mg.min_count,mg.max_count ");
    menuGroupQuery.append(" from  nc_role_menu_group rmg  ");
    menuGroupQuery.append(" inner join nc_menugroup mg ");
    menuGroupQuery.append("  on mg.menugroup_id=rmg.menugroup_id ");
    menuGroupQuery.append(" where rmg.role_id=:roleId ");

    return menuGroupQuery;
  }

  // NCIOT-14537
  private StringBuilder getUserMenuInsertQuery(String visibility) {
    StringBuilder insertUserMenuQuery = new StringBuilder();
    insertUserMenuQuery.append(
        "insert into nc_user_menu(user_id,menu_id,sequence,is_visible) select :userId, ");
    insertUserMenuQuery.append(
        ":menuId,(select max(sequence)+1 from nc_user_menu where user_id=:userId), " + visibility);
    return insertUserMenuQuery;
  }

  // NCIOT-15304
  StringBuilder getPresentVisibleMenuCount(long userId, String visibility, String menuGroupName) {
    StringBuilder getQuery = new StringBuilder();
    getQuery.append(" select count(um.menu_id) from nc_user_menu um ");
    getQuery.append(" left join nc_menu_group_mapping mgm on um.menu_id=mgm.menu_id ");
    getQuery.append(" left join nc_menugroup mg on mgm.menugroup_id=mg.menugroup_id ");
    getQuery.append(" where user_id=" + userId);
    getQuery.append(" and is_visible=" + visibility);
    getQuery.append(" and mg.name = '" + menuGroupName + "' ");
    return getQuery;
  }

  /**
   * This method is added to remove SCM button from Horizontal menu for Customers of Distributors
   * https://stljirap.sial.com/browse/V6MILIQ-971
   */
  private List<MenuInfoDTO> hideSCMButtonForCustOfDistributors(List<MenuInfoDTO> menuInfoList) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    if (Constants.CUSTOMER_ROLES_EXCLUDING_CUST_QUALITY.stream()
        .anyMatch(authUser.getRole()::equalsIgnoreCase)) {
      UserProfile user = userRepository.getUserById(Long.parseLong(authUser.getId()));
      if (Constants.DISTRIBUTOR.equalsIgnoreCase(user.getOrg().getParent().getType())) {
        menuInfoList =
            menuInfoList.stream()
                .filter(
                    r -> !r.getMenuKey().equalsIgnoreCase(Constants.SERVICE_CONTRACT_MANAGEMENT))
                .collect(Collectors.toList());
      }
    }
    return menuInfoList;
  }
}
