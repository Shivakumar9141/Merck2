package com.merck.nextconnect.userhub.validator;

import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.springframework.stereotype.Component;

@Component
public interface LegalTermsValidator {
  public void validateForNull(String languageCode, String countryCode, String type)
      throws DataValidationException;
}
