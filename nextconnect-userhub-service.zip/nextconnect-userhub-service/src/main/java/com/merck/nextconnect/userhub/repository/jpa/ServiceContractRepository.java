/**
 * @author SHATHWAR Changes made as per NCIOT-11630.
 */
package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.ServiceContract;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceContractRepository extends JpaRepository<ServiceContract, Long> {

  @Query(
      "select distinct sc.serviceContractId from ServiceContract sc where sc.serviceContractStatus in :status and sc.emailId = :emailId and sc.soldTo = :soldTo and sc.billTo = :billTo")
  List<String> findDistinctServiceContractIdByEmailId(
      @Param("status") List<String> status,
      @Param("emailId") String email,
      @Param("soldTo") String soldTo,
      @Param("billTo") String billTo);

  List<ServiceContract> findBySmServiceContractIdInAndEmailId(
      List<String> smServiceContractId, String emailId);

  @Query(
      "select distinct sc.smServiceContractId from ServiceContract sc where sc.emailId = :emailId and sc.soldTo = :soldTo and sc.billTo = :billTo")
  List<String> findDistinctSmServiceContractIdByEmailId(
      @Param("emailId") String email,
      @Param("soldTo") String soldTo,
      @Param("billTo") String billTo);

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param deviceId
   * @return ServiceContract
   */
  @Query(
      value =
          "select * from nc_sm_service_contract where service_contract_id in :serviceContractIds and service_contract_status='Expired' order by service_contract_end_date desc limit 1",
      nativeQuery = true)
  ServiceContract findLatestExpiredContract(
      @Param("serviceContractIds") Set<Long> serviceContractIds);

  /**
   * @param status
   * @param serviceContractIds
   * @return ServiceContract
   */
  @Query(
      value =
          "select * from nc_sm_service_contract where service_contract_status in :status and service_contract_id in :serviceContractIds and (DATE(service_contract_start_date) <= DATE(now())) and (DATE(service_contract_end_date) >= DATE(now())) limit 1",
      nativeQuery = true)
  ServiceContract getByServiceContractStatusInAndServiceContractIdIn(
      @Param("status") List<String> status,
      @Param("serviceContractIds") Set<Long> serviceContractIds);
}
