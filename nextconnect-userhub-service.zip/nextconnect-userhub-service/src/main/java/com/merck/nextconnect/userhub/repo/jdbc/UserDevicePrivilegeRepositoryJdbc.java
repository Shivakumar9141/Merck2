package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author tah
 *     <p>This class is for JDBC Template implementation to use native sql
 */
@Repository
public class UserDevicePrivilegeRepositoryJdbc {

  static final Logger LOGGER = LoggerFactory.getLogger(UserDevicePrivilegeRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  String SQL_SELECT_ALL_USER_IDS_BY_DEVICE_ID =
      "select user_id from nc_users_device_privileges where device_id = :deviceId";

  public List<Long> getAllUserIdForDeviceId(Long deviceId) throws CustomException {
    LOGGER.debug("deviceId : {} ", deviceId);
    List<Long> userIdList = new ArrayList<Long>();
    if (deviceId == null) {
      return userIdList;
    }
    try {
      MapSqlParameterSource parameters = new MapSqlParameterSource();
      parameters.addValue("deviceId", deviceId);
      userIdList =
          namedParameterJdbcTemplate.queryForList(
              SQL_SELECT_ALL_USER_IDS_BY_DEVICE_ID, parameters, Long.class);
    } catch (Exception e) {
      LOGGER.error("Exception occured in getAllUserIdForDeviceId while calling DB", e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
    return userIdList;
  }
}
