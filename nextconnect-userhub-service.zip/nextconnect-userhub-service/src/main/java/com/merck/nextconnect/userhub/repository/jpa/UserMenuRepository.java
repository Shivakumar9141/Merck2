package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserMenu;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * @author clukose
 */
@Repository
public interface UserMenuRepository extends JpaRepository<UserMenu, Long> {

  @Query(
      value = "select count(*)>0 from nc_user_menu as menu where menu.user_id=:userId",
      nativeQuery = true)
  boolean existsByUserProfileId(@Param("userId") long userId);

  @Query(
      "select um from  UserMenu um  where  um.userProfile.userId=:userId  and um.menu.menu_id in (:menuIds)")
  List<UserMenu> getUserMenuByUserIdAndMenuId(
      @Param("userId") long userId, @Param("menuIds") List<Integer> menuIds);

  @Query(
      value =
          "select count(*) from nc_user_menu um inner join nc_menu_group_mapping mgm on um.menu_id=mgm.menu_id "
              + " inner join nc_menugroup mg on mgm.menugroup_id=mg.menugroup_id "
              + " where um.user_id=:userId and mg.name=:menuGroupName",
      nativeQuery = true)
  long getCountFromUserMenu(
      @Param("userId") long userId, @Param("menuGroupName") String menuGroupName);

  // NCIOT-14537
  @Query(
      value =
          "Select rmg.menu_id from nc_role_menu_privilege rmg left join nc_menu_group_mapping mgm "
              + " on rmg.menu_id=mgm.menu_id left join nc_menugroup mg on mgm.menugroup_id=mg.menugroup_id "
              + " where rmg.role_id=:roleId and mg.name=:menuGroupName and rmg.menu_id not in "
              + " (Select um.menu_id from nc_user_menu um where um.user_id=:userId)",
      nativeQuery = true)
  List<Integer> getDifferMenuId(
      @Param("roleId") long roleId,
      @Param("userId") long userId,
      @Param("menuGroupName") String menuGroupName);
}
