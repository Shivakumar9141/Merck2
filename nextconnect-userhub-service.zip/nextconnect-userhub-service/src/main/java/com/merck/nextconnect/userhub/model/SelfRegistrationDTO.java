package com.merck.nextconnect.userhub.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

/**
 * @author SHATHWAR Made changes as per NCIOT-12313.
 */
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SelfRegistrationDTO implements Serializable {
  private String firstName;
  private String lastName;
  private String email;
  private String countryCode;
  private String isdCode;
  private String phone;
  private String serialNo;
  private String roleOfInterest;
  // captcha NCIOT-16342
  @NonNull private String captchaResponse;
  private int orgId;
}
