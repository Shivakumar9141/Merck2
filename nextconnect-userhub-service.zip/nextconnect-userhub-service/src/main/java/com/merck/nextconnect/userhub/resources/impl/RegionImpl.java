package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.model.CountryDTO;
import com.merck.nextconnect.userhub.resources.IRegion;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.Region;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.RegionRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RegionImpl implements IRegion {

  @Autowired private RegionRepository regionRepository;

  @Autowired private CountryRepository countryRepository;

  @Override
  public List<Region> getRegions(String searchBy) {
    return regionRepository.findByRegionNameContainingIgnoreCaseOrderByRegionNameAsc(searchBy);
  }

  @Override
  public List<CountryDTO> getCountryByRegionId(List<Integer> regionId) {
    List<Country> countryList =
        countryRepository.findByRegion_regionIdInOrderByCountryNameAsc(regionId);
    List<CountryDTO> countryDTOList = new ArrayList<CountryDTO>();
    for (Country country : countryList) {
      CountryDTO countryDTO;
      countryDTO =
          new CountryDTO()
              .builder()
              .countryCode(country.getCountryCode())
              .countryId(country.getId())
              .countryName(country.getCountryName())
              .region(country.getRegion())
              .build();
      countryDTOList.add(countryDTO);
    }
    return countryDTOList;
  }
}
