package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.FetchCriteria;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

@Component
public class UserDefaulterFeedBackSpecification {

  @Autowired UserOrgPrivileges userOrgPrivileges;

  @Autowired UserFeedBackRepository userFeedBackRepository;

  public Specification<UserProfile> specification(final FetchCriteria fetchCriteria) {
    return new Specification<UserProfile>() {
      @Override
      public Predicate toPredicate(
          Root<UserProfile> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
        List<Predicate> predicates = new ArrayList<>();
        // search By
        if (fetchCriteria.getSearchBy() != null) {
          String search = "%" + fetchCriteria.getSearchBy() + "%";
          predicates.add(cb.like(root.get("org").get("name"), search));
        }
        // filter
        Optional.ofNullable(fetchCriteria.getFilterBy())
            .ifPresent(
                f -> {
                  Map<String, List<String>> filterMap =
                      getFilterValues(fetchCriteria.getFilterBy());
                  Optional.ofNullable(filterMap.get(Constants.ROLE))
                      .filter(fmap -> !filterMap.get(Constants.ROLE).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.ROLE).get("name"))
                                    .value(filterMap.get(Constants.ROLE)));
                          });
                  Optional.ofNullable(filterMap.get(Constants.ORG_NAME))
                      .filter(fmap -> !filterMap.get(Constants.ORG_NAME).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.ORG).get("name"))
                                    .value(filterMap.get(Constants.ORG_NAME)));
                          });
                  Optional.ofNullable(filterMap.get(Constants.ORG_ID))
                      .filter(fmap -> !filterMap.get(Constants.ORG_ID).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.ORG).get("id"))
                                    .value(
                                        filterMap.get(Constants.ORG_ID).stream()
                                            .map(Integer::parseInt)
                                            .collect(Collectors.toList())));
                          });
                  Optional.ofNullable(filterMap.get(Constants.COUNTRY_CODE))
                      .filter(fmap -> !filterMap.get(Constants.COUNTRY_CODE).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get(Constants.COUNTRY).get(Constants.COUNTRY_CODE))
                                    .value(filterMap.get(Constants.COUNTRY_CODE)));
                          });
                });
        // omitting soft delete
        predicates.add(cb.equal(root.get("deleted"), false));
        // ignoring users with system defined roles for users with user
        // defined roles
        AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();

        List<Integer> accessibleOrgs = new ArrayList<>();
        accessibleOrgs.addAll(
            userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
                .filter(o -> o.getOrgId() != authUser.getOrgId())
                .map(o -> o.getOrgId())
                .collect(Collectors.toList()));

        // NCIOT-11742
        if (Constants.DISTRIBUTOR_FSE.equalsIgnoreCase(authUser.getRole())) {
          List<Integer> orgs =
              userFeedBackRepository.getDistributorFSEOrgs(
                  Long.valueOf(authUser.getId()),
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
                  authUser.getOrgId());
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
        }

        Optional.ofNullable(accessibleOrgs)
            .filter(a -> a.isEmpty())
            .ifPresent(
                a -> {
                  predicates.add(
                      cb.or(
                          cb.equal(root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED), false),
                          cb.equal(root.get(Constants.ROLE).get("roleId"), authUser.getRoleId())));
                  predicates.add(cb.equal(root.get("org").get("id"), authUser.getOrgId()));
                });

        Optional.ofNullable(accessibleOrgs)
            .filter(a -> !a.isEmpty())
            .ifPresent(
                a -> {
                  predicates.add(
                      cb.or(
                          (cb.and(
                              (cb.or(
                                  cb.equal(
                                      root.get(Constants.ROLE).get(Constants.SYSTEM_DEFINED),
                                      false),
                                  cb.equal(
                                      root.get(Constants.ROLE).get("roleId"),
                                      authUser.getRoleId()))),
                              cb.equal(root.get("org").get("id"), authUser.getOrgId()))),
                          cb.in(root.get("org").get("id")).value(accessibleOrgs)));
                });
        predicates.add(root.get(Constants.ROLE).get(Constants.NAME).in(Constants.CUSTOMER_ROLES));
        return cb.and(predicates.toArray(new Predicate[0]));
      }

      private Map<String, List<String>> getFilterValues(List<String> filterBy) {
        Map<String, List<String>> filterMap = new HashMap<>();
        List<String> roleFilters = new ArrayList<>();
        List<String> orgNameFilters = new ArrayList<>();
        List<String> orgIdFilters = new ArrayList<>();
        List<String> countryCodeFilters = new ArrayList<>();
        filterBy.stream()
            .forEach(
                afilterBy -> {
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ROLE_FILTER_PREFIXS))
                      .ifPresent(
                          r -> {
                            roleFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ORG_NAME_FILTER_PREFIXS))
                      .ifPresent(
                          r -> {
                            orgNameFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.COUNTRY_CODE_FILTER_PREFIXS))
                      .ifPresent(
                          r -> {
                            countryCodeFilters.add(afilterBy.split("\\.")[1]);
                          });
                });

        if (fetchCriteria.getFilterBy().contains(Constants.NOFEEDBACK)) {
          if (roleFilters.equals(null) && roleFilters.isEmpty()) {
            // Add partner, customer related roles
            roleFilters.add(Constants.CUSTOMER_ADMIN);
            roleFilters.add(Constants.QUALITY_MANAGER);
            roleFilters.add(Constants.TECHNICAL_USER);
            roleFilters.add(Constants.PARTNER_ADMIN);
            roleFilters.add(Constants.PARTNER_HOTLINE);
            roleFilters.add(Constants.CUSTOMER_MANAGER);
          }
        }

        filterMap.put(Constants.ROLE, roleFilters);
        filterMap.put(Constants.ORG_NAME, orgNameFilters);
        filterMap.put(Constants.ORG_ID, orgIdFilters);
        filterMap.put(Constants.COUNTRY_CODE, countryCodeFilters);
        return filterMap;
      }
    };
  }
}
