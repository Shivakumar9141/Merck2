package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.UserFeedBackEntity;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.repo.jdbc.UserFeedBackRepositoryJdbc;
import com.merck.nextconnect.userhub.resources.impl.UserOrgPrivileges;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.model.FetchCriteria;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserFeedBackSpecification {

  @Autowired UserOrgPrivileges userOrgPrivileges;
  @Autowired UserFeedBackRepository userFeedBackRepository;

  @Autowired private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;

  @Autowired private UserRepository userRepository;

  public Specification<UserFeedBackEntity> specification(final FetchCriteria fetchCriteria) {
    return new Specification<UserFeedBackEntity>() {
      @Override
      public Predicate toPredicate(
          Root<UserFeedBackEntity> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
        List<Predicate> predicates = new ArrayList<>();

        // search By
        if (fetchCriteria.getSearchBy() != null) {
          String search = "%" + fetchCriteria.getSearchBy() + "%";
          predicates.add(cb.like(root.get("user").get("org").get("name"), search));
        }
        predicates.add(cb.equal(root.get("user").get("deleted"), false));
        predicates.add(cb.equal(root.get("user").get("status"), "Active"));
        // filter
        Optional.ofNullable(fetchCriteria.getFilterBy())
            .ifPresent(
                f -> {
                  Map<String, List<Object>> filterMap =
                      getFilterValues(fetchCriteria.getFilterBy());
                  Optional.ofNullable(filterMap.get(Constants.RATING))
                      .filter(fmap -> !filterMap.get(Constants.RATING).isEmpty())
                      .ifPresent(
                          s -> {
                            predicates.add(
                                cb.in(root.get(Constants.RATING))
                                    .value(filterMap.get(Constants.RATING)));
                          });

                  Optional.ofNullable(filterMap.get(Constants.ROLES))
                      .filter(fmap -> !filterMap.get(Constants.ROLES).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get("user").get("role").get("name"))
                                    .value(filterMap.get(Constants.ROLES)));
                          });

                  Optional.ofNullable(filterMap.get(Constants.ORG_NAMES))
                      .filter(fmap -> !filterMap.get(Constants.ORG_NAMES).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(root.get("user").get("org").get("name"))
                                    .value(filterMap.get(Constants.ORG_NAMES)));
                          });

                  Optional.ofNullable(filterMap.get(Constants.COUNTRY_CODES))
                      .filter(fmap -> !filterMap.get(Constants.COUNTRY_CODES).isEmpty())
                      .ifPresent(
                          r -> {
                            predicates.add(
                                cb.in(
                                        root.get("user")
                                            .get(Constants.COUNTRYS)
                                            .get(Constants.COUNTRY_CODES))
                                    .value(filterMap.get(Constants.COUNTRY_CODES)));
                          });

                  if (filterMap.get(Constants.FEEDBACK_RANGE).size() != 0) {
                    Calendar c = Calendar.getInstance();
                    Date currentDate = c.getTime();
                    Date startDate = new Date();
                    if (filterMap
                        .get(Constants.FEEDBACK_RANGE)
                        .get(0)
                        .equals(Constants.LESS_THAN_SIX_MONTHS)) {
                      Calendar c6 = Calendar.getInstance();
                      c6.add(Calendar.MONTH, -6);
                      startDate = c6.getTime();
                      predicates.add(cb.between(root.get("createdDate"), startDate, currentDate));
                    } else if (filterMap
                        .get(Constants.FEEDBACK_RANGE)
                        .get(0)
                        .equals(Constants.GREATER_THAN_SIX_MONTHS)) {
                      Calendar c12 = Calendar.getInstance();
                      c12.add(Calendar.MONTH, -6);
                      startDate = c12.getTime();
                      predicates.add(cb.lessThan(root.get("createdDate"), startDate));
                    }
                  }
                });

        AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();

        List<Integer> accessibleOrgs = new ArrayList<>();
        accessibleOrgs.addAll(
            userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
                .filter(o -> o.getOrgId() != authUser.getOrgId())
                .map(o -> o.getOrgId())
                .collect(Collectors.toList()));
        // NCIOT-11742
        if (Constants.DISTRIBUTOR_FSE.equalsIgnoreCase(authUser.getRole())) {
          List<Integer> orgs =
              userFeedBackRepository.getDistributorFSEOrgs(
                  Long.valueOf(authUser.getId()),
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
                  authUser.getOrgId());
          log.debug("Distributor FSE orgs {}", StringUtils.join(orgs, "|"));
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
          predicates.add(
              cb.in(root.get("user").get("role").get("name"))
                  .value(Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(","))));
        }
        if (Constants.DISTRIBUTOR_ADMIN.equalsIgnoreCase(authUser.getRole())) {
          List<Integer> orgs =
              userFeedBackRepository.getDistributorAdminOrgs(
                  Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
                  authUser.getOrgId());
          log.debug("Distributor Admin orgs {}", StringUtils.join(orgs, "|"));
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
          predicates.add(
              cb.in(root.get("user").get("role").get("name"))
                  .value(Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(","))));
        }
        if (Constants.FSE_USER.equalsIgnoreCase(authUser.getRole())) {
          List<Integer> orgs = userFeedBackRepository.getFSEOrgs(Long.valueOf(authUser.getId()));
          log.debug("FSE user orgs {}", StringUtils.join(orgs, "|"));
          if (orgs != null && !orgs.isEmpty()) {
            accessibleOrgs.addAll(orgs);
          }
        }
        UserProfile userProfile = userRepository.getUserById(Long.valueOf(authUser.getId()));
        //				if (Constants.LW_MCS.equalsIgnoreCase(authUser.getRole())) {
        //					List<Integer> orgs =
        // userFeedBackRepository.getFSSOrMCSOrgs(Long.valueOf(authUser.getId()));
        //					if(orgs.isEmpty()) {
        //
        //	orgs=userFeedBackRepository.getFSSORMCSOrgsByCountryId(Long.valueOf(authUser.getId()),
        //							userProfile.getCountry().getId());
        //					}
        //					log.debug("MCS user orgs {}",StringUtils.join(orgs, "|"));
        //					if (orgs != null && !orgs.isEmpty()) {
        //						accessibleOrgs.addAll(orgs);
        //					}
        //				}

        Optional.ofNullable(accessibleOrgs)
            .filter(a -> a.isEmpty())
            .ifPresent(
                a -> {
                  predicates.add(
                      cb.or(
                          cb.equal(
                              root.get("user").get("role").get(Constants.SYSTEM_DEFINED), false),
                          cb.equal(
                              root.get("user").get("role").get("roleId"), authUser.getRoleId())));
                  predicates.add(
                      cb.equal(root.get("user").get("org").get("id"), authUser.getOrgId()));
                });

        Optional.ofNullable(accessibleOrgs)
            .filter(a -> !a.isEmpty())
            .ifPresent(
                a -> {
                  predicates.add(
                      cb.or(
                          (cb.and(
                              (cb.or(
                                  cb.equal(
                                      root.get("user").get("role").get(Constants.SYSTEM_DEFINED),
                                      false),
                                  cb.equal(
                                      root.get("user").get("role").get("roleId"),
                                      authUser.getRoleId()))),
                              cb.equal(
                                  root.get("user").get("org").get("id"), authUser.getOrgId()))),
                          cb.in(root.get("user").get("org").get("id")).value(accessibleOrgs)));
                });

        if (authUser.getRole().equals(Constants.LW_FSE)
            || authUser.getRole().equals(Constants.DISTRIBUTOR_FSE)) {
          List<String> countryCodes =
              userFeedBackRepositoryJdbc.getUserTerritories(authUser.getId());
          if (countryCodes.isEmpty()) {
            countryCodes.add(userProfile.getCountry().getCountryCode());
          }
          log.debug("Country codes {}", StringUtils.join(countryCodes, "|"));
          predicates.add(root.get("user").get("country").get("countryCode").in(countryCodes));
        }

        return cb.and(predicates.toArray(new Predicate[0]));
      }

      private Map<String, List<Object>> getFilterValues(List<String> filterBy) {
        Map<String, List<Object>> filterMap = new HashMap<>();
        List<Object> roleFilters = new ArrayList<>();
        List<Object> ratingFilters = new ArrayList<>();
        List<Object> orgNameFilters = new ArrayList<>();
        List<Object> countryCodeFilters = new ArrayList<>();
        List<Object> feedbackRangeFilters = new ArrayList<>();

        filterBy.stream()
            .forEach(
                afilterBy -> {
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.RATING_FILTER_PREFIXS))
                      .ifPresent(
                          s -> {
                            ratingFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ROLE_FILTER_PREFIXS))
                      .ifPresent(
                          r -> {
                            roleFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.ORG_NAME_FILTER_PREFIXS))
                      .ifPresent(
                          r -> {
                            orgNameFilters.add(afilterBy.split("\\.")[1]);
                          });

                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.COUNTRY_CODE_FILTER_PREFIXS))
                      .ifPresent(
                          r -> {
                            countryCodeFilters.add(afilterBy.split("\\.")[1]);
                          });
                  Optional.ofNullable(afilterBy)
                      .filter(a -> afilterBy.contains(Constants.FEEDBACK_RANGE_PREFIXS))
                      .ifPresent(
                          r -> {
                            feedbackRangeFilters.add(afilterBy.split("\\.")[1]);
                          });
                });

        if (ratingFilters.contains(Constants.ONE)) {
          ratingFilters.remove(Constants.ONE);
          ratingFilters.add(1);
        }
        if (ratingFilters.contains(Constants.TWO)) {
          ratingFilters.remove(Constants.TWO);
          ratingFilters.add(2);
        }
        if (ratingFilters.contains(Constants.THREE)) {
          ratingFilters.remove(Constants.THREE);
          ratingFilters.add(3);
        }
        if (ratingFilters.contains(Constants.FOUR)) {
          ratingFilters.remove(Constants.FOUR);
          ratingFilters.add(4);
        }
        if (ratingFilters.contains(Constants.FIVE)) {
          ratingFilters.remove(Constants.FIVE);
          ratingFilters.add(5);
        }

        filterMap.put(Constants.RATING, ratingFilters);
        filterMap.put(Constants.ROLES, roleFilters);
        filterMap.put(Constants.ORG_NAMES, orgNameFilters);
        filterMap.put(Constants.COUNTRY_CODES, countryCodeFilters);
        filterMap.put(Constants.FEEDBACK_RANGE, feedbackRangeFilters);

        return filterMap;
      }
    };
  }
}
