package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "var_info")
public class VarInfo {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private String varShortName;

  private String varDispName;

  private String varType;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getVarShortName() {
    return varShortName;
  }

  public void setVarShortName(String varShortName) {
    this.varShortName = varShortName;
  }

  public String getVarDispName() {
    return varDispName;
  }

  public void setVarDispName(String varDispName) {
    this.varDispName = varDispName;
  }

  public String getVarType() {
    return varType;
  }

  public void setVarType(String varType) {
    this.varType = varType;
  }
}
