package com.merck.nextconnect.userhub.converter;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.UserCountryDTO;
import com.merck.nextconnect.userhub.response.OrganizationResponseEntity;
import com.merck.nextconnect.userhub.response.RoleResponseEntity;
import com.merck.nextconnect.userhub.response.UserDomainResponseEntity;
import com.merck.nextconnect.userhub.response.UserListResponseEntity;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import java.util.Objects;

public class UserListConverter {
  public static UserListResponseEntity toResponseEntity(UserProfile userProfile) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    if (Objects.isNull(userProfile)) return null;

    UserListResponseEntity user =
        UserListResponseEntity.builder()
            .userId(userProfile.getUserId())
            .loginName(userProfile.getLoginName())
            .firstName(userProfile.getFirstName())
            .lastName(userProfile.getLastName())
            .email(userProfile.getEmail())
            .isdCode(userProfile.getIsdCode())
            .phone(userProfile.getPhone())
            .status(userProfile.getStatus())
            .consentStatus(userProfile.isConsentStatus())
            .privacyPolicyStatus(userProfile.isPrivacyPolicyStatus())
            .timeZoneId(userProfile.getTimeZoneId())
            .country(toDTO(userProfile.getCountry()))
            .role(toResponseEntity(userProfile.getRole()))
            .userDomain(toResponseEntity(userProfile.getUserDomain()))
            .dateFormat(userProfile.getDateFormat())
            .language(userProfile.getLanguage())
            .org(toResponseEntity(userProfile.getOrg()))
            .userProfileSettings(userProfile.getUserProfileSettings())
            .coveredTerritory(userProfile.getCoveredTerritory())
            .isCoveredTerritory(userProfile.isCoveredTerritory())
            .platformSubscription(userProfile.isPlatformSubscription())
            .businessDomain(userProfile.getBusinessDomain())
            .userImage(userProfile.getUserImage())
            .isDomainVisible(userProfile.getIsDomainVisible())
            .isAutoCreated(userProfile.isAutoCreated())
            .createdBy(userProfile.getCreatedBy())
            .createdOn(userProfile.getCreatedOn())
            .createdRole(userProfile.getCreatedRole())
            .invitedOrActivatedTs(userProfile.getInvitedOrActivatedTs())
            .invitedVia(userProfile.getInvitedVia())
            .visible(userProfile.getVisible())
            .isValidated(userProfile.isValidated())
            .build();

    if (Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_BM.contains(user.getRole().getName())) {
      user.setDeleteUser(false);
    } else if (Constants.LW_SERVICE_ADMIN.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_SM.contains(user.getRole().getName())) {
      user.setDeleteUser(false);
    } else if (Constants.LW_MCS.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_MCS.contains(user.getRole().getName())) {
      user.setDeleteUser(false);
    } else if (Constants.LW_SERVICE_COORDINATOR.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_DELETED_BY_ICS.contains(user.getRole().getName())) {
      user.setDeleteUser(false);
    } else {
      user.setDeleteUser(true);
    }

    if (Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_BM.contains(user.getRole().getName())) {
      user.setUpdateUser(false);
    } else if (Constants.LW_SERVICE_ADMIN.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_SM.contains(user.getRole().getName())) {
      user.setUpdateUser(false);
    } else if (Constants.LW_MCS.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_MCS.contains(user.getRole().getName())) {
      user.setUpdateUser(false);
    } else if (Constants.LW_SERVICE_COORDINATOR.equalsIgnoreCase(authUser.getRole())
        && Constants.ROLES_CANT_BE_UPDATED_BY_ICS.contains(user.getRole().getName())) {
      user.setUpdateUser(false);
    } else {
      user.setUpdateUser(true);
    }
    return user;
  }

  public static UserCountryDTO toDTO(Country country) {

    if (Objects.isNull(country)) return null;

    return UserCountryDTO.builder()
        .id(country.getId())
        .countryCode(country.getCountryCode())
        .countryName(country.getCountryName())
        .region(country.getRegion())
        .build();
  }

  public static RoleResponseEntity toResponseEntity(Role role) {

    if (Objects.isNull(role)) return null;

    return RoleResponseEntity.builder().roleId(role.getRoleId()).name(role.getName()).build();
  }

  public static UserDomainResponseEntity toResponseEntity(UserDomain userDomain) {

    if (Objects.isNull(userDomain)) return null;

    return UserDomainResponseEntity.builder()
        .domainId(userDomain.getDomainId())
        .domainName(userDomain.getDomainName())
        .build();
  }

  public static OrganizationResponseEntity toResponseEntity(Organization org) {

    if (Objects.isNull(org)) return null;

    return OrganizationResponseEntity.builder()
        .id(org.getId())
        .name(org.getName())
        .status(org.getStatus())
        .type(org.getType())
        .build();
  }
}
