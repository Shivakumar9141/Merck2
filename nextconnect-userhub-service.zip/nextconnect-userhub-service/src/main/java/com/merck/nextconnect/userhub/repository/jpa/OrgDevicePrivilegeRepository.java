package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.OrgDevicePrivilege;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Made changes as per NCIOT-16812
 *
 * @author SHATHWAR
 */
@Repository
public interface OrgDevicePrivilegeRepository extends JpaRepository<OrgDevicePrivilege, Integer> {

  @Modifying
  @Transactional
  @Query("delete from OrgDevicePrivilege odp where odp.org.id = :orgId")
  void deleteByOrgId(@Param("orgId") int orgId);
}
