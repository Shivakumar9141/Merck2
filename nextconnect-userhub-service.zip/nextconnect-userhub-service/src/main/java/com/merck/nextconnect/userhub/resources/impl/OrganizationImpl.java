package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.entities.AuthOrg;
import com.merck.nextconnect.authfilter.entities.AuthOrgBrandPartnerType;
import com.merck.nextconnect.authfilter.entities.AuthOrgPartnerPeripheralSupplier;
import com.merck.nextconnect.authfilter.entities.AuthPartnerPeripheralSupplier;
import com.merck.nextconnect.authfilter.entities.PartnerBrandPartnerType;
import com.merck.nextconnect.authfilter.entities.PartnerTypeEntity;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgInfo;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.AuthDeviceFamilyPeripheralSupplierRepository;
import com.merck.nextconnect.authfilter.repository.jpa.AuthOrgBrandPartnerTypeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.AuthOrgPartnerPeripheralSupplierRepository;
import com.merck.nextconnect.authfilter.repository.jpa.AuthPartnerPeripheralSupplierRepository;
import com.merck.nextconnect.authfilter.repository.jpa.OrgDeviceFamilyRepository;
import com.merck.nextconnect.authfilter.repository.jpa.OrgRepository;
import com.merck.nextconnect.authfilter.repository.jpa.PartnerBrandPartnerTypeRepository;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.resources.org.CustomOrgProperties;
import com.merck.nextconnect.userhub.constants.UserhubConstants;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.OrganizationType;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.OrgFilter;
import com.merck.nextconnect.userhub.model.OrgPartnerBrandPartnerTypeDTO;
import com.merck.nextconnect.userhub.model.org.OrgDto;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.repository.jpa.OrgDomainRepositiory;
import com.merck.nextconnect.userhub.repository.jpa.OrgSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationTypeRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDevicePrivilegeRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IOrganization;
import com.merck.nextconnect.userhub.resources.IUser;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.userhub.validator.UserhubValidator;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.model.FetchCriteria;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class OrganizationImpl implements IOrganization {

  @Autowired UserOrgPrivileges userOrgPrivileges;

  @Autowired IOrgPermissions orgPermissions;

  @Autowired OrgDomainRepositiory orgDomainRepo;

  @Autowired OrganizationRepository orgRepo;

  @Autowired OrgRepository orgRepository;

  @Autowired private UserhubValidator userhubValidator;

  @Autowired UserRepository userRepo;

  @Autowired private OrgSettingsRepository orgSettingsRepository;

  @Autowired OrgDeviceFamilyRepository orgDeviceFamilyRepo;

  @Autowired AuthDeviceFamilyPeripheralSupplierRepository deviceFamilyPeripheralSupplierRepo;

  @Autowired AuthOrgPartnerPeripheralSupplierRepository orgBrandRepo;

  @Autowired AuthOrgBrandPartnerTypeRepository orgBrandPartnerTypeRepo;

  @Autowired PartnerBrandPartnerTypeRepository partnerBrandPartnerTypeRepository;

  @Autowired AuthOrgBrandPartnerTypeRepository orgBrandPartnerTypeRepository;

  @Autowired AuthPartnerPeripheralSupplierRepository brandRepository;

  @Autowired private OrganizationTypeRepository orgTypeRepository;

  @Autowired private EmailService emailService;
  ;

  @Autowired private IUser iUser;

  @Autowired private UserDevicePrivilegeRepository userDevicePrivilegeRepository;

  @Autowired private ApplicationConfigRepository applicationConfigRepository;

  private String orgNamePattern = "^(?=.{2,50}$).*";

  private String orgDescPattern = "^(?=.{0,100}$).*";

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${nextconnect.email.environment}")
  private String environment;

  static final Logger logger = LoggerFactory.getLogger(OrganizationImpl.class);

  @Override
  public List<OrgDto> getAll(String operation, String searchBy, String type, String reference) {
    List<OrgDto> filteredOrgs = null;
    searchBy = UserhubUtils.escapeUnderscoreSpecialChar(searchBy);
    List<OrgDto> orgs =
        Optional.ofNullable(operation).isPresent()
            ? userOrgPrivileges.getOrgs(OrgPrivileges.valueOf(operation), searchBy, type)
            : getOrgs(searchBy, type);
    // NCIOT-13374
    if (reference != null && reference.equalsIgnoreCase(Constants.ORG_LIST_IN_ADD_USER)) {
      filteredOrgs =
          orgs.stream().filter(o -> (o.getStatus() && !o.isDeleted())).collect(Collectors.toList());
    } else {
      filteredOrgs = orgs;
    }
    return userOrgPrivileges.addCustomProperties(filteredOrgs);
  }

  private List<OrgDto> getOrgs(String searchBy, String type) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    List<OrgDto> orgs =
        orgRepo.findChildOrgs(
            authUser.getOrgId(),
            Optional.ofNullable(searchBy).isPresent() ? searchBy : Constants.EMPTY_STRING,
            type);
    return orgs;
  }

  @Override
  public Organization getOrgByName(String orgName) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return orgRepo.getOrgByName(orgName, authUser.getOrgId());
  }

  @Override
  public List<UserDomain> getDomains(Integer orgId) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Optional.ofNullable(authUser)
        .filter(a -> orgPermissions.hasRoleAccess(orgId, OrgPrivileges.manage_accounts))
        .orElseThrow(() -> new AccessDeniedException("User doesnt have access to the given org"));
    String applicationConifgValue =
        applicationConfigRepository.findValueByCategoryAndKey(
            UserhubConstants.USER_DOMAIN, UserhubConstants.DOMAIN_VISIBILITY);
    String type = orgRepo.getOrgTypeById(orgId);
    List<UserDomain> userDomains = orgDomainRepo.getDomains(orgId);
    if (Constants.YES.equalsIgnoreCase(applicationConifgValue)) {
      return userDomains;
    }
    if (Constants.BUSINESS_UNIT.equalsIgnoreCase(type)) {
      return userDomains.stream()
          .filter(o -> !o.getDomainName().equalsIgnoreCase("nextconnect"))
          .collect(Collectors.toList());
    } else {
      return userDomains;
    }
  }

  @Override
  public int create(OrgInfo orgInfo)
      throws DuplicateResourceException,
          DataValidationException,
          com.merck.nextconnect.utils.file.handler.exception.DataValidationException {
    validateOrgDetails(orgInfo);
    userhubValidator.validateOrgStatus(orgInfo.getStatus());
    return userOrgPrivileges.createOrg(orgInfo);
  }

  @Override
  @Transactional
  public void update(OrgInfo orgInfo, int orgId)
      throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          CustomException {

    userhubValidator.validateOrgStatus(orgInfo.getStatus());

    validateOrgDetails(orgInfo);
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    AuthOrg org = orgRepository.getOrg(orgId);
    Boolean currentOrgStatus = org.getStatus();
    Optional.ofNullable(org)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ORG_NOT_FOUND));
    Optional.ofNullable(org)
        .filter(o -> o.getParent().getId() == authUser.getOrgId())
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.ACCESS_DENIED_TO_UPDATE_ORG));
    Optional.ofNullable(orgInfo.getName())
        .filter(o -> !o.trim().isEmpty())
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.EMPTY_ORG_NAME));
    Optional.ofNullable(orgInfo.getName())
        .filter(o -> !orgRepo.hasOrgByName(o.trim(), org.getParent().getId(), org.getId()))
        .orElseThrow(
            () ->
                new DuplicateResourceException(
                    CustomErrorCodes.DUPLICATE_ORG, Arrays.asList(orgInfo.getName())));

    org.setName(orgInfo.getName().trim());
    org.setDescription(orgInfo.getDesc());
    org.setLastUpdatedBy(authUser.getUsername());
    org.setStatus(orgInfo.getStatus());
    org.setLastUpdatedDate(new Date());
    // Change for - NCIOT-11195,NCIOT-11196,NCIOT-11197
    if (orgInfo.getHistoricalDataSubscription() != null) {
      updateOrgSetting(org.getId(), orgInfo.getHistoricalDataSubscription());
    }
    orgRepository.save(org);
    if (currentOrgStatus && !(orgInfo.getStatus())) {
      updateOrgStatusAndSendEmail(orgId);
    }

    if (orgInfo.getType().equalsIgnoreCase(Constants.PARTNER)) {
      Map<String, Object> customProperties = orgInfo.getCustomProperties();
      List<Integer> partnerTypeIds = orgInfo.getPartnerTypeIds();
      if (!Optional.ofNullable(partnerTypeIds).isPresent() && partnerTypeIds.isEmpty()) {
        throw new DataValidationException(CustomErrorCodes.PARTNER_TYPE_CANNOT_BE_EMPTY);
      }
      int partnerSupplier =
          (int)
              customProperties.getOrDefault(
                  CustomOrgProperties.PARTNER_PERIPHERAL_SUPPPLIER.getValue(), 0);
      if (orgId != 0 && partnerSupplier != 0) {
        // get the brand associated with the org
        AuthOrgPartnerPeripheralSupplier orgPartnerPeripheralSupplier =
            orgBrandRepo.getOrgBrandByOrgId(orgId);
        Optional.ofNullable(orgPartnerPeripheralSupplier)
            .orElseThrow(() -> new DataValidationException(CustomErrorCodes.ORG_BRAND_NOT_EXIST));
        // delete the brand and partner type associated with the org
        int orgBrandPartnerType =
            orgBrandPartnerTypeRepository.deleteById(orgPartnerPeripheralSupplier.getId());
        if (orgBrandPartnerType != 0) {
          // update edited brand with org
          orgBrandRepo.updateOrgBrand(orgId, partnerSupplier);
          // get org brand details for the edited brand to the org
          AuthOrgPartnerPeripheralSupplier authOrgBrand =
              orgBrandRepo.getOrgBrandByOrgIdAndBrandId(orgId, partnerSupplier);
          // get the partner brand object for the edited brand and partner type
          List<PartnerBrandPartnerType> partnerBrandPartnerTypes =
              partnerBrandPartnerTypeRepository.getBrandPartnerType(
                  partnerSupplier, partnerTypeIds);
          Optional.ofNullable(partnerBrandPartnerTypes)
              .orElseThrow(
                  () ->
                      new DataValidationException(
                          CustomErrorCodes.PARTNER_TYPE_FOR_BRAND_NOT_EXIST));
          // save the org with edited brand and editedpartner type
          List<AuthOrgBrandPartnerType> authOrgBrandPartnerTypes =
              partnerBrandPartnerTypes.stream()
                  .map(p -> new AuthOrgBrandPartnerType(authOrgBrand, p))
                  .collect(Collectors.toList());
          orgBrandPartnerTypeRepository.saveAll(authOrgBrandPartnerTypes);
        }
      }
    }
  }

  @Override
  @Transactional
  public void updateOrgStatus(OrgInfo orgInfo, int orgId)
      throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException,
          EmailException,
          CustomException {

    userhubValidator.validateOrgStatus(orgInfo.getStatus());

    AuthOrg org = orgRepository.getOrg(orgId);
    Boolean currentOrgStatus = org.getStatus();
    Optional.ofNullable(org)
        .orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ORG_NOT_FOUND));
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();

    org.setStatus(orgInfo.getStatus());
    org.setLastUpdatedDate(new Date());
    org.setLastUpdatedBy(authUser.getUsername());

    orgRepository.saveAndFlush(org);
    if (currentOrgStatus && !(orgInfo.getStatus())) {
      updateOrgStatusAndSendEmail(orgId);
    }
  }

  private void validateOrgDetails(OrgInfo orgInfo) throws DataValidationException {
    Optional.ofNullable(orgInfo.getName())
        .filter(o -> UserhubUtils.validatePattern(orgNamePattern, o.trim()))
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.ORG_NAME_VALIDATION_ERROR));
    Optional.ofNullable(orgInfo.getDesc())
        .filter(o -> UserhubUtils.validatePattern(orgDescPattern, o))
        .orElseThrow(() -> new DataValidationException(CustomErrorCodes.ORG_DESC_VALIDATION_ERROR));
    // Change for - NCIOT-11195,NCIOT-11196,NCIOT-11197
    if (!Optional.ofNullable(orgInfo.getHistoricalDataSubscription()).isPresent()
        || orgInfo.getHistoricalDataSubscription() < -1) {
      logger.info("historical data subscription cannot be null or less than -1 for customer org");
      throw new DataValidationException(
          CustomErrorCodes.INVALID_HISTORICAL_DATA_SUBSCRIPTION_VALUE);
    }
  }

  public List<String> getFacets(String operation) {
    List<String> facets =
        getAll(operation, null, null, null).stream()
            .map(o -> o.getType())
            .distinct()
            .collect(Collectors.toList()); // NCIOT-13374
    AuthenticatedUser authUser =
        UserhubUtils.getAuthenticatedUser(); // NCIOT-12123,12128,12124,12129
    if (!facets.isEmpty() && (authUser.getRole().equalsIgnoreCase(Constants.LW_MCS))) {
      facets.removeIf(
          r ->
              r.equalsIgnoreCase(Constants.ORG_TYPE_DISTRIBUTOR)
                  || r.equalsIgnoreCase(Constants.ORG_TYPE_PARTNER)
                  || r.equalsIgnoreCase(Constants.ORG_TYPE_CUSTOMER));
    } else if (!facets.isEmpty()
        && (authUser.getRole().equalsIgnoreCase(Constants.LW_BUSINESS_MANAGER))) {
      facets.removeIf(r -> r.equalsIgnoreCase(Constants.ORG_TYPE_CUSTOMER));
    } else if (!facets.isEmpty()
        && (authUser.getRole().equalsIgnoreCase(Constants.LW_SERVICE_ADMIN))) {
      facets.removeIf(r -> r.equalsIgnoreCase(Constants.ORG_TYPE_CUSTOMER));
    } else if (!facets.isEmpty()
        && (authUser.getRole().equalsIgnoreCase(Constants.LW_SERVICE_COORDINATOR))) {
      facets.removeIf(r -> r.equalsIgnoreCase(Constants.ORG_TYPE_CUSTOMER));
    }
    facets.removeIf((r -> r.equalsIgnoreCase(Constants.DEFAULT_TEMPLATE)));
    return facets;
  }

  @Override
  @Transactional
  public void delete(int orgId) throws ResourceNotFoundException, CustomException, EmailException {
    logger.info("Start of delete org for orgId {}", orgId);

    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Optional<Organization> org = Optional.ofNullable(orgRepo.getOrg(orgId));
    org.orElseThrow(() -> new ResourceNotFoundException(CustomErrorCodes.ORG_NOT_FOUND));

    /*
     * Made changes as per NCIOT-16812, Deleting the org and users under it.
     * Changing the logic as per NCIOT-1575
     */
    if (Constants.SUPER_ADMIN.equalsIgnoreCase(authUser.getRole())
        || Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())) {

      deleteOrgUsersAndSendEmail(orgId);

    } else if (Constants.MANUALLY_CREATED_ORG_DELETE_ACCESS_ROLES.contains(authUser.getRole())) {

      if (!org.get().isAutoCreated()) deleteOrgUsersAndSendEmail(orgId);
      else {
        logger.error(
            "User does not have access to delete the org as it is auto created --> org -->  {}, is auto created --> {}",
            org.get(),
            org.get().isAutoCreated());
        throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_FOR_AUTO_CREATED_ORG);
      }

    } else {
      logger.error("User does not have access to delete the orgs --> org -->  {}", org.get());
      throw new DataValidationException(CustomErrorCodes.ACCESS_DENIED_TO_DELETE_ORG);
    }

    /*
     * NCIOT-11418,NCIOT-11416 If org type is PARTNER Delete brand and partner type
     * associated with org. Delete from nc_org_partner_peripheral_suppliers, cascade
     * delete from nc_org_brand_partner_type will happen using create
     * nc_org_brand_partner_type db script
     */
    if (org.filter(o -> o.getType().equalsIgnoreCase(Constants.PARTNER)).isPresent()) {
      orgBrandRepo.deleteByOrgId(orgId);
    }
    userOrgPrivileges.isolateOrg(orgId);
    org.get().setDeleted(true);
    orgRepo.save(org.get());
    logger.info("End of delete org for orgId {}", orgId);
  }

  /**
   * Made changes as per NCIOT-16812
   *
   * @param orgId
   * @throws EmailException
   * @throws CustomException
   */
  private void deleteOrgUsersAndSendEmail(int orgId) throws EmailException, CustomException {
    logger.info("Start of deleteOrgUsersAndSendEmail for orgId {}", orgId);
    List<UserProfile> userProfiles = userRepo.findByOrgIdAndDeleted(orgId, false);
    if (!userProfiles.isEmpty()) {
      deleteAndSendOrgDeleteNotification(userProfiles);
      logger.info(
          "Deleted the users and sent org deletion email to --> userIds --> {}",
          userProfiles.stream().map(UserProfile::getUserId).collect(Collectors.toList()));
    }
    logger.info("End of deleteOrgUsersAndSendEmail for orgId {}", orgId);
  }

  /**
   * Made changes as per NCIOT-16812
   *
   * @param userProfiles
   * @throws EmailException
   * @throws CustomException
   */
  private void deleteAndSendOrgDeleteNotification(List<UserProfile> userProfiles)
      throws EmailException, CustomException {
    for (UserProfile userProfile : userProfiles) {
      logger.info(
          "Start of deleteAndSendOrgDeleteNotification --> unassing the devices from user to {}",
          userProfile.getUserId());

      unassignDevicesFromUser(userProfile);

      logger.info(
          "End of deleteAndSendOrgDeleteNotification --> unassing the devices from user to {}",
          userProfile.getUserId());

      logger.info(
          "Start of deleteAndSendOrgDeleteNotification --> deleting the user to {}",
          userProfile.getUserId());

      iUser.deleteUser(userProfile);

      logger.info(
          "End of deleteAndSendOrgDeleteNotification --> deleting the user to {}",
          userProfile.getUserId());

      if (userProfile.getStatus().equalsIgnoreCase("Active")) {
        logger.info(
            "Start of sendOrgDeleteNotification --> sending email to userid {}",
            userProfile.getUserId());
        emailService.sendOrgDeletionNotification(
            userProfile.getFirstName(),
            userProfile.getLastName(),
            userProfile.getEmail(),
            userProfile.getLanguage().getId(),
            environment,
            fromEmail);
        logger.info(
            "Successfully sent sendOrgDeleteNotification --> sending email to userid {}",
            userProfile.getUserId());
      }
    }
  }

  /**
   * @param userProfile
   * @throws ResourceNotFoundException
   */
  private void unassignDevicesFromUser(UserProfile userProfile) throws ResourceNotFoundException {
    logger.info("Start of unassignDevicesFromUser --> for user to {}", userProfile.getUserId());
    List<Long> deviceIds =
        userDevicePrivilegeRepository.getDeviceIdsFromUserId(userProfile.getUserId());
    List<ResourcePrivilege> resourcePrivileges = new ArrayList<>();
    for (long deviceId : deviceIds) {
      ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
      resourcePrivilege.setResourceid(deviceId);
      resourcePrivilege.setPrivilegeid(OrgPrivileges.assign_device.getPrivilegeId());
      resourcePrivileges.add(resourcePrivilege);
    }
    if (!resourcePrivileges.isEmpty()) {
      iUser.deletePrivileges(userProfile.getUserId(), resourcePrivileges);
    }
    logger.info("End of unassignDevicesFromUser --> for user to {}", userProfile.getUserId());
  }

  /**
   * Made changes as per NCIOT-11283 Getting the filter data based on the privilege of logged in
   * user
   *
   * @return OrgFilter
   */
  @Override
  public OrgFilter getFilter() {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<Organization> orgs = new ArrayList<>();
    List<String> auth =
        authUser.getAuthorities().stream().map(x -> x.toString()).collect(Collectors.toList());
    // NCIOT-16399, NCIOT-16354
    if (auth.contains(Constants.CREATE_ALL_ORG_TYPE_PRIVILEGE)
        || (Constants.LW_SERVICE_COORDINATOR.equals(authUser.getRole())
            || Constants.LW_SERVICE_ADMIN.equals(authUser.getRole())
            || Constants.LW_BUSINESS_MANAGER.equals(authUser.getRole()))) {
      orgs = orgRepo.getAll();
    } else if (auth.contains(Constants.CREATE_PARTNER_ORG_TYPE_PRIVILEGE)) {
      orgs = orgRepo.getAllPartnerOrgs(authUser.getOrgId());
    } else if (auth.contains(Constants.CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE)) {
      orgs = orgRepo.getAllCustomerOrgs(authUser.getOrgId());
    }
    OrgFilter orgFilter = new OrgFilter();
    if (orgs != null && !orgs.isEmpty()) {
      orgFilter.setType(orgs.stream().map(o -> o.getType()).collect(Collectors.toSet()));
      orgFilter.setStatus(orgs.stream().map(o -> o.getStatus()).collect(Collectors.toSet()));
    }
    return orgFilter;
  }

  /**
   * Getting the List of organisation based on filter criteria Made changes as per NCIOT-11283
   *
   * @param fetchCriteria
   * @param authUser
   * @return Page<Organization>
   * @throws CustomException
   */
  @Override
  public Page<Organization> getAllOrgs(FetchCriteria fetchCriteria) throws CustomException {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    fetchCriteria.setSearchBy(
        UserhubUtils.escapeUnderscoreSpecialChar(fetchCriteria.getSearchBy()));
    return getAllByFetchCriteria(fetchCriteria, authUser);
  }

  /**
   * Made changes as per NCIOT-11283 converting the List of organisation to List of OrgDto
   *
   * <p>MMI-FS-ESERV-3417 - Added created by as SM for auto created org
   *
   * @param List<Organization>
   * @return List<OrgDto>
   */
  @Override
  public List<OrgDto> orgListConvertor(List<Organization> orgs) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    List<OrgDto> orgDtoList = new ArrayList<>();
    for (Organization org : orgs) {
      OrgDto orgDto =
          new OrgDto(
              org.getId(),
              org.getName(),
              org.getDescription(),
              org.isAutoCreated() ? Constants.SM : org.getCreatedBy(),
              org.getCreatedDate(),
              org.getStatus(),
              org.getType(),
              orgSettingsRepository.findHistoricalDataSubscriptionByOrgId(org.getId()),
              org.isAutoCreated());
      if (Constants.SUPER_ADMIN.equalsIgnoreCase(authUser.getRole())
          || Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())
          || (Constants.MANUALLY_CREATED_ORG_DELETE_ACCESS_ROLES.contains(authUser.getRole())
              && !orgDto.isAutoCreated())) orgDto.setEnableDeleteIcon(true);
      /** Made changes as per V6MILIQ-2644 */
      logger.info("Checking Customer type for enabling or disabling toggle");
      if ((Constants.SUPER_ADMIN.equalsIgnoreCase(authUser.getRole())
              || Constants.LW_BUSINESS_MANAGER.equalsIgnoreCase(authUser.getRole())
              || Constants.LW_SERVICE_COORDINATOR.equalsIgnoreCase(authUser.getRole())
              || Constants.LW_SERVICE_ADMIN.equalsIgnoreCase(authUser.getRole()))
          && (!Constants.LABWATER.equalsIgnoreCase(org.getParent().getName()))) {
        logger.info(
            "enabling toggle as false for :" + org.getParent().getName() + "," + org.getId());
        orgDto.setEnableToggle(false);
      } else {
        logger.info(
            "enabling toggle as true for :" + org.getParent().getName() + "," + org.getId());
        orgDto.setEnableToggle(true);
      }
      orgDtoList.add(orgDto);
    }
    return orgDtoList;
  }

  /**
   * Getting the List of organisation based on filter criteria Made changes as per NCIOT-11283
   *
   * @param fetchCriteria
   * @param authUser
   * @return Page<Organization>
   * @throws CustomException
   */
  private Page<Organization> getAllByFetchCriteria(
      FetchCriteria fetchCriteria, AuthenticatedUser authUser) throws CustomException {

    Pageable page;
    // sort
    if (fetchCriteria.getSortBy() != null) {
      page = getSortedPageRequest(fetchCriteria);
    } else {
      page = PageRequest.of(fetchCriteria.getPageNo() - 1, fetchCriteria.getPageLimit());
    }

    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .filter(o -> o.getOrgId() != authUser.getOrgId())
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));

    if (accessibleOrgs.size() > 0) {
      return orgRepo.findAll(specification(fetchCriteria, authUser, accessibleOrgs), page);
    }
    return null;
  }

  /**
   * Made changes as per NCIOT-11283
   *
   * @param fetchCriteria
   * @param authUser
   * @param accessibleOrgs
   * @return Specification<Organization>
   */
  private Specification<Organization> specification(
      FetchCriteria fetchCriteria, AuthenticatedUser authUser, List<Integer> accessibleOrgs) {
    return new Specification<Organization>() {

      @Override
      public Predicate toPredicate(
          Root<Organization> root,
          CriteriaQuery<?> criteriaQuery,
          CriteriaBuilder criteriaBuilder) {

        List<Predicate> predicates = new ArrayList<>();
        if (fetchCriteria.getSearchBy() != null) {
          String searchValue = "%" + fetchCriteria.getSearchBy().toLowerCase() + "%";
          predicates.add(
              criteriaBuilder.like(criteriaBuilder.lower(root.get(Constants.NAME)), searchValue));
        }
        if (fetchCriteria.getFilterBy() != null && !fetchCriteria.getFilterBy().isEmpty()) {
          Map<String, List<String>> filterMap = getFilterValues(fetchCriteria.getFilterBy());
          if (filterMap.get("type") != null) {
            predicates.add(
                criteriaBuilder.in(root.get(Constants.TYPE)).value(filterMap.get(Constants.TYPE)));
          }
          if (filterMap.get("status") != null) {
            predicates.add(
                criteriaBuilder.and(
                    criteriaBuilder
                        .in(root.get(Constants.STATUS))
                        .value(
                            filterMap.get(Constants.STATUS).stream()
                                .map(Boolean::valueOf)
                                .collect(Collectors.toList()))));
          }
        }
        List<String> auth =
            authUser.getAuthorities().stream().map(x -> x.toString()).collect(Collectors.toList());
        // NCIOT-16399, NCIOT-16354
        if (!(Constants.LW_SERVICE_COORDINATOR.equals(authUser.getRole())
            || Constants.LW_SERVICE_ADMIN.equals(authUser.getRole())
            || Constants.LW_BUSINESS_MANAGER.equals(authUser.getRole()))) {
          /*
           * If user has create_org_partner this privilege then fetch only org type
           * partner since user has privilege to create only partner type orgs
           */
          if (auth.contains(Constants.CREATE_PARTNER_ORG_TYPE_PRIVILEGE)) {
            predicates.add(
                criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(Constants.TYPE), Constants.PARTNER)));
          }
          /*
           * If user has create_org_customer this privilege then fetch only org type
           * customer since user has privilege to create only customer type orgs
           */
          if (auth.contains(Constants.CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE)) {
            predicates.add(
                criteriaBuilder.and(
                    criteriaBuilder.equal(root.get(Constants.TYPE), Constants.CUSTOMER)));
          }
        }
        predicates.add(
            criteriaBuilder.and(criteriaBuilder.equal(root.get(Constants.DELETED), false)));
        predicates.add(
            criteriaBuilder.and(criteriaBuilder.in(root.get(Constants.ID)).value(accessibleOrgs)));
        predicates.add(
            criteriaBuilder.and(
                criteriaBuilder.notEqual(root.get(Constants.TYPE), Constants.DEFAULT_TEMPLATE)));
        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
      }
    };
  }

  /**
   * Made changes as per NCIOT-11283
   *
   * @param fetchCriteria
   * @return PageRequest
   * @throws CustomException
   */
  private Pageable getSortedPageRequest(FetchCriteria fetchCriteria) throws CustomException {
    PageRequest page = null;
    if (Constants.CREATED_ON.equalsIgnoreCase(fetchCriteria.getSortBy())) {
      fetchCriteria.setSortBy(Constants.CREATED_DATE);
    }
    String sortBy = fetchCriteria.getSortBy();

    if (Constants.ASCENDING.equals(fetchCriteria.getOrderBy())) {
      page =
          PageRequest.of(
              fetchCriteria.getPageNo() - 1, fetchCriteria.getPageLimit(), Direction.ASC, sortBy);
    } else {
      page =
          PageRequest.of(
              fetchCriteria.getPageNo() - 1, fetchCriteria.getPageLimit(), Direction.DESC, sortBy);
    }
    return page;
  }

  /**
   * Made changes as per NCIOT-11283
   *
   * @param filterBy
   * @return Map<String, List<String>>
   */
  private static Map<String, List<String>> getFilterValues(List<String> filterBy) {
    Map<String, List<String>> filterMap = new HashMap<>();

    List<String> orgTypeFilter = new ArrayList<>();
    List<String> statusFilter = new ArrayList<>();
    for (String afilterBy : filterBy) {
      if (afilterBy.contains("status.")) {
        statusFilter.add(afilterBy.replace(Constants.FILTER_STATUS_PREFIX, StringUtils.EMPTY));
      } else if (afilterBy.contains("type.")) {
        orgTypeFilter.add(afilterBy.replace(Constants.FILTER_TYPE_PREFIX, StringUtils.EMPTY));
      }
    }
    if (!statusFilter.isEmpty()) {
      filterMap.put(Constants.STATUS, statusFilter);
    }
    if (!orgTypeFilter.isEmpty()) {
      filterMap.put(Constants.TYPE, orgTypeFilter);
    }
    return filterMap;
  }

  public void updateOrgSetting(int orgId, Long historicalDataSubscription) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    List<String> auth =
        authUser.getAuthorities().stream().map(x -> x.toString()).collect(Collectors.toList());
    logger.info(
        "updateOrgSetting:: orgInfo:: historicalDataSubscription --> {}",
        historicalDataSubscription);
    /*
     * If role is Distributor Admin with privilege of creating org with org type as
     * customer then by default 'Historical Data Subscription' will be Full History
     */
    if (auth.contains(Constants.CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE)) {
      orgSettingsRepository.update(orgId, Long.parseLong(Constants.FULL_YEAR_HISTORICAL_DATA));
    } else {
      logger.info(
          "updateOrgSetting:: orgInfo:: inside else block:: historicalDataSubscription --> {}",
          historicalDataSubscription);
      orgSettingsRepository.update(orgId, historicalDataSubscription);
    }
  }

  @Override
  public List<OrganizationType> getOrganizationType() {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    List<String> auth =
        authUser.getAuthorities().stream().map(x -> x.toString()).collect(Collectors.toList());
    List<OrganizationType> orgTypes = new ArrayList<OrganizationType>();
    // NCIOT-13633
    if (auth.contains(Constants.CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE)
        && auth.contains(Constants.CREATE_PARTNER_ORG_TYPE_PRIVILEGE)) {
      OrganizationType orgTypeCustomer =
          orgTypeRepository.findByOrgTypeName(Constants.ORG_TYPE_CUSTOMER);
      OrganizationType orgTypePartner =
          orgTypeRepository.findByOrgTypeName(Constants.ORG_TYPE_PARTNER);
      orgTypes.add(orgTypeCustomer);
      orgTypes.add(orgTypePartner);
    } else if (auth.contains(Constants.CREATE_CUSTOMER_ORG_TYPE_PRIVILEGE)) {
      OrganizationType orgType = orgTypeRepository.findByOrgTypeName(Constants.ORG_TYPE_CUSTOMER);
      orgTypes.add(orgType);
    } else if (auth.contains(Constants.CREATE_PARTNER_ORG_TYPE_PRIVILEGE)) {
      OrganizationType orgType = orgTypeRepository.findByOrgTypeName(Constants.ORG_TYPE_PARTNER);
      orgTypes.add(orgType);
    } else if (auth.contains(Constants.CREATE_ALL_ORG_TYPE_PRIVILEGE)) {
      orgTypes = orgTypeRepository.findAll();
    }
    return orgTypes;
  }

  /**
   * This method will return the brand and partner types based on organization
   * NCIOT-12122,12118,12123
   */
  @Override
  public OrgPartnerBrandPartnerTypeDTO getOrgBrandPartnerTypes(Integer orgId) {
    AuthenticatedUser authUser = UserhubUtils.getAuthenticatedUser();
    Optional.ofNullable(authUser)
        .filter(a -> orgPermissions.hasRoleAccess(orgId, OrgPrivileges.manage_accounts))
        .orElseThrow(() -> new AccessDeniedException("User doesnt have access to the given org"));
    List<AuthOrgBrandPartnerType> orgBrandPartnerTypes =
        orgBrandPartnerTypeRepository.findByOrgBrandOrgId(orgId);
    Optional<AuthPartnerPeripheralSupplier> brand =
        orgBrandPartnerTypes.stream()
            .map(p -> p.getOrgBrand().getPartnerPeripheralSupplier())
            .findFirst();
    List<PartnerTypeEntity> partnerTypes =
        orgBrandPartnerTypes.stream()
            .map(p -> p.getPartnerBrandPartnerType().getPartnerTypeEntity())
            .collect(Collectors.toList());
    OrgPartnerBrandPartnerTypeDTO partnerBrandAndTypes = new OrgPartnerBrandPartnerTypeDTO();
    if (brand.isPresent()) {
      partnerBrandAndTypes.setOrgId(orgId);
      partnerBrandAndTypes.setBrand(brand.get());
      partnerBrandAndTypes.setPartnerTypes(partnerTypes);
    }

    return partnerBrandAndTypes;
  }

  /**
   * Made changes as per V6MILIQ-2572
   *
   * @param orgId
   * @throws EmailException
   * @throws CustomException
   */
  private void updateOrgStatusAndSendEmail(int orgId) throws EmailException, CustomException {
    logger.info("Start of updateOrgUsersAndSendEmail for orgId {}", orgId);
    List<UserProfile> userProfiles = userRepo.findByOrgIdAndStatus(orgId);
    if (!userProfiles.isEmpty()) {
      for (UserProfile userProfile : userProfiles) {
        logger.info(
            "End of updateAndSendOrgStatusNotification --> updating the user to {}",
            userProfile.getUserId());
        emailService.sendOrgStatusUpdateNotification(
            userProfile.getFirstName(),
            userProfile.getLastName(),
            userProfile.getEmail(),
            userProfile.getLanguage().getId(),
            environment,
            fromEmail);
        logger.info(
            "Successfully sent sendOrgStatusNotification --> sending email to userid {}",
            userProfile.getUserId());
      }
    }
    logger.info("End of updateOrgStatusAndSendEmail for orgId {}", orgId);
  }
}
