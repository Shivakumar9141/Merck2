package com.merck.nextconnect.userhub.model;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author clukose
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuManagementResponse {

  private int menuGroupId;
  private String menuGroupName;
  private int maxVisibleCount;
  private int minVisibleCount;
  private Set<MenuDTO> menus;
}
