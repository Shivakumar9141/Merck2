/**
 * ISelfRegistrationService.java
 *
 * @author Prateek Pande
 *     <p>Copyright © 2020 Merck. All rights reserved.
 */
package com.merck.nextconnect.userhub.resources;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.utils.common.DeviceWarrantyStatus;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.exception.CustomSMException;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.exception.FailedDependencyException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpClientErrorException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpServerErrorException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import jakarta.mail.MessagingException;
import java.io.IOException;
import java.util.List;
import javax.naming.AuthenticationException;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

@Service
public interface ISelfRegistrationService {
  /**
   * Made changes as per NCIOT-12313.
   *
   * @param selfRegistrationDTO
   * @return boolean
   * @throws CustomException
   * @throws DataValidationException
   * @throws AuthenticationException
   * @throws MessagingException
   * @throws EmailException
   * @throws JsonParseException
   * @throws JsonMappingException
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   * @throws CustomSMException
   * @throws IOException
   * @throws JSONException
   * @throws FailedDependencyException
   * @throws RestClientException
   * @throws ParseException
   */
  boolean selfRegistration(SelfRegistrationDTO selfRegistrationDTO, String sessionId)
      throws CustomException,
          DataValidationException,
          AuthenticationException,
          MessagingException,
          EmailException,
          JsonParseException,
          JsonMappingException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          JSONException,
          RestClientException,
          FailedDependencyException,
          ParseException;

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userId
   * @param isValid
   * @return void
   * @throws DataValidationException
   * @throws ResourceNotFoundException
   * @throws EmailException
   */
  void validateSelfRegisteredUser(long userId, boolean isValid)
      throws DataValidationException, ResourceNotFoundException, EmailException;

  /**
   * checks appropriate warranty status for the input device in following sequence: - Warranty -
   * Service Contract - Service Contract Grace Period - Warranty Grace Period
   *
   * @param device
   * @return device warranty status
   * @throws DataValidationException
   */
  DeviceWarrantyStatus getDeviceWarrantyStatus(Device device) throws DataValidationException;

  /**
   * Checks and returns Customer Admin user profile based on the device warranty status
   *
   * @param device
   * @param deviceWarrantyStatus
   * @param userOrgId
   * @return Customer Admin user profile
   */
  UserProfile getCAForDeviceWithWarrantyStatus(
      Device device, DeviceWarrantyStatus deviceWarrantyStatus, int userOrgId);

  /**
   * Checks and returns Customer Admin user profile based on warranty status. Internally refers
   * {@code getDeviceWarrantyStatus()} for warranty status.
   *
   * @param device
   * @param userOrgId
   * @return Customer Admin user profile
   * @throws DataValidationException
   */
  UserProfile getCAForDevice(Device device, int userOrgId) throws DataValidationException;

  /**
   * Raise ServiceMax service request for invalid or non-existing Customer Admin for triggering
   * validation email
   *
   * @param userProfile requested for self registration
   * @param device
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   */
  void raiseInvalidCAServiceRequest(UserProfile userProfile, Device device, String type)
      throws CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException;

  List<RoleOfInterest> selfRegistrationValidation(
      SelfRegistrationDTO selfRegistrationDTO, String sessionId)
      throws CustomException,
          DataValidationException,
          AuthenticationException,
          MessagingException,
          EmailException,
          JsonParseException,
          JsonMappingException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          JSONException,
          RestClientException,
          FailedDependencyException,
          ParseException;
}
