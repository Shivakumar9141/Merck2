package com.merck.nextconnect.userhub.model.user;

public enum UserTypes {
  INTERNAL_AUTH("internal_auth"),
  SIAL_AUTH("sial_auth");

  private final String value;

  public String value() {
    return this.value;
  }

  UserTypes(String value) {
    this.value = value;
  }
}
