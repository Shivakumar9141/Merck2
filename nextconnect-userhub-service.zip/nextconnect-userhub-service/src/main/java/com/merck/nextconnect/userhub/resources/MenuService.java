package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.MenuGroupRequest;
import com.merck.nextconnect.userhub.model.MenuGroupResponse;
import com.merck.nextconnect.userhub.model.MenuManagementRequest;
import com.merck.nextconnect.userhub.model.MenuManagementResponse;
import com.merck.nextconnect.userhub.model.MenuUpdateRequestDTO;
import java.util.List;

/**
 * NCIOT-11851
 *
 * @author clukose
 */
public interface MenuService {

  public List<MenuGroupResponse> getMenuGroups(MenuGroupRequest request);

  List<MenuManagementResponse> getMenuInfo(MenuManagementRequest request) throws CustomException;

  public List<MenuManagementResponse> updateUserMenu(MenuUpdateRequestDTO request)
      throws CustomException;
}
