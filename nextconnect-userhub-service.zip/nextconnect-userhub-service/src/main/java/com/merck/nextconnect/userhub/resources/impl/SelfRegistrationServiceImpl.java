package com.merck.nextconnect.userhub.resources.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.Organization;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.SelfRegisteredUserDeviceMapping;
import com.merck.nextconnect.userhub.entities.ServiceContract;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.repository.hazelcast.SelfRegistrationStore;
import com.merck.nextconnect.userhub.repository.jpa.CoveredProductRepository;
import com.merck.nextconnect.userhub.repository.jpa.DeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.SelfRegisteredUserDeviceRepository;
import com.merck.nextconnect.userhub.repository.jpa.ServiceContractRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDomainRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.ISelfRegistrationService;
import com.merck.nextconnect.userhub.resources.IUserSupport;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.validator.SelfRegistrationValidator;
import com.merck.nextconnect.utils.captcha.service.ValidateCaptchaService;
import com.merck.nextconnect.utils.common.DeviceWarrantyStatus;
import com.merck.nextconnect.utils.common.ServiceRequestType;
import com.merck.nextconnect.utils.common.dto.ServiceContractStatus;
import com.merck.nextconnect.utils.common.dto.ServiceMaxDTO;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.RoleOfInterestRepository;
import com.merck.nextconnect.utils.email.entities.ApplicationConfig;
import com.merck.nextconnect.utils.email.entities.EmailAttribute;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.exception.CustomSMException;
import com.merck.nextconnect.utils.exception.EmailException;
import com.merck.nextconnect.utils.exception.FailedDependencyException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpClientErrorException;
import com.merck.nextconnect.utils.file.handler.exception.CustomHttpServerErrorException;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import com.merck.nextconnect.utils.file.util.CustomErrorCodes;
import com.merck.nextconnect.utils.servicemax.SMConstants;
import com.merck.nextconnect.utils.servicemax.helper.ServiceMaxServiceRequestHelper;
import com.merck.nextconnect.utils.servicemax.model.ServiceMaxAuthInfo;
import com.merck.nextconnect.utils.servicemax.resources.ServiceMaxService;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import com.merck.nextconnect.utils.validator.SerialNumberValidator;
import jakarta.mail.MessagingException;
import java.io.IOException;
import java.net.URI;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import javax.naming.AuthenticationException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

@Service
public class SelfRegistrationServiceImpl implements ISelfRegistrationService {

  static final Logger LOGGER = LoggerFactory.getLogger(SelfRegistrationServiceImpl.class);

  @Autowired private DeviceRepository deviceRepository;

  @Autowired private UserRepository userRepository;

  @Autowired private SelfRegistrationValidator selfRegistrationValidator;

  @Autowired private PhoneNumberValidator phoneNumberValidator;

  @Autowired private CountryRepository countryRepository;

  @Autowired private ServiceContractRepository serviceContractRepository;

  @Autowired private IUserSupport iUserSupport;

  @Autowired private RoleRepository roleRepo;

  @Autowired private EmailTemplateService emailTemplateService;

  @Autowired private EmailService emailService;

  @Autowired private ServiceMaxService serviceMaxService;

  @Autowired private ServiceMaxServiceRequestHelper serviceMaxServiceRequestHelper;

  @Autowired private RoleOfInterestRepository roleOfInterestRepository;

  @Autowired private UserDomainRepository userDomainRepository;

  @Autowired private SelfRegisteredUserDeviceRepository selfRegisteredUserDeviceRepository;

  @Autowired private ApplicationConfigRepository applicationConfigRepository;

  @Autowired private CoveredProductRepository coveredProductRepository;

  @Autowired private OrganizationRepository organizationRepository;

  @Autowired private SerialNumberValidator serialNumberValidator;

  @Autowired private RoleRepository roleRepository;

  @Autowired private UserRolePrivileges userRolePrivileges;

  @Autowired private ValidateCaptchaService validateCaptchaService;

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Value("${servicemax.service.url}")
  private String smServiceURL;

  @Value("${servicemax.service.serviceRequest.url}")
  private String smServiceRequestURL;

  @Value("${servicemax.client.id}")
  private String smClientId;

  @Value("${servicemax.client.secret}")
  private String smClientSecret;

  @Value("${servicemax.username}")
  private String smUserName;

  @Value("${servicemax.password}")
  private String smPassword;

  @Value("${servicemax.token.url}")
  private String smTockenURL;

  @Value("${servicemax.hazelcast.validity}")
  private Long tokenValidity;

  @Value("${servicemax.service.query.url}")
  private String smaxQueryUrl;

  @Value("${servicemax.service.serialno.url}")
  private String smaxSerialNoCheckUrl;

  @Value("${google.recaptcha.verification.endpoint}")
  private String recaptchaEndpoint;

  @Value("${google.recaptcha.secret}")
  private String recaptchaSecret;

  @Autowired private SelfRegistrationStore selfRegistrationStore;

  /**
   * Self registration impl user can self register to the role of interest by providing valid serial
   * number. Made changes as per NCIOT-12313.
   *
   * @return boolean
   * @param SelfRegistrationDTO
   * @throws DataValidationException,
   * @throws AuthenticationException,
   * @throws MessagingException,
   * @throws CustomException,
   * @throws EmailException,
   * @throws CustomHttpClientErrorException,
   * @throws CustomHttpServerErrorException,
   * @throws CustomSMException,
   * @throws IOException
   * @throws JSONException
   * @throws FailedDependencyException
   * @throws RestClientException
   * @throws ParseException
   */
  @Override
  public boolean selfRegistration(SelfRegistrationDTO selfRegistrationDTO, String sessionId)
      throws DataValidationException,
          AuthenticationException,
          MessagingException,
          CustomException,
          EmailException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          JSONException,
          FailedDependencyException,
          ParseException {

    LOGGER.info(
        "Start of selfRegistration for email --> {}, serialNo --> {}",
        selfRegistrationDTO.getEmail(),
        selfRegistrationDTO.getSerialNo());

    SelfRegistrationDTO cacheObject = selfRegistrationStore.getSelfRegistrationMap(sessionId);
    if (Objects.isNull(cacheObject)) {
      LOGGER.error("The session is timed out");
      throw new DataValidationException(CustomErrorCodes.SESSION_TIME_OUT);
    }
    LOGGER.info("the session Object is " + cacheObject.toString());

    selfRegistrationValidator.selfRegistrationDataValidation(selfRegistrationDTO, cacheObject);
    LOGGER.info("Obect comparison is done " + cacheObject.toString());

    Country country = countryRepository.findByCountryCode(selfRegistrationDTO.getCountryCode());

    RoleOfInterest roleOfInterest =
        roleOfInterestRepository.findByRoleOfInterest(selfRegistrationDTO.getRoleOfInterest());

    Device device =
        deviceRepository.findBySerialnoAndStatusAndDeleted(
            selfRegistrationDTO.getSerialNo(), true, false);

    UserProfile user;
    Role role =
        roleRepo.getRoleByName(roleOfInterest.getMymilliqRoleName(), cacheObject.getOrgId());

    long domainId = userDomainRepository.findDomainIdByDomainName(Constants.NEXTCONNECT);

    UserDetails userDetails = new UserDetails();
    userDetails.setFirstName(selfRegistrationDTO.getFirstName());
    userDetails.setLastName(selfRegistrationDTO.getLastName());
    userDetails.setEmail(selfRegistrationDTO.getEmail());
    userDetails.setDomainId(domainId);
    userDetails.setLoginText(selfRegistrationDTO.getEmail());
    userDetails.setOrgId(cacheObject.getOrgId());
    userDetails.setRoleId(role.getRoleId());
    userDetails.setInvitedVia(UserInvitedVia.SELF_REGISTRATION.value());
    if (StringUtils.isNotBlank(selfRegistrationDTO.getPhone())) {
      userDetails.setIsdCode(selfRegistrationDTO.getIsdCode());
      userDetails.setPhone(selfRegistrationDTO.getPhone());
    }
    userDetails.setCountryId(country.getId());
    userDetails.setCountryCode(selfRegistrationDTO.getCountryCode());
    LOGGER.info("Before add");
    user = iUserSupport.add(userDetails);
    LOGGER.info("After add");
    SelfRegisteredUserDeviceMapping selfRegisteredUserDevice =
        new SelfRegisteredUserDeviceMapping();
    selfRegisteredUserDevice.setUserProfile(user);
    selfRegisteredUserDevice.setDevice(device);
    selfRegisteredUserDeviceRepository.save(selfRegisteredUserDevice);

    LOGGER.info(
        "End of selfRegistration for email --> {}, serialNo --> {}",
        selfRegistrationDTO.getEmail(),
        selfRegistrationDTO.getSerialNo());
    // removing the hazalecast session Object from store
    selfRegistrationStore.removeSelfRegistrationMap(sessionId);
    return Optional.ofNullable(user).isPresent();
  }

  /**
   * Checking whether is device is valid or not. Made changes as per NCIOT-12313.
   *
   * @param device
   * @throws DataValidationException
   * @throws IOException
   * @throws CustomSMException
   * @throws CustomHttpServerErrorException
   * @throws CustomHttpClientErrorException
   * @throws JSONException
   * @throws FailedDependencyException
   * @throws RestClientException
   */
  private boolean isDeviceValid(Device device, SelfRegistrationDTO selfRegistrationDTO)
      throws DataValidationException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          RestClientException,
          FailedDependencyException,
          JSONException {

    boolean isDeviceInWarranty = false;
    isShippedDeviceValid(device, selfRegistrationDTO);

    ApplicationConfig warrantyPeriod =
        applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.WARRANTY_PERIOD, Constants.WARRANTY_PERIOD_VALUE, Constants.ACTIVE);

    if (Optional.ofNullable(device.getInstalledDate()).isPresent()) {
      Date installedDate = new Date(device.getInstalledDate().getTime());
      Date now = new Date();
      long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - installedDate.getTime());
      if (diffInDays < Long.valueOf(warrantyPeriod.getValue())) {
        isDeviceInWarranty = true;
      }
    }
    if (!isDeviceInWarranty) {

      Set<Long> serviceContractIds =
          coveredProductRepository.findServiceContractIdByDeviceIdAndServiceLevel(
              device.getDeviceId(), Constants.CP_SERVICE_LEVEL);
      ServiceContract serviceContract = null;
      if (!serviceContractIds.isEmpty()) {
        serviceContract =
            serviceContractRepository.getByServiceContractStatusInAndServiceContractIdIn(
                Arrays.asList(
                    ServiceContractStatus.ACTIVE.value(),
                    ServiceContractStatus.ACITVE_RENEWAL_CREATED.value(),
                    ServiceContractStatus.ACTIVE_PENDING_RENEWAL.value(),
                    ServiceContractStatus.READY_FOR_ACTIVATION.value()),
                serviceContractIds);
      }

      if (!Optional.ofNullable(serviceContract).isPresent()) {
        ServiceContract serviceContractEntity = null;
        if (!serviceContractIds.isEmpty()) {
          serviceContractEntity =
              serviceContractRepository.findLatestExpiredContract(serviceContractIds);
        }

        if (Optional.ofNullable(serviceContractEntity).isPresent()) {

          ApplicationConfig gracePeriod =
              applicationConfigRepository.findByCategoryAndKeyAndStatus(
                  Constants.GRACE_PERIOD,
                  Constants.SERVICE_CONTRACT_GRACE_PERIOD_VALUE,
                  Constants.ACTIVE);

          Date endDate = new Date(serviceContractEntity.getEndDate().getTime());
          Date now = new Date();
          long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - endDate.getTime());

          if (diffInDays > Long.valueOf(gracePeriod.getValue())) {
            LOGGER.info(
                "Device does not have any active service contract and last expired service contract is over grace period, deviceId {}",
                device.getDeviceId());
            throw new DataValidationException(CustomErrorCodes.DEVICE_NOT_VALID);
          }
        } else {
          Date installedDate = new Date(device.getInstalledDate().getTime());
          Date now = new Date();
          ApplicationConfig gracePeriod =
              applicationConfigRepository.findByCategoryAndKeyAndStatus(
                  Constants.GRACE_PERIOD, Constants.WARRANTY_GRACE_PERIOD_VALUE, Constants.ACTIVE);

          long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - installedDate.getTime());

          if (diffInDays
              < (Long.valueOf(warrantyPeriod.getValue()) + Long.valueOf(gracePeriod.getValue()))) {

            isDeviceInWarranty = true;

          } else {
            LOGGER.info("Device is not valid {}", device.getDeviceId());
            throw new DataValidationException(CustomErrorCodes.DEVICE_NOT_VALID);
          }
        }
      }
    }
    return isDeviceInWarranty;
  }

  /**
   * Creating service request. Made changes as per NCIOT-12313.
   *
   * @param selfRegistrationDTO
   * @param device
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   * @throws CustomSMException
   * @throws IOException
   */
  private void createServiceRequest(SelfRegistrationDTO selfRegistrationDTO, Device device)
      throws CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException {
    ServiceMaxDTO serviceMaxDTO = populateServiceMaxDTO(selfRegistrationDTO, device);
    ResponseEntity<String> response = createServiceMaxServiceRequest(serviceMaxDTO);
    Map<String, Object> responseMap =
        new ObjectMapper().readValue(response.getBody(), HashMap.class);
    LOGGER.info("response {}", responseMap);
  }

  /**
   * Sending failure email. Made changes as per NCIOT-12313.
   *
   * @param selfRegistrationDTO
   * @throws EmailException
   */
  private void sendEmail(SelfRegistrationDTO selfRegistrationDTO) throws EmailException {
    EmailTemplate emailTemplate =
        emailTemplateService.findByTemplateName(Constants.SELF_REGISTRATION_FAILURE);
    LOGGER.info(
        "Start of sending self registration failure email to {}", selfRegistrationDTO.getEmail());

    EmailMessage emailMessageCustomer =
        EmailMessage.builder()
            .emailTemplate(emailTemplate)
            .emailFrom(fromEmail)
            .emailTo(selfRegistrationDTO.getEmail())
            .subject(Constants.SELF_REGISTRATION_FAILURE_SUBJECT)
            .status(com.merck.nextconnect.utils.common.Constants.EMAIL_SUCCESS_STATUS)
            .createdBy("USERHUB")
            .createdTimestamp(Timestamp.from(Instant.now()))
            .lastUpdatedBy("USERHUB")
            .lastUpdatedTimestamp(Timestamp.from(Instant.now()))
            .charset(com.merck.nextconnect.utils.common.Constants.EMAIL_CHAR_SET)
            .contentType(com.merck.nextconnect.utils.common.Constants.EMAIL_CONTENT_TYPE)
            .build();

    Set<EmailAttribute> emailAttributeSet = new HashSet<>();

    emailMessageCustomer.setEmailAttributes(emailAttributeSet);

    emailService.sendMail(emailMessageCustomer, environment);
    LOGGER.info(
        "End of sending self registration failure email to {}", selfRegistrationDTO.getEmail());
  }

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param selfRegistrationDTO
   * @param device
   * @return ServiceMaxDTO
   */
  private ServiceMaxDTO populateServiceMaxDTO(
      SelfRegistrationDTO selfRegistrationDTO, Device device) {
    Date today = new Date();
    return ServiceMaxDTO.builder()
        .serviceRequestSource(Constants.MILLI_Q_CONNECT)
        .category(Constants.REGISTRATION)
        .type(ServiceRequestType.SELF_REGISTRATION_TO_MYMILLIQ_FAILURE.value())
        .status(Constants.OPEN)
        .customerEmail(selfRegistrationDTO.getEmail())
        .customerName(
            String.join(
                " ",
                Arrays.asList(
                    selfRegistrationDTO.getFirstName(), selfRegistrationDTO.getLastName())))
        .phoneNumber(selfRegistrationDTO.getPhone())
        .deviceType(
            Optional.ofNullable(device).isPresent()
                ? device.getDeviceType().getDeviceType()
                : Constants.UNKNOWN)
        .serialNo(
            Optional.ofNullable(device).isPresent()
                ? device.getSerialno()
                : selfRegistrationDTO.getSerialNo())
        .dateOfSubmission(new SimpleDateFormat("yyyy-MM-dd").format(today))
        .installedProduct(Optional.ofNullable(device).isPresent() ? device.getSmDeviceId() : " ")
        .build();
  }

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param serviceMaxDTO
   * @return String
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   * @throws CustomSMException
   */
  private ResponseEntity<String> createServiceMaxServiceRequest(ServiceMaxDTO serviceMaxDTO)
      throws CustomHttpClientErrorException, CustomHttpServerErrorException, CustomSMException {
    Map<String, String> params =
        serviceMaxServiceRequestHelper.populateServiceRequest(serviceMaxDTO);
    return serviceMaxService.createCase(smServiceRequestURL, getSMToken(), params);
  }

  /**
   * Made changes as per NCIOT-12313.
   *
   * @return String
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   */
  private String getSMToken()
      throws CustomHttpClientErrorException, CustomHttpServerErrorException {
    return serviceMaxService.getAuthToken(
        smTockenURL,
        ServiceMaxAuthInfo.builder()
            .smClientId(smClientId)
            .smClientSecret(smClientSecret)
            .smUserName(smUserName)
            .smPassword(smPassword)
            .build(),
        tokenValidity);
  }

  /**
   * Made changes as per NCIOT-12313.
   *
   * <p>if device is not there in MyMilliQ, then check in ServiceMax with the user entered serial
   * number if present then create a service request.
   *
   * @param device
   * @param selfRegistrationDTO
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   * @throws FailedDependencyException
   * @throws CustomSMException
   * @throws JSONException
   * @throws EmailException
   * @throws DataValidationException
   * @throws IOException
   */
  private void isDevicePresent(Device device, SelfRegistrationDTO selfRegistrationDTO)
      throws CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          FailedDependencyException,
          CustomSMException,
          JSONException,
          EmailException,
          DataValidationException,
          IOException {
    if (!Optional.ofNullable(device).isPresent()) {

      StringBuilder serviceMaxURL = new StringBuilder();
      serviceMaxURL.append(smaxQueryUrl);
      String query =
          smaxSerialNoCheckUrl.concat("'").concat(selfRegistrationDTO.getSerialNo()).concat("'");
      serviceMaxURL.append(query);
      URI url = URI.create(serviceMaxURL.toString());
      String token = getSMToken();
      String response = serviceMaxService.createCaseGetAttachmentsInfo(url, token);
      JSONObject jsonResponse = new JSONObject(response);
      int totalSize = jsonResponse.getInt("totalSize");
      if (totalSize > 0) {
        LOGGER.info(
            "Device not found in MyMilliQ but found in service max serialNo {}",
            selfRegistrationDTO.getSerialNo());
        sendEmail(selfRegistrationDTO);
        if (!checkIfServiceRequestAlreadyCreated(selfRegistrationDTO)) {
          createServiceRequest(selfRegistrationDTO, device);
        }
        throw new DataValidationException(CustomErrorCodes.DEVICE_NOT_FOUND_IN_MYMILLIQ);
      } else {
        LOGGER.info(
            "Device not found in service max also serialNo {}", selfRegistrationDTO.getSerialNo());
        throw new DataValidationException(
            CustomErrorCodes.DEVICE_NOT_FOUND_IN_MYMILLIQ_AND_SERVICEMAX);
      }
    }
  }

  private boolean checkIfServiceRequestAlreadyCreated(SelfRegistrationDTO selfRegistrationDTO)
      throws RestClientException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          FailedDependencyException,
          CustomSMException,
          IOException,
          JSONException {
    LOGGER.info(
        "Checking if service request for the email and serial number combination already created, serial no {}",
        selfRegistrationDTO.getSerialNo());
    StringBuilder serviceMaxURL = new StringBuilder();
    serviceMaxURL.append(smaxQueryUrl);
    StringBuilder query = new StringBuilder();
    String email = selfRegistrationDTO.getEmail().replace("+", "%2b");

    query
        .append("q=")
        .append(Constants.SELECT_SR_STATUS_FROM_SERVICE_MAX)
        .append(Constants.SERIAL_NO_USER_TO_REGISTER)
        .append(Constants.EQUALS)
        .append(Constants.APOSTROPHE)
        .append(selfRegistrationDTO.getSerialNo())
        .append(Constants.APOSTROPHE)
        .append("+")
        .append(Constants.AND)
        .append("+")
        .append(Constants.CUSTOMER_EMAIL_C)
        .append(Constants.EQUALS)
        .append(Constants.APOSTROPHE)
        .append(email)
        .append(Constants.APOSTROPHE)
        .append("+")
        .append(Constants.AND)
        .append("+")
        .append(Constants.SR_TYPE)
        .append(Constants.EQUALS)
        .append(Constants.APOSTROPHE)
        .append(Constants.SELF_REGISTRATION_TO_MYMILLIQ_FAILURE_WITHOUT_SPACE)
        .append(Constants.APOSTROPHE)
        .append("+")
        .append(Constants.AND)
        .append("+")
        .append(Constants.SR_STATUS)
        .append("+")
        .append(Constants.IN)
        .append("+")
        .append(Constants.OPEN_BRACKET)
        .append(Constants.APOSTROPHE)
        .append(Constants.OPEN)
        .append(Constants.APOSTROPHE)
        .append(Constants.COMMA)
        .append(Constants.APOSTROPHE)
        .append(Constants.IN_PROGRESS)
        .append(Constants.APOSTROPHE)
        .append(Constants.CLOSE_BRACKET);
    LOGGER.info("query {}", query);
    serviceMaxURL.append(query);
    LOGGER.info("serviceMaxURL {}", serviceMaxURL);
    URI url = URI.create(serviceMaxURL.toString());
    String token = getSMToken();
    String response = serviceMaxService.createCaseGetAttachmentsInfo(url, token);
    JSONObject jsonResponse = new JSONObject(response);

    int totalSize = jsonResponse.getInt("totalSize");

    return totalSize > 0;
  }

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userId
   * @param isValid
   * @return void
   * @throws DataValidationException
   * @throws ResourceNotFoundException
   * @throws EmailException
   */
  @Override
  public void validateSelfRegisteredUser(long userId, boolean isValid)
      throws DataValidationException, ResourceNotFoundException, EmailException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    LOGGER.info("Validating the user {} by user {}", userId, authUser.getId());
    UserProfile userProfileOfSelfRegisteredUser =
        userRepository.findByUserIdAndDeletedAndStatus(userId, false, "Active");

    UserProfile userProfileOfUserValidating =
        userRepository.findByUserIdAndDeletedAndStatus(
            Long.valueOf(authUser.getId()), false, "Active");

    selfRegistrationValidator.selfRegistrationUserValidationValidator(
        userProfileOfSelfRegisteredUser, userProfileOfUserValidating);

    if (isValid) {
      userRepository.updateUserValidatedByUserId(userId, true);

      SelfRegisteredUserDeviceMapping selfRegisteredUserDeviceMapping =
          selfRegisteredUserDeviceRepository.findByUserProfileUserId(userId);

      if (Optional.ofNullable(selfRegisteredUserDeviceMapping).isPresent()) {
        Device device =
            deviceRepository.findByDeviceIdAndStatusAndDeleted(
                selfRegisteredUserDeviceMapping.getDevice().getDeviceId(), true, false);

        if (Optional.ofNullable(device).isPresent()) {

          List<ResourcePrivilege> resourcePrivilegeList = new ArrayList<>();

          ResourcePrivilege resourcePrivilege = new ResourcePrivilege();
          resourcePrivilege.setPrivilegeid(OrgPrivileges.assign_device.getPrivilegeId());
          resourcePrivilege.setResourceid(device.getDeviceId());
          resourcePrivilegeList.add(resourcePrivilege);
          userRolePrivileges.autoAddUserDevicePrivileges(
              userProfileOfSelfRegisteredUser, resourcePrivilegeList);
        }
        selfRegisteredUserDeviceRepository.delete(selfRegisteredUserDeviceMapping);
      }
      sendEmailForProfileStatusChange(userProfileOfSelfRegisteredUser, Constants.ACTIVATED);
    } else {
      SelfRegisteredUserDeviceMapping selfRegisteredUserDeviceMapping =
          selfRegisteredUserDeviceRepository.findByUserProfileUserId(userId);
      String systemName = Constants.NOT_AVAILABLE;
      String productCatalogueNumber = Constants.NOT_AVAILABLE;
      String serialNo = Constants.NOT_AVAILABLE;
      if (Optional.ofNullable(selfRegisteredUserDeviceMapping).isPresent()) {
        Device device =
            deviceRepository.findByDeviceIdAndStatusAndDeleted(
                selfRegisteredUserDeviceMapping.getDevice().getDeviceId(), true, false);
        if (Optional.ofNullable(device).isPresent()) {
          systemName = device.getDevicename();
          productCatalogueNumber = device.getProductCatalogNo();
          serialNo = device.getSerialno();
        }
        selfRegisteredUserDeviceRepository.delete(selfRegisteredUserDeviceMapping);
      }
      sendEmailForSelfRegistrationRequestRejected(
          userProfileOfSelfRegisteredUser,
          userProfileOfUserValidating,
          systemName,
          productCatalogueNumber,
          serialNo);
      userRepository.deleteUserByUserId(userId, true);
    }
  }

  @Override
  public UserProfile getCAForDevice(Device device, int userOrgId) throws DataValidationException {

    UserProfile caProfile = null;
    DeviceWarrantyStatus status = null;
    if (isDeviceActive(device)) {
      if (!device.isDealer()) {
        status = getDeviceWarrantyStatus(device);
      }
      caProfile = getCAForDeviceWithWarrantyStatus(device, status, userOrgId);
    } else
      caProfile =
          getCAForDeviceWithWarrantyStatus(device, DeviceWarrantyStatus.OUT_OF_WARRANTY, userOrgId);

    return caProfile;
  }

  @Override
  public DeviceWarrantyStatus getDeviceWarrantyStatus(Device device) {

    DeviceWarrantyStatus warrantyStatus = DeviceWarrantyStatus.OUT_OF_WARRANTY;

    if (isDeviceInWarranty(device)) warrantyStatus = DeviceWarrantyStatus.IN_WARRANTY;
    else if (isDeviceUnderServiceContract(device))
      warrantyStatus = DeviceWarrantyStatus.UNDER_SERVICE_CONTRACT;
    else if (isDeviceUnderServiceContractGracePeriod(device))
      warrantyStatus = DeviceWarrantyStatus.UNDER_SERVICE_CONTRACT_GRACE_PERIOD;
    else if (isDeviceInWarrantyGracePeriod(device))
      warrantyStatus = DeviceWarrantyStatus.IN_WARRANTY_GRACE_PERIOD;

    LOGGER.info(
        "getDeviceWarrantyStatus <-- warranty status :{} for device_id: {}",
        warrantyStatus,
        device.getDeviceId());

    return warrantyStatus;
  }

  @Override
  public UserProfile getCAForDeviceWithWarrantyStatus(
      Device device, DeviceWarrantyStatus deviceWarrantyStatus, int userOrgId) {

    String candidateCAEmail = null;

    Set<Long> serviceContractIds = null;
    if (DeviceWarrantyStatus.UNDER_SERVICE_CONTRACT == deviceWarrantyStatus
        || DeviceWarrantyStatus.UNDER_SERVICE_CONTRACT_GRACE_PERIOD == deviceWarrantyStatus)
      serviceContractIds =
          coveredProductRepository.findServiceContractIdByDeviceIdAndServiceLevel(
              device.getDeviceId(), Constants.CP_SERVICE_LEVEL);

    if (deviceWarrantyStatus != null) {
      switch (deviceWarrantyStatus) {
        case IN_WARRANTY:
        case IN_WARRANTY_GRACE_PERIOD:
          candidateCAEmail = device.getEmailId();
          break;
        case UNDER_SERVICE_CONTRACT:
          if (!serviceContractIds.isEmpty()) {
            ServiceContract serviceContract =
                serviceContractRepository.getByServiceContractStatusInAndServiceContractIdIn(
                    Arrays.asList(
                        ServiceContractStatus.ACTIVE.value(),
                        ServiceContractStatus.ACITVE_RENEWAL_CREATED.value(),
                        ServiceContractStatus.ACTIVE_PENDING_RENEWAL.value(),
                        ServiceContractStatus.READY_FOR_ACTIVATION.value()),
                    serviceContractIds);
            if (Optional.ofNullable(serviceContract).isPresent())
              candidateCAEmail = serviceContract.getEmailId();
          }
          break;
        case UNDER_SERVICE_CONTRACT_GRACE_PERIOD:
          if (!serviceContractIds.isEmpty()) {
            ServiceContract serviceContract =
                serviceContractRepository.findLatestExpiredContract(serviceContractIds);
            if (Optional.ofNullable(serviceContract).isPresent())
              candidateCAEmail = serviceContract.getEmailId();
          }
          break;
        case OUT_OF_WARRANTY:
          // this case is handled below along with above failed cases if any
          break;
      }
    }

    UserProfile caUserProfile = null;

    // Get user org to retrieve CA
    Role role = roleRepository.getRoleByName(Constants.CUSTOMER_ADMIN, userOrgId);
    if (StringUtils.isNotBlank(candidateCAEmail))
      caUserProfile = getActiveUserProfileForEmailAndRole(candidateCAEmail, role.getRoleId());

    // OUT_OF_WARRANTY case and fallback for other scenarios
    if (!Optional.ofNullable(caUserProfile).isPresent()) {
      caUserProfile =
          userRepository.getOldestActiveUsersByRoleIdsAndActive(role.getRoleId(), userOrgId);
    }

    LOGGER.info(
        "getCAForDeviceWithWarrantyStatus <-- CA :{} for device_id: {}",
        caUserProfile,
        Optional.ofNullable(device).isPresent() ? device.getDeviceId() : StringUtils.EMPTY);

    return caUserProfile;
  }

  @Override
  public void raiseInvalidCAServiceRequest(UserProfile userProfile, Device device, String type)
      throws CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException {
    Date today = new Date();
    ServiceMaxDTO invalidCaDTO =
        ServiceMaxDTO.builder()
            .serviceRequestSource(SMConstants.MILLI_Q_CONNECT)
            .category(Constants.REGISTRATION)
            .type(type)
            .status(SMConstants.OPEN)
            .customerEmail(userProfile.getEmail())
            .customerName(
                String.join(
                    " ", Arrays.asList(userProfile.getFirstName(), userProfile.getLastName())))
            .dateOfSubmission(new SimpleDateFormat("yyyy-MM-dd").format(today))
            .phoneNumber(userProfile.getPhone())
            .build();

    if (Optional.ofNullable(device).isPresent()) {
      if (StringUtils.isNotBlank(device.getSmDeviceId()))
        invalidCaDTO.setInstalledProduct(device.getSmDeviceId());
      if (Objects.nonNull(device.getDeviceType())
          && StringUtils.isNotBlank(device.getDeviceType().getDeviceType()))
        invalidCaDTO.setDeviceType(device.getDeviceType().getDeviceType());
      if (StringUtils.isNotBlank(device.getSerialno()))
        invalidCaDTO.setSerialNo(device.getSerialno());
    }

    createServiceRequest(invalidCaDTO);
  }

  /**
   * Made changes as per NCIOT-12010. Sending self registration reject email.
   *
   * @param userProfileOfSelfRegisteredUser
   * @param userProfileOfUserValidating
   * @param systemName
   * @param productCatalogueNumber
   * @param serialNo
   * @throws EmailException
   */
  private void sendEmailForSelfRegistrationRequestRejected(
      UserProfile userProfileOfSelfRegisteredUser,
      UserProfile userProfileOfUserValidating,
      String systemName,
      String productCatalogueNumber,
      String serialNo)
      throws EmailException {
    LOGGER.info(
        "Start of sending self registration rejected email to {}",
        userProfileOfSelfRegisteredUser.getEmail());
    emailService.sendEmailForSelfRegistrationRequestRejected(
        userProfileOfSelfRegisteredUser.getEmail(),
        userProfileOfSelfRegisteredUser.getFirstName(),
        userProfileOfSelfRegisteredUser.getLastName(),
        systemName,
        productCatalogueNumber,
        serialNo,
        userProfileOfUserValidating.getOrg().getName(),
        userProfileOfUserValidating.getFirstName(),
        userProfileOfUserValidating.getLastName(),
        fromEmail,
        environment);
    LOGGER.info(
        "End of sending self registration rejected email to {}",
        userProfileOfSelfRegisteredUser.getEmail());
  }

  /**
   * Made changes as per NCIOT-12010. Sending email to self registered user for
   * validation/invalidation scenario.
   *
   * @param userProfile
   * @throws EmailException
   */
  private void sendEmailForProfileStatusChange(UserProfile userProfile, String status)
      throws EmailException {
    LOGGER.info("Start of sending self registration accepted email to {}", userProfile.getEmail());
    emailService.sendEmailForProfileStatusChange(
        userProfile.getFirstName(),
        userProfile.getLastName(),
        userProfile.getEmail(),
        status,
        environment,
        fromEmail);
    LOGGER.info("End of sending self registration email to {}", userProfile.getEmail());
  }

  private boolean isDeviceInWarranty(Device device) {

    boolean warrantyStatus = false;

    ApplicationConfig warrantyPeriod =
        applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.WARRANTY_PERIOD, Constants.WARRANTY_PERIOD_VALUE, Constants.ACTIVE);

    if (Optional.ofNullable(device.getInstalledDate()).isPresent()) {
      Date installedDate = new Date(device.getInstalledDate().getTime());
      Date now = new Date();
      long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - installedDate.getTime());
      warrantyStatus = (diffInDays <= Long.valueOf(warrantyPeriod.getValue()));
    }

    return warrantyStatus;
  }

  private boolean isDeviceInWarrantyGracePeriod(Device device) {

    boolean underWarrantyGrace = false;

    ApplicationConfig warrantyPeriod =
        applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.WARRANTY_PERIOD, Constants.WARRANTY_PERIOD_VALUE, Constants.ACTIVE);

    ApplicationConfig gracePeriod =
        applicationConfigRepository.findByCategoryAndKeyAndStatus(
            Constants.GRACE_PERIOD, Constants.WARRANTY_GRACE_PERIOD_VALUE, Constants.ACTIVE);

    if (Optional.ofNullable(device.getInstalledDate()).isPresent()) {
      Date installedDate = new Date(device.getInstalledDate().getTime());
      Date now = new Date();
      long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - installedDate.getTime());
      underWarrantyGrace =
          (diffInDays > Long.valueOf(warrantyPeriod.getValue())
              && (diffInDays
                  < (Long.valueOf(warrantyPeriod.getValue())
                      + Long.valueOf(gracePeriod.getValue()))));
    }

    return underWarrantyGrace;
  }

  private boolean isDeviceUnderServiceContract(Device device) {

    boolean isContractValid = false;

    Set<Long> serviceContractIds =
        coveredProductRepository.findServiceContractIdByDeviceIdAndServiceLevel(
            device.getDeviceId(), Constants.CP_SERVICE_LEVEL);
    if (!serviceContractIds.isEmpty()) {

      ServiceContract serviceContract =
          serviceContractRepository.getByServiceContractStatusInAndServiceContractIdIn(
              Arrays.asList(
                  ServiceContractStatus.ACTIVE.value(),
                  ServiceContractStatus.ACITVE_RENEWAL_CREATED.value(),
                  ServiceContractStatus.ACTIVE_PENDING_RENEWAL.value(),
                  ServiceContractStatus.READY_FOR_ACTIVATION.value()),
              serviceContractIds);

      if (Optional.ofNullable(serviceContract).isPresent()) {
        Date endDate = new Date(serviceContract.getEndDate().getTime());
        Date now = new Date();
        isContractValid = endDate.getTime() >= now.getTime();
      }
    }

    return isContractValid;
  }

  private boolean isDeviceUnderServiceContractGracePeriod(Device device) {

    boolean isContractValid = false;

    Set<Long> serviceContractIds =
        coveredProductRepository.findServiceContractIdByDeviceIdAndServiceLevel(
            device.getDeviceId(), Constants.CP_SERVICE_LEVEL);
    ServiceContract serviceContract = null;
    if (!serviceContractIds.isEmpty()) {
      serviceContract =
          serviceContractRepository.getByServiceContractStatusInAndServiceContractIdIn(
              Arrays.asList(
                  ServiceContractStatus.ACTIVE.value(),
                  ServiceContractStatus.ACITVE_RENEWAL_CREATED.value(),
                  ServiceContractStatus.ACTIVE_PENDING_RENEWAL.value(),
                  ServiceContractStatus.READY_FOR_ACTIVATION.value()),
              serviceContractIds);
    }

    if (!Optional.ofNullable(serviceContract).isPresent()) {
      ServiceContract serviceContractEntity = null;
      if (!serviceContractIds.isEmpty())
        serviceContractEntity =
            serviceContractRepository.findLatestExpiredContract(serviceContractIds);

      if (Optional.ofNullable(serviceContractEntity).isPresent()) {

        ApplicationConfig gracePeriod =
            applicationConfigRepository.findByCategoryAndKeyAndStatus(
                Constants.GRACE_PERIOD,
                Constants.SERVICE_CONTRACT_GRACE_PERIOD_VALUE,
                Constants.ACTIVE);

        Date endDate = new Date(serviceContractEntity.getEndDate().getTime());
        Date now = new Date();

        long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - endDate.getTime());
        isContractValid = diffInDays < Long.valueOf(gracePeriod.getValue());
      }
    }
    return isContractValid;
  }

  private boolean isDeviceActive(Device device) {
    return !(Objects.isNull(device) || device.isDeleted()) && device.isStatus();
  }

  private UserProfile getActiveUserProfileForEmailAndRole(String email, long roleId) {

    UserProfile userProfile = null;

    if (StringUtils.isNotBlank(email)) {
      List<UserProfile> profile =
          userRepository.findAllByEmailAndRole_RoleIdAndStatusAndDeleted(
              email, roleId, Constants.ACTIVE, false);
      if (1 == profile.size()) userProfile = profile.get(0);
    }

    return userProfile;
  }

  /**
   * Creating service request. Made changes as per NCIOT-12313.
   *
   * @param selfRegistrationDTO
   * @param device
   * @throws CustomHttpClientErrorException
   * @throws CustomHttpServerErrorException
   * @throws CustomSMException
   * @throws IOException
   */
  private void createServiceRequest(ServiceMaxDTO serviceMaxDTO)
      throws CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException {
    ;
    ResponseEntity<String> response = createServiceMaxServiceRequest(serviceMaxDTO);
    Map<String, Object> responseMap =
        new ObjectMapper().readValue(response.getBody(), HashMap.class);
    LOGGER.info("response {}", responseMap);
  }

  /**
   * This method will be used for validating the input values provided by the self registered user.
   * And based on the serialno the role of interest will be generated for customer and distributor
   * roles.
   */
  @Override
  public List<RoleOfInterest> selfRegistrationValidation(
      SelfRegistrationDTO selfRegistrationDTO, String sessionId)
      throws CustomException,
          DataValidationException,
          AuthenticationException,
          MessagingException,
          EmailException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          CustomSMException,
          IOException,
          JSONException,
          RestClientException,
          FailedDependencyException,
          ParseException {

    LOGGER.info(
        "Start selfRegistrationValidation for email --> {}, serialNo --> {}",
        selfRegistrationDTO.getEmail(),
        selfRegistrationDTO.getSerialNo());

    // captcha validation code NCIOT-16342
    try {
      final boolean isValidCaptcha =
          validateCaptchaService.validateCaptcha(
              selfRegistrationDTO.getCaptchaResponse(), recaptchaEndpoint, recaptchaSecret);
      if (!isValidCaptcha) {
        LOGGER.info("Throwing exception as the captcha is invalid.");
        throw new DataValidationException(CustomErrorCodes.INVALID_CAPTCHA);
      }
    } catch (Exception ex) {
      LOGGER.error("Exception occured while validating captcha", ex);
    }

    UserProfile userProfile = userRepository.getUserByEmail(selfRegistrationDTO.getEmail());

    Country country = countryRepository.findByCountryCode(selfRegistrationDTO.getCountryCode());

    selfRegistrationValidator.selfRegistrationValidator(userProfile, country, selfRegistrationDTO);

    if (StringUtils.isNotBlank(selfRegistrationDTO.getPhone())
        || StringUtils.isNotBlank(selfRegistrationDTO.getIsdCode())) {
      phoneNumberValidator.validatePhoneNumberFormat(
          selfRegistrationDTO.getIsdCode(), selfRegistrationDTO.getPhone());
    }

    serialNumberValidator.validateSerialNumberPattern(selfRegistrationDTO.getSerialNo());

    Device device =
        deviceRepository.findBySerialnoAndStatusAndDeleted(
            selfRegistrationDTO.getSerialNo(), true, false);
    isDevicePresent(device, selfRegistrationDTO);

    List<RoleOfInterest> roleOfInterest = null;
    Organization org = null;
    if (Optional.ofNullable(device).isPresent() && Boolean.TRUE.equals(device.isDealer())) {
      LOGGER.info(
          "Device belongs to Distributor org serial number --> {} and isDealer --> {}",
          device.getSerialno(),
          device.isDealer());
      isShippedDeviceValid(device, selfRegistrationDTO);
      List<Integer> orgIdList =
          organizationRepository.findOrgIdForDistributorDevice(device.getDeviceId());
      if (!CollectionUtils.isEmpty(orgIdList)) {
        if (orgIdList.size() != 1) {
          LOGGER.info("Invalid org for Distributor");
          throw new DataValidationException(CustomErrorCodes.INVALID_ORGANIZATION);
        }
        org = fetchDistributorOrg(orgIdList.get(0));
        selfRegistrationDTO.setOrgId(orgIdList.get(0)); // setting the orgId
        roleOfInterest =
            roleOfInterestRepository.findRoleOfInterestByOrgType(Constants.DISTRIBUTOR_ROLE);
      }
    } else {
      LOGGER.info(
          "Device belongs to customer org serial number --> {} and isDealer --> {}",
          device.getSerialno(),
          device.isDealer());
      String orgName = deviceValidation(device, selfRegistrationDTO);
      org = fetchCustomerOrg(orgName);
      selfRegistrationDTO.setOrgId(org.getId()); // setting the orgId
      roleOfInterest =
          roleOfInterestRepository.findRoleOfInterestByOrgType(Constants.CUSTOMER_ROLE);
    }
    orgValidation(org, selfRegistrationDTO, device);
    LOGGER.info("the session information..:" + sessionId);
    selfRegistrationStore.addSelfRegistrationMap(sessionId, selfRegistrationDTO);

    return roleOfInterest;
  }

  public String deviceValidation(Device device, SelfRegistrationDTO selfRegistrationDTO)
      throws DataValidationException,
          RestClientException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          FailedDependencyException,
          CustomSMException,
          IOException,
          JSONException {
    String orgName = null;

    if (isDeviceValid(device, selfRegistrationDTO)) {
      if (StringUtils.isNotBlank(device.getSoldTo())
          && StringUtils.isNotBlank(device.getBillTo())) {
        orgName =
            Constants.ORG_CAPITAL
                .concat("_")
                .concat(device.getSoldTo())
                .concat("_")
                .concat(device.getBillTo());
      }
    } else {

      Set<Long> serviceContractIds =
          coveredProductRepository.findServiceContractIdByDeviceIdAndServiceLevel(
              device.getDeviceId(), Constants.CP_SERVICE_LEVEL);

      ServiceContract serviceContract =
          serviceContractRepository.getByServiceContractStatusInAndServiceContractIdIn(
              Arrays.asList(
                  ServiceContractStatus.ACTIVE.value(),
                  ServiceContractStatus.ACITVE_RENEWAL_CREATED.value(),
                  ServiceContractStatus.ACTIVE_PENDING_RENEWAL.value(),
                  ServiceContractStatus.READY_FOR_ACTIVATION.value()),
              serviceContractIds);

      if (Optional.ofNullable(serviceContract).isPresent()) {
        if (StringUtils.isNotBlank(serviceContract.getSoldTo())
            && StringUtils.isNotBlank(serviceContract.getBillTo())) {
          orgName =
              Constants.ORG_CAPITAL
                  .concat("_")
                  .concat(serviceContract.getSoldTo())
                  .concat("_")
                  .concat(serviceContract.getBillTo());
        }
      } else {

        ServiceContract serviceContractEntity =
            serviceContractRepository.findLatestExpiredContract(serviceContractIds);
        if (StringUtils.isNotBlank(serviceContractEntity.getSoldTo())
            && StringUtils.isNotBlank(serviceContractEntity.getBillTo())) {
          orgName =
              Constants.ORG_CAPITAL
                  .concat("_")
                  .concat(serviceContractEntity.getSoldTo())
                  .concat("_")
                  .concat(serviceContractEntity.getBillTo());
        }
      }
    }
    return orgName;
  }

  public Organization orgValidation(
      Organization org, SelfRegistrationDTO selfRegistrationDTO, Device device)
      throws EmailException,
          RestClientException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          FailedDependencyException,
          CustomSMException,
          IOException,
          JSONException,
          DataValidationException {
    if (Optional.ofNullable(org).isPresent()) {
      LOGGER.info("Organization is listed {}", org);
      if (Boolean.TRUE.equals(org.getStatus())) {
        LOGGER.info("Organization status is active {}", org);
      } else {
        sendEmail(selfRegistrationDTO);
        if (!checkIfServiceRequestAlreadyCreated(selfRegistrationDTO)) {
          createServiceRequest(selfRegistrationDTO, device);
        }
        throw new DataValidationException(CustomErrorCodes.ORGANIZATION_DEACTIVATED);
      }
    } else {
      sendEmail(selfRegistrationDTO);
      LOGGER.error("Org not found for serial number --> {}", selfRegistrationDTO.getSerialNo());
      throw new DataValidationException(CustomErrorCodes.ORGANIZATION_NOT_FOUND);
    }
    return org;
  }

  /**
   * This method is to get the CustomerOrg by name.
   *
   * @param orgName name of the organization
   * @return Organization
   */
  private Organization fetchCustomerOrg(String orgName) {
    Organization org =
        organizationRepository.findByNameAndTypeAndParentIdAndDeleted(
            orgName,
            Constants.CUSTOMER,
            organizationRepository.findIdByName(Constants.LABWATER),
            false);
    return org;
  }

  /**
   * This method is to get the DistributorOrg by Id.
   *
   * @param orgId id of the organization
   * @return Organization
   */
  private Organization fetchDistributorOrg(int orgId) {
    Organization org = organizationRepository.findOrg(orgId);
    return org;
  }

  private void isShippedDeviceValid(Device device, SelfRegistrationDTO selfRegistrationDTO)
      throws DataValidationException,
          RestClientException,
          CustomHttpClientErrorException,
          CustomHttpServerErrorException,
          FailedDependencyException,
          CustomSMException,
          IOException,
          JSONException {
    if (device.getInstalledDate() == null && device.getShippedDate() != null) {
      if (!checkIfServiceRequestAlreadyCreated(selfRegistrationDTO)) {
        createServiceRequest(selfRegistrationDTO, device);
      }
      LOGGER.info("Device is not valid as its not installed {}", device.getDeviceId());
      throw new DataValidationException(CustomErrorCodes.SHIPPED_DEVICE_NOT_VALID);
    }
  }
}
