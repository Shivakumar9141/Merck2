package com.merck.nextconnect.userhub.authentication;

import com.merck.nextconnect.userhub.model.Login;

public interface IAuthRepository {

  /**
   * Authenticate
   *
   * @param login - login attributes
   * @return authenticated
   */
  boolean authenticate(Login login);
}
