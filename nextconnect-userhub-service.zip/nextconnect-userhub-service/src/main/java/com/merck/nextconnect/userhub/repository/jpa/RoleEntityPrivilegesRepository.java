package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.RoleEntityPrivilege;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * interface talks with RoleEntityPrivilege table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface RoleEntityPrivilegesRepository extends JpaRepository<RoleEntityPrivilege, Long> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.role.RolePrivilege(r.privilege.privilegeId,r.privilege.operation,r.entities.entityId,r.privilege.resourceType)"
          + " from RoleEntityPrivilege r  where r.role.roleId = :roleId")
  List<RolePrivilege> getPrivileges(@Param("roleId") long roleId);

  @Query("select r.privilege.operation from RoleEntityPrivilege r  where r.role.roleId = :roleId")
  List<String> getPrivilegeList(@Param("roleId") long roleId);

  @Modifying
  @Transactional
  long deleteByRoleAndPrivilegeAndEntities(Role roles, Privilege privileges, Entities entities);

  @Modifying
  @Transactional
  long deleteByPrivilege(Privilege privileges);

  @Modifying
  @Transactional
  @Query("delete from RoleEntityPrivilege r where r.role.roleId = :roleId")
  int deleteByRoleId(@Param("roleId") long roleId);

  @Query(
      "select Count(r) != 0 From RoleEntityPrivilege r where r.privilege.operation = :operation and r.role.roleId = :roleId")
  boolean hasCoveredTerritoryAccess(
      @Param("operation") String operation, @Param("roleId") long roleId);

  // NCIOT-16412
  @Modifying
  @Transactional
  @Query(
      "delete from RoleEntityPrivilege r where r.role.roleId in :roleId and r.privilege.privilegeId = :privilegeId and r.entities.entityId = :entityId")
  int deleteCustomerRoleEntityPrivilege(
      @Param("roleId") List<Long> roleId,
      @Param("privilegeId") long privilegeId,
      @Param("entityId") long entityId);
}
