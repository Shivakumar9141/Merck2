package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupAccess;
import com.merck.nextconnect.userhub.model.privilege.DeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.model.role.RoleInfo;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * interface to perform role operations
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface IRoles {

  /**
   * add a role
   *
   * @param role - role (roleName,roleDesc)
   * @return roleId
   * @throws DuplicateResourceException
   * @throws DataValidationException
   */
  long add(RoleInfo roleInfo) throws DuplicateResourceException, DataValidationException;

  /**
   * delete a role
   *
   * @param roleId - id of the role
   * @throws DataValidationException
   */
  void delete(long roleId) throws DataValidationException;

  /**
   * get all roles
   *
   * @return List<role>
   * @throws ResourceNotFoundException
   */
  List<Role> getAll(Integer orgId) throws ResourceNotFoundException;

  /**
   * update a role
   *
   * @param roleInfo
   * @param roleId
   * @throws DataValidationException
   * @throws DuplicateResourceException
   * @throws ResourceNotFoundException
   */
  void update(RoleInfo roleInfo, long roleId)
      throws DataValidationException, DuplicateResourceException, ResourceNotFoundException;

  /**
   * get a role
   *
   * @return role
   */
  Role fetchOne(long roleId);

  /**
   * get all privileges of role
   *
   * @param roleId - roleId
   * @param filterBy - filter criteria(entity,devicetype,devicegroup)
   * @return rolePrivileges - privileges of the role
   * @throws ResourceNotFoundException
   */
  List<RolePrivilege> getPrivileges(long roleId, String filterBy) throws ResourceNotFoundException;

  /**
   * adding privileges to a role
   *
   * @param roleId - roleId
   * @param resourcePrivileges - privileges and resources
   */
  void addPrivileges(long roleId, List<ResourcePrivilege> resourcePrivileges);

  /**
   * delete privileges to a role
   *
   * @param roleId - roleId
   * @param resourcePrivileges - privileges and resources
   */
  void deletePrivileges(long roleId, List<ResourcePrivilege> resourcePrivileges);

  /**
   * get all devicegroup privileges of role
   *
   * @param roleId - roleId
   * @param deviceTypeId - deviceTypeId
   * @return DeviceGroupPrivilege - privileges of the devicegroup
   * @throws ResourceNotFoundException
   */
  DeviceGroupPrivilege getDeviceGroupPrivileges(long roleId, long deviceTypeId)
      throws ResourceNotFoundException;

  /**
   * adding devicegroup privileges to a role
   *
   * @param roleId - roleId
   * @param resourcePrivileges - deviceGroup privileges and resources
   */
  void addDeviceGroupPrivileges(long roleId, List<DeviceGroupAccess> deviceGroupAccess);

  /**
   * delete devicegroup privileges to a role
   *
   * @param roleId - roleId
   * @param deviceGroupAccess - deviceGroup privileges and resources
   */
  void deleteDeviceGroupPrivileges(long roleId, List<DeviceGroupAccess> deviceGroupAccess);

  /**
   * NCIOT-16412 get all privileges for role
   *
   * @param roleId
   * @return
   * @throws ResourceNotFoundException
   */
  List<RolePrivilege> getPrivileges(long roleId) throws ResourceNotFoundException;
}
