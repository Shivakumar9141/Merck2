package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.utils.common.entities.Language;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * interface talks with UserProfile table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public interface UserRepository
    extends JpaRepository<UserProfile, Long>, JpaSpecificationExecutor<UserProfile> {

  @Transactional
  @Modifying
  @Query(
      "UPDATE UserProfile u SET u.firstName = :firstName , u.lastName = :lastName , u.isdCode =:isdCode, u.phone = :phone , u.country.id = :country , u.status = :status , u.dateFormat.id = :dateformat ,u.language.id =:language,u.consentStatus =:consentStatus,u.consentTS =:consentTS,u.privacyPolicyStatus=:privacyPolicyStatus , u.timeZoneId = :timeZone, u.platformSubscription = :platformSubscription where "
          + "u.userId = :id and u.org.id = :org and u.deleted=false")
  int updateUser(
      @Param("id") long id,
      @Param("firstName") String firstName,
      @Param("lastName") String lastName,
      @Param("isdCode") String isdCode,
      @Param("phone") String phone,
      @Param("country") int country,
      @Param("status") String status,
      @Param("dateformat") int dateformat,
      @Param("language") int language,
      @Param("consentStatus") boolean consentStatus,
      @Param("consentTS") Timestamp consentTS,
      @Param("privacyPolicyStatus") boolean privacyPolicyStatus,
      @Param("org") int org,
      @Param("timeZone") int timeZone,
      @Param("platformSubscription") boolean platformSubscription);

  @Query(
      "from UserProfile u where "
          + "u.email = :email and u.deleted=false order by u.userId desc limit 1")
  UserProfile getUserByEmail(@Param("email") String email);

  @Query(
      "from UserProfile u where "
          + "lower(u.loginName) = lower(:loginName) and u.userDomain.authenticationProvider = :loginType and u.org.id = :org and u.deleted=false order by u.userId desc limit 1")
  UserProfile getUser(
      @Param("loginName") String loginName,
      @Param("loginType") String loginType,
      @Param("org") int org);

  @Query(
      "from UserProfile u where "
          + "lower(u.loginName) = lower(:loginName) and u.userDomain.authenticationProvider = :loginType and u.deleted=false order by u.userId desc limit 1")
  UserProfile getUserWithOutOrg(
      @Param("loginName") String loginName, @Param("loginType") String loginType);

  @Transactional
  @Modifying
  @Query(
      "UPDATE UserProfile u SET u.status = :status where " + "u.userId = :id and u.deleted=false")
  int updateUserStatus(@Param("id") long id, @Param("status") String status);

  @Transactional
  @Modifying
  @Query(
      "UPDATE UserProfile u SET u.role.roleId = :roleId where "
          + "u.userId = :id and u.deleted=false")
  int updateUserRole(@Param("id") long id, @Param("roleId") long roleId);

  @Query(
      "from UserProfile u where "
          + "u.role.roleId = :roleId and u.org.id = :org and u.deleted=false")
  List<UserProfile> getUsersByRole(@Param("roleId") long roleId, @Param("org") int org);

  @Query(
      "select u.userDomain.domainName from UserProfile u where "
          + "u.loginName = :loginText and u.deleted=false")
  List<String> getLoginTypes(@Param("loginText") String loginText);

  @Query(
      "from UserProfile u where "
          + "u.userId = :id and u.deleted=false and (u.org.id = :org or u.createdRole = :createdRole)")
  UserProfile getUserById(
      @Param("id") long id, @Param("org") int org, @Param("createdRole") long createdRole);

  @Query(
      "from UserProfile u where "
          + "u.userId = :id and u.deleted=false and (u.org.id in :accessibleOrgs)")
  UserProfile getUserById(
      @Param("id") long id, @Param("accessibleOrgs") List<Integer> accessibleOrgs);

  @Query("from UserProfile u where " + "u.userId = :id and u.deleted=false")
  UserProfile getUserById(@Param("id") long id);

  @Transactional
  @Modifying
  @Query(
      "UPDATE UserProfile u SET u.role.roleId = null where "
          + "u.role.roleId = :id and u.org.id = :org and u.deleted=true")
  int removeDeletedUsersRole(@Param("id") long id, @Param("org") int org);

  public UserProfile findByEmailAndStatus(String eamil, String status);

  @Query("Select usr.email from UserProfile usr where email LIKE :email%")
  public List<String> findByEmailStartingWithIgnoreCase(@Param("email") String email);

  List<UserProfile> findByEmailAndStatusAndDeleted(String mailId, String string, Boolean i);

  @Query(
      "Select usr.email from UserProfile usr where email LIKE ?1% and org.id=?2 and status= ?3 and deleted= ?4")
  List<String> findEmailsByOrgIdAndStatusAndDeleted(
      String email, int orgId, String status, boolean deleted);

  @Query(
      "Select usr.email from UserProfile usr where email=?1 and org.id=?2 and status= ?3 and deleted= ?4")
  List<String> findEmailByOrgIdAndStatusAndDeleted(
      String email, int orgId, String status, boolean deleted);

  @Query(
      "from UserProfile u where "
          + "u.role.roleId = :roleId and u.org.id = :org and u.deleted=false and u.status = 'Active' ")
  List<UserProfile> getUsersByRoleAndActive(@Param("roleId") long roleId, @Param("org") int org);

  @Query("select count(u) != 0 from UserProfile u where u.org.id = :orgId and u.deleted = false")
  boolean hasUsers(@Param("orgId") int orgId);

  @Transactional
  @Modifying
  @Query(
      "UPDATE UserProfile u SET u.invitedOrActivatedTs = :invitedTs, u.status='Pending' where u.userId = :id and u.deleted=false")
  int updateInvitedTs(@Param("id") long id, @Param("invitedTs") Date invitedTs); // NCIOT-16292

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param roleIds
   * @param org
   * @return List<userProfile>
   */
  @Query(
      "from UserProfile u where "
          + "u.role.roleId = :roleId and u.org.id = :org and u.deleted=false and u.status = 'Active' ")
  List<UserProfile> getUsersByRoleIdsAndActive(
      @Param("roleId") long roleIds, @Param("org") int org);

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userId
   * @param isDeleted
   * @param status
   * @return UserProfile
   */
  UserProfile findByUserIdAndDeletedAndStatus(long userId, boolean isDeleted, String status);

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userId
   * @param valid
   */
  @Transactional
  @Modifying
  @Query("update UserProfile u set u.isValidated = :valid where u.userId = :userId")
  void updateUserValidatedByUserId(@Param("userId") long userId, @Param("valid") boolean valid);

  /**
   * Made changes as per NCIOT-12010.
   *
   * @param userId
   * @param isDeleted
   */
  @Transactional
  @Modifying
  @Query("update UserProfile u set u.deleted = :isDeleted where u.userId = :userId")
  void deleteUserByUserId(@Param("userId") long userId, @Param("isDeleted") boolean isDeleted);

  UserProfile findByUserIdAndStatusAndDeleted(Long id, String status, boolean deleted);

  @Query(
      value =
          "select * from nc_user_profile where role_id = :roleId and org_id = :org and deleted=false and status = 'Active' order by created_on asc limit 1",
      nativeQuery = true)
  UserProfile getOldestActiveUsersByRoleIdsAndActive(
      @Param("roleId") long roleId, @Param("org") int org);

  List<UserProfile> findAllByEmailAndRole_RoleIdAndStatusAndDeleted(
      String mailId, long roleId, String string, Boolean deleted);

  @Query(
      "select count(u) != 0 from UserProfile u where u.userId != :userId and u.org.type = :type and u.org.id = :orgId and u.deleted=false and u.role.name = :roleName")
  boolean checkOtherAdminUsers(
      @Param("userId") long userId,
      @Param("orgId") int orgId,
      @Param("type") String type,
      @Param("roleName") String roleName);

  /**
   * @param orgId
   * @param isDeleted
   * @return List<UserProfile>
   */
  List<UserProfile> findByOrgIdAndDeleted(int orgId, boolean isDeleted);

  /**
   * Method to find Distributor FSE of organisation
   *
   * @param orgId
   * @return Distributor FSE
   */
  @Query(
      value =
          "SELECT p.* FROM nc_app.nc_user_profile p join nc_app.nc_roles r on r.role_id = p.role_id WHERE p.status = 'Active' AND p.deleted = false AND r.name IN ('Distributor FSE', 'Distributor Admin') AND r.org_id = :orgId",
      nativeQuery = true)
  List<UserProfile> findDistributorRoles(@Param("orgId") int orgId);

  @Query(
      value =
          "select * from nc_user_profile where role_id = :roleId and org_id = :org and deleted=false and status = 'Inactive' order by created_on asc limit 1",
      nativeQuery = true)
  UserProfile getOldestInactiveUsersByRoleIdsAndActive(
      @Param("roleId") long roleId, @Param("org") int org);

  @Query("select u.language from UserProfile u where u.userId = :userId")
  public Language getLanguageId(@Param("userId") Long userId);

  @Query(
      value =
          "select * from nc_user_profile where org_id = :orgId and status = 'Active' and deleted=false order by created_on asc",
      nativeQuery = true)
  List<UserProfile> findByOrgIdAndStatus(@Param("orgId") int orgId);
}
