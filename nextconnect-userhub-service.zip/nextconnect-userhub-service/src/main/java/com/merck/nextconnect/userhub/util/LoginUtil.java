package com.merck.nextconnect.userhub.util;

import com.merck.nextconnect.userhub.constants.UserhubConstants;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.utils.email.entities.ApplicationConfig;
import com.merck.nextconnect.utils.file.repository.jpa.ApplicationConfigRepository;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.xml.SAMLSchemaBuilder;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.parse.XMLParserException;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

@Component
public class LoginUtil {

  static final Logger logger = LoggerFactory.getLogger(LoginUtil.class);

  @Autowired ApplicationConfigRepository applicationConfigRepository;

  /**
   * validates SAML response XML structure, before parsing the response
   *
   * @param samlResponse
   * @return
   */
  public Response validateAndParseSamlResponse(String samlResponse) {
    logger.info("LoginUtil -> validateAndParseSamlResponse start");
    Response response = null;
    try {
      Document document = getDocumentForSamlResponseString(samlResponse);
      // validate XML
      if (samlDomStructureValidation(document)) response = parseSamlResponse(document);
    } catch (ConfigurationException | SAXException | XMLParserException ex) {
      logger.error("LoginUtil -> validateAndParseSamlResponse" + ex.getMessage());
    }
    logger.info("LoginUtil -> validateAndParseSamlResponse end");
    return response;
  }

  public Response parseSamlResponse(Document document) {
    logger.debug("LoginUtil -> parseSamlResponse start");
    Response response = null;
    /* initialize the opensaml library */
    try {
      Element element = document.getDocumentElement();
      /* Unmarsharing SAML response */
      UnmarshallerFactory unmarshallerFactory = Configuration.getUnmarshallerFactory();
      Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(element);
      XMLObject responseXmlObj = unmarshaller.unmarshall(element);
      response = (Response) responseXmlObj;
      logger.debug("LoginUtil -> parseSamlResponse end");
    } catch (UnmarshallingException ex) {
      logger.error("LoginUtil -> parseSamlResponse" + ex.getMessage());
    }
    return response;
  }

  public BasicX509Credential getCredential() {
    logger.info("LoginUtil -> getCredential start");
    BasicX509Credential publicCredential = null;
    try {
      /* get the certificate file */
      ApplicationConfig applicationConfig =
          applicationConfigRepository.findByCategoryAndKeyAndStatus(
              UserhubConstants.SINGLE_SIGN_ON,
              UserhubConstants.PUBLIC_KEY,
              UserhubConstants.ACTIVE);
      String wrappedCert =
          "-----BEGIN CERTIFICATE-----\n"
              + applicationConfig.getValue()
              + "\n-----END CERTIFICATE-----";
      CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
      InputStream stream = new ByteArrayInputStream(wrappedCert.getBytes(StandardCharsets.UTF_8));
      X509Certificate certificate =
          (X509Certificate) certificateFactory.generateCertificate(stream);
      stream.close();
      /* pull out the public key part of the certificate into a KeySpec */
      X509EncodedKeySpec publicKeySpec =
          new X509EncodedKeySpec(certificate.getPublicKey().getEncoded());
      /* get KeyFactory object that creates key objects, specifying SHA256withRSA */
      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
      // generate public key to validate signatures
      PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
      /* create credentials */
      publicCredential = new BasicX509Credential();
      /* add public key value */
      publicCredential.setPublicKey(publicKey);
      logger.info("creadential created succussfully by using public certficate");
      logger.info("LoginUtil -> getCredential end");
    } catch (CertificateException
        | IOException
        | NoSuchAlgorithmException
        | InvalidKeySpecException ex) {
      logger.error("LoginUtil -> getCredential" + ex.getMessage());
    }
    return publicCredential;
  }

  public boolean validateLoginRequest(Login login) {
    boolean validateStatus = true;
    if (login == null) {
      validateStatus = false;
    }
    if (login != null
        && (login.getUsername() == null
            || login.getPassword() == null
            || login.getUserdomain() == null)) {
      validateStatus = false;
    }
    return validateStatus;
  }

  private Document getDocumentForSamlResponseString(String samlResponse)
      throws ConfigurationException, SAXException, XMLParserException {
    DefaultBootstrap.bootstrap();
    Schema schema = SAMLSchemaBuilder.getSAML11Schema();
    /* get parser pool manager */
    BasicParserPool parserPoolManager = new BasicParserPool();
    parserPoolManager.setNamespaceAware(true);
    parserPoolManager.setIgnoreElementContentWhitespace(true);
    parserPoolManager.setSchema(schema);
    byte[] base64DecodedResponse = Base64.decode(samlResponse);
    ByteArrayInputStream inputStream = new ByteArrayInputStream(base64DecodedResponse);
    return parserPoolManager.parse(inputStream);
  }

  /**
   * OpenSAML XML Validation
   *
   * @see <a
   *     href="https://shibboleth.atlassian.net/wiki/spaces/OpenSAML/pages/1573289995/OSTwoUserManJavaValidation#">XML
   *     Validation</a>
   */
  private boolean samlDomStructureValidation(Document document) {
    boolean isStructureValid = false;
    logger.info("LoginUtil -> samlDomStructureValidation --> started");
    try {
      Schema schema = SAMLSchemaBuilder.getSAML11Schema();
      Validator xmlValidator = schema.newValidator();
      DOMSource dom = new DOMSource(document);
      xmlValidator.validate(dom);
      isStructureValid = true;
    } catch (SAXException | IOException ex) {
      logger.error("LoginUtil -> samlDomStructureValidation --> {}", ex.getMessage());
    }
    logger.info("LoginUtil -> samlDomStructureValidation --> ended");
    return isStructureValid;
  }
}
