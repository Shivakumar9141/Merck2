package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.resources.IRegion;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.utils.common.entities.Region;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
@RequestMapping("/api/regions")
public class RegionController {

  @Autowired private IRegion iRegion;

  @Operation(description = "List of Regions", tags = "Regions")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET)
  public ResponseEntity<List<Region>> getRegions(
      @Parameter(
              name = "searchBy",
              description = "search category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy) {
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.Region, Constants.GET, null));
    if (searchBy == null) {
      searchBy = Constants.EMPTY_STRING;
    }
    return new ResponseEntity<>(iRegion.getRegions(searchBy), HttpStatus.OK);
  }
}
