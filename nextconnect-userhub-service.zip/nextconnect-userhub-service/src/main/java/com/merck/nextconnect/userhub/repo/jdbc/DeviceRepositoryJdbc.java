package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.model.DeviceDTO;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author tah
 *     <p>This class is for JDBC Template implementation to use native sql
 */
@Repository
public class DeviceRepositoryJdbc {

  static final Logger LOGGER = LoggerFactory.getLogger(DeviceRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  String SQL_SELECT_SM_DEVICE_ID =
      "select d.sm_device_id from nc_devices d where d.device_id = :deviceId and d.deleted = false";

  public List<DeviceDTO> findSmDeviceIdByDeviceId(Long deviceId) {

    List<DeviceDTO> deviceDTOList = new ArrayList<DeviceDTO>();

    if (deviceId == null) {
      return deviceDTOList;
    }

    try {
      MapSqlParameterSource parameters = new MapSqlParameterSource();
      parameters.addValue("deviceId", deviceId);
      deviceDTOList =
          namedParameterJdbcTemplate.query(
              SQL_SELECT_SM_DEVICE_ID,
              parameters,
              (rs, rowNum) ->
                  DeviceDTO.builder().smDeviceId(rs.getString("d.sm_device_id")).build());
    } catch (Exception e) {
      LOGGER.error("Exception occured in findSmDeviceIdByDeviceId while calling DB", e);
    }

    return deviceDTOList;
  }
}
