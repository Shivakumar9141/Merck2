/*package com.merck.nextconnect.userhub.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "nc_subscription_category_event_mapping")
public class SubscriptionCategoryEventMap implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "subscription_category_event_id")
	private Long subscriptionCategoryEventId;
	@OneToOne
	private SubscriptionCategory subscriptionCategory; //subscription_category_id
	@OneToOne
	private VarInfo varInfo;//event_id

	@Column(name = "status")
	private String status;
	@Column(name = "remarks")
	private String remarks;

	@Column(name = "created_ts")
	private Timestamp createdTimestamp;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "last_updated_by")
	private String lastUpdatedBy;
	@Column(name = "last_updated_ts")
	private Timestamp lastUpdatedTimestamp;



}
*/
