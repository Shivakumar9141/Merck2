package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.OrgSettings;
import com.merck.nextconnect.userhub.model.org.OrgSettingsDto;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgSettingsRepository extends JpaRepository<OrgSettings, Integer> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.org.OrgSettingsDto(r.logo,r.theme,r.appName)"
          + " from OrgSettings r  where r.org.id = :orgId")
  OrgSettingsDto getOrgSettings(@Param("orgId") int orgId);

  @Transactional
  @Modifying
  @Query(
      "update OrgSettings os set os.historicalDataSubscription = :historicalDataSubscription where os.org.id = :orgId")
  void update(
      @Param("orgId") int orgId,
      @Param("historicalDataSubscription") Long historicalDataSubscription);

  /**
   * Made changes as per NCIOT-11283.
   *
   * @param orgId
   */
  @Query("select os.historicalDataSubscription from OrgSettings os where os.org.id = :orgId")
  Long findHistoricalDataSubscriptionByOrgId(@Param("orgId") int orgId);
}
