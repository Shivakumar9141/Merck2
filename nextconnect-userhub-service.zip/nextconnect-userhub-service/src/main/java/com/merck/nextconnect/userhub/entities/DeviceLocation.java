package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "nc_device_location")
public class DeviceLocation {

  @Id
  @Column(name = "location_id")
  private Long locationId;

  @Column(name = "location_name")
  private String locationName;

  public DeviceLocation() {}

  public Long getLocationId() {
    return locationId;
  }

  public void setLocationId(Long locationId) {
    this.locationId = locationId;
  }

  public String getLocationName() {
    return locationName;
  }

  public void setLocationName(String locationName) {
    this.locationName = locationName;
  }
}
