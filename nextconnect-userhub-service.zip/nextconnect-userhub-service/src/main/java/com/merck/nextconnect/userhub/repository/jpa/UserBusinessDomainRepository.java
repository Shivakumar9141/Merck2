package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.UserBusinessDomain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UserBusinessDomainRepository extends JpaRepository<UserBusinessDomain, Long> {

  // NCIOT-1696
  @Transactional
  @Modifying
  @Query(
      "UPDATE UserBusinessDomain u SET u.businessDomain.domainId = :domainId where "
          + "u.userId = :userId ")
  void updateBusinessDomainForUser(@Param("domainId") int domainId, @Param("userId") Long userId);

  @Query("from UserBusinessDomain u where" + " u.userId = :userId ")
  UserBusinessDomain findByUserId(@Param("userId") Long userId);
}
