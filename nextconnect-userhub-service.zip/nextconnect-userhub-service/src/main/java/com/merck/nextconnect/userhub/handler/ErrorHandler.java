package com.merck.nextconnect.userhub.handler;

import com.merck.nextconnect.authfilter.exception.CustomAuthenticationException;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.FailedDependencyException;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.MethodNotAllowedException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.ErrorResponse;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ErrorHandler {

  static final Logger logger = LoggerFactory.getLogger(ErrorHandler.class);

  /**
   * @param ex - any Exception
   * @return - ErrorResponse
   */
  @ExceptionHandler(Exception.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(CustomErrorCodes.INTERNAL_SERVER_ERROR.getErrorCode());
    error.setErrorMessage(CustomErrorCodes.INTERNAL_SERVER_ERROR.getDescription());
    logger.error("Internal server error", ex);
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  /**
   * @param ex - custom Exception
   * @return - ErrorResponse
   */
  @ExceptionHandler(CustomException.class)
  public ResponseEntity<ErrorResponse> exceptionHandler(CustomException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    try {
      // custom mapping of error code to status code.
      // Based on the error code, status code can be configured if different status codes to be
      // returned for same exception
      return new ResponseEntity<ErrorResponse>(error, errorStatusMapping.get(ex.getErrorCode()));
    } catch (Exception e) {
      logger.error("Internal server error", e);
      return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * @param ex - LoginAuthenticationException
   * @return - ErrorResponse
   */
  @ExceptionHandler(LoginAuthenticationException.class)
  public ResponseEntity<ErrorResponse> loginexceptionHandler(LoginAuthenticationException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.UNAUTHORIZED);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public ResponseEntity<ErrorResponse> accessDeniedException(AccessDeniedException ex) {
    ErrorResponse error = new ErrorResponse();
    // error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.FORBIDDEN);
  }

  @ExceptionHandler(com.merck.nextconnect.userhub.exception.AccessDeniedException.class)
  public ResponseEntity<ErrorResponse> accessDeniedException(
      com.merck.nextconnect.userhub.exception.AccessDeniedException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.FORBIDDEN);
  }

  @ExceptionHandler(DuplicateResourceException.class)
  public ResponseEntity<ErrorResponse> duplicateResourceException(DuplicateResourceException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.CONFLICT);
  }

  @ExceptionHandler(FailedDependencyException.class)
  public ResponseEntity<ErrorResponse> failedDependencyException(FailedDependencyException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.FAILED_DEPENDENCY);
  }

  @ExceptionHandler(MethodNotAllowedException.class)
  public ResponseEntity<ErrorResponse> methodNotAllowedException(MethodNotAllowedException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.METHOD_NOT_ALLOWED);
  }

  /**
   * @param ex - DataValidationException
   * @return - ErrorResponse
   */
  @ExceptionHandler(DataValidationException.class)
  public ResponseEntity<ErrorResponse> dataValidationException(DataValidationException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.UNPROCESSABLE_ENTITY);
  }

  /**
   * @param ex - DataValidationException
   * @return - ErrorResponse
   */
  @ExceptionHandler(
      com.merck.nextconnect.utils.file.handler.exception.DataValidationException.class)
  public ResponseEntity<ErrorResponse> FileValidationExceptionHandler(
      com.merck.nextconnect.utils.file.handler.exception.DataValidationException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.UNPROCESSABLE_ENTITY);
  }

  /**
   * @param ex - ResourceNotFoundException
   * @return - ErrorResponse
   */
  @ExceptionHandler(ResourceNotFoundException.class)
  public ResponseEntity<ErrorResponse> resourceNotFoundException(ResourceNotFoundException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(CustomAuthenticationException.class)
  public ResponseEntity<ErrorResponse> customAuthenticationException(
      CustomAuthenticationException ex) {
    ErrorResponse error = new ErrorResponse();
    error.setErrorCode(ex.getErrorCode());
    error.setErrorMessage(ex.getMessage());
    return new ResponseEntity<ErrorResponse>(error, HttpStatus.UNAUTHORIZED);
  }

  // error code to status code mapping
  private static Map<String, HttpStatus> errorStatusMapping =
      Collections.unmodifiableMap(
          new HashMap<String, HttpStatus>() {
            {
              put(
                  CustomErrorCodes.ROLE_VALIDATION_ERROR.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(CustomErrorCodes.ROLE_NAME_CONFLICT.getErrorCode(), HttpStatus.CONFLICT);
              put(
                  CustomErrorCodes.EMAIL_SUBSCRIPTION_ERROR.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(CustomErrorCodes.USERS_EXIST_IN_ORG.getErrorCode(), HttpStatus.FORBIDDEN);
              put(CustomErrorCodes.CHILDERN_EXIST_FOR_ORG.getErrorCode(), HttpStatus.FORBIDDEN);
              put(CustomErrorCodes.USER_FEED_BACK_NOT_FOUND.getErrorCode(), HttpStatus.BAD_REQUEST);
              put(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY.getErrorCode(), HttpStatus.OK);
              put(
                  CustomErrorCodes.CUSTOMER_ALREADY_GIVEN_FEEDBACK.getErrorCode(),
                  HttpStatus.BAD_REQUEST);
              put(
                  CustomErrorCodes.INVALID_MENU_SEQUENCE.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(
                  CustomErrorCodes.ONLY_CUSTOMER_ADMIN_USER.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(
                  CustomErrorCodes.ONLY_PARTNER_ADMIN_USER.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(
                  CustomErrorCodes.ONLY_DISTRIBUTOR_ADMIN_USER.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(
                  CustomErrorCodes.DEVICES_ASSIGNED_TO_USER.getErrorCode(),
                  HttpStatus.UNPROCESSABLE_ENTITY);
              put(
                  CustomErrorCodes.INTERNAL_SERVER_ERROR.getErrorCode(),
                  HttpStatus.INTERNAL_SERVER_ERROR);
            }
          });
}
