package com.merck.nextconnect.userhub.model;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author clukose
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuUpdateRequest implements Serializable {
  /** */
  private static final long serialVersionUID = 4687708069598222293L;

  private int menuGroupId;
  private String menuGroupName;
  private List<MenuUpdate> menus;
}
