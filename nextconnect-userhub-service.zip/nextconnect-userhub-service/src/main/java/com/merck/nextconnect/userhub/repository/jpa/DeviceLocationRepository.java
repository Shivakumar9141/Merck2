package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.DeviceLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface DeviceLocationRepository extends JpaRepository<DeviceLocation, Long> {}
