package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.repository.jpa.DateFormatRepository;
import com.merck.nextconnect.userhub.resources.IDateFormat;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DateFormatImpl implements IDateFormat {

  @Autowired DateFormatRepository dateFormatRepo;

  @Override
  public List<DateFormat> getDateFormats() {
    return dateFormatRepo.findAll();
  }
}
