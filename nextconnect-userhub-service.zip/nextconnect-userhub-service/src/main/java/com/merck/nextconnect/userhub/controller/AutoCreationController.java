package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.resources.IAutoCreation;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.model.OrgAndUserDetail;
import com.merck.nextconnect.utils.model.OrgAndUserDetailResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author tah
 *     <p>Auto creation API controller.
 */
@Component
@RestController
@RequestMapping("/api/v1/auto")
public class AutoCreationController {

  static final Logger LOGGER = LoggerFactory.getLogger(AutoCreationController.class);

  @Autowired IAutoCreation autoCreation;

  /**
   * NCIOT-10531, NCIOT-10533 , NCIOT-10583
   *
   * @param orgAndUserDetail
   * @return
   * @throws DuplicateResourceException
   * @throws MessagingException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws ResourceNotFoundException
   * @throws CustomException
   */
  @Operation(description = "Create org and user", tags = "Auto")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(value = "org-and-user", method = RequestMethod.POST)
  @PreAuthorize("hasAuthority('create_org') and hasAuthority('create_user')")
  public ResponseEntity<OrgAndUserDetailResponse> createOrgAndUser(
      @Parameter(
              name = "org and user",
              description = "org and user details",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          OrgAndUserDetail orgAndUserDetail)
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          ResourceNotFoundException,
          CustomException {
    LOGGER.info("Start : createOrgAndUser API call");
    LOGGER.info("OrgAndUserDetail : {} ", orgAndUserDetail);
    OrgAndUserDetailResponse response = autoCreation.create(orgAndUserDetail);
    response.setDeviceId(orgAndUserDetail.getDeviceId());
    LOGGER.info("End : createOrgAndUser API call");
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
