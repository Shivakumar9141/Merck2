package com.merck.nextconnect.userhub.validator.impl;

import static com.merck.nextconnect.utils.validations.helper.StringValidationHelpers.notNullString;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.model.SelfRegistrationDTO;
import com.merck.nextconnect.userhub.validator.SelfRegistrationValidator;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.RoleOfInterest;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.file.util.CustomErrorCodes;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author SHATHWAR Made changes as per NCIOT-12313.
 */
@Service
public class SelfRegistrationValidatorImpl implements SelfRegistrationValidator {

  static final Logger LOGGER = LoggerFactory.getLogger(SelfRegistrationValidatorImpl.class);

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param Device
   * @param UserProfile
   * @param Country
   * @param SelfRegistrationDTO
   * @param RoleOfInterest
   */
  @Override
  public void selfRegistrationValidator(
      UserProfile userProfile,
      Country country,
      SelfRegistrationDTO selfRegistrationDTO,
      RoleOfInterest roleOfInterest)
      throws DataValidationException {

    notNullString.test(selfRegistrationDTO.getFirstName()).throwIfInvalid("First Name");
    notNullString.test(selfRegistrationDTO.getLastName()).throwIfInvalid("Last Name");
    notNullString.test(selfRegistrationDTO.getEmail()).throwIfInvalid("Email");

    if (Optional.ofNullable(userProfile).isPresent()) {
      LOGGER.info("User already exists");
      throw new DataValidationException(CustomErrorCodes.EMAIL_ALREADY_EXISTS);
    }
    notNullString.test(selfRegistrationDTO.getCountryCode()).throwIfInvalid("Country Code");
    notNullString.test(selfRegistrationDTO.getRoleOfInterest()).throwIfInvalid("Role of Interest");

    if (!Optional.ofNullable(country).isPresent()) {
      LOGGER.info(
          "Country not present in NextConnect with country code provided --> {}",
          selfRegistrationDTO.getCountryCode());
      throw new DataValidationException(CustomErrorCodes.INVALID_COUNTRY_CODE);
    }
    if (!Optional.ofNullable(roleOfInterest).isPresent()) {
      LOGGER.info("Role of interest is not found {}", selfRegistrationDTO.getRoleOfInterest());
      throw new DataValidationException(CustomErrorCodes.ROLE_OF_INTERESET_NOT_FOUND);
    }
  }

  @Override
  public void selfRegistrationUserValidationValidator(
      UserProfile userProfileOfSelfRegisteredUser, UserProfile userProfileOfUserValidating)
      throws DataValidationException {
    if (!Optional.ofNullable(userProfileOfSelfRegisteredUser).isPresent()) {
      LOGGER.info("User not found");
      throw new DataValidationException(CustomErrorCodes.USER_NOT_FOUND);
    }
    if (!UserInvitedVia.SELF_REGISTRATION
        .value()
        .equalsIgnoreCase(userProfileOfSelfRegisteredUser.getInvitedVia())) {
      LOGGER.info("User is not self registered.");
      throw new DataValidationException(CustomErrorCodes.USER_IS_NOT_SELF_REGISTERED);
    }
    if (!Optional.ofNullable(userProfileOfUserValidating).isPresent()) {
      LOGGER.info("User not found");
      throw new DataValidationException(CustomErrorCodes.USER_NOT_FOUND);
    }
    if (Boolean.TRUE.equals(userProfileOfSelfRegisteredUser.isValidated())) {
      LOGGER.info("User is already validated");
      throw new DataValidationException(CustomErrorCodes.USER_ALREADY_VALIDATED);
    }
    if (userProfileOfSelfRegisteredUser.getOrg().getId()
        != userProfileOfUserValidating.getOrg().getId()) {
      LOGGER.info(
          "User being validated org id {} and user who is validating org id {} not matching",
          userProfileOfSelfRegisteredUser.getOrg().getId(),
          userProfileOfUserValidating.getOrg().getId());
    }
  }

  /**
   * Made changes as per NCIOT-12313.
   *
   * @param Device
   * @param UserProfile
   * @param Country
   * @param SelfRegistrationDTO
   * @param RoleOfInterest
   */
  @Override
  public void selfRegistrationValidator(
      UserProfile userProfile, Country country, SelfRegistrationDTO selfRegistrationDTO)
      throws DataValidationException {

    notNullString.test(selfRegistrationDTO.getFirstName()).throwIfInvalid("First Name");
    notNullString.test(selfRegistrationDTO.getLastName()).throwIfInvalid("Last Name");
    notNullString.test(selfRegistrationDTO.getEmail()).throwIfInvalid("Email");

    if (Optional.ofNullable(userProfile).isPresent()) {
      LOGGER.info("User already exists");
      throw new DataValidationException(CustomErrorCodes.EMAIL_ALREADY_EXISTS);
    }
    notNullString.test(selfRegistrationDTO.getCountryCode()).throwIfInvalid("Country Code");

    if (!Optional.ofNullable(country).isPresent()) {
      LOGGER.info(
          "Country not present in NextConnect with country code provided --> {}",
          selfRegistrationDTO.getCountryCode());
      throw new DataValidationException(CustomErrorCodes.INVALID_COUNTRY_CODE);
    }
  }

  public void roleOfInterestValidation(RoleOfInterest roleOfInterest)
      throws DataValidationException {
    if (!Optional.ofNullable(roleOfInterest).isPresent()) {
      LOGGER.info("Role of interest is not found {}", roleOfInterest.getRoleOfInterest());
      throw new DataValidationException(CustomErrorCodes.ROLE_OF_INTERESET_NOT_FOUND);
    }
  }

  /**
   * Self Registration validation for data fileds.
   *
   * @param input
   * @param cache
   * @throws DataValidationException
   */
  @Override
  public void selfRegistrationDataValidation(SelfRegistrationDTO input, SelfRegistrationDTO cache)
      throws DataValidationException {
    LOGGER.info("Validating the Objects of selfRegistration input{}, cache {}", input, cache);
    valueCheck(input.getFirstName(), cache.getFirstName());
    valueCheck(input.getLastName(), cache.getLastName());
    valueCheck(input.getEmail(), cache.getEmail());
    valueCheck(input.getSerialNo(), cache.getSerialNo());
    valueCheck(input.getCountryCode(), cache.getCountryCode());
    valueCheck(input.getPhone(), cache.getPhone());
    valueCheck(input.getIsdCode(), cache.getIsdCode());
  }

  /**
   * Objects string properties will be checked here.
   *
   * @param input
   * @param cache
   * @throws DataValidationException
   */
  public void valueCheck(String input, String cache) throws DataValidationException {
    if (!StringUtils.equals(input, cache)) {
      LOGGER.info(" SelfRegistration property is not mattching {}", input);
      throw new DataValidationException(CustomErrorCodes.PROPERTY_MISMATCH);
    }
  }
}
