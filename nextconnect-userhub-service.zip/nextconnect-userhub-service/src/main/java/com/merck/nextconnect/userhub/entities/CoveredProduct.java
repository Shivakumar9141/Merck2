package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@Entity
@Table(name = "nc_sm_covered_product")
@AllArgsConstructor
@NoArgsConstructor
public class CoveredProduct {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long coveredProductId;

  @Column(name = "sm_covered_product_id")
  private String smCoveredProductId;

  @Column(name = "covered_product_name")
  private String coveredProductName;

  @Column(name = "service_level")
  private String serviceLevel;

  @Column(name = "service_contract_id")
  private Long serviceContractId;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "created_timestamp")
  private Date createdTimestamp;

  @Column(name = "update_timestamp")
  private Date updatedTimestamp;

  @Column(name = "sm_system_mod_stamp")
  private Date smSystemModTimeStamp;

  @Column(name = "device_id")
  private Long deviceId;
}
