package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;

/**
 * this is introduced as a part of menuManagement
 *
 * @author clukose
 */
@Entity
@Table(name = "nc_menugroup")
@Getter
@Setter
public class MenuGroup implements Serializable {

  /** */
  private static final long serialVersionUID = -2824906213734257228L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int menugroup_id;

  @Column(name = "name")
  private String name;

  @Column(name = "min_count")
  private int minCount;

  @Column(name = "max_count")
  private int maxCount;

  @Column(name = "modified_date")
  private Timestamp modifiedDate;

  @Column(name = "created_date")
  private Timestamp createdDate;
}
