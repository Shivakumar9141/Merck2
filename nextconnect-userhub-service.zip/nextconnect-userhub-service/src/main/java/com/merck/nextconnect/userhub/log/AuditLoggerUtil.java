package com.merck.nextconnect.userhub.log;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import java.util.Map;
import java.util.Optional;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

public class AuditLoggerUtil {

  static final Logger logger = LoggerFactory.getLogger(AuditLoggerUtil.class);

  public static String formatLog(
      String resource, String action, Map<String, String> additionalProps) {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String requestUrl = ServletUriComponentsBuilder.fromCurrentRequest().build().toString();
    JSONObject log = new JSONObject();
    try {
      log.put("requestUrl", requestUrl);
      log.put("user", authUser.getUsername());
      log.put("action", action);
      log.put("resource", resource);
      Optional.ofNullable(additionalProps)
          .ifPresent(
              aProps -> {
                aProps.entrySet().stream()
                    .forEach(
                        a -> {
                          try {
                            log.put(a.getKey(), a.getValue());
                          } catch (JSONException e) {
                            logger.error("failed to write audit log::" + e.getMessage());
                          }
                        });
              });
    } catch (JSONException e) {
      logger.error("failed to write audit log::" + e.getMessage());
    }
    return log.toString();
  }

  public static String formatLogWithoutUser(
      String resource, String action, Map<String, String> additionalProps) {
    String requestUrl = ServletUriComponentsBuilder.fromCurrentRequest().build().toString();
    JSONObject log = new JSONObject();
    try {
      log.put("requestUrl", requestUrl);
      // log.put("user", authUser.getUsername());
      log.put("action", action);
      log.put("resource", resource);
      Optional.ofNullable(additionalProps)
          .ifPresent(
              aProps -> {
                aProps.entrySet().stream()
                    .forEach(
                        a -> {
                          try {
                            log.put(a.getKey(), a.getValue());
                          } catch (JSONException e) {
                            logger.error("failed to write audit log::" + e.getMessage());
                          }
                        });
              });
    } catch (JSONException e) {
      logger.error("failed to write audit log::" + e.getMessage());
    }
    return log.toString();
  }
}
