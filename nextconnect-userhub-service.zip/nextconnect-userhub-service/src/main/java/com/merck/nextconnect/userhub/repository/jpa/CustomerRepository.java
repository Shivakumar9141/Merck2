package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {}
