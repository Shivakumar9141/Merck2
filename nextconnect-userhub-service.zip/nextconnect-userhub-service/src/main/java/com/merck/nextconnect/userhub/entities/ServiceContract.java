package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author SHATHWAR Changes made as per NCIOT-11630.
 */
@Entity
@Table(name = "nc_sm_service_contract")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@lombok.Builder
public class ServiceContract implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long serviceContractId;

  @Column(name = "service_contract_name")
  private String serviceContractName;

  @Column(name = "service_contract_status")
  private String serviceContractStatus;

  @Column(name = "service_contract_start_date")
  private Timestamp startDate;

  @Column(name = "service_contract_end_date")
  private Timestamp endDate;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "device_id")
  private Device deviceEntity;

  @Column(name = "sm_service_contract_id")
  private String smServiceContractId;

  @Column(name = "sm_service_request_id")
  private String smServiceRequestId;

  @Column(name = "description")
  private String description;

  @Column(name = "requested_start_date")
  private Timestamp requestedStartDate;

  @Column(name = "requested_end_date")
  private Timestamp requestedEndDate;

  @Column(name = "sm_service_contract_created_from")
  private String smServiceContractCreatedFrom;

  @Column(name = "sync_status")
  private String syncStatus;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "created_timestamp")
  private Timestamp createdTimestamp;

  @Column(name = "update_timestamp")
  private Timestamp updateTimestamp;

  @Column(name = "sm_email")
  private String emailId;

  @Column(name = "sold_to")
  private String soldTo;

  @Column(name = "bill_to")
  private String billTo;
}
