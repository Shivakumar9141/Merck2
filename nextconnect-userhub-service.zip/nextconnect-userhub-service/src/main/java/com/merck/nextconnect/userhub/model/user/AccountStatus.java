package com.merck.nextconnect.userhub.model.user;

public enum AccountStatus {
  ACTIVE("ACTIVE"),
  INACTIVE("INACTIVE"),
  LOCKED("LOCKED");

  private final String value;

  public String value() {
    return this.value;
  }

  AccountStatus(String value) {
    this.value = value;
  }
}
