package com.merck.nextconnect.userhub.repository.ldap;

import com.merck.nextconnect.userhub.repository.IAuthenticationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.stereotype.Component;

/** service class to do authentication */
/**
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal
 */
@Component
public class AuthenticationRepositoryImpl implements IAuthenticationRepository {

  @Autowired
  @Qualifier("sialLdap")
  private LdapTemplate sialLdap;

  /**
   * Authenticate with LDAP
   *
   * @return authed
   */
  public boolean authenticateByEmail(final String email, final String password) {
    String EMPTY_STR = "";
    String MAIL = "mail";
    final Filter f = new EqualsFilter(MAIL, email);
    final boolean authenticated = sialLdap.authenticate(EMPTY_STR, f.encode(), password);
    return authenticated;
  }

  /**
   * Authenticate with LDAP
   *
   * @return authed
   */
  public boolean authenticateByUsername(final String username, final String password) {
    String EMPTY_STR = "";
    final Filter f = new EqualsFilter("sAMAccountName", username);
    final boolean authenticated = sialLdap.authenticate(EMPTY_STR, f.encode(), password);

    return authenticated;
  }
}
