package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Customer;
import com.merck.nextconnect.userhub.entities.DeviceLocation;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.RoleDeviceGroupPrivilege;
import com.merck.nextconnect.userhub.model.role.RoleDeviceGroup;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

/**
 * interface talks with RoleDevicePrivilege table
 *
 * @author <a href="mailto:shihas.arakkal@sial.com">Shihas Arakkal</a>
 */
@Component
public interface RoleDeviceGroupPrivilegesRepository
    extends JpaRepository<RoleDeviceGroupPrivilege, Long> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.role.RolePrivilege(r.privilege.privilegeId,r.privilege.operation ,r.customer.customerId,r.privilege.resourceType)"
          + " from RoleDeviceGroupPrivilege r  where r.role.roleId = :roleId")
  List<RolePrivilege> getPrivileges(@Param("roleId") long roleId);

  @Query(
      "select r.customer.customerId from RoleDeviceGroupPrivilege r  where r.role.roleId = :roleId")
  List<Long> getPrivilegeList(@Param("roleId") long roleId);

  @Modifying
  @Transactional
  @Query("delete from RoleDeviceGroupPrivilege r where r.role.roleId = :roleId")
  int deleteByRoleId(@Param("roleId") long roleId);

  @Modifying
  @Transactional
  long deleteByRoleAndPrivilegeAndCustomerAndDeviceLocationAndDeviceTypeId(
      Role roles,
      Privilege privileges,
      Customer customer,
      DeviceLocation deviceLocation,
      Long deviceTypeId);

  @Query(
      "select new com.merck.nextconnect.userhub.model.role.RoleDeviceGroup(r.privilege.privilegeId,r.deviceLocation.locationId,r.deviceLocation.locationName,r.customer.customerId,r.customer.customerName)"
          + " from RoleDeviceGroupPrivilege r  where r.role.roleId = :roleId and r.deviceTypeId = :deviceTypeId")
  List<RoleDeviceGroup> getPrivileges(
      @Param("roleId") long roleId, @Param("deviceTypeId") long deviceTypeId);
}
