package com.merck.nextconnect.userhub.validator.impl;

import static com.merck.nextconnect.utils.validations.helper.ListValidationHelpers.inList;
import static com.merck.nextconnect.utils.validations.helper.StringValidationHelpers.notNullString;

import com.merck.nextconnect.userhub.validator.LegalTermsValidator;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class LegalTermsValidatorImpl implements LegalTermsValidator {

  List<String> typeList = Arrays.asList("privacy policy", "terms and condition");

  @Override
  public void validateForNull(String languageCode, String countryCode, String type)
      throws DataValidationException {
    notNullString.test(languageCode).throwIfInvalid("language code");
    notNullString.test(countryCode).throwIfInvalid("country code");
    notNullString.and(inList(typeList)).test(type).throwIfInvalid("type");
  }
}
