package com.merck.nextconnect.userhub.model;

import java.util.List;

public class FetchCriteria {

  private String sortBy;
  private String orderBy;
  private List<String> filterBy;
  private String searchBy;
  private int pageNo;
  private int pageLimit;

  /**
   * @param aSortBy - a {@link java.lang.String} - parameter used for sorting
   * @param aOrderBy - a {@link java.lang.String} - ascending or descending order sorting
   * @param aSearchBy - a {@link java.lang.String} - parameter used for searching
   * @param aPageNo - a {@link java.lang.String} - page number
   * @param aPageLimit - a {@link java.lang.String} - page limit
   */
  public FetchCriteria() {}

  public FetchCriteria(
      String aSortBy,
      String aOrderBy,
      List<String> aFilterBy,
      String aSearchBy,
      Integer aPageNo,
      Integer aPageLimit) {

    sortBy = aSortBy;
    orderBy = aOrderBy;
    setFilterBy(aFilterBy);
    searchBy = aSearchBy;
    pageNo = aPageNo;
    pageLimit = aPageLimit;
  }

  public String getSortBy() {
    return sortBy;
  }

  public void setSortBy(String sortBy) {
    this.sortBy = sortBy;
  }

  public String getOrderBy() {
    return orderBy;
  }

  public void setOrderBy(String orderBy) {
    this.orderBy = orderBy;
  }

  public String getSearchBy() {
    return searchBy;
  }

  public void setSearchBy(String searchBy) {
    this.searchBy = searchBy;
  }

  public int getPageNo() {
    return pageNo;
  }

  public void setPageNo(int pageNo) {
    this.pageNo = pageNo;
  }

  public int getPageLimit() {
    return pageLimit;
  }

  public void setPageLimit(int pageLimit) {
    this.pageLimit = pageLimit;
  }

  public List<String> getFilterBy() {
    return filterBy;
  }

  public void setFilterBy(List<String> filterBy) {
    this.filterBy = filterBy;
  }
}
