package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.userhub.entities.UserFeedBackEntity;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.FeedBackDTO;
import com.merck.nextconnect.userhub.model.FeedBackStatus;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.UserDefaulterFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackPageDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackRatingsDTO;
import com.merck.nextconnect.userhub.model.user.UserDataList;
import com.merck.nextconnect.userhub.repo.jdbc.UserFeedBackRepositoryJdbc;
import com.merck.nextconnect.userhub.repository.jpa.UserDefaulterFeedBackSpecification;
import com.merck.nextconnect.userhub.repository.jpa.UserFeedBackRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserFeedBackSpecification;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IUserFeedBackService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.model.FetchCriteria;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class UserFeedBackServiceImpl implements IUserFeedBackService {

  static final Logger logger = LoggerFactory.getLogger(UserFeedBackServiceImpl.class);

  @Value("${user.experience.feedback.freeze.period}")
  private int userFeedBackMaxInterval;

  @Autowired private UserFeedBackRepository userFeedBackRepository;

  @Autowired private UserFeedBackRepositoryJdbc userFeedBackRepositoryJdbc;

  @Autowired private UserFeedBackSpecification userFeedBackSpecification;

  @Autowired private UserRepository userRepository;

  @Autowired private UserDefaulterFeedBackSpecification userDefaulterFeedBackSpecification;

  @Autowired private UserOrgPrivileges userOrgPrivileges;

  @Value("#{'${users.roles.ignore}'.split(',')}")
  private List<String> rolesList;

  public UserDataDTO createFeedBack(UserFeedBackDTO feedBackDTO, String userId)
      throws CustomException {

    Long uId = Long.valueOf(userId);

    UserProfile userProfile = userRepository.findByUserIdAndStatusAndDeleted(uId, "Active", false);
    UserFeedBackEntity userEntity =
        userFeedBackRepository.save(
            UserFeedBackEntity.builder()
                .feedBack(feedBackDTO.getFeedback())
                .rating(feedBackDTO.getRating())
                .user(userProfile)
                .createdDate(Timestamp.from(Instant.now()))
                .build());
    return UserDataDTO.builder()
        .countryName(userEntity.getUser().getCountry().getCountryName())
        .createdDate(userEntity.getCreatedDate())
        .feedback(userEntity.getFeedBack())
        .rating(userEntity.getRating())
        .userId(Long.valueOf(userId))
        .build();
  }

  @Override
  public FeedBackDTO getAllUsersFeedBack(AuthenticatedUser user) throws CustomException {

    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .filter(o -> o.getOrgId() != user.getOrgId())
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));

    List<UserDataDTO> entities = null;
    if (user.getRole().equals(Constants.FSE_USER)) {
      entities = userFeedBackRepositoryJdbc.getAllFeedBacks(user.getId());

      return calculateFeedsUsers(entities);
    } else if (user.getRole().equals(Constants.DISTRIBUTOR_FSE)) { // NCIOT-12528

      List<Integer> orgs =
          userFeedBackRepository.getDistributorFSEOrgs(
              Long.valueOf(user.getId()),
              Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
              user.getOrgId());
      if (orgs != null && !orgs.isEmpty()) {
        accessibleOrgs.addAll(orgs);
      }
      if (accessibleOrgs.size() > 0) {
        entities =
            userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSE(
                String.valueOf(user.getId()),
                Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                accessibleOrgs);
      }
      return calculateFeedsUsers(entities);

    } else if (user.getRole().equals(Constants.DISTRIBUTOR_ADMIN)) {

      List<Integer> orgs =
          userFeedBackRepository.getDistributorAdminOrgs(
              Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")), user.getOrgId());
      if (orgs != null && !orgs.isEmpty()) {
        accessibleOrgs.addAll(orgs);
      }
      if (accessibleOrgs.size() > 0) {
        entities =
            userFeedBackRepositoryJdbc.getAllUsersFeedBacksForDistributorAdmin(
                Arrays.asList(getAvailabeRoleForFeedBack().split(",")), accessibleOrgs);
      }
      return calculateFeedsUsers(entities);

    } else {
      entities = userFeedBackRepositoryJdbc.getAllUsersFeedBacks();
      return calculateFeedsUsers(entities);
    }
  }

  @Override
  public FeedBackStatus getFeedBack(Long userId) throws CustomException {
    FeedBackStatus feedBackStatus = null;
    UserFeedBackEntity entity = userFeedBackRepository.getLatestFeedBack(userId);
    UserProfile userProfile = userRepository.findById(userId).get();
    List<UserFeedBackEntity> entities =
        userFeedBackRepository.getAllFeedbackByCountry(userProfile.getCountry().getId());
    if (entities.isEmpty()) {
      throw new CustomException(CustomErrorCodes.USER_FEED_BACK_NOT_FOUND);
    }
    if (!entities.isEmpty()) {
      double totalUsers = 0;
      long totalRating = 0;
      Double avgRating = null;
      DecimalFormat df = new DecimalFormat("#.#");
      for (UserFeedBackEntity FeedEntity : entities) {
        totalUsers = totalUsers + 1;
        totalRating = totalRating + FeedEntity.getRating();
      }
      try {
        avgRating = totalRating / totalUsers;
      } catch (ArithmeticException e) {
        logger.error("Total number of users {}", totalUsers);
      }
      // NCIOT-4489
      boolean status = false;
      if (userProfile.isValidated()) {
        status =
            (entity != null)
                ? (!timeDifference(entity.getCreatedDate(), Timestamp.from(Instant.now())))
                    ? Boolean.TRUE
                    : Boolean.FALSE
                : checkUserActivatedDate(userProfile.getInvitedOrActivatedTs());
      }
      feedBackStatus =
          FeedBackStatus.builder()
              .rating(Double.valueOf(df.format(avgRating)))
              .status(status)
              .totalFeedbacks((long) totalUsers)
              .build();
    }
    return feedBackStatus;
  }

  public FeedBackDTO getAllFeedBack(Long userId) throws CustomException {

    List<UserDataDTO> entities = userFeedBackRepositoryJdbc.getAllUsersFeedBacks();

    if (entities != null && !entities.isEmpty()) {
      return calculateFeedsUsers(entities);
    } else {
      throw new CustomException(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY);
    }
  }

  private boolean timeDifference(Date createdDate, Date timestamp) {
    long period =
        Duration.between(
                new Timestamp(createdDate.getTime()).toLocalDateTime(),
                new Timestamp(timestamp.getTime()).toLocalDateTime())
            .toDays();
    return period < userFeedBackMaxInterval ? Boolean.TRUE : Boolean.FALSE;
  }

  private FeedBackDTO calculateFeedsUsers(List<UserDataDTO> entities) throws CustomException {
    if (entities != null && !entities.isEmpty()) {
      double totalUsers = 0;
      long totalRating = 0;
      Double avgRating = null;
      DecimalFormat df = new DecimalFormat("#.#");
      for (UserDataDTO entity : entities) {
        totalUsers = totalUsers + 1;
        totalRating = totalRating + entity.getRating();
      }
      try {
        avgRating = totalRating / totalUsers;

      } catch (ArithmeticException e) {
        logger.error("Total number of users {}", totalUsers);
      }

      return FeedBackDTO.builder()
          .noOfUserFeedBacks(totalUsers)
          .avgRating(Double.valueOf(df.format(avgRating)))
          .build();
    } else {
      throw new CustomException(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY);
    }
  }

  public UserFeedBackPageDTO getAllFeedBacks(FetchCriteria fetchCriteria) {
    Page<UserFeedBackEntity> pagedUsers = getAllByFetchCriteria(fetchCriteria);
    List<UserFeedBackEntity> users = pagedUsers.getContent();
    List<UserDataDTO> dto = new ArrayList<>();
    users.stream()
        .forEach(
            a -> {
              dto.add(
                  UserDataDTO.builder()
                      .userId(a.getUser().getUserId())
                      .language(a.getUser().getLanguage().getValue())
                      .firstName(a.getUser().getFirstName())
                      .lastName(a.getUser().getLastName())
                      .customerOrgName(a.getUser().getOrg().getName())
                      .countryName(a.getUser().getCountry().getCountryName())
                      .rating(a.getRating())
                      .feedback(a.getFeedBack())
                      .createdDate(a.getCreatedDate())
                      .countryCode(a.getUser().getCountry().getCountryCode())
                      .role(a.getUser().getRole().getName())
                      .email(a.getUser().getEmail())
                      .build());
            });

    long totalPages = pagedUsers.getTotalPages();
    UserFeedBackPageDTO userList = new UserFeedBackPageDTO();
    userList.setUsers(dto);
    userList.setTotalPages(totalPages);
    userList.setRecordCount(pagedUsers.getTotalElements());
    return userList;
  }

  private Page<UserFeedBackEntity> getAllByFetchCriteria(FetchCriteria fetchCriteria) {

    Page<UserFeedBackEntity> pagedUsers = null;
    PageRequest page;
    // sort
    if (fetchCriteria.getSortBy() != null) {
      page = getSortedPageRequest(fetchCriteria);
    } else {
      Sort sort = Sort.by(Sort.Direction.DESC, "rating", "createdDate");
      page = PageRequest.of(fetchCriteria.getPageNo() - 1, fetchCriteria.getPageLimit(), sort);
    }
    pagedUsers =
        userFeedBackRepository.findAll(
            userFeedBackSpecification.specification(fetchCriteria), page);

    return pagedUsers;
  }

  private Page<UserProfile> getNoFeedBackAllByFetchCriteria(
      com.merck.nextconnect.userhub.model.FetchCriteria fetchCriteria) {

    Page<UserProfile> pagedUsers = null;
    PageRequest page;
    // sort
    if (fetchCriteria.getSortBy() != null) {
      page = getNoFeedBackSortedPageRequest(fetchCriteria);
    } else {
      page = PageRequest.of(fetchCriteria.getPageNo() - 1, fetchCriteria.getPageLimit());
    }
    pagedUsers =
        userRepository.findAll(
            userDefaulterFeedBackSpecification.specification(fetchCriteria), page);

    return pagedUsers;
  }

  private PageRequest getNoFeedBackSortedPageRequest(
      com.merck.nextconnect.userhub.model.FetchCriteria fetchCriteria) {
    PageRequest page;
    String sortBy = fetchCriteria.getSortBy();
    page =
        PageRequest.of(
            fetchCriteria.getPageNo() - 1,
            fetchCriteria.getPageLimit(),
            Direction.fromString(fetchCriteria.getOrderBy()),
            sortBy);
    return page;
  }

  private PageRequest getSortedPageRequest(FetchCriteria fetchCriteria) {
    PageRequest page;
    String sortBy = fetchCriteria.getSortBy();
    page =
        PageRequest.of(
            fetchCriteria.getPageNo() - 1,
            fetchCriteria.getPageLimit(),
            Direction.fromString(fetchCriteria.getOrderBy()),
            sortBy);
    return page;
  }

  @Override
  public UserFeedBackFacets getUserFeedBackFacets() throws CustomException {

    List<UserFeedBackEntity> userProfiles =
        userFeedBackRepository.findAll(
            userFeedBackSpecification.specification(new FetchCriteria()));

    if (userProfiles == null || userProfiles.isEmpty()) {
      return emptyUserListingFacets();
    }

    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    UserFeedBackFacets userFeedBackFacets = new UserFeedBackFacets();

    userFeedBackFacets.setRoles(
        (getUniqueList(
            userProfiles.stream()
                .map(u -> u.getUser().getRole().getName())
                .collect(Collectors.toList()))));

    userFeedBackFacets.setRating(
        (getUniqueList(
                userProfiles.stream()
                    .map(u -> String.valueOf(u.getRating()))
                    .collect(Collectors.toList())))
            .stream().map(s -> Integer.parseInt(s)).collect(Collectors.toList()));
    userFeedBackFacets.setCountryCode(
        getUniqueList(
            userProfiles.stream()
                .map(u -> u.getUser().getCountry())
                .filter(Objects::nonNull)
                .map(Country::getCountryCode)
                .collect(Collectors.toList())));

    Optional.ofNullable(authUser.getAuthorities())
        .filter(
            authorities ->
                authorities.containsAll(AuthorityUtils.createAuthorityList(Constants.CREATE_ORG)))
        .ifPresent(
            x -> {
              userFeedBackFacets.setCusorg(
                  (getUniqueList(
                      userProfiles.stream()
                          .map(u -> u.getUser().getOrg().getName())
                          .collect(Collectors.toList()))));
            });
    userFeedBackFacets.setCusorg(
        (getUniqueList(
            userProfiles.stream()
                .map(u -> u.getUser().getOrg().getName())
                .collect(Collectors.toList()))));

    return userFeedBackFacets;
  }

  private List<String> getUniqueList(List<String> list) {
    Set<String> uniqueSet = new HashSet<String>(list);
    return new ArrayList<String>(uniqueSet);
  }

  private UserFeedBackFacets emptyUserListingFacets() {
    UserFeedBackFacets usersListingFacets = new UserFeedBackFacets();
    usersListingFacets.setRating(new ArrayList<>());
    usersListingFacets.setRoles(new ArrayList<>());

    return usersListingFacets;
  }

  @Override
  public UserFeedBackRatingDTO getRatingDetails(
      Long userId, AuthenticatedUser authUser, List<String> filterBy) throws CustomException {

    List<Integer> accessibleOrgs = new ArrayList<>();
    accessibleOrgs.addAll(
        userOrgPrivileges.getOrgs(OrgPrivileges.manage_accounts, null, null).stream()
            .filter(o -> o.getOrgId() != authUser.getOrgId())
            .map(o -> o.getOrgId())
            .collect(Collectors.toList()));

    String filteredQuery = getFilter(filterBy);

    if (authUser.getRole().equals(Constants.FSE_USER)) {
      return ratingCalculation(userId, filteredQuery);
    }
    // NCIOT-11742
    else if (authUser.getRole().equals(Constants.DISTRIBUTOR_FSE)) {

      List<Integer> orgs =
          userFeedBackRepository.getDistributorFSEOrgs(
              Long.valueOf(authUser.getId()),
              Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")),
              authUser.getOrgId());
      if (orgs != null && !orgs.isEmpty()) {
        accessibleOrgs.addAll(orgs);
      }

      List<UserFeedBackRatingsDTO> val = new ArrayList<>();

      if (accessibleOrgs.size() > 0) {
        val =
            userFeedBackRepositoryJdbc.getAllRatingsForDistributorFSE(
                userId,
                accessibleOrgs,
                Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                filteredQuery);
      }

      Map<Integer, Integer> map = new HashMap<>();
      for (UserFeedBackRatingsDTO str : val) {
        map.put(str.getRatings(), str.getCount());
      }

      List<UserDataDTO> entities = new ArrayList<>();

      if (accessibleOrgs.size() > 0) {
        entities =
            userFeedBackRepositoryJdbc.getAllFeedBacksForDistributorFSEWithFilters(
                String.valueOf(userId),
                Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                accessibleOrgs,
                filteredQuery);
      }

      FeedBackDTO totalFeedback = new FeedBackDTO();
      if (entities != null && !entities.isEmpty()) {
        totalFeedback = calculateFeedsUsers(entities);
      } else {
        throw new CustomException(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY);
      }

      Long totalUsers =
          userFeedBackRepositoryJdbc.getTotalDistributorFSEUsers(
              userId,
              Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
              accessibleOrgs,
              filteredQuery);
      Double percentage = calculatePercentage(totalUsers, getUniqueUsersCounts(entities));

      return UserFeedBackRatingDTO.builder()
          .ratings(map)
          .totalUsers(totalFeedback.getNoOfUserFeedBacks())
          .avgRating(totalFeedback.getAvgRating())
          .feedBackPercentage(percentage)
          .build();

    } else if (authUser.getRole().equals(Constants.DISTRIBUTOR_ADMIN)) {

      List<Integer> orgs =
          userFeedBackRepository.getDistributorAdminOrgs(
              Arrays.asList(Constants.FEEDBACK_DISTRIBUTOR_ROLES.split(",")), authUser.getOrgId());
      if (orgs != null && !orgs.isEmpty()) {
        accessibleOrgs.addAll(orgs);
      }

      List<UserFeedBackRatingsDTO> val = new ArrayList<>();

      if (accessibleOrgs.size() > 0) {
        val =
            userFeedBackRepositoryJdbc.getAllUsersRatingsForDistributorAdmin(
                userId,
                accessibleOrgs,
                Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                filteredQuery);
      }

      Map<Integer, Integer> map = new HashMap<>();
      for (UserFeedBackRatingsDTO str : val) {
        map.put(str.getRatings(), str.getCount());
      }

      List<UserDataDTO> entities = new ArrayList<>();

      if (accessibleOrgs.size() > 0) {
        entities =
            userFeedBackRepositoryJdbc.getAllUsersFeedBacksForDistributorAdminWithFilters(
                Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
                accessibleOrgs,
                filteredQuery);
      }
      FeedBackDTO totalFeedback = new FeedBackDTO();
      if (entities != null && !entities.isEmpty()) {
        totalFeedback = calculateFeedsUsers(entities);
      } else {
        throw new CustomException(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY);
      }

      Long totalUsers =
          userFeedBackRepositoryJdbc.getTotalUsersDistributorAdmin(
              Arrays.asList(getAvailabeRoleForFeedBack().split(",")),
              accessibleOrgs,
              filteredQuery);
      Double percentage = calculatePercentage(totalUsers, getUniqueUsersCounts(entities));
      return UserFeedBackRatingDTO.builder()
          .ratings(map)
          .totalUsers(totalFeedback.getNoOfUserFeedBacks())
          .avgRating(totalFeedback.getAvgRating())
          .feedBackPercentage(percentage)
          .build();
    } else {

      List<UserFeedBackRatingsDTO> val =
          userFeedBackRepositoryJdbc.getAllUsersRatings(userId, filteredQuery);
      Map<Integer, Integer> map = new HashMap<>();
      for (UserFeedBackRatingsDTO str : val) {
        map.put(str.getRatings(), str.getCount());
      }

      List<UserDataDTO> entities =
          userFeedBackRepositoryJdbc.getAllUsersFeedBacksWithFilters(filteredQuery);
      FeedBackDTO totalFeedback = new FeedBackDTO();
      if (entities != null && !entities.isEmpty()) {
        totalFeedback = calculateFeedsUsers(entities);
      } else {
        throw new CustomException(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY);
      }

      Long totalUsers = userFeedBackRepositoryJdbc.getTotalUsers(rolesList, filteredQuery);
      Double percentage = calculatePercentage(totalUsers, getUniqueUsersCounts(entities));
      return UserFeedBackRatingDTO.builder()
          .ratings(map)
          .totalUsers(totalFeedback.getNoOfUserFeedBacks())
          .avgRating(totalFeedback.getAvgRating())
          .feedBackPercentage(percentage)
          .build();
    }
  }

  public double getUniqueUsersCounts(List<UserDataDTO> user) {
    return new HashSet<Long>(user.stream().map(UserDataDTO::getUserId).collect(Collectors.toSet()))
        .size();
  }

  double calculatePercentage(double totalUsers, double totalNoOfUsersFeedBack) {
    Double percentage = 0.00;
    DecimalFormat df = new DecimalFormat("#.#");
    try {
      percentage = totalNoOfUsersFeedBack * 100 / totalUsers;
      percentage = Double.valueOf(df.format(percentage));
    } catch (ArithmeticException e) {
      logger.error("Error while calculating user feedback percentage");
    }
    return percentage;
  }

  @Override
  public UserDataList getFeedBackDefaulters(FetchCriteria fetchCriteria) throws CustomException {
    long totalPages;
    List<UserDataDTO> userDTOs = new ArrayList<>();
    UserDataList listOfUsers = new UserDataList();
    Page<?> pagedNoUsers = null;
    if ((fetchCriteria.getFilterBy() != null)
        && fetchCriteria.getFilterBy().contains(Constants.NOFEEDBACK)) {
      com.merck.nextconnect.userhub.model.FetchCriteria fetchCriteriaFilters =
          new com.merck.nextconnect.userhub.model.FetchCriteria();
      fetchCriteriaFilters.setFilterBy(fetchCriteria.getFilterBy());
      fetchCriteriaFilters.setOrderBy(fetchCriteria.getOrderBy());
      fetchCriteriaFilters.setPageLimit(fetchCriteria.getPageLimit());
      fetchCriteriaFilters.setPageNo(fetchCriteria.getPageNo());
      fetchCriteriaFilters.setSearchBy(fetchCriteria.getSearchBy());
      fetchCriteriaFilters.setSortBy(
          (fetchCriteria.getSortBy().equals(Constants.CREATED_DATE)
                  || fetchCriteria.getSortBy().equals(Constants.ORG_USER_NAME))
              ? Constants.ORG_NAME_CONSTRINT
              : fetchCriteria.getSortBy().equals(Constants.USER_ROLE_NAME)
                  ? Constants.ROLE_NAME
                  : fetchCriteria.getSortBy().equals(Constants.USER_COUNTRY_COUNTRY_CODE)
                      ? Constants.COUNTRY_COUNTRYCODE
                      : Constants.EMAIL);
      pagedNoUsers = getNoFeedBackAllByFetchCriteria(fetchCriteriaFilters);
      totalPages = pagedNoUsers.getTotalPages();
      List<UserProfile> userListByPageWise = (List<UserProfile>) pagedNoUsers.getContent();
      List<UserFeedBackEntity> users = userFeedBackRepository.findAll();
      Set<Long> uIds = users.stream().map(s -> s.getUser().getUserId()).collect(Collectors.toSet());
      Iterator<UserProfile> userListIterator = userListByPageWise.iterator();
      UserProfile userProfileDTO = new UserProfile();
      while (userListIterator.hasNext()) {
        userProfileDTO = (UserProfile) userListIterator.next();
        if (!uIds.contains(userProfileDTO.getUserId())) {
          UserDataDTO user = new UserDataDTO();
          user.setUserId(userProfileDTO.getUserId());
          user.setFirstName(userProfileDTO.getFirstName());
          user.setLastName(userProfileDTO.getLastName());
          user.setLanguage(userProfileDTO.getLanguage().getValue());
          user.setCountryName(
              userProfileDTO.getCountry() == null
                  ? ""
                  : userProfileDTO.getCountry().getCountryName());
          user.setCountryCode(
              userProfileDTO.getCountry() == null
                  ? ""
                  : userProfileDTO.getCountry().getCountryCode());
          user.setCustomerOrgName(userProfileDTO.getOrg().getName());
          user.setEmail(userProfileDTO.getEmail());
          user.setRole(userProfileDTO.getRole().getName());
          userDTOs.add(user);
        }
      }
    } else {
      pagedNoUsers = getAllByFetchCriteria(fetchCriteria);
      totalPages = pagedNoUsers.getTotalPages();
      List<UserFeedBackEntity> users = (List<UserFeedBackEntity>) pagedNoUsers.getContent();
      users.stream()
          .forEach(
              a -> {
                userDTOs.add(
                    UserDataDTO.builder()
                        .userId(a.getUser().getUserId())
                        .language(a.getUser().getLanguage().getValue())
                        .firstName(a.getUser().getFirstName())
                        .lastName(a.getUser().getLastName())
                        .customerOrgName(a.getUser().getOrg().getName())
                        .countryName(a.getUser().getCountry().getCountryName())
                        .rating(a.getRating())
                        .feedback(a.getFeedBack())
                        .createdDate(a.getCreatedDate())
                        .countryCode(a.getUser().getCountry().getCountryCode())
                        .role(a.getUser().getRole().getName())
                        .email(a.getUser().getEmail())
                        .build());
              });
    }
    listOfUsers.setUsers(userDTOs);
    listOfUsers.setTotalPages(totalPages);
    listOfUsers.setRecordCount(pagedNoUsers.getTotalElements());
    return listOfUsers;
  }

  public UserDefaulterFacets getFeedBackDefaultersFacets() throws CustomException {
    UserFeedBackFacets facets = getUserFeedBackFacets();
    List<String> oldFeedBackDurationList =
        Arrays.asList(
            Constants.NONE_CONSTANT,
            Constants.LESS_THAN_SIX_MONTHS,
            Constants.GREATER_THAN_SIX_MONTHS);
    UserDefaulterFacets defaulters = new UserDefaulterFacets();
    defaulters.setOldFeedBack(oldFeedBackDurationList);
    defaulters.setCusorg(facets.getCusorg());
    defaulters.setRoles(facets.getRoles());
    defaulters.setCountryCode(facets.getCountryCode());
    return defaulters;
  }

  public String getNoFeedBackSortByEntries(List<String> filterBy, String sortBy) {
    if (sortBy != null) {
      sortBy = sortBy.trim();
    }
    if (filterBy != null) {
      Iterator<String> itr = filterBy.iterator();
      String filterStr;
      while (itr.hasNext()) {
        filterStr = itr.next().toString();
        if (filterStr.contains(Constants.NOFEEDBACK_CONSTANT)
            && sortBy != null
            && sortBy.contains(Constants.CREATED_DATE)) {
          sortBy = Constants.CREATED_ON;
        } else if (filterStr.contains(Constants.NOFEEDBACK_CONSTANT) && sortBy != null) {
          sortBy = sortBy.substring(Constants.USERS_CONSTANT.length());
        }
      }
    }
    return sortBy;
  }

  /**
   * @return
   */
  String getAvailabeRoleForFeedBack() {
    return "Technical User,Quality Manager,Customer Admin";
  }

  private UserFeedBackRatingDTO ratingCalculation(Long userId, String filteredQuery)
      throws CustomException {
    List<UserFeedBackRatingsDTO> val =
        userFeedBackRepositoryJdbc.getAllRatings(userId, filteredQuery);
    Map<Integer, Integer> map = new HashMap<>();
    for (UserFeedBackRatingsDTO str : val) {
      map.put(str.getRatings(), str.getCount());
    }

    List<UserDataDTO> entities =
        userFeedBackRepositoryJdbc.getAllFeedBacksWithFilters(userId.toString(), filteredQuery);
    FeedBackDTO totalFeedback = new FeedBackDTO();
    if (entities != null && !entities.isEmpty()) {
      totalFeedback = calculateFeedsUsers(entities);
    } else {
      throw new CustomException(CustomErrorCodes.CUSTOMERS_FEED_BACK_EMPTY);
    }

    Long totalUsers = userFeedBackRepositoryJdbc.getTotalFSEUsers(userId, rolesList, filteredQuery);
    Double percentage = calculatePercentage(totalUsers, getUniqueUsersCounts(entities));

    return UserFeedBackRatingDTO.builder()
        .ratings(map)
        .totalUsers(totalFeedback.getNoOfUserFeedBacks())
        .avgRating(totalFeedback.getAvgRating())
        .feedBackPercentage(percentage)
        .build();
  }

  // NCIOT-4489
  private boolean checkUserActivatedDate(Timestamp invitedOrActivatedTs) {
    return (null != invitedOrActivatedTs)
        ? (!timeDifference(invitedOrActivatedTs, Timestamp.from(Instant.now())))
            ? Boolean.TRUE
            : Boolean.FALSE
        : Boolean.TRUE;
  }

  private String getFilter(List<String> filterBy) {
    List<String> filters = new ArrayList<>();

    Optional.ofNullable(filterBy)
        .ifPresent(
            f -> {
              Map<String, List<Object>> filterMap = getFilterValues(filterBy);
              Optional.ofNullable(filterMap.get(Constants.RATING))
                  .filter(fmap -> !filterMap.get(Constants.RATING).isEmpty())
                  .ifPresent(
                      s -> {
                        filters.add(
                            "feedback.rating in "
                                + filterMap.get(Constants.RATING).stream()
                                    .map(n -> String.valueOf(n))
                                    .collect(Collectors.joining("','", "('", "')")));
                      });

              Optional.ofNullable(filterMap.get(Constants.ROLES))
                  .filter(fmap -> !filterMap.get(Constants.ROLES).isEmpty())
                  .ifPresent(
                      r -> {
                        filters.add(
                            "r.name in "
                                + filterMap.get(Constants.ROLES).stream()
                                    .map(n -> String.valueOf(n))
                                    .collect(Collectors.joining("','", "('", "')")));
                      });

              Optional.ofNullable(filterMap.get(Constants.ORG_NAMES))
                  .filter(fmap -> !filterMap.get(Constants.ORG_NAMES).isEmpty())
                  .ifPresent(
                      r -> {
                        filters.add(
                            "o.name in "
                                + filterMap.get(Constants.ORG_NAMES).stream()
                                    .map(n -> String.valueOf(n))
                                    .collect(Collectors.joining("','", "('", "')")));
                      });

              Optional.ofNullable(filterMap.get(Constants.COUNTRY_CODES))
                  .filter(fmap -> !filterMap.get(Constants.COUNTRY_CODES).isEmpty())
                  .ifPresent(
                      r -> {
                        filters.add(
                            "c.country_code in "
                                + filterMap.get(Constants.COUNTRY_CODES).stream()
                                    .map(n -> String.valueOf(n))
                                    .collect(Collectors.joining("','", "('", "')")));
                      });
            });
    String fil = filters.stream().map(n -> n).collect(Collectors.joining(" and "));
    return (fil.length() > 0 ? " and " + fil : fil);
  }

  private Map<String, List<Object>> getFilterValues(List<String> filterBy) {
    Map<String, List<Object>> filterMap = new HashMap<>();
    List<Object> roleFilters = new ArrayList<>();
    List<Object> ratingFilters = new ArrayList<>();
    List<Object> orgNameFilters = new ArrayList<>();
    List<Object> countryCodeFilters = new ArrayList<>();

    filterBy.stream()
        .forEach(
            afilterBy -> {
              Optional.ofNullable(afilterBy)
                  .filter(a -> afilterBy.contains(Constants.RATING_FILTER_PREFIXS))
                  .ifPresent(
                      s -> {
                        ratingFilters.add(afilterBy.split("\\.")[1]);
                      });
              Optional.ofNullable(afilterBy)
                  .filter(a -> afilterBy.contains(Constants.ROLE_FILTER_PREFIXS))
                  .ifPresent(
                      r -> {
                        roleFilters.add(afilterBy.split("\\.")[1]);
                      });
              Optional.ofNullable(afilterBy)
                  .filter(a -> afilterBy.contains(Constants.ORG_NAME_FILTER_PREFIXS))
                  .ifPresent(
                      r -> {
                        orgNameFilters.add(afilterBy.split("\\.")[1]);
                      });

              Optional.ofNullable(afilterBy)
                  .filter(a -> afilterBy.contains(Constants.COUNTRY_CODE_FILTER_PREFIXS))
                  .ifPresent(
                      r -> {
                        countryCodeFilters.add(afilterBy.split("\\.")[1]);
                      });
            });

    if (ratingFilters.contains(Constants.ONE)) {
      ratingFilters.remove(Constants.ONE);
      ratingFilters.add(1);
    }
    if (ratingFilters.contains(Constants.TWO)) {
      ratingFilters.remove(Constants.TWO);
      ratingFilters.add(2);
    }
    if (ratingFilters.contains(Constants.THREE)) {
      ratingFilters.remove(Constants.THREE);
      ratingFilters.add(3);
    }
    if (ratingFilters.contains(Constants.FOUR)) {
      ratingFilters.remove(Constants.FOUR);
      ratingFilters.add(4);
    }
    if (ratingFilters.contains(Constants.FIVE)) {
      ratingFilters.remove(Constants.FIVE);
      ratingFilters.add(5);
    }

    filterMap.put(Constants.RATING, ratingFilters);
    filterMap.put(Constants.ROLES, roleFilters);
    filterMap.put(Constants.ORG_NAMES, orgNameFilters);
    filterMap.put(Constants.COUNTRY_CODES, countryCodeFilters);

    return filterMap;
  }
}
