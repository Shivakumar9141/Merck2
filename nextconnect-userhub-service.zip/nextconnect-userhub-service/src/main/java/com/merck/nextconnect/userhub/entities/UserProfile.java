package com.merck.nextconnect.userhub.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import lombok.ToString;

@ToString
@Entity
@Table(name = "NC_USER_PROFILE")
public class UserProfile implements Serializable {

  /** */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long userId;

  private String loginName;

  private String firstName;

  private String lastName;

  private String email;

  private String isdCode;

  @Transient private String userImage;

  private String phone;

  @Transient private BusinessDomainDTO businessDomain;

  @Transient private Boolean isDomainVisible;

  private String status;

  @Column(name = "consent_ts")
  private Timestamp consentTS;

  @Column(name = "consent_status")
  private boolean consentStatus;

  private Long createdRole;

  private String createdBy;

  @Column(name = "created_on")
  private Timestamp createdOn;

  @Column(name = "invited_or_activated_ts")
  private Timestamp invitedOrActivatedTs;

  @Column(name = "privacy_policy_status")
  private boolean privacyPolicyStatus;

  private Integer timeZoneId;

  @JsonIgnore
  @Column(columnDefinition = "boolean default false", nullable = false)
  private Boolean deleted = false;

  @Transient @JsonProperty private Boolean visible = true; // added for NCIOT 8783

  @OneToOne
  @JoinColumn(name = "COUNTRY_ID", nullable = true)
  private Country country;

  @OneToOne
  @JoinColumn(name = "ROLE_ID", nullable = true)
  private Role role;

  @OneToOne
  @JoinColumn(name = "DOMAIN_ID")
  private UserDomain userDomain;

  @OneToOne
  @JoinColumn(name = "DATE_FORMAT_ID")
  private DateFormat dateFormat;

  @ManyToOne
  @JoinColumn(name = "LANGUAGE_ID")
  private Language language;

  @ManyToOne
  @JoinColumn(name = "ORG_ID")
  private Organization org;

  @Transient @JsonProperty private UserProfileSettingsDTO userProfileSettings;

  @Column private boolean isValidated;

  @Column(columnDefinition = "boolean default false", nullable = false)
  private boolean isAutoCreated;

  @Column private String invitedVia;

  @Column private boolean platformSubscription = true;

  @Transient @JsonProperty private List<Integer> coveredTerritory;

  @Transient @JsonProperty private boolean isCoveredTerritory;

  @Column(name = "email_invite_count")
  private int emailInviteCount;

  public UserProfile() {}

  public UserProfile(
      String loginName,
      String firstName,
      String lastName,
      String email,
      String isdCode,
      String phone) {
    this.loginName = loginName;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.isdCode = isdCode;
    this.phone = phone;
  }

  public String getIsdCode() {
    return isdCode;
  }

  public void setIsdCode(String isdCode) {
    this.isdCode = isdCode;
  }

  public long getUserId() {
    return userId;
  }

  public void setUserId(long userId) {
    this.userId = userId;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Role getRole() {
    return role;
  }

  public void setRole(Role role) {
    this.role = role;
  }

  public String getLoginName() {
    return loginName;
  }

  public void setLoginName(String loginName) {
    this.loginName = loginName;
  }

  public UserDomain getUserDomain() {
    return userDomain;
  }

  public void setUserDomain(UserDomain userDomain) {
    this.userDomain = userDomain;
  }

  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public Language getLanguage() {
    return language;
  }

  public void setLanguage(Language language) {
    this.language = language;
  }

  public boolean isDeleted() {
    return deleted;
  }

  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

  public DateFormat getDateFormat() {
    return dateFormat;
  }

  public void setDateFormat(DateFormat dateFormat) {
    this.dateFormat = dateFormat;
  }

  public Timestamp getConsentTS() {
    return consentTS;
  }

  public void setConsentTS(Timestamp consentTS) {
    this.consentTS = consentTS;
  }

  public boolean isConsentStatus() {
    return consentStatus;
  }

  public void setConsentStatus(boolean consentStatus) {
    this.consentStatus = consentStatus;
  }

  public Organization getOrg() {
    return org;
  }

  public void setOrg(Organization org) {
    this.org = org;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Date getCreatedOn() {
    return createdOn;
  }

  public void setCreatedOn(Timestamp createdOn) {
    this.createdOn = createdOn;
  }

  public Long getCreatedRole() {
    return createdRole;
  }

  public void setCreatedRole(Long createdRole) {
    this.createdRole = createdRole;
  }

  public boolean isPrivacyPolicyStatus() {
    return privacyPolicyStatus;
  }

  public void setPrivacyPolicyStatus(boolean privacyPolicyStatus) {
    this.privacyPolicyStatus = privacyPolicyStatus;
  }

  public Integer getTimeZoneId() {
    return timeZoneId;
  }

  public void setTimeZoneId(Integer timeZoneId) {
    this.timeZoneId = timeZoneId;
  }

  public void setVisible(Boolean visible) {
    this.visible = visible;
  }

  public Boolean getVisible() {
    return visible;
  }

  public Timestamp getInvitedOrActivatedTs() {
    return invitedOrActivatedTs;
  }

  public UserProfileSettingsDTO getUserProfileSettings() {
    return userProfileSettings;
  }

  public void setUserProfileSettings(UserProfileSettingsDTO userProfileSettings) {
    this.userProfileSettings = userProfileSettings;
  }

  public void setInvitedOrActivatedTs(Timestamp invitedOrActivatedTs) {
    this.invitedOrActivatedTs = invitedOrActivatedTs;
  }

  public boolean isAutoCreated() {
    return isAutoCreated;
  }

  public void setAutoCreated(boolean isAutoCreated) {
    this.isAutoCreated = isAutoCreated;
  }

  public String getInvitedVia() {
    return invitedVia;
  }

  public boolean isValidated() {
    return isValidated;
  }

  public void setValidated(boolean isValidated) {
    this.isValidated = isValidated;
  }

  public void setInvitedVia(String invitedVia) {
    this.invitedVia = invitedVia;
  }

  public boolean isPlatformSubscription() {
    return platformSubscription;
  }

  public void setPlatformSubscription(boolean platformSubscription) {
    this.platformSubscription = platformSubscription;
  }

  public List<Integer> getCoveredTerritory() {
    return coveredTerritory;
  }

  public void setCoveredTerritory(List<Integer> coveredTerritory) {
    this.coveredTerritory = coveredTerritory;
  }

  public boolean isCoveredTerritory() {
    return isCoveredTerritory;
  }

  public void setCoveredTerritory(boolean isCoveredTerritory) {
    this.isCoveredTerritory = isCoveredTerritory;
  }

  public Boolean getIsDomainVisible() {
    return isDomainVisible;
  }

  public void setIsDomainVisible(Boolean isDomainVisible) {
    this.isDomainVisible = isDomainVisible;
  }

  public BusinessDomainDTO getBusinessDomain() {
    return businessDomain;
  }

  public void setBusinessDomain(BusinessDomainDTO businessDomain) {
    this.businessDomain = businessDomain;
  }

  public String getUserImage() {
    return userImage;
  }

  public void setUserImage(String userImage) {
    this.userImage = userImage;
  }

  public int getEmailInviteCount() {
    return emailInviteCount;
  }

  public void setEmailInviteCount(int emailInviteCount) {
    this.emailInviteCount = emailInviteCount;
  }
}
