package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.UserDefaulterFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackDTO;
import com.merck.nextconnect.userhub.model.UserFeedBackFacets;
import com.merck.nextconnect.userhub.model.UserFeedBackPageDTO;
import com.merck.nextconnect.userhub.model.user.UserDataList;
import com.merck.nextconnect.userhub.resources.IUserFeedBackService;
import com.merck.nextconnect.utils.common.Constants;
import com.merck.nextconnect.utils.model.FetchCriteria;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/feedback")
public class UserFeedBackController {

  @Autowired private IUserFeedBackService userFeedBackService;

  @Operation(
      summary = "save customer feedback",
      tags = "User Experience FeedBack",
      description = "This API is used to save user feedback")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @PreAuthorize("hasAuthority('create_feedback')")
  @PostMapping
  public ResponseEntity<?> createFeedBack(@RequestBody UserFeedBackDTO feedBackDTO)
      throws CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return new ResponseEntity<>(
        userFeedBackService.createFeedBack(feedBackDTO, authUser.getId()), HttpStatus.OK);
  }

  @Operation(
      summary = "Get feedbacks",
      tags = "User Experience FeedBack",
      description = "This API is used to get users feedback")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @PreAuthorize("hasAuthority('view_feedback')")
  @GetMapping
  public ResponseEntity<?> getTotalFeedbacks() throws CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    return new ResponseEntity<>(userFeedBackService.getAllUsersFeedBack(authUser), HttpStatus.OK);
  }

  @Operation(
      summary = "Get feedback",
      tags = "User Experience FeedBack",
      description = "This API is used to get user feedback")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @PreAuthorize("hasAuthority('create_feedback')")
  @GetMapping("/{userId}")
  public ResponseEntity<?> getTotalFeedback(@PathVariable("userId") Long userId)
      throws CustomException {

    return new ResponseEntity<>(userFeedBackService.getFeedBack(userId), HttpStatus.OK);
  }

  @Operation(
      summary = "List all FeedBacks",
      tags = "User Experience FeedBack",
      description = "This API is used to fetch all FeedBacks")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @GetMapping("/all")
  @PreAuthorize("hasAuthority('view_feedback')")
  public ResponseEntity<?> getAllFeedBacks(
      @Parameter(
              name = "sortBy",
              description = "Sort on a user attribute",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "sortBy", required = false)
          String sortBy,
      @Parameter(
              name = "orderBy",
              description = "Order by ascending/descending asc/desc",
              schema = @Schema(defaultValue = "asc"))
          @RequestParam(value = "orderBy", required = false)
          String orderBy,
      @Parameter(
              name = "filterBy",
              description = "List of filters",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          List<String> filterBy,
      @Parameter(
              name = "searchBy",
              description = "search category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy,
      @Parameter(name = "page", description = "page number", schema = @Schema(defaultValue = "1"))
          @RequestParam(value = "page", required = false)
          Integer page,
      @Parameter(
              name = "pageLimit",
              description = "per page limit",
              schema = @Schema(defaultValue = "20"))
          @RequestParam(value = "pageLimit", required = false)
          Integer pageLimit) {
    if (page == null) {
      page = 1;
    }
    if (pageLimit == null) {
      pageLimit = 10;
    }
    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);

    UserFeedBackPageDTO userFeedBackPageDTO = userFeedBackService.getAllFeedBacks(fetchCriteria);
    HttpHeaders headers = new HttpHeaders();
    headers.set("X-Pagination-Count", String.valueOf(userFeedBackPageDTO.getTotalPages()));
    headers.set("X-Record-Count", String.valueOf(userFeedBackPageDTO.getRecordCount()));
    return new ResponseEntity<>(userFeedBackPageDTO, headers, HttpStatus.OK);
  }

  @Operation(
      summary = "Get all Rating Filter facets",
      tags = "User Experience FeedBack",
      description = "This API is used to get Rating Filter facets")
  @Parameter(
      name = "Authorization",
      description = "Authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/facets")
  @PreAuthorize("hasAuthority('view_feedback')")
  public ResponseEntity<?> getUsersFacets() throws CustomException {
    UserFeedBackFacets usersListingFacets = userFeedBackService.getUserFeedBackFacets();
    return new ResponseEntity<>(usersListingFacets, HttpStatus.OK);
  }

  @Operation(
      summary = "Get feedback rating",
      tags = "User Experience FeedBack",
      description = "This API is used to get user feedback ratings")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @PreAuthorize("hasAuthority('view_feedback')")
  @GetMapping("/ratings/{userId}")
  public ResponseEntity<?> getRatingDetails(
      @PathVariable(name = "userId") long userId,
      @Parameter(
              name = "filterBy",
              description = "List of filters",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          List<String> filterBy)
      throws CustomException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return new ResponseEntity<>(
        userFeedBackService.getRatingDetails(userId, authUser, filterBy), HttpStatus.OK);
  }

  @Operation(
      summary = "Get all Rating Filter facets",
      tags = "User Experience FeedBack",
      description = "This API is used to get Defaulter Rating Filter facets")
  @Parameter(
      name = "Authorization",
      description = "Authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @GetMapping("/defaulters/facets")
  @PreAuthorize("hasAuthority('view_feedback')")
  public ResponseEntity<?> getDefaultersFacets() throws CustomException {
    UserDefaulterFacets usersListingFacets = userFeedBackService.getFeedBackDefaultersFacets();
    return new ResponseEntity<>(usersListingFacets, HttpStatus.OK);
  }

  @Operation(
      summary = "Get feedback defaulters",
      tags = "User Experience FeedBack",
      description = "This API is used to get feedback defaulters")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer token (Value should have the format - Bearer {token}) ",
      in = ParameterIn.HEADER)
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_200,
            description = "Fetched successfully."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_408,
            description = "Request Timeout."),
        @ApiResponse(
            responseCode = Constants.OPENAPI_RESPONSECODE_500,
            description = "Internal Application Error Occurred.")
      })
  @PreAuthorize("hasAuthority('view_feedback')")
  @GetMapping("/defaulters")
  public ResponseEntity<?> getFeedbackDefaulters(
      @Parameter(
              name = "sortBy",
              description = "Sort on a user attribute",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "sortBy", required = false)
          String sortBy,
      @Parameter(
              name = "orderBy",
              description = "Order by ascending/descending asc/desc",
              schema = @Schema(defaultValue = "asc"))
          @RequestParam(value = "orderBy", required = false)
          String orderBy,
      @Parameter(
              name = "filterBy",
              description = "List of filters",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          List<String> filterBy,
      @Parameter(
              name = "searchBy",
              description = "search category",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "searchBy", required = false)
          String searchBy,
      @Parameter(name = "page", description = "page number", schema = @Schema(defaultValue = "1"))
          @RequestParam(value = "page", required = false)
          Integer page,
      @Parameter(
              name = "pageLimit",
              description = "per page limit",
              schema = @Schema(defaultValue = "20"))
          @RequestParam(value = "pageLimit", required = false)
          Integer pageLimit)
      throws CustomException {

    if (page == null) {
      page = 1;
    }
    if (pageLimit == null) {
      pageLimit = 10;
    }

    sortBy = userFeedBackService.getNoFeedBackSortByEntries(filterBy, sortBy);
    FetchCriteria fetchCriteria =
        new FetchCriteria(sortBy, orderBy, filterBy, searchBy, page, pageLimit);
    UserDataList userDataList = userFeedBackService.getFeedBackDefaulters(fetchCriteria);
    HttpHeaders headers = new HttpHeaders();
    headers.set("x-pagination-count", String.valueOf(userDataList.getTotalPages()));
    headers.set("X-Record-Count", String.valueOf(userDataList.getRecordCount()));

    return new ResponseEntity<>(userDataList.getUsers(), headers, HttpStatus.OK);
  }
}
