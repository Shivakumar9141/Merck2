/**
 * UserProfileResponseEntity.java
 *
 * @author Prateek Pande
 *     <p>Copyright © 2021 Merck. All rights reserved.
 */
package com.merck.nextconnect.userhub.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.model.UserCountryDTO;
import com.merck.nextconnect.userhub.model.UserProfileSettingsDTO;
import com.merck.nextconnect.utils.common.entities.DateFormat;
import com.merck.nextconnect.utils.common.entities.Language;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UserProfileResponseEntity {

  private long userId;

  private String loginName;

  private String firstName;

  private String lastName;

  private String email;

  private String isdCode;

  private String phone;

  private String status;

  private boolean consentStatus;

  private boolean privacyPolicyStatus;

  private Integer timeZoneId;

  private UserCountryDTO country;

  private RoleResponseEntity role;

  private UserDomainResponseEntity userDomain;

  private DateFormat dateFormat;

  private Language language;

  private OrganizationResponseEntity org;

  private UserProfileSettingsDTO userProfileSettings;

  private List<Integer> coveredTerritory;

  @JsonProperty private boolean isCoveredTerritory;

  private boolean platformSubscription;

  private BusinessDomainDTO businessDomain;

  private String userImage;

  private Boolean isDomainVisible;

  private boolean isAutoCreated;

  private boolean deleteUser;

  private boolean updateUser;
}
