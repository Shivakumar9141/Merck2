package com.merck.nextconnect.userhub.model;

import com.merck.nextconnect.userhub.entities.Menu;
import com.merck.nextconnect.userhub.entities.UserMenu;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author clukose
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuDTO {
  private int menuId;
  private String menuKey;
  private int menuSequence;
  private boolean isVisible;
  private boolean isMandatory;
  private String iconUriImage;
  private String toolTip;
  private String tag;

  /**
   * @param menu
   * @return
   */
  public static MenuDTO converter(Menu menu) {

    MenuDTO menuDTO = new MenuDTO();
    menuDTO.setMenuId(menu.getMenu_id());
    menuDTO.setMenuSequence(menu.getDefaultSequence());
    menuDTO.setIconUriImage(menu.getIconRelativeUriImage());
    menuDTO.setVisible(menu.isActive());
    menuDTO.setToolTip(menu.getToolTip());
    menuDTO.setMandatory(menu.isMandatory());
    menuDTO.setMenuKey(menu.getMenu_key());
    return menuDTO;
  }

  /**
   * @param userMenu
   * @return
   */
  public static MenuDTO existingUserMenu(UserMenu userMenu) {

    MenuDTO menuDTO = new MenuDTO();
    menuDTO.setMenuId(userMenu.getMenu().getMenu_id());
    menuDTO.setMenuSequence(userMenu.getSequence());
    menuDTO.setIconUriImage(userMenu.getMenu().getIconRelativeUriImage());
    menuDTO.setVisible(userMenu.isVisible());
    menuDTO.setToolTip(userMenu.getMenu().getToolTip());
    menuDTO.setMandatory(userMenu.getMenu().isMandatory());
    menuDTO.setMenuKey(userMenu.getMenu().getMenu_key());
    return menuDTO;
  }
}
