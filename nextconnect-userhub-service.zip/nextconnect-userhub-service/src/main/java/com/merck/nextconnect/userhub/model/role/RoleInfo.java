package com.merck.nextconnect.userhub.model.role;

public class RoleInfo {
  private String name;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
