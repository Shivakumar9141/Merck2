package com.merck.nextconnect.userhub.mail.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.entities.Device;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.mail.MailTemplate;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.utils.email.entities.EmailAttribute;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.exception.EmailException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class MailTemplateImpl implements MailTemplate {

  private static final Logger logger = LoggerFactory.getLogger(MailTemplateImpl.class);

  @Autowired private EmailService emailService;

  @Autowired private EmailTemplateService emailTemplateService;

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${nextconnect.email.environment}")
  private String environment;

  /**
   * @param toMail
   * @throws CustomException
   */
  @Override
  public void sendCountryUpdateAlertMail(String toMail) throws CustomException {
    try {
      logger.info("Start of Country Change alert  email to {}", toMail);
      AuthenticatedUser authUser =
          (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

      int languageId = emailTemplateService.findLanguageIdByEmail(toMail);

      EmailTemplate emailTemplate =
          emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
              Constants.COUNTRY_CHANGE, languageId > 0 ? languageId : 1, Constants.ACTIVE);

      EmailMessage emailMessage = new EmailMessage();
      emailMessage.setEmailTemplate(emailTemplate);

      emailMessage.setEmailFrom(fromEmail);
      emailMessage.setEmailTo(toMail);
      emailMessage.setSubject(Constants.REGISTERED_COUNTRY_ALERT_SUBJECT);
      emailMessage.setStatus(Constants.EMAIL_PENDING_STATUS);
      emailMessage.setCreatedBy(authUser.getUsername());
      emailMessage.setCreatedTimestamp(Timestamp.from(Instant.now()));
      emailMessage.setLastUpdatedBy(authUser.getUsername());
      emailMessage.setLastUpdatedTimestamp(Timestamp.from(Instant.now()));
      emailMessage.setCharset(Constants.EMAIL_CHAR_SET);
      emailMessage.setContentType(Constants.EMAIL_CONTENT_TYPE);
      emailMessage.setEmailReplyTo(authUser.getUsername());

      emailMessage.setEmailAttributes(new HashSet<EmailAttribute>());
      logger.info("Preparing to send email to {} for country change", toMail);
      emailService.sendMail(emailMessage, environment);
    } catch (EmailException e) {
      logger.error("error while sending mail to {} for country change", toMail, e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }

  // change for NCIOT-10688
  /**
   * This method is used to send mail on the basis of template name and category name.
   *
   * @param userProfile,device,templateName,categoryName,status
   * @throws CustomException
   * @return void
   */
  @Override
  public void sendDeviceAssignmentChangeMail(
      UserProfile userProfile,
      Device device,
      String templateName,
      String categoryName,
      String status)
      throws CustomException {
    try {

      AuthenticatedUser authUser =
          (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

      EmailTemplate emailTemplate =
          emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
              templateName, userProfile.getLanguage().getId(), status);

      EmailMessage emailMessage = new EmailMessage();
      emailMessage.setEmailTemplate(emailTemplate);

      emailMessage.setEmailFrom(fromEmail);
      emailMessage.setEmailTo(userProfile.getEmail());
      emailMessage.setSubject(Constants.DEVICE_ASSIGNMENT_MAIL_SUBJECT);
      emailMessage.setStatus(Constants.EMAIL_PENDING_STATUS);
      emailMessage.setCreatedBy(authUser.getUsername());
      emailMessage.setCreatedTimestamp(Timestamp.from(Instant.now()));
      emailMessage.setLastUpdatedBy(authUser.getUsername());
      emailMessage.setLastUpdatedTimestamp(Timestamp.from(Instant.now()));
      emailMessage.setCharset(Constants.EMAIL_CHAR_SET);
      emailMessage.setContentType(Constants.EMAIL_CONTENT_TYPE);
      emailMessage.setEmailReplyTo(authUser.getUsername());

      Set<EmailAttribute> emailAttributeSet = new HashSet<>();
      emailAttributeSet.add(
          EmailAttribute.builder()
              .attributeName("name_of_the_user")
              .attributeValue(userProfile.getFirstName() + " " + userProfile.getLastName())
              .emailMessage(emailMessage)
              .build());
      emailAttributeSet.add(
          EmailAttribute.builder()
              .attributeName("system_name")
              .attributeValue(device.getDevicename())
              .emailMessage(emailMessage)
              .build());
      emailAttributeSet.add(
          EmailAttribute.builder()
              .attributeName("system_catalogue_number")
              .attributeValue(device.getProductCatalogNo())
              .emailMessage(emailMessage)
              .build());
      emailAttributeSet.add(
          EmailAttribute.builder()
              .attributeName("system_serial_number")
              .attributeValue(device.getSerialno())
              .emailMessage(emailMessage)
              .build());

      emailMessage.setEmailAttributes(emailAttributeSet);
      emailService.sendMail(emailMessage, environment);
    } catch (EmailException e) {
      logger.error(
          "error while sending mail to {} for device assignment", userProfile.getEmail(), e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }
}
