/** */
package com.merck.nextconnect.userhub.validator;

import com.merck.nextconnect.utils.common.entities.Country;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import org.springframework.stereotype.Component;

/**
 * @author Harshit Shrivastava 26-Nov-2018
 */
@Component
public interface SubscriptionValidator {

  public void validateSmsIsdSupportedCountries(Country country) throws DataValidationException;

  public void validateOtp(String isdCode, String phoneNumber, String otp)
      throws DataValidationException;
}
