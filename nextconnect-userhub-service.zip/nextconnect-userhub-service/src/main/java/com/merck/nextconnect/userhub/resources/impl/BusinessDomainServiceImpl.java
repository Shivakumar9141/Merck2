package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import com.merck.nextconnect.userhub.repo.jdbc.BusinessDomainRepositoryJdbc;
import com.merck.nextconnect.userhub.resources.IBusinessDomainService;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service class for Business Domain
 *
 * @author SSHREEBE
 */
@Service
public class BusinessDomainServiceImpl implements IBusinessDomainService {

  @Autowired private BusinessDomainRepositoryJdbc businessDomainRepositoryJdbc;

  static final Logger logger = LoggerFactory.getLogger(BusinessDomainServiceImpl.class);

  @Override
  public List<BusinessDomainDTO> getAllBusinessDomain(Boolean includeGeneric)
      throws DataValidationException {

    List<BusinessDomainDTO> businesDomainDTOList =
        businessDomainRepositoryJdbc.obtainAllBusinessDomain();
    // if true is passed in includeGeneric it returns businessDomainList excluding
    // Others
    // if false is passed in includeGeneric it returns businessDomainList excluding
    // Generics
    if (includeGeneric) {
      businesDomainDTOList =
          businesDomainDTOList.stream()
              .filter(o -> !o.getDomainName().equalsIgnoreCase("Others"))
              .collect(Collectors.toList());
    } else {
      businesDomainDTOList =
          businesDomainDTOList.stream()
              .filter(o -> !o.getDomainName().equalsIgnoreCase("Generic"))
              .collect(Collectors.toList());
    }
    logger.info("businesDomainDTOList{}", businesDomainDTOList);
    return businesDomainDTOList;
  }
}
