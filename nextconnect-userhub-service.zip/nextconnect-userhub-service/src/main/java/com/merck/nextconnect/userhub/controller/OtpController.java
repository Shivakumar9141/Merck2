package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.resources.IUserSubscription;
import com.merck.nextconnect.utils.file.handler.exception.CustomException;
import com.merck.nextconnect.utils.otp.resource.IOtpService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.modeshape.common.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
@RequestMapping("/api/v1/otp")
public class OtpController {

  static final Logger logger = LoggerFactory.getLogger(OtpController.class);

  @Autowired private IOtpService otpService;

  @Autowired private IUserSubscription userSubscriptionService;

  @Value("${nextconnect.sms.url}")
  private String smsHost;

  @Value("${nextconnect.sms.username}")
  private String smsUsername;

  @Value("${nextconnect.sms.password}")
  private String smsPassword;

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Operation(
      summary = "Send the OTP to the phonenumber",
      tags = "OTP",
      description = "This API is used to send the OTP to the mobile number entered by the user")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PostMapping("/send")
  public ResponseEntity<?> sendOTP(
      @Parameter(
              name = "phoneNumber",
              description = "Mobile number of the user",
              schema = @Schema(defaultValue = "false"))
          @RequestParam(value = "phoneNumber", required = false)
          Boolean isSMSRequired,
      @Parameter(
              name = "email",
              description = "Email of the user",
              schema = @Schema(defaultValue = "false"))
          @RequestParam(value = "email", required = false)
          Boolean isEmailRequired)
      throws CustomException, DataValidationException {
    logger.info("Phone number provided : {}, Email provided : {}", isSMSRequired, isEmailRequired);
    if (!isSMSRequired && !isEmailRequired) {
      throw new DataValidationException("Please select atleast one option");
    }
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Pair<String, String> userContactDetails;
    try {
      userContactDetails =
          userSubscriptionService.getUserPhoneAndEmail(Long.parseLong(authUser.getId()));
    } catch (Exception e) {
      throw new DataValidationException("Please configure mobile number with this user's profile");
    }
    otpService.sendOTP(
        isSMSRequired,
        isEmailRequired,
        authUser.getId(),
        userContactDetails,
        smsHost,
        smsUsername,
        smsPassword,
        fromEmail,
        environment);
    return new ResponseEntity<>(true, HttpStatus.OK);
  }

  @Operation(
      summary = "Send the OTP to the phonenumber",
      tags = "OTP",
      description = "This API is used to send the OTP to the mobile number entered by the user")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @PostMapping("/validate")
  public ResponseEntity<?> validateOtp(
      @Parameter(
              name = "otp",
              description = "otp for validation",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "otp", required = false)
          String otp)
      throws CustomException, DataValidationException {
    logger.info("Start of validate otp for OTP {}", otp);
    if (StringUtil.isBlank(otp)) {
      throw new DataValidationException("OTP cannot be blank");
    }
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Pair<String, String> userContactDetails;
    try {
      userContactDetails =
          userSubscriptionService.getUserPhoneAndEmail(Long.parseLong(authUser.getId()));
    } catch (Exception e) {
      throw new DataValidationException("Please configure mobile number with this user's profile");
    }
    boolean isOtpValid =
        otpService.validateOTP(
            otp,
            userContactDetails.getFirst(),
            userContactDetails.getSecond(),
            String.valueOf(authUser.getId()));
    logger.info("End of validate otp for OTP {}", otp);
    return new ResponseEntity<>(isOtpValid, HttpStatus.OK);
  }
}
