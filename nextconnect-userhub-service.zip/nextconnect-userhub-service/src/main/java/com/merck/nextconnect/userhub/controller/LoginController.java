package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.authfilter.exception.CustomAuthenticationException;
import com.merck.nextconnect.authfilter.model.AuthToken;
import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.JwtUser;
import com.merck.nextconnect.authfilter.repository.hazelcast.TokenStore;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.authfilter.util.JwtTokenValidator;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.LoginAuthenticationException;
import com.merck.nextconnect.userhub.exception.ResourceNotFoundException;
import com.merck.nextconnect.userhub.model.Login;
import com.merck.nextconnect.userhub.model.UserInfo;
import com.merck.nextconnect.userhub.model.user.UserLoginInfo;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.resources.IAuthentication;
import com.merck.nextconnect.userhub.response.SamlAuthResponse;
import com.merck.nextconnect.userhub.service.LoginService;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.LoginUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.util.Map;
import java.util.Objects;
import javax.naming.AuthenticationException;
import lombok.Setter;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Component
@RestController
public class LoginController {
  static final Logger logger = LoggerFactory.getLogger(LoginController.class);

  @Autowired IAuthentication authentication;

  @Autowired JwtTokenValidator jwtTokenValidator;

  @Autowired JwtTokenGenerator jwtTokenGenerator;

  @Autowired UserRepository userRepo;

  @Value("${saml.idap.app.url}")
  private String idpAppURL;

  @Value("${saml.relay.state}")
  private String relayState;

  @Value("${saml.asserstion.consumer.url}")
  private String assertionConsumerServiceUrl;

  @Value("${saml.sp.entity.id}")
  private String samlCreationIssuerId;

  @Value("${saml.relay.state}")
  private String relayURL;

  @Autowired @Setter LoginService loginService;

  @Autowired LoginUtil loginUtil;

  @Autowired TokenStore tokenStore;

  // NCIOT-11655
  @CrossOrigin
  @Operation(
      summary = "login",
      tags = "Authentication",
      description = "This API is used to login by user credentials")
  @RequestMapping(value = "/api/login", method = RequestMethod.POST)
  public ResponseEntity<AuthToken> login(
      @Parameter(name = "login", description = "login") @RequestBody Login login)
      throws AuthenticationException, AccessDeniedException {
    logger.info("login called");
    AuthToken authToken = new AuthToken();
    HttpStatus status = null;
    boolean validateRequestStatus = loginUtil.validateLoginRequest(login);
    if (!validateRequestStatus) {
      status = HttpStatus.BAD_REQUEST;
    } else {
      authToken = authentication.login(login);
      status = authToken.getAccessToken() != null ? HttpStatus.OK : HttpStatus.UNAUTHORIZED;
      if (null == authToken.getAccessToken()) {
        throw new LoginAuthenticationException("Username or Password is incorrect");
      }
    }
    return new ResponseEntity<>(authToken, status);
  }

  @CrossOrigin
  @Operation(description = "ssoreplay", tags = "SSO Reply")
  @RequestMapping(
      value = "/api/login/sso/reply",
      method = RequestMethod.POST,
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = {"application/x-www-form-urlencoded; charset=UTF-8", "application/*"})
  public void loginSsoReply(
      @Parameter(name = "SAMLResponse", description = "SAMLResponse")
          @RequestParam(defaultValue = "")
          String SAMLResponse,
      HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse)
      throws AuthenticationException, IOException, ServletException {
    logger.info("loginSsoReply called");
    String redirectURL = "";
    SamlAuthResponse samlAuthResponse = new SamlAuthResponse();
    if (SAMLResponse != null && !SAMLResponse.equalsIgnoreCase("")) {
      /*store the auth token in the cache after generating and get the hash used for storing and set it in cookie and return back to user*/
      logger.info("loginSsoReply --> SAMLResponse not empty");
      samlAuthResponse = authentication.loginBySaml(SAMLResponse);
    } else {
      logger.info("LoginController -> loginSsoReply -> SAML is not valid -> BadRequest");
      samlAuthResponse.setStatusCode(400);
      samlAuthResponse.setStatusMessage("BadRequest");
    }
    if (Objects.nonNull(relayURL)) {
      redirectURL = relayURL;
    }
    if (samlAuthResponse == null
        || samlAuthResponse.getStatusCode() == 400
        || samlAuthResponse.getStatusCode() == 401
        || samlAuthResponse.getStatusCode() == 500) {
      httpServletResponse.addHeader(
          "Set-Cookie", "atomCacheCode=" + samlAuthResponse.getStatusCode() + "; Path=/;Secure;");
      httpServletResponse.sendRedirect(redirectURL);
      httpServletRequest
          .getRequestDispatcher(redirectURL)
          .include(httpServletRequest, httpServletResponse);
    } else {
      logger.info("Access token== " + samlAuthResponse.getAuthToken().getAccessToken());
      logger.info("Refresh token== " + samlAuthResponse.getAuthToken().getRefreshToken());
      logger.info("LoginController -> loginSsoReply -> SAML is valid" + redirectURL);
      httpServletResponse.addHeader(
          "Set-Cookie",
          "atomCacheCode=" + samlAuthResponse.getHashTokenCacheKey() + "; Path=/;Secure;");
      httpServletResponse.sendRedirect(redirectURL);
      httpServletRequest
          .getRequestDispatcher(redirectURL)
          .include(httpServletRequest, httpServletResponse);
    }
    logger.info("Redirect URL== " + redirectURL);
    logger.info("loginSsoReply ended");
  }

  // NCIOT-11655
  @CrossOrigin
  @Operation(description = "userinfo", tags = "Authentication")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(value = "/api/userinfo", method = RequestMethod.GET)
  public ResponseEntity<UserInfo> getUserDetails() throws ResourceNotFoundException {
    AuthenticatedUser authUser =
        (AuthenticatedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    UserInfo user =
        authentication.getUserInfo(
            Long.parseLong(authUser.getId()), authUser.getUsername(), authUser.getOrgId());
    return new ResponseEntity<>(user, HttpStatus.OK);
  }

  @Operation(description = "get user and authentication type", tags = "Authentication")
  @RequestMapping(value = "/api/logintypes", method = RequestMethod.GET)
  public ResponseEntity<UserLoginInfo> getUserLoginTypes(
      @Parameter(name = "loginText", description = "user email id")
          @RequestParam(value = "loginText", required = true)
          String loginText) {

    UserLoginInfo userLoginInfo = new UserLoginInfo();
    userLoginInfo = authentication.getLoginTypes(loginText);
    if (userLoginInfo.getAuthenticationTypes().isEmpty()) {
      throw new LoginAuthenticationException("INVALID_USERNAME");
    }
    return new ResponseEntity<>(userLoginInfo, HttpStatus.OK);
  }

  @CrossOrigin
  @Operation(description = "logout user", tags = "Authentication")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(value = "/api/logout", method = RequestMethod.GET)
  public ResponseEntity<?> logout(HttpServletRequest http) {

    String header = http.getHeader("Authorization");
    String authToken = header.substring(7);
    jwtTokenValidator.invalidateToken(authToken);
    logger.info("successfully log out");
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @CrossOrigin
  @Operation(description = "get access token", tags = "Authentication")
  @Parameter(
      name = "Authorization",
      description =
          "authorization header containing the bearer refresh token to get new access token",
      in = ParameterIn.HEADER)
  @RequestMapping(value = "/api/token", method = RequestMethod.GET)
  public ResponseEntity<String> getAccessToken()
      throws JSONException, CustomAuthenticationException, CustomException {
    JSONObject token = new JSONObject();
    String accessToken = jwtTokenGenerator.updateAccessToken();
    token.put(Constants.ACCESSTOKEN, accessToken);
    return new ResponseEntity<String>(token.toString(), HttpStatus.OK);
  }

  @CrossOrigin
  @Operation(
      summary = "SSO Auth Token",
      tags = "Authentication",
      description =
          "This API is used to retrieve the Auth tokens from cache only for SSO type login")
  @RequestMapping(value = "/api/sso/token", method = RequestMethod.POST)
  public ResponseEntity<String> getAccessTokenFromCacheForSSO(
      @RequestBody Map<String, String> atomCacheId) throws CustomException {
    String authToken = "";
    HttpStatus status = null;
    if (atomCacheId != null && !atomCacheId.isEmpty()) {
      try {
        if (null != atomCacheId && !atomCacheId.isEmpty()) {
          String cacheId = atomCacheId.get("atomCacheId");
          authToken = authentication.getTokenFromCacheByHash(cacheId);
          status = HttpStatus.OK;
          if (authToken != null && !authToken.equalsIgnoreCase("")) {
            tokenStore.removeAuthToken(cacheId);
          }
        } else {
          status = HttpStatus.UNAUTHORIZED;
        }
      } catch (Exception e) {
        logger.error("failed to get the token from cache for sso", e.getMessage());
        status = HttpStatus.INTERNAL_SERVER_ERROR;
      }
    } else {
      status = HttpStatus.BAD_REQUEST;
    }
    return new ResponseEntity<String>(authToken, status);
  }

  @CrossOrigin
  @Operation(description = "validate jti", tags = "Authentication")
  @RequestMapping(value = "/api/token/{jti}", method = RequestMethod.GET)
  public ResponseEntity<UserProfile> validateToken(
      @Parameter(name = "jti", description = "jti", schema = @Schema(defaultValue = ""))
          @PathVariable(value = "jti")
          String jti) {
    UserProfile userProfile = null;
    try {
      JwtUser user = jwtTokenValidator.parseToken(jti);
      userProfile = userRepo.getUserById(user.getId());
    } catch (com.merck.nextconnect.authfilter.exception.LoginAuthenticationException e) {
      throw new LoginAuthenticationException(e.getMessage());
    }
    return new ResponseEntity<>(userProfile, HttpStatus.OK);
  }

  @CrossOrigin
  @Operation(description = "ssoredirect", tags = "SSO Redirect")
  @RequestMapping(value = "/api/login/sso", method = RequestMethod.GET)
  public ResponseEntity<String> redirectToIDPWithAuthNRequest() {
    logger.info("redirectToIDPWithAuthNRequest called");
    String redirectUrl;
    redirectUrl =
        loginService.getAuthNRedirectUrl(
            idpAppURL, relayState, assertionConsumerServiceUrl, samlCreationIssuerId);
    logger.info("redirectToIDPWithAuthNRequest redirection url generated");
    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(URI.create(redirectUrl));
    return new ResponseEntity<>(headers, HttpStatus.FOUND);
  }
}
