package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * @author clukose
 */
@Entity
@Table(name = "nc_menu")
@Getter
@Setter
public class Menu {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int menu_id;

  @Column(name = "menu_key")
  private String menu_key;

  @Column(name = "icon_relative_uri_image")
  private String iconRelativeUriImage;

  @Column(name = "is_active")
  private boolean isActive;

  @Column(name = "tool_tip")
  private String toolTip;

  @Column(name = "tag")
  private String tag;

  @Column(name = "is_mandatory")
  private boolean isMandatory;

  @Column(name = "default_sequence")
  private int defaultSequence;
}
