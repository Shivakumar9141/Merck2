package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author tah
 *     <p>This class is for JDBC Template implementation to use native sql
 */
@Repository
public class UserProfileRepositoryJdbc {

  static final Logger LOGGER = LoggerFactory.getLogger(UserDevicePrivilegeRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  String SQL_SELECT_USER_ORG_DETAILS_BY_USER_ID =
      "select up.user_id, up.org_id,o.created_via from nc_user_profile up inner join nc_org o ON up.org_id=o.id  where o.is_auto_created = true and up.user_id in (:userIdList) and up.deleted=false";

  public List<UserDataDTO> getUserOrgDetails(List<Long> userIdList) throws CustomException {
    LOGGER.debug("userIdList : {} ", userIdList);
    List<UserDataDTO> userDataList = new ArrayList<UserDataDTO>();
    if (userIdList.isEmpty()) {
      return userDataList;
    }
    try {
      MapSqlParameterSource parameters = new MapSqlParameterSource();
      parameters.addValue("userIdList", userIdList);
      userDataList =
          namedParameterJdbcTemplate.query(
              SQL_SELECT_USER_ORG_DETAILS_BY_USER_ID,
              parameters,
              (rs, rowNum) ->
                  UserDataDTO.builder()
                      .userId(rs.getLong("up.user_id"))
                      .orgId(rs.getLong("up.org_id"))
                      .userOrgCreatedVia(rs.getString("o.created_via"))
                      .build());
    } catch (Exception e) {
      LOGGER.error("Exception occured in getUserOrgDetails while calling DB", e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
    return userDataList;
  }
}
