package com.merck.nextconnect.userhub.repository.jpa;

import com.merck.nextconnect.userhub.entities.Card;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.RoleCardPrivilege;
import com.merck.nextconnect.userhub.model.role.RolePrivilege;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleCardPrivilegesRepository extends JpaRepository<RoleCardPrivilege, Long> {

  @Query(
      "select new com.merck.nextconnect.userhub.model.role.RolePrivilege(r.privilege.privilegeId,r.privilege.operation,r.card.id,r.privilege.resourceType)"
          + " from RoleCardPrivilege r  where r.role.roleId = :roleId")
  List<RolePrivilege> getPrivileges(@Param("roleId") long roleId);

  @Modifying
  @Transactional
  long deleteByRoleAndPrivilegeAndCard(Role roles, Privilege privileges, Card card);

  @Modifying
  @Transactional
  @Query("delete from RoleCardPrivilege r where r.role.roleId = :roleId")
  int deleteByRoleId(@Param("roleId") long roleId);
}
