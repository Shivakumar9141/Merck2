package com.merck.nextconnect.userhub.response;

import com.merck.nextconnect.authfilter.model.AuthToken;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
public class SamlAuthResponse {

  @Setter @Getter private int statusCode;

  @Setter @Getter private String statusMessage;

  @Setter @Getter private AuthToken authToken;

  @Setter @Getter private String hashTokenCacheKey;
}
