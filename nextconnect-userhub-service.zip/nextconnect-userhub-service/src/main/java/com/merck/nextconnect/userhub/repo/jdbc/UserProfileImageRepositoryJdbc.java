package com.merck.nextconnect.userhub.repo.jdbc;

import com.merck.nextconnect.userhub.constants.UserhubConstants;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * This is the Repository class which consists of native queries for user profile image
 *
 * @author SSHREEBE
 */
@Repository
public class UserProfileImageRepositoryJdbc {

  static final Logger LOGGER = LoggerFactory.getLogger(UserProfileImageRepositoryJdbc.class);

  @Autowired
  @Qualifier("namedParameterJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  static final String SQL_SELECT_BLOB_IMAGE_BY_USER_ID =
      "Select upi.blob_image from nc_user_profile_image upi where upi.user_id=:userId";

  static final String SQL_SELECT_THUMBNAIL_BLOB_IMAGE_BY_USER_ID =
      "Select upi.thumbnail_blob_image from nc_user_profile_image upi where upi.user_id=:userId";

  static final String SQL_DELETE_USER_PROFILE_IMAGE_BY_USER_ID =
      "delete from nc_user_profile_image where user_id= :userId";

  public String fetchUserThumbnailBlobImage(Long userId) {
    String userThumbnailImage = null;
    try {

      Map<String, Object> namedParameters = new HashMap<>();
      namedParameters.put(UserhubConstants.USER_ID, userId);
      userThumbnailImage =
          namedParameterJdbcTemplate.queryForObject(
              SQL_SELECT_THUMBNAIL_BLOB_IMAGE_BY_USER_ID, namedParameters, String.class);
      LOGGER.debug("UserThumbnailImage : {}", userThumbnailImage);

      return userThumbnailImage;

    } catch (EmptyResultDataAccessException e) {
      return null;
    } catch (Exception e) {
      LOGGER.error("Exception occured while fetching thumbnail image for the user ", e);
    }
    return userThumbnailImage;
  }

  public String fetchUserBlobImage(Long userId) throws CustomException {
    String userBlobImage = null;
    try {

      Map<String, Object> namedParameters = new HashMap<>();
      namedParameters.put(UserhubConstants.USER_ID, userId);
      userBlobImage =
          namedParameterJdbcTemplate.queryForObject(
              SQL_SELECT_BLOB_IMAGE_BY_USER_ID, namedParameters, String.class);
      LOGGER.debug("UserBlobImage : {}", userBlobImage);

      return userBlobImage;
    } catch (EmptyResultDataAccessException e) {
      return null;
    } catch (Exception e) {
      LOGGER.error("Exception occured while fetching blob image for the user ", e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }

  public void deleteUserImage(Long userId) throws CustomException {
    try {
      Map<String, Object> namedParameters = new HashMap<>();
      namedParameters.put(UserhubConstants.USER_ID, userId);
      namedParameterJdbcTemplate.update(SQL_DELETE_USER_PROFILE_IMAGE_BY_USER_ID, namedParameters);
    } catch (Exception e) {
      LOGGER.error("Exception occured while deleting the user image ", e);
      throw new CustomException(CustomErrorCodes.INTERNAL_SERVER_ERROR);
    }
  }
}
