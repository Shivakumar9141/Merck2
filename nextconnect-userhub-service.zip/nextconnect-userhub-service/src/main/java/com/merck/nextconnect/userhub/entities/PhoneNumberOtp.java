package com.merck.nextconnect.userhub.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder(toBuilder = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "nc_phone_number_otp")
public class PhoneNumberOtp implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "otp_id")
  private Long otpId;

  @Column(name = "otp")
  private String otp;

  @Column(name = "phone_number")
  private String phoneNumber;

  @Column(name = "generated_timestamp")
  private Timestamp timeStamp;

  @Column(name = "validated")
  private boolean validated;

  @JoinColumn(name = "user_id")
  @OneToOne
  private UserProfile userProfile;
}
