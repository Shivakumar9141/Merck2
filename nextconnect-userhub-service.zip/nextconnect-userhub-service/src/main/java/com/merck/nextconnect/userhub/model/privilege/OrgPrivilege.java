package com.merck.nextconnect.userhub.model.privilege;

public class OrgPrivilege extends Privileges {

  /** */
  private static final long serialVersionUID = 1L;

  public OrgPrivilege() {}

  public OrgPrivilege(long privilegeId, String operation, int resourceId, String resourceType) {
    setPrivilegeId(privilegeId);
    setOperation(operation);
    setResourceId(resourceId);
    setResourceType(resourceType);
  }
}
