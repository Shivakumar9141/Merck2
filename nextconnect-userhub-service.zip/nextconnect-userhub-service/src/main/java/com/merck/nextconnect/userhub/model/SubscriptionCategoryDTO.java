package com.merck.nextconnect.userhub.model;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SubscriptionCategoryDTO implements Serializable, Comparable<SubscriptionCategoryDTO> {

  private static final long serialVersionUID = 1L;
  private Long subscriptionCategoryId;
  private String categoryName;
  private boolean status;
  private List<String> emails;
  private int numberOfDaysAdvance;

  @Override
  public int compareTo(SubscriptionCategoryDTO o) {

    return this.subscriptionCategoryId.compareTo(o.subscriptionCategoryId);
  }

  @Override
  public String toString() {
    return "SubscriptionCategoryDTO [subscriptionCategoryId="
        + subscriptionCategoryId
        + ", categoryName="
        + categoryName
        + ", status="
        + status
        + ", emails="
        + emails
        + ", numberOfDaysAdvance="
        + numberOfDaysAdvance
        + "]";
  }
}
