package com.merck.nextconnect.userhub.model;

import com.merck.nextconnect.utils.common.entities.Region;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@lombok.Builder
@ToString
public class CountryDTO {

  private int countryId;
  private String countryCode;
  private String countryName;
  private Region region;
}
