package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.resources.ILanguage;
import com.merck.nextconnect.utils.common.entities.Language;
import com.merck.nextconnect.utils.common.repository.jpa.LanguageRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LanguageImpl implements ILanguage {

  @Autowired LanguageRepository languageRepo;

  @Override
  public List<Language> getAll() {
    return languageRepo.findAll();
  }
}
