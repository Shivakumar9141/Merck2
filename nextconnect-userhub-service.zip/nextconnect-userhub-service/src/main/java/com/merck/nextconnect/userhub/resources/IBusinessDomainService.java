package com.merck.nextconnect.userhub.resources;

import com.merck.nextconnect.userhub.exception.DataValidationException;
import com.merck.nextconnect.userhub.model.BusinessDomainDTO;
import java.util.List;

public interface IBusinessDomainService {

  /**
   * this method fetches all the business domains
   *
   * @param includeGeneric
   * @return List<BusinessDomainDTO>
   */
  List<BusinessDomainDTO> getAllBusinessDomain(Boolean includeGeneric)
      throws DataValidationException;
}
