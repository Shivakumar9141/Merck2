package com.merck.nextconnect.userhub.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@lombok.Builder
@ToString
public class CountryTimezoneDTO {

  private long id;
  private String timezoneName;
  private String timezoneDesc;
  private String timezoneAbbr;
  private int country;
}
