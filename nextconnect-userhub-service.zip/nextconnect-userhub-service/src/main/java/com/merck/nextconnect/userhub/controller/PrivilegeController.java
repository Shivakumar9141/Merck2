package com.merck.nextconnect.userhub.controller;

import com.merck.nextconnect.userhub.entities.Entities;
import com.merck.nextconnect.userhub.entities.Privilege;
import com.merck.nextconnect.userhub.log.AuditLogger;
import com.merck.nextconnect.userhub.log.AuditLoggerUtil;
import com.merck.nextconnect.userhub.model.privilege.PrivilegeInfo;
import com.merck.nextconnect.userhub.resources.Iprivileges;
import com.merck.nextconnect.userhub.util.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriTemplate;

@Component
@RestController
@RequestMapping("/api")
public class PrivilegeController {

  static final Logger logger = LoggerFactory.getLogger(PrivilegeController.class);

  @Autowired Iprivileges iprivileges;

  @Operation(
      summary = "Add privilege",
      tags = "Privileges",
      description = "This API is used to add new privileges")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.POST, value = "/privileges")
  public ResponseEntity<?> addPrivilege(
      @Parameter(
              name = "privilege",
              description = "privilege details",
              schema = @Schema(defaultValue = ""))
          @RequestBody
          PrivilegeInfo privilegeInfo) {
    long privilegeId = iprivileges.add(privilegeInfo);
    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(new UriTemplate("/privileges/{privilegeId}").expand(privilegeId));
    return new ResponseEntity<>(headers, HttpStatus.CREATED);
  }

  @Operation(description = "delete privilege", tags = "Privileges")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.DELETE, value = "/privileges/{id}")
  public ResponseEntity<?> deletePrivilege(
      @Parameter(
              name = "id",
              description = "id of the privilege",
              schema = @Schema(defaultValue = ""))
          @PathVariable(value = "id")
          long privilegeId) {
    iprivileges.delete(privilegeId);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Operation(description = "List all privileges", tags = "Privileges")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/privileges")
  public ResponseEntity<List<Privilege>> getPrivileges(
      @Parameter(
              name = "filterBy",
              description = "filter by privilege level",
              schema = @Schema(defaultValue = ""))
          @RequestParam(value = "filterBy", required = false)
          String filterBy) {
    List<Privilege> privileges = new ArrayList<Privilege>();
    privileges = iprivileges.getAll(filterBy);
    AuditLogger.getInstance()
        .auditLog(AuditLoggerUtil.formatLog(Constants.PRIVILEGE, Constants.GET, null));
    return new ResponseEntity<List<Privilege>>(privileges, HttpStatus.OK);
  }

  @Operation(description = "List all entities", tags = "Entities")
  @Parameter(
      name = "Authorization",
      description = "authorization header containing the bearer token",
      in = ParameterIn.HEADER)
  @RequestMapping(method = RequestMethod.GET, value = "/entities")
  public ResponseEntity<List<Entities>> getEntities() {
    List<Entities> entities = new ArrayList<Entities>();
    entities = iprivileges.getAllEntities();
    return new ResponseEntity<List<Entities>>(entities, HttpStatus.OK);
  }
}
