package com.merck.nextconnect.userhub.util;

import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.helper.UserHubServiceMaxHelper;
import com.merck.nextconnect.userhub.model.CoveredProductDTO;
import com.merck.nextconnect.userhub.model.DeviceDTO;
import com.merck.nextconnect.userhub.model.UserDataDTO;
import com.merck.nextconnect.userhub.model.privilege.ResourcePrivilege;
import com.merck.nextconnect.userhub.repo.jdbc.CoveredProductRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.DeviceRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.UserDevicePrivilegeRepositoryJdbc;
import com.merck.nextconnect.userhub.repo.jdbc.UserProfileRepositoryJdbc;
import com.merck.nextconnect.utils.email.entities.EmailAttribute;
import com.merck.nextconnect.utils.email.entities.EmailMessage;
import com.merck.nextconnect.utils.email.entities.EmailTemplate;
import com.merck.nextconnect.utils.email.resources.EmailService;
import com.merck.nextconnect.utils.email.resources.EmailTemplateService;
import com.merck.nextconnect.utils.exception.EmailException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * @author tah
 *     <p>Asynch service class for UserHUB Module
 */
@Service
public class UserHubAsyncService {

  private static final Logger logger = LoggerFactory.getLogger(UserHubAsyncService.class);

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Autowired private UserHubServiceMaxHelper userHubServiceMaxHelper;

  @Autowired UserDevicePrivilegeRepositoryJdbc userDevicePrivilegeRepositoryJdbc;

  @Autowired UserProfileRepositoryJdbc userProfileRepositoryJdbc;

  @Autowired CoveredProductRepositoryJdbc coveredProductRepositoryJdbc;

  @Autowired DeviceRepositoryJdbc deviceRepositoryJdbc;

  @Autowired private EmailTemplateService emailTemplateService;

  @Autowired private EmailService emailService;

  /**
   * This method updates the service max mymilliq activated check box when device is auto assigned
   * for the user
   *
   * @param userProfile
   * @param resourcePrivileges
   */
  @Async
  public void updateMymilliqActivtedCheckboxForDeviceAutoAssignment(Long deviceId) {
    logger.info("Async execution of updateMymilliqActivtedCheckboxFor Device AutoAssignment start");
    updateMymilliqActivatedCheckBoxIP(deviceId, true);
    updateMymilliqActivatedCheckBoxCP(deviceId, true);
    logger.info("Async execution of updateMymilliqActivtedCheckboxFor Device AutoAssignment End");
  }

  /**
   * This method updates the service max mymilliq activated check box when device is assigned
   * manually for the user
   *
   * @param userProfile
   * @param resourcePrivileges
   */
  @Async
  public void updateMymilliqActivtedCheckboxForDeviceAssignment(
      Optional<UserProfile> userProfile, List<ResourcePrivilege> resourcePrivileges) {
    logger.info("Async execution of updateMymilliqActivtedCheckboxFor Device Assignment start");

    boolean isUserOrgAutoCreated = userProfile.get().getOrg().isAutoCreated();
    logger.info(
        "userId : {} , userOrg: {} , isUserOrgAutoCreated : {}",
        userProfile.get().getUserId(),
        userProfile.get().getOrg().getName(),
        isUserOrgAutoCreated);

    if (isUserOrgAutoCreated) {
      for (ResourcePrivilege resource : resourcePrivileges) {
        updateMymilliqActivatedCheckBoxIP(resource.getResourceid(), true);
        updateMymilliqActivatedCheckBoxCP(resource.getResourceid(), true);
      }
    }
    logger.info("Async execution of updateMymilliqActivtedCheckboxFor Device Assignment End");
  }

  /**
   * This method updates the service max mymilliq activated check box when device is deassigned
   * manually for the user
   *
   * @param userProfile
   * @param resourcePrivileges
   */
  @Async
  public void updateMymilliqActivtedCheckboxForDeviceDeAssignment(
      Optional<UserProfile> userProfile, List<ResourcePrivilege> resourcePrivileges) {
    logger.info("Async execution of updateMymilliqActivtedCheckboxFor Device DeAssignment start");

    boolean isUserOrgAutoCreated = userProfile.get().getOrg().isAutoCreated();
    logger.info(
        "userId : {} , userOrg: {} , isUserOrgAutoCreated : {}",
        userProfile.get().getUserId(),
        userProfile.get().getOrg().getName(),
        isUserOrgAutoCreated);

    if (isUserOrgAutoCreated) {
      checkforLastUserOftheDevice(userProfile, resourcePrivileges);
    }

    logger.info("Async execution of updateMymilliqActivtedCheckboxFor Device DeAssignment End");
  }

  /**
   * send email for assigned/unassigned notification
   *
   * @param fromEmail
   * @param toEmails
   * @param subject
   */
  @Async
  public void sendEmailToUserForAssignedUnassignedSubscriptions(
      String fromEmail, String toEmail, String subject) {
    logger.info("--Async execution of sendEmailToUserForAssignedUnassignedSubscriptions() start--");
    logger.info("email subject -->{}, fromEmail--{}, toEmail-->{}", subject, fromEmail, toEmail);
    try {
      int languageId = emailTemplateService.findLanguageIdByEmail(toEmail);
      EmailTemplate emailTemplate = null;
      if (Constants.SUBJECT_ASSIGNED.equals(subject)) {

        emailTemplate =
            emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
                Constants.RECIPIENTS_ASSIGNED_NOTIFICATION_FSE_CUSTOMER_DISTRIBUTOR,
                languageId,
                Constants.ACTIVE);
      } else if (Constants.SUBJECT_UNASSIGNED.equals(subject)) {
        emailTemplate =
            emailTemplateService.findByTemplateNameAndLanguageIdAndStatus(
                Constants.RECIPIENTS_UNASSIGNED_NOTIFICATION_FSE_CUSTOMER_DISTRIBUTOR,
                languageId,
                Constants.ACTIVE);
      }
      EmailMessage emailMessageCustomer = new EmailMessage();
      emailMessageCustomer.setEmailTemplate(emailTemplate);

      try {
        emailMessageCustomer.setEmailFrom(fromEmail);
        emailMessageCustomer.setEmailTo(toEmail);
        emailMessageCustomer.setSubject(subject);
        emailMessageCustomer.setStatus(Constants.EMAIL_SUCCESS_STATUS);
        emailMessageCustomer.setCreatedBy(fromEmail);
        emailMessageCustomer.setCreatedTimestamp(Timestamp.from(Instant.now()));
        emailMessageCustomer.setLastUpdatedBy(fromEmail);
        emailMessageCustomer.setLastUpdatedTimestamp(Timestamp.from(Instant.now()));
        emailMessageCustomer.setCharset(Constants.EMAIL_CHAR_SET);
        emailMessageCustomer.setContentType(Constants.EMAIL_CONTENT_TYPE);

        Set<EmailAttribute> emailAttributeSet = new HashSet<EmailAttribute>();

        EmailAttribute emailAttribute = new EmailAttribute();
        emailAttribute = new EmailAttribute();
        emailAttribute.setAttributeName("name_of_the_user");
        emailAttribute.setAttributeValue(toEmail);
        emailAttribute.setEmailMessage(emailMessageCustomer);
        emailAttributeSet.add(emailAttribute);

        EmailAttribute emailAttribute2 = new EmailAttribute();
        emailAttribute2 = new EmailAttribute();
        emailAttribute2.setAttributeName("name_of_the_user_creating_the_notification");
        emailAttribute2.setAttributeValue(fromEmail);
        emailAttribute2.setEmailMessage(emailMessageCustomer);
        emailAttributeSet.add(emailAttribute2);

        emailMessageCustomer.setEmailAttributes(emailAttributeSet);

        emailService.sendMail(emailMessageCustomer, environment);
        logger.info(
            "Sending Email for recipient, when assigned/unassigned against notification preference. "
                + "Email from: "
                + fromEmail
                + ", Email To:"
                + toEmail);
      } catch (EmailException e) {
        logger.error(
            "error in Sending Email for recipient. Email from: "
                + fromEmail
                + ", Email To:"
                + toEmail);
      }
    } catch (Exception ex) {
      logger.error("Exception occured while sending email." + ex);
    }
    logger.info("--Async execution of sendEmailToUserForAssignedUnassignedSubscriptions() End--");
  }

  /**
   * Check for last user of the device and updates mymilliq activated check box as false
   *
   * @param userProfile
   * @param resourcePrivileges
   * @throws CustomException
   */
  private void checkforLastUserOftheDevice(
      Optional<UserProfile> userProfile, List<ResourcePrivilege> resourcePrivileges) {

    for (ResourcePrivilege resource : resourcePrivileges) {
      try {
        logger.info(
            "checkforLastUserOftheDevice -> userId : {} , deviceId : {} ",
            userProfile.get().getUserId(),
            resource.getResourceid());

        List<Long> userIdList =
            userDevicePrivilegeRepositoryJdbc.getAllUserIdForDeviceId(resource.getResourceid());
        List<UserDataDTO> userDataDTOList = userProfileRepositoryJdbc.getUserOrgDetails(userIdList);

        if (userDataDTOList.isEmpty()) {
          logger.debug(
              "device : {}  is no more assinged to any of the user", resource.getResourceid());

          updateMymilliqActivatedCheckBoxIP(resource.getResourceid(), false);
          updateMymilliqActivatedCheckBoxCP(resource.getResourceid(), false);

        } else {
          logger.info("device : {} is still assigned for other users ", resource.getResourceid());
          for (UserDataDTO userDataDTO : userDataDTOList) {
            logger.info(
                "userId : {} orgId : {}, UserOrgCreatedVia :{} ",
                userDataDTO.getUserId(),
                userDataDTO.getOrgId(),
                userDataDTO.getUserOrgCreatedVia());
          }
        }
      } catch (Exception e) {
        logger.error("Exception occured in checkforLastUserOftheDevice method", e);
      }
    }
  }

  private void updateMymilliqActivatedCheckBoxIP(long deviceId, boolean isMymilliqActivated) {
    List<DeviceDTO> deviceDTOList = deviceRepositoryJdbc.findSmDeviceIdByDeviceId(deviceId);
    for (DeviceDTO deviceDTO : deviceDTOList) {
      if (StringUtils.isNotBlank(deviceDTO.getSmDeviceId())) {
        userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxIP(
            deviceDTO.getSmDeviceId(), isMymilliqActivated);
      }
    }
  }

  private void updateMymilliqActivatedCheckBoxCP(long deviceId, boolean isMymilliqActivated) {
    List<CoveredProductDTO> smCoveredProductIdList =
        coveredProductRepositoryJdbc.getSmCoveredProductId(deviceId);
    for (CoveredProductDTO coveredProductDTO : smCoveredProductIdList) {
      if (StringUtils.isNotBlank(coveredProductDTO.getSmCoveredProductId())) {
        userHubServiceMaxHelper.updateMymilliqActivatedCheckBoxCP(
            coveredProductDTO.getSmCoveredProductId(), isMymilliqActivated);
      }
    }
  }
}
