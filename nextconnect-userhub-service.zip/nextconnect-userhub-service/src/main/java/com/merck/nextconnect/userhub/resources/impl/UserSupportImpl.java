package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.authfilter.model.AuthenticatedUser;
import com.merck.nextconnect.authfilter.model.OrgPrivileges;
import com.merck.nextconnect.authfilter.repository.jpa.AuthUserDevicePrivilegeRepository;
import com.merck.nextconnect.authfilter.repository.jpa.UserAccessTokenRepository;
import com.merck.nextconnect.authfilter.repository.jpa.UserTerritoryRepository;
import com.merck.nextconnect.authfilter.resources.IOrgPermissions;
import com.merck.nextconnect.authfilter.resources.IprivilegeProvider;
import com.merck.nextconnect.authfilter.util.JwtTokenGenerator;
import com.merck.nextconnect.userhub.entities.Role;
import com.merck.nextconnect.userhub.entities.UserProfile;
import com.merck.nextconnect.userhub.exception.AccessDeniedException;
import com.merck.nextconnect.userhub.exception.CustomException;
import com.merck.nextconnect.userhub.exception.DuplicateResourceException;
import com.merck.nextconnect.userhub.mail.IMailService;
import com.merck.nextconnect.userhub.model.user.UserDetails;
import com.merck.nextconnect.userhub.model.user.UserStatus;
import com.merck.nextconnect.userhub.repo.jdbc.GenericJdbc;
import com.merck.nextconnect.userhub.repository.jpa.DateFormatRepository;
import com.merck.nextconnect.userhub.repository.jpa.OrgDomainRepositiory;
import com.merck.nextconnect.userhub.repository.jpa.OrganizationRepository;
import com.merck.nextconnect.userhub.repository.jpa.RoleRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserCredentialsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserDomainRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserProfileSettingsRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserRepository;
import com.merck.nextconnect.userhub.repository.jpa.UserSpecification;
import com.merck.nextconnect.userhub.resources.IAuthentication;
import com.merck.nextconnect.userhub.resources.IUserSupport;
import com.merck.nextconnect.userhub.util.Constants;
import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import com.merck.nextconnect.userhub.util.UserHubAsyncService;
import com.merck.nextconnect.userhub.util.UserhubUtils;
import com.merck.nextconnect.utils.common.dto.UserInvitedVia;
import com.merck.nextconnect.utils.common.entities.CountryLanguage;
import com.merck.nextconnect.utils.common.entities.UserDomain;
import com.merck.nextconnect.utils.common.repository.jpa.CountryLanguageRepository;
import com.merck.nextconnect.utils.common.repository.jpa.CountryRepository;
import com.merck.nextconnect.utils.common.repository.jpa.LanguageRepository;
import com.merck.nextconnect.utils.file.handler.exception.DataValidationException;
import com.merck.nextconnect.utils.validator.PhoneNumberValidator;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.security.Keys;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;
import javax.crypto.SecretKey;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class UserSupportImpl implements IUserSupport {

  static final Logger logger = LoggerFactory.getLogger(UserSupportImpl.class);

  @Autowired UserRepository userRepo;

  @Autowired RoleRepository roleRepo;

  @Autowired UserProfileSettingsRepository userProfileSettingsRepository;

  @Autowired UserCredentialsRepository userCredentialsRepo;

  @Autowired UserDomainRepository userDomainRepo;

  @Autowired JwtTokenGenerator jwtTokenGenerator;

  @Autowired UserRolePrivileges userRolePrivileges;

  @Autowired UserAccessTokenRepository userAccessTokenRepo;

  @Autowired private IMailService mailService;

  @Autowired UserSpecification userSpecification;

  @Autowired DateFormatRepository dateFormatRepo;

  @Autowired LanguageRepository languageRepo;

  @Autowired OrganizationRepository orgRepo;

  @Autowired IOrgPermissions orgPermissions;

  @Autowired IAuthentication authentication;

  @Autowired OrgDomainRepositiory orgDomainRepo;

  @Autowired UserOrgPrivileges userOrgPrivileges;

  @Value("${nextconnect.email.fromemail}")
  private String fromEmail;

  @Value("${user.password_pattern}")
  private String passwordPattern;

  @Value("${nextconnect.email.environment}")
  private String environment;

  @Value("${nextconnect.usermgmtsearch.url}")
  private String userMgmtURL;

  @Autowired private PhoneNumberValidator phoneNumberValidator;

  @Autowired IprivilegeProvider privilegeProvider;

  @Autowired private CountryRepository countryRepository;

  @Autowired CountryLanguageRepository countryLanguageRepository;

  @Value("${nextconnect.subscription.numberofdaysadvance}")
  private int numberOfDaysAdvance;

  @Autowired UserHubAsyncService userHubAsyncService;

  @Autowired UserTerritoryRepository userTerritoryRepo;

  @Autowired AuthUserDevicePrivilegeRepository userDevicePrivilegeRepo;

  @Autowired GenericJdbc genericJdbc;

  @Value("${nextconnect.sms.url}")
  private String smsHost;

  @Value("${nextconnect.sms.username}")
  private String smsUsername;

  @Value("${nextconnect.sms.password}")
  private String smsPassword;

  /**
   * add a user
   *
   * @param userDetails - userDetails
   * @return UserProfile
   * @throws DuplicateResourceException
   * @throws DataValidationException
   * @throws MessagingException
   * @throws com.merck.nextconnect.utils.file.handler.exception.DataValidationException
   * @throws com.merck.nextconnect.userhub.exception.AccessDeniedException
   * @throws com.merck.nextconnect.userhub.exception.DataValidationException
   * @throws
   */
  public UserProfile add(UserDetails userDetails)
      throws DuplicateResourceException,
          DataValidationException,
          MessagingException,
          DataValidationException,
          AccessDeniedException,
          com.merck.nextconnect.userhub.exception.DataValidationException {

    logger.info("userDetails::" + userDetails);
    // validate the user's phone number
    phoneNumberValidator.validatePhoneNumberFormat(
        userDetails.getIsdCode(), userDetails.getPhone());

    /*Made changes as per NCIOT-12313.*/
    AuthenticatedUser authUser =
        UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
            ? null
            : UserhubUtils.getAuthenticatedUser();
    if (userRepo.getUserByEmail(userDetails.getEmail()) != null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.USER_EMAIL_CONFLICT, Arrays.asList(userDetails.getEmail()));
    }
    String loginName = userDetails.getLoginText();
    // NCIOT-13711
    if (StringUtils.isBlank(loginName)) {
      new com.merck.nextconnect.userhub.exception.DataValidationException(
          CustomErrorCodes.USER_NAME_INVALID);
    }

    UserDomain userDomain = userDomainRepo.findById(userDetails.getDomainId()).get();
    Optional.ofNullable(userDomain)
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.DataValidationException(
                    CustomErrorCodes.INVALID_DOMAIN));
    /*Made changes as per NCIOT-12313.*/
    if (!UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
        && userRepo.getUser(loginName, userDomain.getAuthenticationProvider(), authUser.getOrgId())
            != null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.USER_LOGIN_NAME_CONFLICT, Arrays.asList(loginName));
    }
    UserProfile user =
        new UserProfile(
            loginName,
            userDetails.getFirstName(),
            userDetails.getLastName(),
            userDetails.getEmail(),
            userDetails.getIsdCode(),
            userDetails.getPhone());
    long roleId = userDetails.getRoleId();
    Role role;
    if (userDetails.getOrgId() != 0) {
      /*Made changes as per NCIOT-12313.*/
      if (!UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
        Optional.ofNullable(userDetails)
            .filter(
                uD -> orgPermissions.hasRoleAccess(uD.getOrgId(), OrgPrivileges.manage_accounts))
            .orElseThrow(
                () -> new AccessDeniedException("User doesnt have access to the given org"));
      }
      user.setOrg(orgRepo.findById(userDetails.getOrgId()).get());
      role = roleRepo.getRoleByOrg(roleId, userDetails.getOrgId());
    } else {
      user.setOrg(orgRepo.findById(authUser.getOrgId()).get());
      role = roleRepo.getRoleByOrg(roleId, authUser.getOrgId());
    }
    // NCIOT-11199
    Optional.of(user)
        .filter(u -> u.getOrg().getStatus().equals(true))
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.AccessDeniedException(
                    CustomErrorCodes.ACCESS_DENIED_SELECTED_ORG_DEACTIVATED));

    Optional.ofNullable(role)
        .orElseThrow(
            () ->
                new com.merck.nextconnect.userhub.exception.DataValidationException(
                    CustomErrorCodes.INVALID_ROLE_SPECIFIED));
    /*Made changes as per NCIOT-12313.*/
    if (!UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      Optional.ofNullable(userDetails)
          .filter(u -> u.getOrgId() == authUser.getOrgId())
          .ifPresent(
              u -> {
                validateActionForSystemDefinedRole(
                    authUser.getRoleId(), authUser.isSystemDefinedRole(), role);
              });
    }
    user.setRole(role);
    user.setUserDomain(userDomain);
    user.setStatus(UserStatus.PENDING.value());
    user.setDateFormat(dateFormatRepo.findById(Constants.DEFAULT_DATE_FORMAT).get());
    setLanguage(authUser, userDetails, user);
    /*Made changes as per NCIOT-12313.*/
    user.setCreatedRole(
        UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
            ? null
            : authUser.getRoleId());
    /*Made changes as per NCIOT-12313.*/
    user.setCreatedBy(
        UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())
            ? "Self Registered"
            : authUser.getUsername());
    user.setCreatedOn(Timestamp.from(Instant.now()));
    user.setInvitedOrActivatedTs(Timestamp.from(Instant.now()));
    user.setAutoCreated(userDetails.isAutoCreated());
    user.setInvitedVia(
        StringUtils.isNotBlank(userDetails.getInvitedVia())
            ? userDetails.getInvitedVia()
            : Constants.MANUAL);
    if (UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      user.setCountry(countryRepository.findById(userDetails.getCountryId()));
    } else if (UserInvitedVia.INSTALLED_PRODUCT
            .value()
            .equalsIgnoreCase(userDetails.getInvitedVia())
        || UserInvitedVia.SERVIE_CONTRACT.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      user.setCountry(countryRepository.findByCountryCode(userDetails.getCountryCode()));
    }
    UserProfile userProfile = null; // NCIOT-16020
    synchronized (user) {
      logger.info("inside synchronized user::" + user);
      if (userRepo.getUserByEmail(userDetails.getEmail()) == null)
        logger.info("inside if userDetails.getEmail() null");
      userProfile = userRepo.save(user);
      logger.info("after save::" + userProfile);
    }
    if (userProfile == null) {
      throw new DuplicateResourceException(
          CustomErrorCodes.USER_EMAIL_CONFLICT, Arrays.asList(userDetails.getEmail()));
    }
    try {
      sendEmail(userProfile, Constants.INVITE_USER);
    } catch (Exception e) {
      userAccessTokenRepo.deleteByUser(userProfile.getUserId());
      userRepo.deleteById(userProfile.getUserId());
      throw new com.merck.nextconnect.userhub.exception.DataValidationException(
          CustomErrorCodes.EMAIL_SENDING_ERROR);
    }
    return userProfile;
  }

  /**
   * validates operations for users with system defined roles
   *
   * @param authRoleId - logged in user role id
   * @param authSystemDefinedRole - boolean
   * @param userRole - role
   */
  private void validateActionForSystemDefinedRole(
      long authRoleId, boolean authSystemDefinedRole, Role userRole) {
    Optional.ofNullable(userRole)
        .filter(r -> r.isSystemDefined())
        .ifPresent(
            r -> {
              Optional.ofNullable(authSystemDefinedRole)
                  .filter(s -> s.booleanValue())
                  .orElseThrow(
                      () ->
                          new org.springframework.security.access.AccessDeniedException(
                              "unauthorized to perform this operation"));
              Optional.ofNullable(authSystemDefinedRole)
                  .filter(s -> s.booleanValue())
                  .ifPresent(
                      s -> {
                        Optional.ofNullable(authRoleId)
                            .filter(a -> a == r.getRoleId())
                            .orElseThrow(
                                () ->
                                    new org.springframework.security.access.AccessDeniedException(
                                        "unauthorized to operate on this user"));
                      });
            });
  }

  /**
   * Sets the language of based on country
   *
   * @param authUser
   * @param userDetails
   * @param user
   */
  private void setLanguage(AuthenticatedUser authUser, UserDetails userDetails, UserProfile user) {

    UserProfile authUserProfile = null;
    if (authUser != null) {
      authUserProfile = userRepo.getUserById(Long.valueOf(authUser.getId()));
    }
    logger.info(
        "invitedVia : {} , countryCode : {} , authUserOrgType : {} ",
        userDetails.getInvitedVia(),
        userDetails.getCountryCode(),
        (authUserProfile != null) ? authUserProfile.getOrg().getType() : "NA");

    if (UserInvitedVia.INSTALLED_PRODUCT.value().equalsIgnoreCase(userDetails.getInvitedVia())
        || UserInvitedVia.SERVIE_CONTRACT.value().equalsIgnoreCase(userDetails.getInvitedVia())
        || UserInvitedVia.SELF_REGISTRATION.value().equalsIgnoreCase(userDetails.getInvitedVia())) {
      if (StringUtils.isNotBlank(userDetails.getCountryCode())) {
        CountryLanguage countryLanguage =
            countryLanguageRepository.findByCountryCountryCode(userDetails.getCountryCode());
        user.setLanguage(countryLanguage.getLanguage());
      } else {
        user.setLanguage(languageRepo.findById(Constants.DEFAULT_LANGUAGE));
      }
    } else if (Constants.ORG_TYPE_CUSTOMER.equalsIgnoreCase(authUserProfile.getOrg().getType())
        || Constants.ORG_TYPE_PARTNER.equalsIgnoreCase(authUserProfile.getOrg().getType())) {
      CountryLanguage countryLanguage =
          countryLanguageRepository.findByCountryCountryCode(
              authUserProfile.getCountry().getCountryCode());
      user.setLanguage(countryLanguage.getLanguage());
    } else if (Constants.ORG_TYPE_DISTRIBUTOR.equalsIgnoreCase(authUserProfile.getOrg().getType())
        || Constants.ORG_TYPE_BUSINESS_UNIT.equalsIgnoreCase(authUserProfile.getOrg().getType())) {
      user.setLanguage(languageRepo.findById(Constants.DEFAULT_LANGUAGE));
    }
  }

  /**
   * sending mail to user
   *
   * @param userProfile - user profile
   * @param action - action (invite user , password update)
   * @throws MessagingException
   * @throws AddressException
   * @throws CustomException
   */
  private void sendEmail(UserProfile userProfile, String action)
      throws AddressException, MessagingException, CustomException {
    String jti = generateToken(userProfile.getUserId());
    logger.info("Sending email to {}", userProfile.getEmail());
    mailService.send(userProfile, action, jti, environment);
    logger.info("Sent email successfully to {}", userProfile.getEmail());
  }

  /**
   * generate token for password update
   *
   * @param email - id of the user
   * @return token - password update token
   */
  public String generateToken(long userId) {
    logger.info("inside generateToken userId::" + userId);
    String jti = UUID.randomUUID().toString();
    SecureRandom random = new SecureRandom();
    byte[] bytes = new byte[64];
    random.nextBytes(bytes);
    SecretKey secretKey = Keys.hmacShaKeyFor(bytes);
    jwtTokenGenerator.generateAndPersistTokenForPassword(
        Encoders.BASE64.encode(secretKey.getEncoded()), jti, userId);
    logger.info("inside generateToken::" + jti);
    return jti;
  }
}
