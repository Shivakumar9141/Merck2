package com.merck.nextconnect.userhub.exception;

import com.merck.nextconnect.userhub.util.CustomErrorCodes;
import java.util.List;

public class DataValidationException extends CustomException {

  private static final long serialVersionUID = 1L;

  public DataValidationException(String msg) {
    super(msg);
  }

  public DataValidationException(CustomErrorCodes customErrorCodes) {
    super(customErrorCodes);
  }

  public DataValidationException(CustomErrorCodes customErrorCodes, List<String> params) {
    super(customErrorCodes, params);
  }
}
