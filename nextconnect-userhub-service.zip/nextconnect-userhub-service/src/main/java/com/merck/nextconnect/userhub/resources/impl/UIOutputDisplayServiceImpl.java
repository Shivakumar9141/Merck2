package com.merck.nextconnect.userhub.resources.impl;

import com.merck.nextconnect.userhub.entities.UIOutputDisplay;
import com.merck.nextconnect.userhub.repository.jpa.UIOutputDisplayRepository;
import com.merck.nextconnect.userhub.resources.IUIOutputDisplay;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UIOutputDisplayServiceImpl implements IUIOutputDisplay {

  @Autowired UIOutputDisplayRepository outputDisplayRepository;

  @Override
  public List<UIOutputDisplay> getAll() {
    return outputDisplayRepository.findAll();
  }
}
