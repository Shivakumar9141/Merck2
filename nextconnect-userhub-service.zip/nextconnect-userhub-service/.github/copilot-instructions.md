# Copilot Instructions for NextConnect MyMilliQ UserHub Service

## Project Overview

This repository contains the **NextConnect UserHub Service**, a Spring Boot microservice that handles user management, authentication, authorization, and privilege management for the NextConnect platform by Merck.

### Key Features
- User registration, authentication, and management
- Role-based access control (RBAC) and privilege management
- Organization and business domain management
- LDAP integration for enterprise user authentication
- SAML-based single sign-on support
- Email notifications and user invitation workflows
- Integration with ServiceMax
- Hazelcast-based distributed caching
- JWT token-based authentication

## Technology Stack

- **Java 21** - Primary programming language
- **Spring Boot 4.0.0** - Application framework
- **Maven 3.5.0** - Build and dependency management
- **JPA/Hibernate** - Object-relational mapping
- **Hazelcast** - Distributed caching
- **OpenAPI/Swagger** - API documentation
- **JUnit** - Testing framework
- **Docker** - Containerization
- **AWS EKS** - Kubernetes deployment

## Project Structure

```
src/
├── main/
│   ├── java/com/merck/nextconnect/userhub/
│   │   ├── UserHubApplication.java    # Main Spring Boot application
│   │   ├── authentication/            # Authentication implementations
│   │   ├── cache/                      # Cache management (Hazelcast)
│   │   ├── config/                     # Spring configuration classes
│   │   ├── constants/                  # Application constants
│   │   ├── controller/                 # REST API controllers
│   │   ├── converter/                  # Data type converters
│   │   ├── entities/                   # JPA entity classes
│   │   ├── exception/                  # Custom exception classes
│   │   ├── handler/                    # Exception handlers
│   │   ├── helper/                     # Helper/utility classes
│   │   ├── log/                        # Audit logging
│   │   ├── mail/                       # Email service
│   │   ├── model/                      # DTOs and data models
│   │   ├── repo/                       # JDBC repositories
│   │   ├── repository/                 # JPA, LDAP, and Hazelcast repositories
│   │   ├── resources/                  # Resource interfaces
│   │   ├── response/                   # API response entities
│   │   ├── service/                    # Business logic services
│   │   ├── util/                       # Utility classes
│   │   ├── validations/                # Input validation
│   │   └── validator/                  # Custom validators
│   └── resources/
│       ├── application.properties      # Default configuration
│       └── application-{env}.properties # Environment-specific configs
└── test/
    └── java/                           # Unit and integration tests
```

## Coding Conventions

### Code Style
- Follow **Google Java Style Guide** (configured via `.checkstyle`)
- Use meaningful variable and method names
- Add Javadoc comments for public methods and classes
- Keep methods focused and small (single responsibility)

### Naming Conventions
- Classes: PascalCase (e.g., `UserController`, `UserProfileDTO`)
- Methods: camelCase (e.g., `getAllUsers`, `fetchOneUser`)
- Constants: UPPER_SNAKE_CASE (e.g., `MAX_TOTAL_CONNECTIONS`)
- Packages: lowercase (e.g., `com.merck.nextconnect.userhub`)

### Controller Guidelines
- Use `@RestController` annotation for REST APIs
- Apply `@RequestMapping` at class level for base path
- Use specific HTTP method annotations (`@GetMapping`, `@PostMapping`, etc.)
- Include OpenAPI `@Operation` and `@Parameter` annotations for documentation
- Apply `@PreAuthorize` for authorization checks
- Use `ResponseEntity<T>` for response wrapping

### Service Layer
- Create interfaces for services (e.g., `IUser` interface for user operations)
- Implement business logic in service classes
- Use `@Autowired` for dependency injection
- Handle transactions appropriately

### Repository Layer
- Use Spring Data JPA for database operations
- Separate JPA, JDBC, LDAP, and Hazelcast repositories
- Follow naming conventions for query methods

### Exception Handling
- Use custom exceptions (e.g., `CustomException`, `DataValidationException`)
- Return appropriate HTTP status codes
- Log exceptions with context information

### Logging
- Use SLF4J with Logback for logging
- Use audit logging (`AuditLogger`) for security-relevant operations
- Log at appropriate levels (INFO for normal operations, ERROR for exceptions)

## API Design

### REST Endpoints
- Base path: `/nextconnect/userhub/api`
- Use plural nouns for resources (e.g., `/users`, `/roles`, `/organizations`)
- Support pagination with `page` and `pageLimit` parameters
- Support sorting with `sortBy` and `orderBy` parameters
- Support filtering with `filterBy` parameter
- Return custom headers for pagination metadata (`x-pagination-count`, `x-record-count`)

### Authentication
- All API endpoints require JWT bearer token authentication
- Use `Authorization: Bearer <token>` header
- Token validation handled by `nextconnect-authfilter`

### Authorization
- Use Spring Security with `@PreAuthorize` annotations
- Define privileges in `EntityPrivileges` class (e.g., `READ_USER`, `CREATE_USER`)
- Support role-based and privilege-based access control

## Testing Guidelines

### Test Structure
- Unit tests in `src/test/java`
- Use JUnit 5 for testing
- Create base test classes for common setup (e.g., `UserhubBaseTest`)
- Mock external dependencies using Mockito

### Test Naming
- Test classes: `{ClassName}Test.java`
- Test methods: descriptive names indicating what is being tested

## Build and Run

### Local Development
```bash
# Build the project
mvn clean install

# Run locally
mvn spring-boot:run -Dspring-boot.run.profiles=local

# Run tests
mvn test

# Run with coverage
mvn verify
```

### Docker Build
The application is containerized using a multi-stage Dockerfile that:
1. Downloads the JAR from JFrog Artifactory
2. Creates a minimal runtime image using Eclipse Temurin JRE 21

### Environment Profiles
- `local` - Local development
- `dev` - Development environment
- `qa` - QA testing
- `int` - Integration testing
- `stg` - Staging
- `pstg` - Pre-staging
- `prod` - Production

## Dependencies

### Internal Dependencies
- `nextconnect-base-service` - Parent POM with common configurations
- `nextconnect-authfilter` - JWT authentication filter
- `nextconnect-utils` - Common utilities

### External Dependencies
- Spring Boot Starter Web
- Spring Boot Starter Data JPA
- spring-security-saml2-core (org.springframework.security.extensions)
- Hazelcast for distributed caching
- Apache HttpClient 5

## Configuration

### Key Configuration Properties
- `server.port` - Application port (default: 9000)
- `server.servlet.context-path` - Context path (`/nextconnect/userhub`)
- `ldap.*` - LDAP connection settings
- `cache.*` - Hazelcast cache settings
- `jwt.*` - JWT token configuration
- `servicemax.*` - ServiceMax integration settings

## Security Considerations

- All sensitive data should use environment variables or secure vaults
- Never commit secrets or passwords to the repository
- Use parameterized queries to prevent SQL injection
- Validate and sanitize all user inputs
- Apply appropriate CORS settings for cross-origin requests

## CI/CD Workflows

- `pr-quality-checks.yml` - Code quality analysis for pull requests
- `formatting.yml` - Code formatting and style checks
- `build-only.yml` - Build pipeline
- `deploy-only.yml` - Deployment pipeline
- `manual-deploy.yml` - Manual deployment trigger
- `merge-flow.yml` - Main branch merge workflow
- `dependency-submission.yml` - Dependency tracking

## Common Patterns

### Creating a New Endpoint
1. Add method to the relevant controller
2. Annotate with OpenAPI documentation
3. Apply appropriate authorization
4. Create/update DTOs if needed
5. Implement business logic in service layer
6. Add audit logging
7. Write unit tests

### Adding a New Entity
1. Create entity class in `entities` package
2. Create repository interface in `repository` package
3. Create DTO in `model` package
4. Create service interface and implementation
5. Add controller endpoints
6. Write unit and integration tests

## Troubleshooting

### Common Issues
- Connection timeouts: Check network settings and increase timeout values
- Cache issues: Verify Hazelcast cluster configuration
- Authentication failures: Validate JWT token and check expiration
- LDAP errors: Verify LDAP connection settings and credentials
